package com.citi.risk.core.application.api;

public class IntegrationTabMenuItem {
	private String appName;
	private String perspectiveName;
	private String viewClassString;
	private String itemName;

	public IntegrationTabMenuItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getPerspectiveName() {
		return perspectiveName;
	}

	public void setPerspectiveName(String perspectiveName) {
		this.perspectiveName = perspectiveName;
	}

	public String getViewClassString() {
		return viewClassString;
	}

	public void setViewClassString(String viewClassString) {
		this.viewClassString = viewClassString;
	}

	public IntegrationTabMenuItem(String appName, String perspectiveName, String viewClassString, String itemName) {
		this.appName = appName;
		this.perspectiveName = perspectiveName;
		this.viewClassString = viewClassString;
		this.itemName = itemName;
	}
}
