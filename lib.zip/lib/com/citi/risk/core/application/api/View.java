package com.citi.risk.core.application.api;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.bean.CriterionBean;
import com.citi.risk.core.application.impl.CriteriaWrapper;
import com.citi.risk.core.application.impl.DefaultFilter;
import com.citi.risk.core.application.impl.DefaultView;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.collection.Pair;
import com.citi.risk.core.lang.table.SimpleTable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@JsonTypeInfo(use = Id.CLASS, defaultImpl = DefaultView.class)
public interface View extends Serializable, Cloneable, ViewComponent, Container<TableBasedElement>, HasRoot<Perspective>{

	String TOOLKIT_VIEW_TYPE = "toolkit";

	void setLoadAllWithNonCriteria();

	void updateViewWithNewDomain(String domainName);

	@JsonIgnore
	Navigation getNavigation(String itemName);

	List<Navigation> getMenuList();
	void setMenuList(List<Navigation> menuList);

	@JsonIgnore
	Dictionary getDictionary();
	void setDictionary(Dictionary dictionary);

	void setCriteria(List<CriterionBean> criterionList);

	@JsonIgnore
	Criteria getCriteria();
	void setCriteria(Criteria criteria);

	@JsonIgnore
	List<CriterionBean> getCriteriaDetail();

	void setDefaultCriteria();

	@JsonIgnore
	CriteriaWrapper getNavigationContextCriteriaWrapper();
	void setNavigationContextCriteriaWrapper(CriteriaWrapper viewCriteriaWrapper);

	@JsonIgnore
	CriteriaWrapper getGlobalCriteriaWrapper();
	void setGlobalCriteriaWrapper(CriteriaWrapper globalCriteriaWrapper);

	/**
	 * @deprecated
	 */
	@Deprecated
	@JsonIgnore
	Map<String, DataDomain> getAvailableDomainMap();

	/**
	 * @deprecated
	 */
	@Deprecated
	@JsonIgnore
	Map<String, TimeMark> getAvailableDailyBusinessDays(TimeMark currentTimeMark);

	/**
	 * @deprecated
	 */
	@Deprecated
	@JsonIgnore
	Map<String, TimeMark> getAvailableMonthlyBusinessDays(
			TimeMark currentTimeMark);

	@JsonIgnore
	SearchElement getSearchElement();

	FormBasedElement getFormBasedElement();
	void setFormBasedElement(FormBasedElement formBasedElement);

	GraphBasedElement getGraphBasedElement();
	void setGraphBasedElement(GraphBasedElement graphBasedElement);

	List<TableBasedElement> getTableBasedElementList();
	void setTableBasedElementList(List<TableBasedElement> tableBasedElementList);

	void addTableElement(TableBasedElement tableBasedElement);

	List<Pair<List<ColumnHeader>, SimpleTable>> loadAllTableBasedElements();

	@JsonIgnore
	Perspective getPerspective();
	void setPerspective(Perspective perspective);

	Boolean getSelected();
	void setSelected(Boolean selected);

	String getName();
	void setName(String name);

	String getViewType();
	void setViewType(String viewType);

	@JsonIgnore
	Boolean isToolkitView();

	String getDomainName();
	void setDomainName(String domainName);

	String getUiPath();
	void setUiPath(String uipath);

	Boolean getHidden();
	void setHidden(Boolean hidden);

	Boolean isShared();
	void setShared(Boolean hidden);

	/**
	 * @deprecated
	 */
	@Deprecated
	String getTemplateName();

	/**
	 * @deprecated
	 */
	@Deprecated
	void setTemplateName(String templateName);

	Integer getId();
	void setId(Integer id);

	Integer getSourceId();
	void setSourceId(Integer sourceId);

	@JsonIgnore
	ViewContext getViewContext();
	void setViewContext(ViewContext viewContext);

	Integer getDisplayIndex();
	void setDisplayIndex(Integer displayIndex);

	@JsonIgnore
	List<DefaultFilter> getDefaultFilterList();
	void setDefaultFilterList(List<DefaultFilter> defaultFilterList);

	Object clone() throws CloneNotSupportedException;

	/**
	 * @deprecated
	 */
	@Deprecated
	View copy(Perspective p);

	/**
	 * @deprecated
	 */
	@Deprecated
	Map<String, TimeMark> getAllBussinessDays(TimeMark basetimemark);

	/**
	 * @deprecated
	 */
	@Deprecated
	DateTime minusTimeToDateTimeByDay(TimeMark origianlTimeMark, int minusValue);

	/**
	 * @deprecated
	 */
	@Deprecated
	DateTime minusTimeToDateTimeByMonth(TimeMark origianlTimeMark,
			int minusValue);

	@JsonIgnore
	Map<String, TimeMark> getAvailableDataKeys();

	String getViewClass();
	void setViewClass(String viewClassString);
}