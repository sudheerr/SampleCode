package com.citi.risk.core.application.api;

import java.io.File;
import java.util.List;

import com.citi.risk.core.application.impl.CriteriaWrapper;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.SimpleTable;

public interface NavigationParameter {
	
	String getOperationName();

	void setOperationName(String operationName);
	
	void setSimpleTable(SimpleTable simpleTable);

	SimpleTable getSimpleTable();

	String getDumpLocation();

	void setDumpLocation(String dumpLocation);

	String getLoaderClassName();

	void setLoaderClassName(String loaderClassName);

	TimeMark getTimeMark();

	/**
	 * @deprecated
	 */
	@Deprecated
	void setTimeMark(String timeMarkStr, String batchFrequencyStr);

	CreatedBy getCreateBy();

	void setCreateBy(String versionNumber, String module, String process);

	void setFileList(List<File> files);

	List<File> getFileList();

	void setTargetView(View view);

	View getTargetView();

	void setCriteria(Criteria criteria);

	Criteria getCriteria();
	
	void setFurtherCriteria(Criteria criteria);
	
	Criteria getFurtherCriteria();
	
	List<Criteria> getDisabledNormalCriterias();

	void setDisabledNormalCriterias(List<Criteria> disabledNormalCriterias);

	List<Criteria> getDisabledFurtherCriterias();

	void setDisabledFurtherCriterias(List<Criteria> disabledFurtherCriterias);

	void setDomainName(String domainName);

	String getDomainName();

	String getMovementKeyName();
	void setMovementKeyName(String movementKeyName);

	DataSelectionItem getMovementTarget() ;
	void setMovementTarget(DataSelectionItem movementTarget);
	
	void setTimeSeriesMeasures(List<DataSelectionItem> measures);
	List<DataSelectionItem> getTimeSeriesMeasures();

	void setTimeSeriesCurveMeasure(String measure);
	String getTimeSeriesCurveMeasure();

	/**
	 * @deprecated use setCOBs(cobs)
	 */
	@Deprecated
	void setCOBs(List<String> cobs, String batchFrequencyStr);
	void setCOBs(List<String> cobs);
	List<TimeMark> getCOBs();

	String getExposureMeasureType();
	void setExposureMeasureType(String exposureMeasureType);

	String getTimeMarkKey();
	void setTimeMarkKey(String timeMarkKey);
	
	String getBatchName();
	void setBatchName(String batchName);
	
	String getBdRunId();
	void setBdRunId(String bdRunId);
	
	CriteriaWrapper getFocusCriteriaWrapper();
	void setFocusCriteriaWrapper(CriteriaWrapper focusCriteriaWrapper);
	
	CriteriaWrapper getSwitchCriteriaWrapper();
	void setSwitchCriteriaWrapper(CriteriaWrapper switchCriteriaWrapper);

	CriteriaWrapper getExcludeCriteriaWrapper();

	void setExcludeCriteriaWrapper(CriteriaWrapper excludeCriteriaWrapper);

	void setTableBasedElement(TableBasedElement tableBasedElement);
	
	TableBasedElement getTableBasedElement();
	
	void setPageSize (int pageSize);
	
	int getPageSize();
	
	void setEnableFacilityCriteria(boolean enableFacilityCriteria);
	
	boolean getEnableFacilityCriteria();
	
	void setStartDate(String startDate);
	
	String getStartDate();
	
	void setEndDate(String endDate);
	
	String getEndDate();
	
	void setAliasEnabled(boolean aliasEnabled);
	
	boolean isAliasEnabled();
	
	void setSelectLevel(String selectLevel);
	
	String getSelectLevel();
	
	String getCobKeyName();
	void setCobKeyName(String cobKeyName);
	
}
