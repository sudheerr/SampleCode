package com.citi.risk.core.application.api;

import java.util.List;

import com.citi.risk.core.dictionary.api.DataDomain;

public interface NavigationHolder {
	List<Navigation> getNavigations(DataDomain domain);

	void addNavigation(Class<?> domainClass, Class<? extends Navigation> navigationClass);

	void addNavigationElementIntersection(String elementName, Class<? extends Navigation> navigationClass);

	void addNavigationElementIntersection(Class<? extends Navigation> navigationClass, String elementName);

	void addNavigationElementUnion(String elementName, Class<? extends Navigation> navigationClass);

	/**
	 * @deprecated use getNavigations() instead
	 */
	@Deprecated
	List<Navigation> getNavigationsIntersection(String elementName);

	/**
	 * @deprecated
	 */
	@Deprecated
	List<String> getElementNamesIntersection(Class<? extends Navigation> navigationClass);

	/** 
	 * Get navigation item by domain, and element name.
	 * 
	 * @param domain domain class
	 * @param elementName element name (actually template name)
	 * @return list of navigation items
	 * 
	 * */
	List<Navigation> getNavigations(DataDomain domain, String elementName);

	void clearHolder();

}
