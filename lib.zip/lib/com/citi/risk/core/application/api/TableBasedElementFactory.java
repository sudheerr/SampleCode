package com.citi.risk.core.application.api;

public interface TableBasedElementFactory {
	TableBasedElement configElement(TableBasedElement element);
}
