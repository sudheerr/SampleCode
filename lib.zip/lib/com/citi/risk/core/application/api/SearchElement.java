package com.citi.risk.core.application.api;

import java.util.List;

import com.citi.risk.core.application.bean.Node;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataPath;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * SearchElement is the element used for browsing/choosing search Criteria items
 * of a specific domain. <p>It presents items/relationships in a tree of which the
 * root node is the domain. Items are not expandable, relationships are
 * expandable in terms of being presented as tree nodes.
 * 
 * @author ww78389
 * 
 */
public interface SearchElement extends Element<List<Node>> {

	/**
	 * Expand the current treeNode(relationship). Explore the items and
	 * relationships under the specified currentPath and return the path of them
	 * in a list. It uses <code>Triplet</code> to resemble tree nodes.
	 * 
	 * @param currentPath
	 * @return List of Triplet that resembles tree nodes
	 */
	List<Node> expand(DataPath currentPath);

	/**
	 * Look up possible values of a certain item in the Search Tree.
	 * 
	 * @param criteria
	 * @return
	 */
	List<Object> lookUp(Criteria criteria);

	/**
	 * Look up distinct values of a certain item by adding aggregation on path.
	 * 
	 * @param criteria
	 * @param path
	 * @return
	 */
	List<Object> lookUpWithDistinct(Criteria criteria, DataPath path);

	void setTreeNodeFullConstructed(boolean treeNodeFullConstructed); 
	
	@JsonIgnore
	List<Node> getTreeNode(DataPath path);
}
