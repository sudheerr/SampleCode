package com.citi.risk.core.application.api;

import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.TimeMark;

public interface ViewContext {
	/**
	 * @deprecated can't set dictionary
	 */
	@Deprecated
	void setDictionary(Dictionary dictionary);

	Dictionary getDictionary();

	void setDomain(DataDomain domain);

	DataDomain getDomain();

	void setQuery(Query query);

	Query getQuery();
	
	void setBasedTimeMark(TimeMark basedTimeMark);

	TimeMark getBasedTimeMark();
}
