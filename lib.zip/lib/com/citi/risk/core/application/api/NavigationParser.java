package com.citi.risk.core.application.api;

import java.util.List;

public interface NavigationParser {
	NavigationHolder parse(List<Class<? extends Navigation>> classes);
}
