package com.citi.risk.core.application.api;

public class RightMouseMenuItem {
	
	private String itemName;
	
	private String itemOperatorName;
	
	private String itemDefaultValue;
	
	/**
	 * 0 = <code>com.citi.risk.core.application.api.Navigation.Tppe.POPUP</code> <br>
	 * 1 = <code>com.citi.risk.core.application.api.Navigation.Tppe.OPERATION</code> <br>
	 * 2 = <code>com.citi.risk.core.application.api.Navigation.Tppe.SWITCH</code> <br>
	 */
	int operationType;

	public RightMouseMenuItem(String itemName,String itemOperatorName,int operationType){
		this.itemName = itemName;
		this.operationType = operationType;
		this.itemOperatorName = itemOperatorName;
	}
	
	public RightMouseMenuItem withDefaultInputValue(String inputValue){
		this.itemDefaultValue = inputValue;
		return this;
	}
	
	
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemOperatorName() {
		return itemOperatorName;
	}

	public void setItemOperatorName(String itemOperatorName) {
		this.itemOperatorName = itemOperatorName;
	}

	public int getOperationType() {
		return operationType;
	}

	public void setOperationType(int operationType) {
		this.operationType = operationType;
	}


	public String getItemDefaultValue() {
		return itemDefaultValue;
	}


	public void setItemDefaultValue(String itemDefaultValue) {
		this.itemDefaultValue = itemDefaultValue;
	}
}
