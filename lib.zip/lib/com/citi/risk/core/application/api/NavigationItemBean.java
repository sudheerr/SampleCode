package com.citi.risk.core.application.api;

public class NavigationItemBean {
	private String itemName;

	public NavigationItemBean(String itemName) {
		this.itemName = itemName;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

}
