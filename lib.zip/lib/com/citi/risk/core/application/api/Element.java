package com.citi.risk.core.application.api;

import java.io.Serializable;

import com.citi.risk.core.data.query.api.Query;
import com.fasterxml.jackson.annotation.JsonIgnore;

public interface Element<T> extends Serializable, Cloneable{
	T onLoad();
	@JsonIgnore
	Query getQuery();
	void setQuery(Query query);
	
	@JsonIgnore
	ViewContext getViewContext();
	void setViewContext(ViewContext viewContext);
	
	Object clone() throws CloneNotSupportedException;
}