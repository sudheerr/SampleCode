package com.citi.risk.core.application.api;

public interface NavigationParameterAware {
	void setNavigationParameter(NavigationParameter navigationParameter);
}
