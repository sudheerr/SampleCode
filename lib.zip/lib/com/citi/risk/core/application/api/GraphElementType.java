package com.citi.risk.core.application.api;


public enum GraphElementType {
	LINE, BAR
}
