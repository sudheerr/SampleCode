package com.citi.risk.core.application.api;

/**
 * @author bh30850
 */
public interface HasRoot<R> {

    R getRoot();
    Boolean hasRoot();

}
