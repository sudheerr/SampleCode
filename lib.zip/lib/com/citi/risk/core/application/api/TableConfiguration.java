package com.citi.risk.core.application.api;

public interface TableConfiguration {

	String getTableId();
	String getTableName(); 
	Class<?> getDomainClass(); 
	Class<? extends TableBasedElement> getTableBasedElementClass(); 
	Class<?> getQueryClass();
	ViewContext getViewContext();
}
