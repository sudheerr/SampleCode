package com.citi.risk.core.application.api;

import com.citi.risk.core.application.impl.DefaultPerspective;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.security.api.EnforcementMode;
import com.citi.risk.core.security.api.SecureDomain;
import com.citi.risk.core.security.api.SecurityProvider;
import com.citi.risk.core.security.api.SecurityRealm;

@DDD(name="EemsPerspective", domainImplClasses={DefaultPerspective.class})
@SecureDomain(name = "EemsPerspective", securityProvider = SecurityProvider.EEMS, enforcementMode = EnforcementMode.STRICT,
	securityRealms={SecurityRealm.ETS, SecurityRealm.WHOLESALE_CREDIT, SecurityRealm.RETAIL_CREDIT, SecurityRealm.CITIRISK_LEM, SecurityRealm.CITIRISK_ACE})
public interface EemsPerspective extends Perspective {

}
