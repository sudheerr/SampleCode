package com.citi.risk.core.application.api;


public interface PerspectiveFactory {
	Perspective createPerspective();

	Perspective configurePerspective(Perspective defaultPerspective);
}
