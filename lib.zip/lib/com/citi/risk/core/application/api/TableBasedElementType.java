package com.citi.risk.core.application.api;

public enum TableBasedElementType {
	FlatElement, MasterElement, DetailElement, TableElement;
}
