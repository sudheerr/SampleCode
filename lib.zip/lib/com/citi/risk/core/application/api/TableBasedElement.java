package com.citi.risk.core.application.api;

import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.impl.DefaultTableBasedElement;
import com.citi.risk.core.data.pivot.api.PivotTable;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.table.SimpleTable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;

/**
 * The Interface TableBasedElement.
 */
@JsonTypeInfo(use = Id.CLASS, defaultImpl = DefaultTableBasedElement.class)
public interface TableBasedElement extends Element<SimpleTable>, ViewComponent, Container<ColumnHeader>, HasRoot<Perspective>{

	void initHeader();

	void addColumn(ColumnHeader columnHeader);

	void removeColumn(ColumnHeader columnHeader);

	void setCriteria(Criteria criteria);

	void setFurtherCriteria(Criteria criteria);

	void setLoadAllWithNonCriteria(boolean loadAllWithNonCriteria);

	/**
	 * Get the generated excel file.
	 *
	 * @return
	 */
	void populateExcelOutputStream();

	/**
	 * Gets the navigation.
	 *
	 * @return the navigation
	 */
	List<Navigation> getMenuList();

	void setMenuList(List<Navigation> menuList);

	@JsonIgnore
	List<Navigation> getTableOperatorList();

	@JsonIgnore
	Navigation getNavigation(String itemName);

	View navigateTo(String itemName, NavigationParameter parameter);

	List<View> popUp(String itemName, NavigationParameter parameter);

	void updateCell(String key, String updatePathString, Object toValue);

	/**
	 * Set record count per page for pagination
	 */
	Integer getPageSize();
	void setPageSize(Integer pageSize);

	Integer getCurrency();
	void setCurrency(Integer currency);

	/**
	 * Set current page index for pagination
	 * @param pageIndex
	 */
	void setPageIndex(Integer pageIndex);

	/**
	 * Get total page count for pagination
	 * @return
	 */
	Integer getPageCount();

	/**
	 * Get total result count for pagination
	 * @return
	 */
	Integer getResultCount();

	/**
	 * Get the outPutStream to download excel
	 * @return
	 */
	@JsonIgnore
	OutputStream getOutputStream();

	/**
	 * Set the outPutStream to download excel
	 * @param out
	 */
	void setOutputStream(OutputStream out);

	void setSortColumn(ColumnHeader columnHeader);

	/******************** setXX() getXX() methods for JPA ********************/
	Integer getId();
	void setId(Integer id);

	String getName();
	void setName(String name);

	String getDomainName();
	void setDomainName(String domainName);

	String getType();
	void setType(String type);

	Integer getDisplayIndex();
	void setDisplayIndex(Integer displayIndex);

	List<ColumnHeader> getHeader();

	Boolean isSubtotalDisplayed();
	void setSubtotalDisplayed(Boolean isSubtotalDisplayed);

	void setHeader(List<ColumnHeader> header);

	@JsonIgnore
	View getView();
	@JsonProperty
	void setView(View view);

	Boolean getHidden();
	void setHidden(Boolean hidden);

	String getTemplateName();
	void setTemplateName(String templateName);

	Integer getSourceId();
	void setSourceId(Integer sourceId);

	@Override
	Object clone();

	/**
	 * @deprecated
	 */
	@Deprecated
	TableBasedElement copy(View v);

	Integer getIsGlobalFilterDisabled();
	void setIsGlobalFilterDisabled(Integer isGlobalFilterDisabled);

	String getElementCriteriaString();
	void setElementCriteriaString(String elementCriteriaString);

	List<Map<String, Object>> getElementCriteria();
	void setElementCriteria(List<Map<String, Object>> elementCriteria);

	DataSelection toDataSelection(List<ColumnHeader> columnHeaders);

	boolean isCriteriaValidForLoadAll();

	PivotTable onLoadByPivotQuery();

	DataSelection toPivotDataSelection(List<ColumnHeader> columnHeaders);

	QueryRequest populateQueryRequest();

}
