package com.citi.risk.core.application.api;

import com.citi.risk.core.application.impl.DefaultPerspective;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import java.io.Serializable;
import java.util.List;

@DDD(name="Perspective", domainImplClasses={DefaultPerspective.class})
/*
@SecureDomain(name = "Perspective", securityProvider = SecurityProvider.EEMS, enforcementMode = EnforcementMode.STRICT,
	securityRealms={SecurityRealm.ETS, SecurityRealm.WHOLESALE_CREDIT, SecurityRealm.RETAIL_CREDIT, SecurityRealm.CITIRISK_LEM, SecurityRealm.CITIRISK_ACE})
*/
@JsonTypeInfo(use = Id.CLASS, defaultImpl=DefaultPerspective.class)
public interface Perspective extends Serializable, Cloneable, IdentifiedBy<Integer>, Container<View>, ViewComponent{

	@JsonIgnore
	View getViewByName(String name);

	@DDI(name="Id")
	Integer getId();
	void setId(Integer id);

	@DDI(name="Name")
	String getName();
	void setName(String name);

	@DDI(name="Alias")
	String getAlias();
	void setAlias(String alias);

	@DDI(name="Is Active")
	Boolean isActive();
	void setActive(Boolean active);

	@DDI(name="Type")
	String getType();
	void setType(String type);

	@DDI(name="Startup URL")
	String getStartupUrl();
	void setStartupUrl(String startupUrl);

	String getSoeId();
	void setSoeId(String soeId);

	@DDI(name="Source Id")
	Integer getSourceId();
	void setSourceId(Integer sourceId);

	/**
	 * @deprecated
	 */
	@Deprecated
	@DDI(name="Perspective Category")
	String getPerspectiveCategory();

	/**
	 * @deprecated
	 */
	@Deprecated
	void setPerspectiveCategory(String perspectiveCategory);

	@DDI(name="Application")
	String getAppAlias();
	void setAppAlias(String appAlias);

	@DDI(name="Is Shared")
	Boolean isShared();
	void setShared(Boolean hidden);

	List<View> getViewList();
	void setViewList(List<View> viewList);

	String getFolderPath();
	void setFolderPath(String folderPath);


	Object clone() throws CloneNotSupportedException;

	/**
	 * @deprecated
	 */
	@Deprecated
	Perspective copy();

	List<IntegrationTabMenuItem> getViewCreationMenuItems();
	void setViewCreationMenuItems(List<IntegrationTabMenuItem> integrationTabMenuItems);

	IntegrationTabMenuItem getViewCreationMenuItem(String itemName);
}