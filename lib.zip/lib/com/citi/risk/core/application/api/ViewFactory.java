package com.citi.risk.core.application.api;


public interface ViewFactory {

	View newView(Class<? extends View> viewClass);

	View configView(View view);

}

