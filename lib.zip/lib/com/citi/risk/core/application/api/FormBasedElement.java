package com.citi.risk.core.application.api;

import java.util.List;

public interface FormBasedElement extends Element<Object>{
	String getName();
	void setName(String name);
	Navigation getNextNavigation();
	void setNextNavigation(Navigation navigation);
	List<Field<String, List<String>>> getFields();
	void setFields(List<Field<String, List<String>>> fields);

	interface Field<K,V> {
		K getKey();
		V getValue();
	}

}
