package com.citi.risk.core.application.api;

import java.util.List;

import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.bean.GraphData;
import com.citi.risk.core.lang.table.SimpleTable;


public interface GraphBasedElement<K, V> extends Element<SimpleTable> {

	void setGraphType(GraphElementType type);
	GraphElementType getGraphType();

	void setTableData(SimpleTable simpleTable);
	SimpleTable getTableData();

	void setHeaders(List<String> headers);
	List<String> getHeaders();

	void setGraphData(GraphData graphData);
	GraphData getGraphData();
	
	void setTableHeaders(List<ColumnHeader> tableHeaders);
	List<ColumnHeader> getTableHeaders();
	
	void setDownloadLink(String link);
	String getDownloadLink();
}
