package com.citi.risk.core.application.api;

/**
 * @author bh30850
 */
public interface ViewComponent {

    Integer getId();
    void setId(Integer id);

}
