package com.citi.risk.core.application.api;

import java.util.List;

/**
 * @author bh30850
 */
public interface Container<T> {

    List<T> getChildren();

}
