package com.citi.risk.core.application.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.citi.risk.core.application.impl.CriteriaWrapper;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.businessobject.TimeMark.RelativeTimePoint;

public interface CacheService {

	static final String TIMEMARK_KEY = "TimeMark Key";

	/**
	 * @deprecated
	 */
	@Deprecated
	String getDomainName(String pathString);

	/**
	 * @deprecated
	 */
	@Deprecated
	DataDomain getDomain(String domainName);
	Map<String, DataDomain> getAvailableDomainMap();
	List<Map<String, String>> loadDomainList(boolean aliasEnabled);
	String getTerminatingItemName(String pathString, boolean aliasEnabled);
	String getTerminatingItemName(DataItem dataItem, boolean aliasEnabled);

	/**
	 * @deprecated
	 */
	@Deprecated
	Dictionary getDictionary(DataDomain domain);

	/**
	 * @deprecated
	 */
	@Deprecated
	String getDomainNameFromFullClassName(String fullDomainClassName);

	DataDomain parseDomain(Class<?> klass);
	DataDomain parseDomain(String domainFullKlassName);
	String getDataTypeForPathString(String pathString);
	
	/**
	 * @deprecated Should use DataDomain
	 */
	@Deprecated
	boolean isTerminatingItemTimeMarkKey(String pathString);
	
	List<String> getBusinessDatesAsTimeMarkDisplayFormatString(DataDomain domain);
	
	TimeMark getTimeMarkFromDisplayFormatString(DataDomain domain, String dateString);
	String getUIDisplayString(String pathString, String dateString);
	
	TimeMark getTimeMarkFromRelativeTimePoint(RelativeTimePoint RelativeTimePoint, BatchFrequency batchFrequency, String pathString);
	ArrayList<TimeMark> getTimeMarksFromCriterionMapList(DataDomain domain, List<Map<String, Object>> criterionMapList);
	
	Criteria getTimeMarkCriteria(List<Map<String, Object>> criteriaMap, DataDomain domain);
	CriteriaWrapper toCriteriaWrapper(List<Map<String, Object>> criterionMapList, DataDomain domain);
	CriteriaWrapper toCriteriaWrapper(List<Map<String, Object>> criterionMapList);
	
	String getDomainDataDisplayPathString(DataPath dataPath);

	DataPath getTimeMarkPath(DataDomain domain);
}
