package com.citi.risk.core.application.api;

import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.impl.DataCachesQuery;

@Target({ TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface ViewConfiguration {

	String name();

	Class<?> domainClass();

	Class<? extends TableBasedElement>[] tableBasedElementClasses();

	Class<? extends Query> queryClass() default DataCachesQuery.class;
}
