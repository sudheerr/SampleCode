package com.citi.risk.core.application.api;

import java.util.List;

import com.citi.risk.core.application.impl.GuiNavigationParameters;
import com.citi.risk.core.application.impl.NavigationFlow;
import com.citi.risk.core.gui.api.Widget;

public interface Navigation extends NavigationParameterAware {
	
	com.citi.risk.core.application.api.View navigateTo(NavigationParameter navigationParameter);
	
	Widget navigateTo(GuiNavigationParameters navigationParameter);
	
	List<View> popUp(NavigationParameter navigationParameter);

	String getItemName();
	
	String getDisplayName();
	
	@Override
	String toString();
	
	String getTargetDomainName();
	
	NavigationFlow getNavigationFlow();

	void setItemName(String itemName);
	
	void setDisplayName(String displayName);
	
	void setTargetDomainName(String targetDomainName);
	
	void setNavigationFlow(NavigationFlow navigationFlow);
	
}
