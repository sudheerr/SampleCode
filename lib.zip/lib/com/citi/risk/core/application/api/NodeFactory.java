package com.citi.risk.core.application.api;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.application.bean.Node;
import com.citi.risk.core.dictionary.api.DataPath;
import com.google.common.collect.Lists;

public class NodeFactory {
	
	private NodeFactory(){}
	
	public static Node newNodeByPaths(List<DataPath<?,?>> paths) {

		if (CollectionUtils.isNotEmpty(paths)) {
			DataPath<?,?> path0 = paths.get(0);
			String name = path0.getStartingDomain().getName();
			List<String> domainNames = Lists.newArrayList();
			domainNames.add(name);
			Node firstNode = new Node(name, domainNames, null, false);

			for (DataPath<?,?> path : paths) {
				firstNode.addChild(path);
			}
			return firstNode;
		}

		return null;

	}
}
