package com.citi.risk.core.application.api;

import com.citi.risk.core.application.impl.DefaultPerspective;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.security.api.EnforcementMode;
import com.citi.risk.core.security.api.SecureDomain;
import com.citi.risk.core.security.api.SecurityProvider;
import com.citi.risk.core.security.api.SecurityRealm;

@DDD(name="CracPerspective", domainImplClasses={DefaultPerspective.class})
@SecureDomain(name = "CracPerspective", securityProvider = SecurityProvider.CRAC, enforcementMode = EnforcementMode.STRICT,
	securityRealms={SecurityRealm.ETS, SecurityRealm.WHOLESALE_CREDIT, SecurityRealm.RETAIL_CREDIT})
public interface CracPerspective extends Perspective {

}
