package com.citi.risk.core.application.bean;

public class TableModel {
	private String fields;
	private String columns;
	private String data;
	private Integer total;
	private String contextMenu;
	private String operators;

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getColumns() {
		return columns;
	}

	public void setColumns(String columns) {
		this.columns = columns;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public String getContextMenu() {
		return contextMenu;
	}

	public void setContextMenu(String contextMenu) {
		this.contextMenu = contextMenu;
	}

	public String getOperators() {
		return operators;
	}

	public void setOperators(String operators) {
		this.operators = operators;
	}

	public TableModel(String fields, String columns, String data, Integer total,
			String contextMenu, String operators) {
		this.fields = fields;
		this.columns = columns;
		this.data = data;
		this.total = total;
		this.contextMenu = contextMenu;
		this.operators = operators;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("{");
		result.append("fields:").append(fields).append(",");
		result.append("columns:").append(columns).append(",");
		result.append("data:").append(data).append(",");
		result.append("total:").append(total).append(",");
		result.append("contextMenu:").append(contextMenu).append(",");
		result.append("operators:").append(operators);
		result.append("}");

		return result.toString();
	}

}
