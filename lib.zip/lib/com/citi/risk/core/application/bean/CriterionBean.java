package com.citi.risk.core.application.bean;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.application.api.CacheService;
import com.citi.risk.core.application.impl.CustomDate;
import com.citi.risk.core.application.impl.DataTypeUtil;
import com.citi.risk.core.application.impl.UserVisibleException;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.Criterion.Op;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.impl.AggregateInfoParser;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.RelativeTimePoint;
import com.citi.risk.core.lang.compare.CompareInfoParser;
import com.citi.risk.core.lang.compare.DefaultQueryCompareMeasure;
import com.citi.risk.core.lang.compare.HistoryComparator;
import com.citi.risk.core.lang.compare.QueryCompareMeasure;
import com.citi.risk.core.lang.compare.TimeMarkCompareMeasure;
import com.google.common.base.Functions;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
 
public class CriterionBean {
	private static final String OPERANDS_DELIMITER = ", ";
	private static final String HEADER_NAME_SEPERATOR = ">";
	private static final String CRITERION_HEADER_DELIMINTER = ":";
	private static final String NOT_LIKE = "notLike";
	public static final String IS_NULL_OR_EMPTY = "isNullOrEmpty";
	public static final String IS_NOT_NULL_OR_EMPTY = "isNotNullOrEmpty";
	private static final String EMPTY_STRING = "";
	private static final String PATH_NOT_NULL_WARN_STRING = "Path cannot be null";
	private static final Logger LOGGER=LoggerFactory.getLogger(CriterionBean.class);
	
	private String pathString;
	private String operator;
	private String operatorString;
	private List<String> operandsString;
	private String criterionHeader;
	/**
	 * Special for further criteria, further criteria is like having clause in SQL
	 */
	private DataSelection<?> dataSelection;
	private boolean isForHistoricalColumn;
	private boolean isForAggregatedColumn;
	private String aggregationMeasure;
	private String compareTimeofTimeKey;
	private String compareMeasureName;
	private int repetitiveRatio;
	
	/**
	 * if a criterion is not applicable during navigation, set its disabled to true
	 */
	private boolean disabled;
	
	public CriterionBean(String pathString, String operator, List<String> operandsString, boolean disabled) {
		super();
		this.pathString = pathString;
		this.operator = operator;
		this.operandsString = operandsString;
		this.disabled=disabled;
	}
	
	public CriterionBean(String pathString, String operator, List<String> operandsString, DataSelection dataSelection, boolean disabled){
		this(pathString,operator,operandsString,disabled);
		this.dataSelection=dataSelection;
	}

	public CriterionBean(Criterion criterion) {
		this(criterion.getDataSelectionItem().getUnderlyingPath().toPathString(),
				criterion.getOP().toString(),
				Lists.transform((List) criterion.getAllOperands(), Functions.toStringFunction()), criterion.isDisabled());
		this.operatorString = criterion.getOP().toString();
		this.criterionHeader = convertPathToCriterionHeader(criterion.getDataSelectionItem().getUnderlyingPath()) + CRITERION_HEADER_DELIMINTER + convertOperandsToString(criterion);
	}

	public String getPathString() {
		return pathString;
	}

	public String getOperator() {
		return operator;
	}

	public List<String> getOperandsString() {
		return operandsString;
	}

	public String getCriterionHeader() {
		return criterionHeader;
	}

	public DataSelection<?> getDataSelection() {
		return dataSelection;
	}

	public void setDataSelection(DataSelection<?> dataSelection) {
		this.dataSelection = dataSelection;
	}

	public boolean isForHistoricalColumn() {
		return isForHistoricalColumn;
	}

	public void setForHistoricalColumn(boolean isForHistoricalColumn) {
		this.isForHistoricalColumn = isForHistoricalColumn;
	}

	public boolean isForAggregatedColumn() {
		return isForAggregatedColumn;
	}

	public void setForAggregatedColumn(boolean isForAggregatedColumn) {
		this.isForAggregatedColumn = isForAggregatedColumn;
	}

	public String getAggregationMeasure() {
		return aggregationMeasure;
	}

	public void setAggregationMeasure(String aggregationMeasure) {
		this.aggregationMeasure = aggregationMeasure;
	}

	public String getComparedTimeKey() {
		return compareTimeofTimeKey;
	}

	public void setComparedTimeKey(String compareTimeoffset) {
		this.compareTimeofTimeKey = compareTimeoffset;
	}

	public String getCompareMeasureName() {
		return compareMeasureName;
	}

	public void setCompareMeasureName(String compareMeasureName) {
		this.compareMeasureName = compareMeasureName;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public int getRepetitiveRatio() {
		return repetitiveRatio;
	}

	public void setRepetitiveRatio(int repetitiveRatio) {
		this.repetitiveRatio = repetitiveRatio;
	}

	@Override
	public String toString() {
		return "CriterionBean [pathString=" + pathString + ", operator="
				+ operator + ", operatorString=" + operatorString
				+ ", operandsString=" + operandsString + ", criterionHeader="
				+ criterionHeader + ", isForHistoricalColumn="
				+ isForHistoricalColumn + ", isForAggregatedColumn="
				+ isForAggregatedColumn + ", aggregationMeasure="
				+ aggregationMeasure + ", compareTimeoffset="
				+ compareTimeofTimeKey + ", compareMeasureName="
				+ compareMeasureName + ", disabled=" + disabled + "]";
	}

	private String convertOperandsToString(Criterion criterion) {
		StringBuilder sb = new StringBuilder();

		if (criterion == null || criterion.getAllOperands().isEmpty()) {
			return sb.toString();
		}

		Collection operands = criterion.getAllOperands();
		Iterator iter = operands.iterator();

		if (iter.hasNext()) {
			sb.append(iter.next().toString());
		}

		while (iter.hasNext()) {
			sb.append(OPERANDS_DELIMITER + iter.next().toString());
		}

		return sb.toString();
	}

	private String convertPathToCriterionHeader(DataPath path) {
		if (path == null) {
			return null;
		}

		StringBuilder headerName = new StringBuilder();
		List<DataRelationship> allRelationship = path.getRelationships();

		for (DataRelationship relationship : allRelationship) {
			headerName.append(relationship.getName() + HEADER_NAME_SEPERATOR);
		}

		if (path.isTerminatedWithAnItem()) {
			headerName.append(path.getTerminatingItem().getName());
		}

		return headerName.toString();
	}

	/**
	 * Conversion method for normal criteria from Map<String, Object> object to Criteria object.
	 * @param criterionMap
	 * @param dictionary
	 * @param normalCriteria
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Criteria toNormalCriteria(Map<String, Object> criterionMap, Dictionary dictionary){
		
		if(criterionMap==null) 
			return null;
		
		if(Op.existsAny.toString().equalsIgnoreCase(criterionMap.get("operator").toString()) || 
				Op.existsAll.toString().equalsIgnoreCase(criterionMap.get("operator").toString())){
			
			 Criteria criteria;
			 Boolean existsAll =  Op.existsAll.toString().equalsIgnoreCase(criterionMap.get("operator").toString());
			 
			 String pathString = criterionMap.get("pathString").toString();
			 List<Map<String, Object>> innerCriterionMapList = (List<Map<String, Object>>) criterionMap.get("operandsString");
			 Criteria innerCriteria = null;
			 for(Map<String, Object> innerCriterionMap : innerCriterionMapList){
				 innerCriteria = innerCriteria == null ? CriterionBean.formCriteria(innerCriterionMap, dictionary) : 
					 innerCriteria.and(CriterionBean.formCriteria(innerCriterionMap, dictionary));
			 }
			 
			 DataPath path = getPathFromPathString(dictionary, pathString);
			 
			 if(!existsAll){
				 criteria = path.existsAny(innerCriteria);
			 }else{
				 criteria = path.existsAll(innerCriteria);
			 }
			 
			 criteria.getCriterion(0).setDisabled(isDisableValue(criterionMap));
			 return criteria;
		}else{
			 return CriterionBean.formCriteria(criterionMap, dictionary);
		}
	}

	private static DataPath getPathFromPathString(Dictionary dictionary, String pathString) {
	    DataPath path = dictionary.newPath(pathString);
	     if(path==null){
	    	LOGGER.error(PATH_NOT_NULL_WARN_STRING);
	    	throw new IllegalArgumentException(PATH_NOT_NULL_WARN_STRING);
	     }
	    return path;
    }
	
	@SuppressWarnings("unchecked")
	private static Criteria formCriteria(Map<String, Object> criterionMap, Dictionary dictionary){
		CriterionBean criterionBean = new CriterionBean(
				criterionMap.get("pathString").toString(),
				criterionMap.get("operator").toString(), 
				(List<String>) criterionMap.get("operandsString"),
				isDisableValue(criterionMap)
			);
		return criterionBean.toSingleNormalCriteria(dictionary);
	}

	private static boolean isDisableValue(Map<String, Object> criterionMap) {
	    return criterionMap.get("disabled")==null?false:Boolean.valueOf(criterionMap.get("disabled").toString());
    }
	
	/**
	 * Conversion method for further criteria from Map<String, Object> object to Criteria object.
	 * @param criterionMap
	 * @param dictionary
	 * @param futherCriteria
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Criteria toFurtherCriteria(Map<String, Object> criterionMap, Dictionary dictionary){
		if(criterionMap==null) 
			return null;
		
		CriterionBean criterionBean;
		boolean isForHistoricalColumn = criterionMap.get("isForHistoricalColumn")==null?false:Boolean.valueOf(criterionMap.get("isForHistoricalColumn").toString());
		boolean isForAggregatedColumn = criterionMap.get("isForAggregatedColumn")==null?false:Boolean.valueOf(criterionMap.get("isForAggregatedColumn").toString());
		String pathString=filterPathString(criterionMap.get("pathString")==null?null:criterionMap.get("pathString").toString());
		String operator = criterionMap.get("operator")==null?null:criterionMap.get("operator").toString();
		List<String> operandsString= criterionMap.get("operandsString")==null?null:(List<String>) criterionMap.get("operandsString");
		String aggregationMeasureInfo=criterionMap.get("aggregationMeasure")==null?null:criterionMap.get("aggregationMeasure").toString();
		String compareTimeoffset=criterionMap.get("compareTimeoffset")==null?null:criterionMap.get("compareTimeoffset").toString();
		String compareMeasureName=criterionMap.get("compareMeasureName")==null?null:criterionMap.get("compareMeasureName").toString();
		boolean disabled=isDisableValue(criterionMap);
		
		// Get e.g T1~Monthly or T1~Daily, at this moment only header name has relative time information. JIRA 2279. 
		// Need this relative time offset later to reset relative time point in time mark to compare to get formatted display label. 
		String relativeCompareTimeOffset = criterionMap.get("relativeCompareTimeOffset")==null?null:criterionMap.get("relativeCompareTimeOffset").toString();
		String histColumnHeaderName=criterionMap.get("histColumnHeaderName")==null?null:criterionMap.get("histColumnHeaderName").toString();
		
		if (isForHistoricalColumn && histColumnHeaderName != null && Strings.isNullOrEmpty(relativeCompareTimeOffset))
			relativeCompareTimeOffset = CustomDate.getRelativeTimePointAndBatchFrequencyFromColumnHeaderName(histColumnHeaderName);
		
		DataPath columnPath=dictionary.newPath(pathString);
		
		if(isForAggregatedColumn && !isForHistoricalColumn){
			criterionBean=new CriterionBean(pathString, operator, operandsString, getAggregateDataSelection(columnPath, aggregationMeasureInfo),disabled);
		}else if(!isForAggregatedColumn && isForHistoricalColumn){
			criterionBean=new CriterionBean(pathString, operator, operandsString, getComparisonDataSelection(relativeCompareTimeOffset, compareTimeoffset, compareMeasureName, columnPath.select()), disabled);
		}else if(isForAggregatedColumn && isForHistoricalColumn){
			DataSelection aggreDataSelection=getAggregateDataSelection(columnPath, aggregationMeasureInfo);
			DataSelection aggreAndCmpDataSelection=getComparisonDataSelection(relativeCompareTimeOffset, compareTimeoffset, compareMeasureName, aggreDataSelection);
			criterionBean=new CriterionBean(pathString, operator, operandsString, aggreAndCmpDataSelection,disabled);
		} else {
			throw new UnsupportedOperationException("toFurtherCriteria for not ForAggregatedColumn and not ForHistoricalColumn");
		}

		return criterionBean.toSingleFurtherCriteria(dictionary, checkUndetectableTerminatingItemTypeIfApply(aggregationMeasureInfo));
	}
	
	/**
	 * Suppose a count aggregation on a string value column, the terminatingItemType will be detected as string, 
	 * which results in the operands being formatted as string while it should be formatted as number.
	 * but actually it should be number since the aggregation measure is count.</br>
	 * So in this case you have to explicitly pass in the terminatingItemType.</br>
	 * If the terminatingItemType could be detected from the path, just return null.
	 * @param aggregationMeasureInfo
	 * @return
	 */
	private static Class<?> checkUndetectableTerminatingItemTypeIfApply(String aggregationMeasureInfo){
		Class<?> terminatingItemType=null;
		if(aggregationMeasureInfo!=null && aggregationMeasureInfo.toLowerCase().startsWith("count")){
			terminatingItemType=Integer.class;
		}
		return terminatingItemType;
	}
	
	@SuppressWarnings("rawtypes")
	private static DataSelection getAggregateDataSelection(DataPath columnPath, String aggregationMeasureInfo){
		if(columnPath==null || aggregationMeasureInfo==null){
			String msg="Column path and aggregationMeasureInfo cannot be null";
			LOGGER.error(msg);
			throw new UserVisibleException(msg);
		}
		String[] tmpStrArr = aggregationMeasureInfo.split(DataSelectionItem.MEASURE_CLASS_SEPARATOR);
		String aggregateMeasureName = tmpStrArr[0]==null?null:tmpStrArr[0].trim();
		String aggregateClassName = tmpStrArr[0]==null?null:tmpStrArr[1].trim();
		AggregateMeasure aggregateMeasure=createAggregateMeasure(aggregateMeasureName, aggregateClassName);
		return columnPath.aggregateTo(aggregateMeasure);
	}

	@SuppressWarnings("rawtypes")
	private static DataSelection getComparisonDataSelection(String relativeCompareTimeOffset, String compareTimeoffset, String compareMeasureName, DataSelection dataSelection){
		if(compareTimeoffset==null || compareMeasureName==null || dataSelection==null){
			String msg="Parameters of getComparisonDataSelection cannot be null";
			LOGGER.error(msg);
			throw new UserVisibleException(msg);
		}
		QueryCompareMeasure queryCompareMeasure;
		TimeMark timemarkofCompared = null;
		try {
			timemarkofCompared =  DefaultTimeMark.getTimeMarkfromKey(compareTimeoffset);
			queryCompareMeasure = createyCompareMeasure(relativeCompareTimeOffset, compareMeasureName, timemarkofCompared);  
		} catch (RuntimeException e) {
			throw new UserVisibleException("Failed to create Compare Measure", e);
		}

		return dataSelection.compareWith(queryCompareMeasure);
	}

	@SuppressWarnings("rawtypes")
	private static AggregateMeasure createAggregateMeasure(String measureName, String aggregateClassName) {
		if(measureName==null || aggregateClassName==null) {
			String msg="Measure name and class name of aggregation cannot be null";
			LOGGER.error(msg);
			throw new IllegalArgumentException(msg);
		}
		AggregateMeasure measure = null;
		try {
			measure = new AggregateInfoParser().parse(Class.forName(aggregateClassName)).getMeasure(measureName);
		} catch (ClassNotFoundException e) {
			throw new UserVisibleException("Failed to create aggregate measure", e);
		}
		return measure;
	}
	
	@SuppressWarnings("rawtypes")
	private static QueryCompareMeasure createyCompareMeasure(String relativeCompareTimeOffset, String measureName, TimeMark timemarkofCompared) {
		if(measureName==null) {
			String msg="Measure name of Compare Measure cannot be null";
			LOGGER.error(msg);
			throw new IllegalArgumentException(msg);
		}
		QueryCompareMeasure measure = null;
		QueryCompareMeasure returnedMeasure = null;
		try {
			measure = new CompareInfoParser().parse(HistoryComparator.class).getMeasure(measureName);
			returnedMeasure = new TimeMarkCompareMeasure((DefaultQueryCompareMeasure)measure, timemarkofCompared);
			// reset relative time point in time mark to compare to get formatted display label later. JIRA 2279. 
			if (relativeCompareTimeOffset != null && relativeCompareTimeOffset.split(TimeMark.DELIMITER).length > 1) 
					((TimeMarkCompareMeasure)returnedMeasure).
						setRelativeTimePoint(RelativeTimePoint.valueOf(relativeCompareTimeOffset.split(TimeMark.DELIMITER)[0]));
		} catch (RuntimeException e) {
			throw new UserVisibleException("Failed to create Compare Measure", e);
		}
		return returnedMeasure;
	}
	
	private static String filterPathString(String pathStr){
		if(pathStr==null) 
			return null;
		if(pathStr.split(DataSelectionItem.PATH_COMPARE_SEPARATOR).length > 1){
			return pathStr.split(DataSelectionItem.PATH_COMPARE_SEPARATOR)[0];
		}else{
			return pathStr;
		}
	}
	
	public Criteria toSingleNormalCriteria(Dictionary dictionary) {
		
		DataPath path = getPathFromPathString(dictionary, pathString);
		
		Criteria criteria = null;
		
		if(operator.equalsIgnoreCase(NOT_LIKE) || Op.notLikeObjectString.toString().equalsIgnoreCase(operator)){
			criteria = path.likeObjectString(operandsString.get(0));
			return criteria.not();
		}
		
		if (Op.like.toString().equalsIgnoreCase(operator) || Op.likeObjectString.toString().equalsIgnoreCase(operator)) {
			criteria = path.likeObjectString(operandsString.get(0));
			return criteria;
		}

		Class<?> terminatingItemType = path.getTerminatingItem().getJavaSimpleType();
		Class<?> domainClass=path.getTerminatingItem().getDomain().getDomainClass();
		List<Comparable<?>> operands=formatOperands(terminatingItemType, domainClass);
		
		final boolean compareOperator = isCompareOperator();
		
		if (Op.in.toString().equalsIgnoreCase(operator)) {
			criteria = path.in((List) operands);
		}else if (Op.between.toString().equalsIgnoreCase(operator)) {
			criteria = path.between((Comparable) operands.get(0), (Comparable) operands.get(1));
		}else if (Op.isNull.toString().equalsIgnoreCase(operator)) {
			Method opMethod = null;
			try {
				opMethod = DataPath.class.getMethod(operator);
				criteria = (Criteria) opMethod.invoke(path);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + operator, e);
			}
		}else if ("notIn".equalsIgnoreCase(operator)) {
			Method opMethod = null;
			try {
				opMethod = DataPath.class.getMethod(Op.in.toString(),Collection.class);
				criteria = (Criteria) opMethod.invoke(path,operands);
				criteria = criteria.not();
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + Op.in.toString() + "(Collection)", e);
			}
		}else if ("isNotNull".equalsIgnoreCase(operator)) {
			Method opMethod = null;
			try {
				opMethod = DataPath.class.getMethod(Op.isNull.toString());
				criteria = (Criteria) opMethod.invoke(path);
				criteria = criteria.not();
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				LOGGER.error("Fail to invoke method " + Op.isNull.toString(),e);
			}
		}else if (IS_NULL_OR_EMPTY.equalsIgnoreCase(operator)) {
			criteria = path.in(null, EMPTY_STRING);
		}else if (IS_NOT_NULL_OR_EMPTY.equalsIgnoreCase(operator)) {
			criteria = path.in(null, EMPTY_STRING);
			criteria = criteria.not();
		}else if (compareOperator) {
			Method opMethod = null;
			try {
				opMethod = DataPath.class.getMethod(operator, Object.class);
				criteria = (Criteria) opMethod.invoke(path, operands.get(0));
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + operator + "(Object)", e);
			}
		}
		
		//single criteria
		if(criteria!=null && criteria.getAllCriterion()!=null){
			criteria.getCriterion(0).setDisabled(this.disabled);
		}
		
		return criteria;
	}

	private boolean isCompareOperator() {
	    List<String> compareOperatorStringsList = Lists.newArrayList(Op.eq.toString().toLowerCase(),Op.ge.toString().toLowerCase(),
										   Op.le.toString().toLowerCase(),Op.lt.toString().toLowerCase(),
										   Op.ne.toString().toLowerCase(),Op.gt.toString().toLowerCase());
		return compareOperatorStringsList.contains(operator.toLowerCase());
    }
	
	/**
	 * Suppose a count aggregation on a string value column, the terminatingItemType will be detected as string, 
	 * which results in the operands being formatted as string while it should be formatted as number since the aggregation measure is count.</br>
	 * So this method provides you the ability of explicitly passing in the terminatingItemType.</br>
	 * If the terminatingItemType could be detected from the path, just pass null in.
	 * @param dictionary
	 * @param terminatingItemType
	 * @return
	 */
	public Criteria toSingleFurtherCriteria(Dictionary dictionary, Class<?> terminatingItemType){
		
		if(dataSelection==null) 
			return null;
		
		Criteria criteria = null;
			
		if (Op.like.toString().equalsIgnoreCase(operator) || Op.likeObjectString.toString().equalsIgnoreCase(operator)) {
			if(operandsString.isEmpty()){
				criteria = dataSelection.likeObjectString(operandsString.get(0));
			}
			return criteria;
		}
		
		DataPath path = getPathFromPathString(dictionary, pathString);
		
		Class<?> itemType = terminatingItemType == null ? path.getTerminatingItem().getJavaSimpleType() : terminatingItemType;
		Class<?> domainClass=path.getTerminatingItem().getDomain().getDomainClass();
		List<Comparable<?>> operands=formatOperands(itemType, domainClass);
		
		criteria = generateCriteriaWithDiffOperators(criteria, path, operands);
		
		//single criteria
		if(criteria!=null && criteria.getAllCriterion()!=null){
			criteria.getCriterion(0).setDisabled(this.disabled);
		}
		
		return criteria;
	}

	private Criteria generateCriteriaWithDiffOperators(Criteria criteria, DataPath path, List<Comparable<?>> operands) {
		Criteria localCriteria = criteria;
		final boolean compareOperator = isCompareOperator();
		
		if (Op.in.toString().equalsIgnoreCase(operator)) {
			localCriteria = dataSelection.in((List) operands);
		}else if (Op.between.toString().equalsIgnoreCase(operator)) {
			localCriteria = dataSelection.between((Comparable) operands.get(0), (Comparable) operands.get(1));
		}else if (Op.isNull.toString().equalsIgnoreCase(operator)) {
			Method opMethod = null;
			try {
				opMethod = DataSelection.class.getMethod(operator);
				localCriteria = (Criteria) opMethod.invoke(dataSelection);
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + operator, e);
			}
		}else if ("notIn".equalsIgnoreCase(operator)) {
			Method opMethod = null;
			try {
				opMethod = DataPath.class.getMethod(Op.in.toString(),Collection.class);
				localCriteria = (Criteria) opMethod.invoke(path,operands);
				localCriteria = localCriteria.not();
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + Op.in.toString() + "(Collection)", e);
			}
		}
		else if ("isNotNull".equalsIgnoreCase(operator)){
			Method opMethod = null;
			try {
				opMethod = DataSelection.class.getMethod(Op.isNull.toString());
				localCriteria = (Criteria) opMethod.invoke(dataSelection);
				localCriteria = localCriteria.not();
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + Op.isNull.toString(), e);
			}
		}
		else if (compareOperator) {
			Method opMethod = null;
			try {
				opMethod = DataSelection.class.getMethod(operator, Comparable.class);
				localCriteria = (Criteria) opMethod.invoke(dataSelection, operands.get(0));
			} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new InvokeException("Fail to invoke method " + operator + "(Comparable)", e);
			}
		}
	    return localCriteria;
    }

	protected List<Comparable<?>> formatOperands(Class<?> terminatingItemType, Class<?> domainClass){
		List<Comparable<?>> operands = Lists.newArrayList();
		if(terminatingItemType==null || domainClass==null) 
			return operands;
		if (terminatingItemType.isEnum()) {
			for (String operand : operandsString) {
				dealWithOperandsWithEnumTerminatingItem(terminatingItemType, operands, operand);
			}
		} else if (terminatingItemType.getSuperclass() !=null && terminatingItemType.getSuperclass().equals(Number.class)) {
			for (String operand : operandsString) {
				dealWithNumberTerminatingItem(terminatingItemType, operands, operand);
			}
		} else if (Date.class.isAssignableFrom(terminatingItemType) && !TimeMark.class.isAssignableFrom(domainClass)){
			for (String operand : operandsString) {
				Date date = null;
				if (StringUtils.isNotBlank(operand)) {
					date = CustomDate.newDate(operand);
				}
				operands.add(date);
			}
        } else if (Boolean.class.isAssignableFrom(terminatingItemType)) {
            for (Object operand : operandsString) {
                dealWithBooleanTerminatingItem(operands, operand);
            }
        } else {
			operands = (List) operandsString;
		}

		return operands;
	}

	private void dealWithBooleanTerminatingItem(List<Comparable<?>> operands, Object operand) {
	    try {
	        Boolean value = operands.add(Boolean.valueOf(operand.toString()));
	        operands.add(value);
	    } catch (Exception e) {
	        throw new IllegalArgumentException("Fail to convert value to Boolean type", e);
	    }
    }

	private void dealWithNumberTerminatingItem(Class<?> terminatingItemType, List<Comparable<?>> operands,
            String operand) {
	    Constructor<?> constructor = null;
	    try {
	    	boolean hasBeenSet = false;
	    	if(this.dataSelection!=null && this.dataSelection.getSelectionItems()!=null){
	    		for(DataSelectionItem item : this.dataSelection.getSelectionItems()){
	    			hasBeenSet = addOperands(operands, operand, hasBeenSet, item);
	    		}
	    	}
	    	if(!hasBeenSet){
	    		constructor = terminatingItemType.getDeclaredConstructor(String.class);
	    		if(!operand.isEmpty())
	    			operands.add((Comparable<?>) constructor.newInstance(operand));
	    	}
	    } catch (Exception e) {
	    	throw new InvokeException("Fail to convert value to Number type", e);
	    }
    }

	private boolean addOperands(List<Comparable<?>> operands, String operand, boolean hasBeenSet, DataSelectionItem item) {
		boolean localHasBeenSet = hasBeenSet;
	    if(item.getCompareMeasure()!=null && item.getCompareMeasure().getMeasureName()!=null 
	    		&& (StringUtils.equalsIgnoreCase(item.getCompareMeasure().getMeasureName(), "DifferencePercentage")
	    		|| StringUtils.equalsIgnoreCase(item.getCompareMeasure().getMeasureName(),"DifferenceValue"))){
	    	localHasBeenSet=true;
	    	
	    	/**
	    	 * The return type of getDifferenceValue() and getDifferencePercentage() are hard-coded to Double in CompareResult class, 
	    	 * so we have to hard code here. Otherwise, for those whose terminatingItemType is Integer, the operand will be formatted as Integer, 
	    	 * while its DifferenceValue is hard coded as Double, which causes the filter not work right.
	    	 * 
	    	 * e.g, when GUI setting filter on historical column 'Txn Count', assume its compare measure is differenceValue, 
	    	 * the filter operand will be formatted as 10, but the differenceValue is 10.0, 10(Integer)!=10.0(Double),
	    	 * so GUI will not show 10.0, obviously this is not right.
	    	 */
	    	operands.add(Double.parseDouble(operand));
	    }
	    return localHasBeenSet;
    }

	private String dealWithOperandsWithEnumTerminatingItem(Class<?> terminatingItemType, List<Comparable<?>> operands,
            String operand) {
		String localOperand = operand;
	    if (EnumUtils.isValidEnum((Class) terminatingItemType, operand)) {
	    	operands.add(Enum.valueOf((Class) terminatingItemType, operand));
	    } else {
	    	boolean islowerCase = false;
	    	List<?> enumConstants = Arrays.asList(terminatingItemType.getEnumConstants());
	    	for(Object enumConstant: enumConstants){
	    		if(enumConstant.toString().equalsIgnoreCase(operand)){
	    			localOperand = enumConstant.toString();
	    			operands.add(Enum.valueOf((Class) terminatingItemType, localOperand));
	    			islowerCase = true;
	    			break;
	    		}
	    	}
	    	if(!islowerCase)
	    		{operands.add(localOperand);}
	    }
	    return localOperand;
    }

	public static LinkedHashMap<String, Object> convertCriterionToMap(Criterion<?> criterion, String itemName, boolean aliasEnabled, CacheService cacheService) {
		LinkedHashMap<String, Object> mapItem = new LinkedHashMap<>();
		if (criterion == null) {
			return mapItem;
		}
		Class<?> dataType = criterion.getDataSelectionItem().getUnderlyingPath().getTerminatingItem().getJavaSimpleType();
		String pathString=criterion.getDataSelectionItem().getUnderlyingPath().toPathString(); 
		// Need relative time point later to reset to time mark to compare to get formatted display label. JIRA 2279. 
		RelativeTimePoint relativeTimePoint = criterion.getDataSelectionItem().getCompareMeasure()==null?
				null:((TimeMarkCompareMeasure)criterion.getDataSelectionItem().getCompareMeasure()).getRelativeTimePoint();
		mapItem.put("relativeTimePoint", relativeTimePoint);
		mapItem.put("pathString", pathString);
		mapItem.put("itemName", itemName);
		mapItem.put("dataTypeString", DataTypeUtil.getDataTypeString(dataType));
		mapItem.put("isNegated", criterion.isNegated());
		List<String> operandsValue = new ArrayList<>();
		for (Object operand : criterion.getAllOperands()) {
			if((operand instanceof Date) && (dataType.isAssignableFrom(Date.class))){
				operandsValue.add(CustomDate.toDefaultDisplayString(operand));
			}else if(cacheService.isTerminatingItemTimeMarkKey(pathString)){
				operandsValue.add(cacheService.getUIDisplayString(pathString, operand.toString()));
			} else if (null == operand) {
				operandsValue.add(null);
			} else{
				operandsValue.add(operand + "");	
			}
		}
		if(isNullOrEmptyOperator(criterion)){
			mapItem.put("operator", IS_NULL_OR_EMPTY);
			mapItem.put("operandsString", Lists.newArrayList());
		}else{
			mapItem.put("operator", criterion.getOP());
			mapItem.put("operandsString", operandsValue);
		}
		mapItem.put("disabled", criterion.isDisabled());
		mapItem.put("repetitiveRatio", criterion.getDataSelectionItem().getUnderlyingPath().getTerminatingItem().getRepetitiveRatio().getRatio());
		composeFurtherCriterionMap(criterion.getDataSelectionItem(), mapItem, itemName);
		
		LOGGER.info("aliasEnable: " + aliasEnabled);
		return mapItem;
	}

	private static boolean isNullOrEmptyOperator(Criterion<?> criterion) {
		if (criterion.getOP().equals(Op.in) && CollectionUtils.isNotEmpty(criterion.getAllOperands()) && criterion.getAllOperands().contains("")) {
			for(Object o : criterion.getAllOperands()) {
				if (o == null) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * There is no property in Criterion which can indicate whether the criterion is a further criterion or not, the following method 
	 * use regular expression to detect the further information from the dataSelectionItem.toString() result, if dataSelectionItem.toString()
	 * is changed, this method and its related functions will be impacted.
	 * @param dataSelectionItem
	 * @param mapItem
	 */
	private static void composeFurtherCriterionMap(DataSelectionItem<?, ?> dataSelectionItem, Map<String, Object> mapItem, String itemName) {
		if(dataSelectionItem==null || mapItem==null) 
			return;
		String dataSelectionInfo=dataSelectionItem.toString();
		String path=dataSelectionItem.getUnderlyingPath().toPathString();
		if(dataSelectionInfo==null || dataSelectionInfo.length()==0) 
			return;
		
		int aggregationInfoIndex=dataSelectionInfo.indexOf("with");
		int comparisonInfoIndex = dataSelectionInfo.indexOf("compareWith");
		
		setComparisonInfoWithDiffIndex(mapItem, itemName, dataSelectionInfo, path, aggregationInfoIndex,
                comparisonInfoIndex);
	}

	private static void setComparisonInfoWithDiffIndex(Map<String, Object> mapItem, String itemName,
            String dataSelectionInfo, String path, int aggregationInfoIndex, int comparisonInfoIndex) {
	    if(aggregationInfoIndex!=-1 && comparisonInfoIndex==-1){
			String regex="[a-zA-Z0-9]+-(\\w*\\.(?![0-9])\\w*)+";
			String qualifiedAggregationMeasureInfo=getSingleMatcher(regex, dataSelectionInfo);
			setAggregationInfo(qualifiedAggregationMeasureInfo, mapItem);
		}else if(aggregationInfoIndex==-1 && comparisonInfoIndex!=-1){
			String regex="compareWith(\\s*[0-9a-zA-Z~])*";
			String comparisonInfo=getSingleMatcher(regex, dataSelectionInfo);
			setComparisonInfo(comparisonInfo, mapItem, path, itemName);

		}else if(aggregationInfoIndex!=-1 && comparisonInfoIndex!=-1){
			String regex="[a-zA-Z0-9]+-(\\w*\\.(?![0-9])\\w*)+|compareWith(\\s*[0-9a-zA-Z~])*";
			List<String> aggreAndComparInfo=getMatchers(regex, dataSelectionInfo);
			String qualifiedAggregationMeasureInfo;
			String comparisonInfo;
			if(aggreAndComparInfo.size()==2){
				qualifiedAggregationMeasureInfo=aggreAndComparInfo.get(0);
				setAggregationInfo(qualifiedAggregationMeasureInfo,mapItem);
				
				comparisonInfo=aggreAndComparInfo.get(1);
				setComparisonInfo(comparisonInfo, mapItem, path, itemName);

			}
		}
    }
	
	private static void setAggregationInfo(String qualifiedAggregationMeasureInfo, Map<String, Object> mapItem){
		if(qualifiedAggregationMeasureInfo==null || mapItem==null) 
			return;
		mapItem.put("aggregationMeasure", qualifiedAggregationMeasureInfo);
		mapItem.put("isForAggregatedColumn", true);
	}

	private static void setComparisonInfo(String comparisonInfo, Map<String, Object> mapItem, String path, String itemName){
		if(comparisonInfo==null || mapItem==null || path==null) 
			return;

		String regex="([\\w~]+)*\\sby\\s([a-zA-Z])*";
		Pattern p = Pattern.compile(regex);
		String comparedResult;
		Matcher m = p.matcher(comparisonInfo);
		if (m.find()) {
			comparedResult = m.group();
		} else {
			return;
		}
		String[] results = comparedResult.split(DataSelectionItem.COMPARE_TIMEMARK_SEPARATOR);
		String comparedTimekey = results[0];
		String compareMeasureName = results[1];

		if(compareMeasureName!=null){
			mapItem.put("isForHistoricalColumn", true);
			mapItem.put("compareMeasureName", compareMeasureName);
			RelativeTimePoint relativeTimePoint = (RelativeTimePoint)mapItem.get("relativeTimePoint");

			String histColumnHeaderName = 
					getHistColumnHeaderName(itemName, compareMeasureName, comparedTimekey, relativeTimePoint);

			mapItem.put("compareTimeoffset", comparedTimekey);
			mapItem.put("histColumnHeaderName", histColumnHeaderName);
		}
	}

	public static String getHistColumnHeaderName(String itemName, String compareMeasureName, 
			String nonControlledTimeMarkKey, RelativeTimePoint relativeTimePoint) {
		String histColumnHeaderName = itemName;
		if(StringUtils.equalsIgnoreCase(compareMeasureName,"DifferencePercentage")){
			histColumnHeaderName += " Diff% ";
		}else if(StringUtils.equalsIgnoreCase(compareMeasureName,"DifferenceValue")){
			histColumnHeaderName += " Diff ";
		}else if(StringUtils.equalsIgnoreCase(compareMeasureName,"AbsoluteDiffValue")){
			histColumnHeaderName += " AbsDiff ";
		}else{
			histColumnHeaderName += " ";
		}
		// Reset relative time point to time mark to compare to get formatted display label. JIRA 2279. 
		TimeMark timeMark = DefaultTimeMark.getTimeMarkfromKey(nonControlledTimeMarkKey);
		((DefaultTimeMark)timeMark).setRelativeTimePoint(relativeTimePoint);
		histColumnHeaderName += "("+CustomDate.getFormattedUIStringForTimeMark(timeMark)+")";

		return histColumnHeaderName;
	}
	
	private static List<String> getMatchers(String regex, String source){
		List<String> results=Lists.newArrayList();
		if(regex==null || source==null) 
			return results;
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(source);
		while (m.find()) {
			results.add(m.group());
		}
		return results;
	}
	
	private static String getSingleMatcher(String regex, String source){
		String result=null;
		if(regex==null || source==null) 
			return result;
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(source);
		if(m.find()){
			result=m.group();
		}
		return result;
	}
	
	public static class InvokeException extends RuntimeException{
		public InvokeException() {
			super();
		}
		
		public InvokeException(String error, Throwable e){
			super(error, e);
		}
	}
}
