package com.citi.risk.core.application.bean;

public class BatchFrequencyBean {
	String key = null;

	public BatchFrequencyBean(String key) {
		super();
		this.key = key;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}


}
