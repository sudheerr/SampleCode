package com.citi.risk.core.application.bean;

public class TableHeaderColumn {
	private String header;
	private String dataIndex;
	private String path;
	private int width = 150;

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getDataIndex() {
		return dataIndex;
	}

	public void setDataIndex(String dataIndex) {
		this.dataIndex = dataIndex;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public TableHeaderColumn(String header, String dataIndex, String path) {
		this.header = header;
		this.dataIndex = dataIndex;
		this.path = path;
	}

}
