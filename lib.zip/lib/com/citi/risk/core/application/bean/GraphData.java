package com.citi.risk.core.application.bean;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;

public class GraphData {

	private String xField;
	private List<String> yField;
	private Map<String, List<Object>> graphData;

	public String getxField() {
		return xField;
	}

	public void setxField(String xField) {
		this.xField = xField;
	}

	public List<String> getyField() {
		return yField;
	}

	public void setyField(List<String> yField) {
		this.yField = yField;
	}

	public Map<String, List<Object>> getGraphData() {
		return graphData;
	}

	public void setGraphData(Map<String, List<Object>> graphData) {
		this.graphData = graphData;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder("{xField:'");
		result.append(xField);
		result.append("',yField:[");
		for(String yValue : yField){
			result.append("'").append(yValue).append("',");
		}
		if(result.toString().endsWith(",")){
			result.deleteCharAt(result.length() - 1);
		}
		result.append("]");
		result.append(",data:[");

		Set<String> graphDataKeys = graphData.keySet();
		for(String graphDataKey : graphDataKeys){
			result.append("{'");
			result.append(xField).append("':'").append(graphDataKey).append("',");
			Collection<Object> graphDataValues = graphData.get(graphDataKey);
			Iterator<Object> iterator = graphDataValues.iterator();
			int index = 0;
			while(iterator.hasNext()){
				Object object = iterator.next();
				result.append("'").append(yField.get(index++));
				if(object instanceof Number){
					result.append("':").append(object).append(",");
				}else{
					result.append("':'").append(object.toString()).append("',");
				}
			}
			if(result.toString().endsWith(",")){
				result.deleteCharAt(result.length() - 1);
			}
			result.append("},");
		}

		if(result.toString().endsWith(",")){
			result.deleteCharAt(result.length() - 1);
		}
		result.append("]}");
		return result.toString();

	}

}
