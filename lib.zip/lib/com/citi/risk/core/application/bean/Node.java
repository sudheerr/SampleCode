package com.citi.risk.core.application.bean;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.application.impl.DataTypeUtil;
import com.citi.risk.core.dictionary.api.DDType;
import com.citi.risk.core.dictionary.api.DomainGraphPath;
import com.citi.risk.core.dictionary.api.ItemList;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.Prominence;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;

/**
 * @author rl57434
 *
 */
public class Node {

	private transient DataPath nodePath;
	private String path;
	private String facadePathString;
	private String text;
	private String alias;
	private Boolean leaf = false;
	private Boolean expanded = false;
	private Boolean lookupable = false;
	private Boolean visible = true;
	private String dataTypeString;
	private Boolean measure;
	private Boolean isItemList;
	private String qtip;
	private Prominence prominence = Prominence.Low;
	private List<Node> children;

	private String groupId;
	private Boolean isGroupable = false;
	private Boolean underCollection = false;
	private int repetitiveRatio = -1;

	private transient List<String> parentTags;

	public static final boolean LEAFTRUE = true;
	public static final boolean PARENT = false;

	private Boolean renamed = false;
	private Boolean deleted = false;
	private Boolean shared = false;
	private Boolean shareUpdated = false;
	private Integer value;
	private Integer fromValue;
	private List<Integer> route;

	public Node(String text, DataPath nodePath, Boolean leaf) {
		this.text = text;
		this.nodePath = nodePath;
		this.path = nodePath!=null?nodePath.toPathString():null;
		this.leaf = leaf;

		this.lookupable = checkLookUpAble(nodePath);
		this.dataTypeString = convertDataTypeFromPath(nodePath);
		this.repetitiveRatio = nodePath!=null?nodePath.getRepetitiveRatio():-1;
		/* If the children of a node is not null, then the node will be treated as loaded
		 * which result in the GUI tree cannot expand the node to load data.
		 * changing it back, as the tree has to be loaded only once. it shouldn't have to go back to server for expands.
		 */
	}

	public Node(String text, String alias, DataPath nodePath, Boolean leaf) {
		this(text, nodePath, leaf);
		this.alias = alias;
	}
	
	public Node(String text, DataPath nodePath, Boolean leaf, Boolean measure, Boolean isItemList, Prominence prominence) {
		this(text, nodePath, leaf);
		this.measure = measure;
		this.isItemList = isItemList;
		this.prominence = prominence;
	}

	public Node(String text, String alias, DataPath nodePath, Boolean leaf, Boolean measure, Boolean isItemList, Prominence prominence) {
		this(text, nodePath, leaf, measure, isItemList, prominence);
		this.alias = alias;
	}

	public Node(String text, String alias, DataPath nodePath, Boolean leaf, Boolean measure, Boolean isItemList, Prominence prominence, String[] labels) {
		this(text, alias, nodePath, leaf, measure, isItemList, prominence);
		this.qtip = convertLabelsToString(labels);
	}

	public Node(DomainGraphPath domainGraphPath){
		this(domainGraphPath.getTerminatingMember().getName(),
				domainGraphPath.getTerminatingMember().getAlias(),
				domainGraphPath.getGraphPath(),
				(domainGraphPath.getGraphPath().getDDType() == DDType.ITEM) || (domainGraphPath.getGraphPath().getDDType() == DDType.ITEMLIST),
				!domainGraphPath.getTerminatingMember().isDimension(),
				domainGraphPath.getGraphPath().getDDType() == DDType.ITEMLIST,
				domainGraphPath.getTerminatingMember().getProminence(),
				domainGraphPath.getGraphPath().getDDType() == DDType.ITEMLIST ? ((ItemList)domainGraphPath.getTerminatingMember()).getLabels():null
				);
	}

	public Node(String text, List<String> parentTags, DataPath nodePath, Boolean leaf) {
		this(text, nodePath, leaf);
		this.parentTags = parentTags;
		if (children == null) {
			children = new ArrayList<>();
		}
	}

	public Node(String text, List<Node> children) {
		this.text = text;
		this.children = children;
		this.isGroupable = true;
		this.leaf = false;
		this.lookupable = true;
	}

	public void addChild(DataPath<?,?> path) {
		List<String> parentTagList = Lists.newArrayList();

		parentTagList.add(path.getStartingDomain().getName());
		for (DataRelationship relationship : path.getRelationships()) {
			parentTagList.add(relationship.getName());
		}

		String parentTagString = StringUtils.join(parentTags, ",");
		String childTagString = StringUtils.join(parentTagList, ",");
		
		if (childTagString.indexOf(parentTagString) == -1) {
            return;
        }

        if (parentTagList.size() - parentTags.size() > 0) {
            List<String> parentTags0 = Lists.newArrayList();

            for (int i = 0; i < parentTags.size() + 1; i++) {
                parentTags0.add(parentTagList.get(i));
            }
            String nodeName = parentTags0.get(parentTags0.size() - 1);
            for (Node node : children) {
                if (StringUtils.equals(node.getText(), nodeName) && !node.getLeaf()) {
                    node.addChild(path);
                    return;
                }
            }
            Node subNode = new Node(nodeName, parentTags0, path, false);
            subNode.addChild(path);
            children.add(subNode);
        }

        addTerminatingSubNode(path, parentTagList);
	}

    private void addTerminatingSubNode(DataPath<?, ?> path, List<String> parentTagList) {
        if (parentTagList.size() == parentTags.size()) {
            if (DDType.ITEM.equals(path.getDDType())) {
                Node subNode = new Node(path.getTerminatingItem().getName(), parentTagList, path, true);
                if (!this.getLeaf()) {
                    children.add(subNode);
                }
            }
            if (DDType.RELATIONSHIP.equals(path.getDDType()) && !this.nodePath.equals(path)) {
                String localText = parentTagList.get(parentTagList.size() - 1);
                Node subNode = new Node(localText, parentTagList, path, false);
                children.add(subNode);
            }
        }
    }

	public void initChildren() {
		if(!leaf)
			this.children= new ArrayList<>();
	}	

	private Boolean checkLookUpAble(DataPath nodePath) {
		if (nodePath == null) {
			return false;
		}
		if (!nodePath.isTerminatedWithAnItem()) {
			return false;
		}
		if (nodePath.getTerminatingItem().isKey() || nodePath.getTerminatingItem().isName()) {
			return true;
		}
		return false;
	}

	private String convertDataTypeFromPath(DataPath nodePath) {
		if (nodePath == null) {
			return null;
		}
		if (!nodePath.isTerminatedWithAnItem()) {
			return null;
		}

		Class<?> simpleDataType = nodePath.getTerminatingItem().getJavaSimpleType();
		return DataTypeUtil.getDataTypeString(simpleDataType);
	}

	private String convertLabelsToString(String[] labels){
		return StringUtils.join(labels, ", ");
	}

	@JsonIgnore
	public DataPath getNodePath() {
		return nodePath;
	}

	public void setNodePath(DataPath nodePath) {
		this.nodePath = nodePath;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getFacadePathString() {
		return facadePathString;
	}

	public void setFacadePathString(String facadePathString) {
		this.facadePathString = facadePathString;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public Boolean getLeaf() {
		return leaf;
	}

	public void setLeaf(Boolean leaf) {
		this.leaf = leaf;
	}

	public Boolean getExpanded() {
		return expanded;
	}

	public void setExpanded(Boolean expanded) {
		this.expanded = expanded;
	} 

	public Boolean getLookupable() {
		return lookupable;
	}

	public void setLookupable(Boolean lookupable) {
		this.lookupable = lookupable;
	}
	
	public Boolean getVisible() {
		return visible;
	}

	public void setVisible(Boolean visible) {
		this.visible = visible;
	}
	
	public String getDataTypeString() {
		return dataTypeString;
	}

	public void setDataTypeString(String dataTypeString) {
		this.dataTypeString = dataTypeString;
	}

	public Boolean getMeasure() {
		return measure;
	}

	public void setMeasure(Boolean measure) {
		this.measure = measure;
	}

	public Boolean getIsItemList() {
		return isItemList;
	}

	public void setIsItemList(Boolean isItemList) {
		this.isItemList = isItemList;
	}

	public String getQtip() {
		return qtip;
	}

	public void setQtip(String qtip) {
		this.qtip = qtip;
	}

	public Prominence getProminence() {
		return prominence;
	}

	public void setProminence(Prominence prominence) {
		this.prominence = prominence;
	}

	public List<Node> getChildren() {
		return children;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	public Boolean getIsGroupable() {
		return isGroupable;
	}

	public List<String> getParentTags() {
		return parentTags;
	}

	public Boolean getUnderCollection() {
		return underCollection;
	}

	public void setUnderCollection(Boolean underCollection) {
		this.underCollection = underCollection;
	}

	public int getRepetitiveRatio() {
		return repetitiveRatio;
	}

	public void setRepetitiveRatio(int repetitiveRatio) {
		this.repetitiveRatio = repetitiveRatio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dataTypeString == null) ? 0 : dataTypeString.hashCode());
		result = prime * result
				+ ((expanded == null) ? 0 : expanded.hashCode());
		result = prime * result
				+ ((isItemList == null) ? 0 : isItemList.hashCode());
		result = prime * result + ((qtip == null) ? 0 : qtip.hashCode());
		result = prime * result + ((leaf == null) ? 0 : leaf.hashCode());
		result = prime * result
				+ ((lookupable == null) ? 0 : lookupable.hashCode());
		result = prime * result + ((measure == null) ? 0 : measure.hashCode());
		result = prime * result
				+ ((nodePath == null) ? 0 : nodePath.hashCode());
		result = prime * result
				+ ((prominence == null) ? 0 : prominence.hashCode());
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		result = prime * result + ((underCollection == null) ? 0 : underCollection.hashCode());
		result = prime * result + prime*repetitiveRatio;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Node other = (Node) obj;
		if (dataTypeString == null) {
			if (other.dataTypeString != null)
				return false;
		} else if (!dataTypeString.equals(other.dataTypeString))
			return false;
		if (expanded == null) {
			if (other.expanded != null)
				return false;
		} else if (!expanded.equals(other.expanded))
			return false;
		if (isItemList == null) {
			if (other.isItemList != null)
				return false;
		} else if (!isItemList.equals(other.isItemList))
			return false;
		if (qtip == null) {
			if (other.qtip != null)
				return false;
		} else if (!qtip.equals(other.qtip))
			return false;
		if (leaf == null) {
			if (other.leaf != null)
				return false;
		} else if (!leaf.equals(other.leaf))
			return false;
		if (lookupable == null) {
			if (other.lookupable != null)
				return false;
		} else if (!lookupable.equals(other.lookupable))
			return false;
		if (measure == null) {
			if (other.measure != null)
				return false;
		} else if (!measure.equals(other.measure))
			return false;
		if (nodePath == null) {
			if (other.nodePath != null)
				return false;
		} else if (!nodePath.equals(other.nodePath))
			return false;
		if (prominence != other.prominence)
			return false;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		if (underCollection == null) {
			if (other.underCollection != null)
				return false;
		} else if (!underCollection.equals(other.underCollection))
			return false;
		if (repetitiveRatio != other.repetitiveRatio)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Node [nodePath=" + nodePath + ", text=" + text + ", leaf="
				+ leaf + ", expanded=" + expanded + ", lookupable="
				+ lookupable + ", dataType=" + dataTypeString + ", measure="
				+ measure + ", isItemList=" + isItemList + ", qtip=" + qtip
				+ ", prominence=" + prominence + "], repetitiveRatio=" + repetitiveRatio;
	}

	public Boolean isRenamed() {
		return renamed;
	}

	public void setRenamed(Boolean isRenamed) {
		this.renamed = isRenamed;
	}

	public Boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean isDeleted) {
		this.deleted = isDeleted;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public Integer getFromValue() {
		return fromValue;
	}

	public void setFromValue(Integer fromValue) {
		this.fromValue = fromValue;
	}

	public Boolean isShared() {
		return shared;
	}

	public void setShared(Boolean isShared) {
		this.shared = isShared;
	}

	public Boolean isShareUpdated() {
		return shareUpdated;
	}

	public void setShareUpdated(Boolean shareUpdated) {
		this.shareUpdated = shareUpdated;
	}

	public List<Integer> getRoute() {
		return route;
	}

	public void setRoute(List<Integer> route) {
		this.route = route;
	}
}
