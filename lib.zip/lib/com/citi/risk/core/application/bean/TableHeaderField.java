package com.citi.risk.core.application.bean;

public class TableHeaderField {
	private String header;
	private String name;
	private String path;
	int serial;
	private Boolean editable = false;
	private String type = "string";
	private Boolean measure = false;

	public TableHeaderField(String header, String name, String path, int serial) {
		this.header = header;
		this.name = name;
		this.path = path;
		this.serial = serial;
	}

	public TableHeaderField(String header, String name, String path, int serial, Boolean editable, String type) {
		this(header, name, path, serial);
		this.editable = editable;
		this.type = type;
	}

	public TableHeaderField(String header, String name, String path, Boolean editable, String type) {
		this(header, name, path, 0, editable, type);
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getSerial() {
		return serial;
	}

	public void setSerial(int serial) {
		this.serial = serial;
	}

	public Boolean getEditable() {
		return editable;
	}

	public void setEditable(Boolean editable) {
		this.editable = editable;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Boolean getMeasure() {
		return measure;
	}

	public void setMeasure(Boolean measure) {
		this.measure = measure;
	}
}