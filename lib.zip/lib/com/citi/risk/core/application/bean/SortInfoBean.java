package com.citi.risk.core.application.bean;

public class SortInfoBean {
	private String property = null;
	private String direction = null;

	public SortInfoBean(String property, String direction) {
		super();
		this.property = property;
		this.direction = direction;
	}

	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}



}
