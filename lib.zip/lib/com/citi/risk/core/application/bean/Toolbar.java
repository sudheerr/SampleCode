package com.citi.risk.core.application.bean;

import java.util.List;

import com.google.common.collect.Lists;
import com.google.gson.Gson;

public class Toolbar {
	private List<ToolbarElement> elements = Lists.newLinkedList();

	public void addElement(ToolbarElement element) {
		elements.add(element);
	}

	@Override
	public String toString() {
		Gson gson = new Gson();
		return gson.toJson(elements);
	}

}
