package com.citi.risk.core.application.bean;

import com.google.common.collect.Ordering;

public class CacheLoaderItem {

	private String name;
	private String key;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public CacheLoaderItem(String name, String key) {
		super();
		this.name = name;
		this.key = key;
	}

	public static final Ordering<CacheLoaderItem> byCacheLoaderkeyOrdering = new Ordering<CacheLoaderItem>() {
		@Override
		public int compare(CacheLoaderItem left, CacheLoaderItem right) {
			return Ordering.natural().compare(left.getKey(),right.getKey());
		}
	};

}
