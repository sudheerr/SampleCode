package com.citi.risk.core.application.bean;

import com.citi.risk.core.application.api.*;
import com.citi.risk.core.application.impl.DataTypeUtil;
import com.citi.risk.core.application.impl.DefaultTableBasedElement;
import com.citi.risk.core.dictionary.api.*;
import com.citi.risk.core.lang.compare.QueryCompareMeasure;
import com.citi.risk.core.navigator.api.NavigatorColumnHeader;
import com.citi.risk.core.navigator.impl.DefaultNavigatorColumnHeader;
import com.citi.risk.core.navigator.widget.api.NavigatorWidget;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Column header used for {@link TableBasedElement}
 *
 * @author zg76836
 *
 */

@Entity
@Table(name = "ColumnHeader")
public class ColumnHeader implements Serializable, Cloneable, NavigatorWidget<NavigatorColumnHeader>, ViewComponent, HasRoot<Perspective>{
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ColumnHeader.class);

	private static final String HEADER_NAME_SEPERATOR = ">";

	private TableBasedElement tableBasedElement;
	private transient DataSelectionItem dataSelectionItem;
	private String headerName = null;
	private String groupName = null;
	private Boolean editable = false;
	private Boolean isKey = false;
	private Boolean isMeasure = false;
	private Boolean isMovementEnabled=false;
	private Boolean isItemList = false;
	private String tooltip;
	private Boolean isSubTotalOn;

	private DataPath path;

	@Enumerated(EnumType.STRING)
	private SortBy sortBy;
	private Integer sortIndex;

	private AggregateMeasure<?, ?> selectedAggregateMeasure = null;
	private QueryCompareMeasure queryCompareMeasure = null;
	private List<Map<String, String>> availableAggregateMeasureList = null;

	private NavigatorColumnHeader navigatorColumnHeader = new DefaultNavigatorColumnHeader();


	public ColumnHeader(String chstring){
		super();
		String chsplits[] = chstring.split("!");
		this.aggregateMeasureString = chsplits[0];
		this.compareMeasureString = chsplits[1];
		this.description = chsplits[2];
		this.displayAlign = chsplits[3];
		this.pathString = chsplits[4];

	}

	public ColumnHeader(DataSelectionItem dataSelectionItem) {
		this(dataSelectionItem.getUnderlyingPath(), dataSelectionItem.getSortBy());
		this.dataSelectionItem = dataSelectionItem;
		this.selectedAggregateMeasure = dataSelectionItem.getSelectedAggregateMeasure();
		this.queryCompareMeasure = dataSelectionItem.getCompareMeasure();
	}

	public ColumnHeader(DataPath path, AggregateMeasure<?, ?> selectedAggregateMeasure, SortBy sortBy) {
		this(path, sortBy);
		this.selectedAggregateMeasure = selectedAggregateMeasure;
	}

	public ColumnHeader(DataPath path, SortBy sortBy) {
		this.path = path;
		this.sortBy = sortBy;
		this.headerName = convertPathToString(path);
		this.dataTypeString = convertDataTypeFromPath(path);
		this.editable = checkEditable(path);
		this.isKey = checkIsKey(path);
		this.isItemList = path.getDDType().equals(DDType.ITEMLIST)?true:false;
	}

	@Transient
	public List<Map<String, String>> getAvailableAggregateMeasureList() {
		return availableAggregateMeasureList;
	}

	public void setAvailableAggregateMeasureList(
			List<Map<String, String>> availableAggregateMeasureList) {
		this.availableAggregateMeasureList = availableAggregateMeasureList;
	}

	@JsonIgnore
	@Transient
	public QueryCompareMeasure getQueryCompareMeasure() {
		return queryCompareMeasure;
	}

	public void setQueryCompareMeasure(QueryCompareMeasure queryCompareMeasure) {
		this.queryCompareMeasure = queryCompareMeasure;
	}

	Boolean checkEditable(DataPath path) {
		if (path == null) {
			return false;
		}
		if (!path.isTerminatedWithAnItem()) {
			return false;
		}

		if (path.getTerminatingItem().path().getTerminatingItem().isEditable()) {
			return true;
		}

		return false;
	}

	Boolean checkIsKey(DataPath path) {
		if (path == null) {
			return false;
		}
		if (!path.isTerminatedWithAnItem()) {
			return false;
		}

		if (path.getTerminatingItem().path().getTerminatingItem().isKey()) {
			return true;
		}

		return false;
	}

	private String convertPathToString(DataPath path) {
		if (path == null) {
			return null;
		}

		StringBuilder localheaderName = new StringBuilder();
		List<DataRelationship> allRelationship = path.getRelationships();

		for (DataRelationship relationship : allRelationship) {
			localheaderName.append(relationship.getName() + HEADER_NAME_SEPERATOR);
		}
		if(path.isTerminatedWithAnItem()) {
			if(DDType.ITEMLIST==path.getDDType()){
				ItemList itemList=(ItemList)path.getTerminatingItem();
				localheaderName.append(itemList.getName(path));
			}else {
				localheaderName.append(path.getTerminatingItem().getName());
			}
		}
		return localheaderName.toString();
	}

	private String convertDataTypeFromPath(DataPath nodePath) {
		if (nodePath == null) {
			return null;
		}
		if (!nodePath.isTerminatedWithAnItem()) {
			return null;
		}

		Class<?> simpleDataType = nodePath.getTerminatingItem().getJavaSimpleType();
		return DataTypeUtil.getDataTypeString(simpleDataType);
	}

	@Transient
	public String getHeaderName() {
		return headerName;
	}

	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

	@Transient
	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	@JsonIgnore
	@Transient
	public DataSelectionItem getDataSelectionItem() {
		return dataSelectionItem;
	}

	public void setDataSelectionItem(DataSelectionItem dataSelectionItem) {
		this.dataSelectionItem = dataSelectionItem;
	}

	@Transient
	public Boolean getEditable() {
		return editable;
	}

	public void setEditable(Boolean editable) {
		this.editable = editable;
	}

	@Transient
	public Boolean getIsKey() {
		return isKey;
	}

	public void setIsKey(Boolean isKey) {
		this.isKey = isKey;
	}

	@JsonIgnore
	@Transient
	public DataPath getPath() {
		return path;
	}

	public void setPath(DataPath path) {
		this.path = path;
	}

	public SortBy getSortBy() {
		return sortBy;
	}

	public void setSortBy(SortBy sortBy) {
		this.sortBy = sortBy;
	}

	public Integer getSortIndex() {
		return sortIndex;
	}

	public void setSortIndex(Integer sortIndex) {
		this.sortIndex = sortIndex;
	}

	@JsonIgnore
	@Transient
	public AggregateMeasure<?, ?> getSelectedAggregateMeasure() {
		return selectedAggregateMeasure;
	}

	public void setSelectedAggregateMeasure(
			AggregateMeasure<?, ?> selectedAggregateMeasure) {
		this.selectedAggregateMeasure = selectedAggregateMeasure;
	}

	@Transient
	public Boolean getIsMeasure() {
		return isMeasure;
	}

	public void setIsMeasure(Boolean isMeasure) {
		this.isMeasure = isMeasure;
	}

	@Transient
	public Boolean getIsMovementEnabled() {
		return isMovementEnabled;
	}

	public void setIsMovementEnabled(Boolean isMovementEnabled) {
		this.isMovementEnabled = isMovementEnabled;
	}

	@Transient
	public Boolean getIsItemList() {
		return isItemList;
	}

	public void setIsItemList(Boolean isItemList) {
		this.isItemList = isItemList;
	}

	@Transient
	public String getTooltip() {
		return tooltip;
	}

	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}

	private Integer id;
	@ToBeCompared
	private String description;
	@ToBeCompared
	private String pathString;
	private String facadePathString;
	private String dataTypeString;
	private String displayAlign;
	@ToBeCompared
	private Integer displayIndex;
	@ToBeCompared
	private String aggregateMeasureString;
	@ToBeCompared
	private String compareMeasureString;
	private MeasureType measureTypeString;

	public ColumnHeader() {
		super();
	}

	@Transient
	public MeasureType getMeasureTypeString() {
		return measureTypeString;
	}

	public void setMeasureTypeString(MeasureType measureTypeString) {
		this.measureTypeString = measureTypeString;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ColumnHeader_Seq")  //generator setting in orm.xml in apps project 
	@Column(name = "id", nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	@Column(length = 250)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(nullable = false, length = 250)
	public String getPathString() {
		return pathString;
	}

	public void setPathString(String pathString) {
		this.pathString = pathString;
	}

	@Transient
	public String getFacadePathString() {
		return facadePathString;
	}

	public void setFacadePathString(String facadePathString) {
		this.facadePathString = facadePathString;
	}

	@Transient
	public String getDataTypeString() {
		return dataTypeString;
	}

	public void setDataTypeString(String dataTypeString) {
		this.dataTypeString = dataTypeString;
	}

	@Column(length = 50)
	public String getDisplayAlign() {
		return displayAlign;
	}

	public void setDisplayAlign(String displayAlign) {
		this.displayAlign = displayAlign;
	}

	public Integer getDisplayIndex() {
		return displayIndex;
	}

	public void setDisplayIndex(Integer displayIndex) {
		this.displayIndex = displayIndex;
	}

	@Column(length = 100)
	public String getAggregateMeasureString() {
		return aggregateMeasureString;
	}

	public void setAggregateMeasureString(String aggregateMeasureString) {
		this.aggregateMeasureString = aggregateMeasureString;
	}

	@Column(length = 100)
	public String getCompareMeasureString() {
		return compareMeasureString;
	}

	public void setCompareMeasureString(String compareMeasureString) {
		this.compareMeasureString = compareMeasureString;
	}

	@JsonIgnore
	@ManyToOne(targetEntity = DefaultTableBasedElement.class)
	@JoinColumn(name="elementId", insertable=true, updatable=true)
	public TableBasedElement getTableBasedElement() {
		return tableBasedElement;
	}

	@JsonProperty
	public void setTableBasedElement(TableBasedElement tableBasedElement) {
		this.tableBasedElement = tableBasedElement;
	}

	@Column(name = "isSubTotalOn")
	public Boolean isSubTotalOn() {
		return isSubTotalOn;
	}

	public void setSubTotalOn(Boolean isSubTotalOn) {
		this.isSubTotalOn = isSubTotalOn;
	}

	  /**
	    * @deprecated (when, why, refactoring advice...)
	    */
	@Deprecated
	public ColumnHeader copy(TableBasedElement tbe) {
		ColumnHeader column = null;
		try {
			column = (ColumnHeader) super.clone();
			column.setTableBasedElement(tbe);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy Column", e);
		}
		return column;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((path == null) ? 0 : path.hashCode());
		result = prime
				* result
				+ ((selectedAggregateMeasure == null) ? 0
				: selectedAggregateMeasure.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if(this == obj){
			return true;
		}
		if(obj == null){
			return false;
		}
		if(!(obj instanceof ColumnHeader)){
			return false;
		}
		ColumnHeader other = (ColumnHeader) obj;
		if(this.getHeaderName() == null){
			if(other.getHeaderName() != null){
				return false;
			}
		}else{
			if(!this.getHeaderName().equals(other.getHeaderName())){
				return false;
			}
		}
		if(this.getId() == null){
			if(other.getId() != null){
				return false;
			}
		}else{
			if(!this.getId().equals(other.getId())){
				return false;
			}
		}
		if(this.getIsKey() == null){
			if(other.getIsKey() != null){
				return false;
			}
		}else{
			if(!this.getIsKey().equals(other.getIsKey())){
				return false;
			}
		}
		if(this.getPathString() == null){
			if(other.getPathString() != null){
				return false;
			}
		}else{
			if(!this.getPathString().equals(other.getPathString())){
				return false;
			}
		}
		if(this.getEditable() == null){
			if(other.getEditable() != null){
				return false;
			}
		}else{
			if(!this.getEditable().equals(other.getEditable())){
				return false;
			}
		}
		if(this.getSelectedAggregateMeasure() == null){
			if(other.getSelectedAggregateMeasure() != null){
				return false;
			}
		}else{
			if(!this.getSelectedAggregateMeasure().equals(other.getSelectedAggregateMeasure())){
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		return "Column(" + headerName + "){" +
				" id = " + id +
				", aggregateMeasureString = " + aggregateMeasureString +
				", compareMeasureString = " + compareMeasureString +
				", description = " + description +
				", displayAlign = " + displayAlign +
				", displayIndex = " + displayIndex +
				", sortBy = " + sortBy +
				", sortIndex = " + sortIndex +
				", pathString = " + pathString +
				", elementId = " + (tableBasedElement != null ? tableBasedElement.getId() : null) +
				", isSubTotalOn = " + isSubTotalOn +
				"}";
	}

	@Override
	public Object clone() {

		ColumnHeader column = null;
		try {
			column = (ColumnHeader) super.clone();
			column.setId(null);
			column.setTableBasedElement(null);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy Column", e);
		}
		return column;
	}

	@Override
	@JsonIgnore
	@Transient
	public NavigatorColumnHeader getDefinition() {
		return navigatorColumnHeader;
	}

	@Override
	public void setDefinition(NavigatorColumnHeader navigatorColumnHeader) {
		this.navigatorColumnHeader = navigatorColumnHeader;
	}

	@Override
	@JsonIgnore
	@Transient
	public Perspective getRoot() {
		return getTableBasedElement().getView().getPerspective();
	}

	@Override
	@JsonIgnore
	@Transient
	public Boolean hasRoot() {
		return true;
	}
}
