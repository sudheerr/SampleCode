package com.citi.risk.core.application.bean;

import com.google.common.collect.Ordering;

public class DomainItem {
	private String name;
	private String key;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public DomainItem(String name, String key) {
		this.name = name;
		this.key = key;
	}

	public DomainItem(String name) {
		this.name = name;
		this.key = name;
	}

	public static final Ordering<DomainItem> byDomainNameOrdering = new Ordering<DomainItem>() {
		@Override
		public int compare(DomainItem left, DomainItem right) {
			return Ordering.natural().compare(left.getName(),right.getName());
		}
	};
}
