package com.citi.risk.core.application.impl;

import java.io.File;
import java.util.Collection;
import java.util.concurrent.ExecutionException;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.common.collect.Lists;
import com.google.inject.Inject;

public class DumpByTimeMarkNavigation extends DefaultNavigation {
	
	private static final String ITEMNAME = "Dump by TimeMark";
	
	@Inject
	private CacheManager cacheManager;
	
	public DumpByTimeMarkNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		String targetPathString = navigationParameter.getDumpLocation();
		if (!targetDirectoryValid(targetPathString)) {
			throw new RuntimeException("Target Directory Invalid!");
		}
		File targetDirectory = new File(targetPathString);
		if (!targetDirectory.exists()){
			targetDirectory.mkdirs();
		}

		TimeMark timeMark = navigationParameter.getTimeMark();
		Collection<TimeMark> timeMarks = Lists.newArrayList(timeMark);

		try {
			cacheManager.serializeToDisk(timeMarks, targetDirectory).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		
		return null;
	}
	
	private boolean targetDirectoryValid(String pathString) {
		if (pathString == null || pathString.length() <= 0)
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
