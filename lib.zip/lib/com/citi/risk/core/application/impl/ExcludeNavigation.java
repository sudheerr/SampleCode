package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.dictionary.api.Criteria;

public class ExcludeNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Exclude";
	private static final NavigationFlow TYPE = NavigationFlow.FILTER;
	
	public ExcludeNavigation() {
		super(ITEMNAME,TYPE);
	}
	
	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		View targetView = navigationParameter.getTargetView();
		CriteriaWrapper criteriaWrapper = navigationParameter.getExcludeCriteriaWrapper();
		Criteria criteria = criteriaWrapper.getNormalCriteria();
		
		if(targetView == null)
			throw new RuntimeException("cannot navigate to null");
		if(criteria == null){
			throw new RuntimeException("cannot exclude empty");
		}
		
		targetView.setGlobalCriteriaWrapper(criteriaWrapper);
		
		return targetView;
	}
}
