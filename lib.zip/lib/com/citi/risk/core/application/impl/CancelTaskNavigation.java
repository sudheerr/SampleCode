package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.api.Task;
import com.google.common.collect.Table;
import com.google.inject.Inject;

public class CancelTaskNavigation extends DefaultNavigation {
	
	private static final String ITEMNAME = "Cancel";
	
	@Inject
	ManagedExecutorService managedExecutorService;
	
	public CancelTaskNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		List<Long> keyList = populateKeyList(navigationParameter.getSimpleTable());
		for (Long taskId : keyList) {
			Task task = managedExecutorService.search(taskId);
			if(task!=null)
				task.cancel();
		}
		
		return null;
	}
	
	protected List<Long> populateKeyList(Table<Integer, DataSelectionItem, Object> selectedTable) {
		List<Long> keyList = new ArrayList<>();
		for (Map<DataSelectionItem, Object> row : selectedTable.rowMap().values()) {
			for (Entry<DataSelectionItem, Object> entry : row.entrySet()) {
				DataSelectionItem dataSelectionItem = entry.getKey();
				Object object = entry.getValue();
				if (dataSelectionItem.getUnderlyingPath().getTerminatingItem().isKey()) {
					keyList.add(Long.valueOf((String)object));
				}
			}
		}
		return keyList;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
