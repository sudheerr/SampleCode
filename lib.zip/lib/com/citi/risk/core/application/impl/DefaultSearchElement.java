package com.citi.risk.core.application.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.application.api.SearchElement;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.application.bean.Node;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataMember;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.api.ItemList;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.aggregate.ComparableAggregate;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

/**
 * Default implementation for SearchElement
 * 
 * @author ww78389
 * 
 */
public class DefaultSearchElement implements SearchElement {

	private static final  Logger logger = LoggerFactory.getLogger(DefaultSearchElement.class);
	private static final String FAIL_MESSAGE = "Failed to look up";

	private Query query;

	private static final int MAX_LOOKUP_ROW_COUNT = 100;

	/**
	 * A relationship of a domain is leaf in searchElement as a tree node
	 */
	private static final boolean LEAF = true;

	/**
	 * An item of a domain is not leaf in searchElement as a tree node
	 */
	private static final boolean NOT_LEAF = false;

	private ViewContext viewContext;
	
	private static final int CONTINUE_COMPARE = -2;

	private boolean treeNodeFullConstructed = false;

	@Override
	public Object clone() {
		//TODO
		throw new RuntimeException("Method is not implemented yet");
	}

	@Override
	public List<Node> onLoad() {
		if (this.getViewContext().getDomain() == null) {
			return Lists.newArrayList();
		}
		return populatePathList(this.getViewContext().getDomain());
	}

	@Override
	public List<Node> expand(DataPath currentPath) {
		checkExpandable(currentPath);
		DataDomain currentDomain = getCurrentDomain(currentPath);
		List<Node> pathList = populatePathList(currentDomain);
		appendPathListToCurrentPath(pathList, currentPath);
		return pathList;
	}

	private void appendPathListToCurrentPath(List<Node> pathList, DataPath currentPath) {
		for (Node node : pathList) {
			node.setPath(currentPath.append(node.getNodePath()).toPathString());
		}
	}

	private List<Node> populatePathList(DataDomain domain) {

		List<Node> pathList;
		if(!isTreeNodeFullConstructed())
			pathList = populatePathList4SimpleTreeNode(domain);
		else
			pathList = populatePathList4FullTreeNode(domain);

		return pathList;
	}

	/**
	 * Find Items and Relationships that belong to the given domain and populate
	 * the name, path, isExpandable of them in a List.
	 *
	 * @param domain
	 * @return
	 */
	private List<Node> populatePathList4SimpleTreeNode(DataDomain domain) {
		List<Node> pathList = Lists.newArrayList();
		Collection<DataItem> items = domain.getAllItems();
		Collection<DataRelationship> relationships = domain.getAllRelationships();
		if (items == null || relationships == null)
			throw new IllegalArgumentException("items or relationships of domain is null");
		for (DataItem item : items){
			Node node = new Node(item.getName(), item.getAlias(),item.path(), LEAF);
			node.setGroupId(item.getGroupId() == null ? "" : item.getGroupId());
			pathList.add(node);
		}
		for (DataRelationship relationship : relationships){
			Node node = new Node(relationship.getName(), relationship.getAlias(),relationship.path(), NOT_LEAF);
			node.setGroupId(relationship.getGroupId() == null ? "" : relationship.getGroupId());
			pathList.add(node);
		}

		return pathList;
	}

	private List<Node> populatePathList4FullTreeNode(DataDomain domain) {
		List<Node> pathList = Lists.newArrayList();
		List<DataItem> items = Lists.newArrayList(domain.getAllItems().iterator());
		List<ItemList> itemLists = Lists.newArrayList(domain.getAllItemLists().iterator());
		List<DataRelationship> relationships = Lists.newArrayList(domain.getAllRelationships().iterator());
		if (items == null || relationships == null)
			throw new IllegalArgumentException("items or relationships of domain is null");
		sort(relationships);
		for (DataRelationship relationship : relationships){
			Node node = new Node(relationship.getName(), relationship.getAlias(), relationship.path(), NOT_LEAF, false, false, relationship.getProminence());
			node.setGroupId(relationship.getGroupId() == null ? "" : relationship.getGroupId());
			pathList.add(node);
		}
		sort(items);
		for (DataItem item : items) {
			Node node = new Node(item.getName(), item.getAlias(), item.path(), LEAF, !item.isDimension(),
					false, item.getProminence());
			node.setGroupId(item.getGroupId() == null ? "" : item.getGroupId());
			pathList.add(node);
		}
		sort(itemLists);
		for (ItemList itemList : itemLists) {
			Node node = new Node(itemList.getName(), itemList.getAlias(), itemList.path(), LEAF, !itemList.isDimension(),
					true, itemList.getProminence(), itemList.getLabels());
			node.setGroupId(itemList.getGroupId() == null ? "" : itemList.getGroupId());
			pathList.add(node);
		}
		return pathList;
	}


	/**
	 * Get the domain specified by the given currentPath
	 *
	 * @param currentPath
	 * @return
	 */
	private DataDomain getCurrentDomain(DataPath<?,?> currentPath) {
		// the last relationship found in the current path is the current
		// relationship
		DataRelationship currentRelationship = currentPath.getRelationships().get(currentPath.getRelationships().size() - 1);
		return currentRelationship.getEndingDomain();
	}

	/**
	 * Throw Runtime exception if the currentPath doesn't indicate an expandable
	 * relationship.
	 *
	 * @param currentPath
	 */
	private void checkExpandable(DataPath currentPath) {
		if (currentPath.isTerminatedWithAnItem() || currentPath.getRelationships().isEmpty())
			throw new IllegalArgumentException(currentPath.toPathString() + " is not an expandable path");
	}

	private SimpleTable lookUpWithCriterion(Criterion criterion) {
		if (criterion == null || !criterion.getDataSelectionItem().getUnderlyingPath().isTerminatedWithAnItem()) {
			return null;
		}

		QueryRequest queryRequest = criterion.getDataSelectionItem().getUnderlyingPath().select().asQueryRequest();
		queryRequest.addCriteria(criterion.criteria());

		QueryResult queryResult = null;
		try {
			queryResult = (QueryResult) getQuery().submit(queryRequest).get();
		} catch (InterruptedException|ExecutionException e) {
            throw new IllegalStateException(FAIL_MESSAGE, e);
		}
		return queryResult.getTable();
	}

	private SimpleTable lookUpWithDistinctWithCriterion(Criterion criterion, DataPath path) {
		if (criterion == null || !criterion.getDataSelectionItem().getUnderlyingPath().isTerminatedWithAnItem()) {
			return null;
		}

		QueryRequest queryRequest = criterion.getDataSelectionItem().getUnderlyingPath().select().asQueryRequest();
		//Use adding aggregation on other DSI to simulate distinct on this DSI
		if (criterion.getDataSelectionItem().getUnderlyingPath().getStartingDomain()
				.equals(path.getStartingDomain())) {
			queryRequest = criterion.getDataSelectionItem().getUnderlyingPath().select()
					.and(path.aggregateTo(ComparableAggregate.Count))
					.asQueryRequest();
		}
		else {
			logger.warn("Failed to lookup value with distinct...");
		}

		queryRequest.addCriteria(criterion.criteria());
		queryRequest.setMaxRowCount(MAX_LOOKUP_ROW_COUNT);

		QueryResult queryResult = null;
		try {
			queryResult = (QueryResult) getQuery().submit(queryRequest).get();
		} catch (InterruptedException|ExecutionException e) {
			throw new IllegalStateException(FAIL_MESSAGE, e);
		}
		return queryResult.getTable();
	}

	private SimpleTable lookUpWithCriteria(Criteria<?> criteria) {
		if (criteria == null || criteria.getAllCriterion().isEmpty()) {
			return null;
		}

		return lookUpWithCriterion(criteria.getAllCriterion().iterator().next());
	}

	private SimpleTable lookUpWithDistinctWithCriteria(Criteria<?> criteria, DataPath path) {
		if (criteria == null || criteria.getAllCriterion().isEmpty()) {
			return null;
		}

		return lookUpWithDistinctWithCriterion(criteria.getAllCriterion().iterator().next(), path);
	}

	@Override
	@InfraInvocation
	public List<Object> lookUp(Criteria criteria) {
		SimpleTable lookUpTable = this.lookUpWithCriteria(criteria);
		if (lookUpTable == null || lookUpTable.size() == 0) {
			return Lists.newArrayList();
		}

		Map<Integer, Object> lookUpMap = lookUpTable.column(lookUpTable.columnKeySet().iterator().next());
		List<Object> lookUpList = Lists.newArrayList(Sets.newHashSet(lookUpMap.values()));
		Collections.sort(lookUpList, new Comparator<Object>() {
			@Override
			public int compare(Object o1, Object o2) {
				return o1.toString().compareTo(o2.toString());
			}
		});
		return lookUpList;
	}

	@Override
	@InfraInvocation
	public List<Object> lookUpWithDistinct(Criteria criteria, DataPath path) {
		SimpleTable lookUpTable = this.lookUpWithDistinctWithCriteria(criteria, path);
		if (lookUpTable == null || lookUpTable.size() == 0) {
			return Lists.newArrayList();
		}

		Map<Integer, Object> lookUpMap = lookUpTable.column(lookUpTable.columnKeySet().iterator().next());
		List<Object> lookUpList = Lists.newArrayList(Sets.newHashSet(lookUpMap.values()));
		Collections.sort(lookUpList, new Comparator<Object>() {
			@Override
			public int compare(Object o1, Object o2) {
				return o1.toString().compareTo(o2.toString());
			}
		});
		return lookUpList;
	}

	@Override
	public Query getQuery() {
		return this.query;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	@Override
	public ViewContext getViewContext() {
		return viewContext;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		this.viewContext = viewContext;
	}

	protected void sort(List<? extends DataMember> members) {
		Collections.sort(members, new Comparator<DataMember>() {
			@Override
			public int compare(DataMember o1, DataMember o2) {
				int result = comparePartNull(o1, o2);
				if (result != CONTINUE_COMPARE)
					return result;
				if (o1.getProminence().equals(o2.getProminence())) {
					result = comparePartNull(o1.getName(), o2.getName());
					if (result == CONTINUE_COMPARE) {
						return o1.getName().compareToIgnoreCase(o2.getName());
					} else {
						return result;
					}
				} else {
					return o1.getProminence().compareTo(o2.getProminence());
				}
			}

		});
	}

	private <E> int comparePartNull(E o1, E o2) {
		if (o1 != null && o2 != null) {
			return CONTINUE_COMPARE;
		} else if (o1 == o2) {
			return 0;
		} else {
			return o1 == null ? -1 : 1;
		}
	}

	public boolean isTreeNodeFullConstructed() {
		return treeNodeFullConstructed;
	}

	@Override
	public void setTreeNodeFullConstructed(boolean treeNodeFullConstructed) {
		this.treeNodeFullConstructed = treeNodeFullConstructed;
	}

	@Override
	public List<Node> getTreeNode(DataPath path) {
		if (path == null) {
			return this.onLoad();
		} else
			return this.expand(path);
	}

}