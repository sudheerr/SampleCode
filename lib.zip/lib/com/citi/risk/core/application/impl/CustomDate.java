package com.citi.risk.core.application.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.ioc.impl.guice.CRFGuiceContext;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.businessobject.TimeMark.RelativeTimePoint;
import com.citi.risk.core.lang.collection.Pair;
import org.apache.commons.lang3.StringUtils;

public class CustomDate {
	
	private static final String FORMATTER_STRING = "y-M-d-HH-mm-ss";
	private static final String MDY_FORMATTER_STRING = "MMM d yyyy";
	private static final String MY_FORMATTER_STRING = "MMM yyyy";
	
	private static final String DAILY_DISPLAY_STRING = "Day";
	private static final String WEEKLY_DISPLAY_STRING = "Week";
	private static final String MONTHLY_DISPLAY_STRING = "Month";
	private static final String QUARTERLY_DISPLAY_STRING = "Quarter";
	private static final String YEARLY_DISPLAY_STRING = "Year";
	private static final String SPACE_SEPERATOR = " ";

	private static final String CURRENT_DISPLAY_STRING = "Current";
	private static final String PRIOR_DISPLAY_STRING = "Prior";
	private static final String TIME_PERIOD_SEPERATOR = "-";
	
	private static final String OPEN_PARENTHESIS = "(";
	private static final String CLOSE_PARENTHESIS = ")";
	private static Map<BatchFrequency,List<Pair<RelativeTimePoint,String>>> displayStringMap = null;
	
	private CustomDate(){}

	public static String getUIDisplayStringForTimeMark(TimeMark timeMark){
		if (timeMark == null) {
			return "Timemark Not Available";
		}
		StringBuilder uiDisplayString = new StringBuilder();
		uiDisplayString.append(getRelativeTimePeriodStringForTimeMarkKey(timeMark));
		uiDisplayString.append(SPACE_SEPERATOR);
		uiDisplayString.append(getDisplayStringForTimeMarkKey(timeMark));
		return uiDisplayString.toString();
	}

	// From TimeMark to something like "Prior Month-2 (Jun 2014 BD10)". 
	public static String getFormattedUIStringForTimeMark(TimeMark timeMark){
		if (timeMark == null) {
			return "Timemark Not Available";
		}
		StringBuilder uiDisplayString = new StringBuilder();
		uiDisplayString.append(getRelativeTimePeriodStringForTimeMarkKey(timeMark));
		uiDisplayString.append(SPACE_SEPERATOR);
		uiDisplayString.append(getFormattedStringForTimeMarkKey(timeMark));
		return uiDisplayString.toString();
	}

	public static String getRelativeTimePointAndBatchFrequency(String uiDisplayString){
		StringBuilder relativeTimePointAndBatchFrequencyyBuf = new StringBuilder();
		relativeTimePointAndBatchFrequencyyBuf.append(getRelativeTimePointFromUIDisplayString(uiDisplayString).name())
		.append(TimeMark.DELIMITER)
		.append(getBatchFrequencyFromUIDisplayString(uiDisplayString).name());
		return relativeTimePointAndBatchFrequencyyBuf.toString();
	}

	public static TimeMark findTimeMarkWithDisplayString(String dateString, Set<TimeMark> timeMarks){
		//dateString could be "2013~1~0~1~0~Daily" or Current Day (2013~1~0~7~5~Daily)
		String searchTimeMarkKey;
		if(dateString.contains(OPEN_PARENTHESIS)){
			searchTimeMarkKey = dateString.substring(dateString.indexOf(OPEN_PARENTHESIS)+1, dateString.length()-1);
		}else{
			searchTimeMarkKey = dateString;
		}
		for(TimeMark timeMark : timeMarks){
			if(searchTimeMarkKey.equals(timeMark.getTimeMarkKey())){
				return timeMark;
			}
		}
		if(!timeMarks.isEmpty())
			return timeMarks.iterator().next();
		return null;
	}

	// From "Anything (Prior Month-2 (Jun 2014 BD10))" to "T3~Monthly". 
	public static String getRelativeTimePointAndBatchFrequencyFromColumnHeaderName(String varianceColumnHeaderName) {
		Pattern pattern = Pattern.compile("\\((.*)\\)");
		Matcher matcher = pattern.matcher(varianceColumnHeaderName);
		if(matcher.find()) 
			return getRelativeTimePointAndBatchFrequency(matcher.group(1));
		return null;
	}

	public static List<String> sortTimeMarkString(List<String> dateStringList){
		Collections.sort(dateStringList, new TimeMarkStringComparator());
		return dateStringList;
	}

	public static String toDefaultDisplayString(Object value){
		if(value == null || "".equals(value) || NullTerminator.isCreatedByNullTerminator(value)){
			return "";
		}
		return new SimpleDateFormat(FORMATTER_STRING).format(value);
	}

	//new date from 2011-02-05-00-00-00
	public static Date newDate(String dateString){
		try{
			if(StringUtils.isBlank(dateString))
				return new Date();
			return new SimpleDateFormat(FORMATTER_STRING).parse(dateString);
		}catch(ParseException parseException){
			return new Date();
		}
	}

	public static String getRelativeTimePeriodStringForTimeMarkKey(TimeMark timeMark){
		initDisplayStringMap();
		StringBuilder uiDisplayString = new StringBuilder();
		List<Pair<RelativeTimePoint,String>> displayStringList = displayStringMap.get(timeMark.getBatchFrequency());
		for(Pair<RelativeTimePoint,String> relativeTimeAnddisplayStringPair : displayStringList){
			if(relativeTimeAnddisplayStringPair.getFirst().equals(timeMark.getRelativeTimePoint())){
				uiDisplayString.append(relativeTimeAnddisplayStringPair.getSecond());
				uiDisplayString.toString();
			}
		}
		return uiDisplayString.toString();
	}

	// From TimeMark to something like "(Jun 2014 BD10)".
	public static String getFormattedStringForTimeMarkKey(TimeMark timeMark){
		StringBuilder uiTimeMarkKey = new StringBuilder();
		uiTimeMarkKey.append(OPEN_PARENTHESIS);
		String formatString;
		switch (timeMark.getBatchFrequency()) {
			case Daily:
				formatString =  new SimpleDateFormat(MDY_FORMATTER_STRING).format(timeMark.getFiscalDate());
				break;
			case Monthly:
				formatString = new SimpleDateFormat(MY_FORMATTER_STRING).format(timeMark.getFiscalDate());
				if(timeMark.getBDNumber()!=null) {
					formatString = formatString + " BD" + timeMark.getBDNumber();
				}
				break;
			default:
				formatString = timeMark.getTimeMarkKey();
		}
		uiTimeMarkKey.append(formatString);
		uiTimeMarkKey.append(CLOSE_PARENTHESIS);
		return uiTimeMarkKey.toString();
	}

	//Private methods
	private static String getDisplayStringForTimeMarkKey(TimeMark timeMark){
		StringBuilder uiTimeMarkKey = new StringBuilder();
		uiTimeMarkKey.append(OPEN_PARENTHESIS);
		uiTimeMarkKey.append(timeMark.getTimeMarkKey());
		uiTimeMarkKey.append(CLOSE_PARENTHESIS);
		return uiTimeMarkKey.toString();
	}

    private static void prepareDisplayStrings() {
        displayStringMap = new EnumMap<>(TimeMark.BatchFrequency.class);
        for (BatchFrequency batchFrequency : BatchFrequency.values()) {
            int timePeriod = 1;
            for (RelativeTimePoint relativeTimePoint : RelativeTimePoint.values()) {
                List<Pair<RelativeTimePoint, String>> displayStringList;
                StringBuilder uiDisplayStringBuilder = new StringBuilder();
                switch (batchFrequency) {
                case Daily:
                    timePeriod = dailyBatchFrequency(timePeriod, relativeTimePoint, uiDisplayStringBuilder);
                    break;
                case Monthly:
                    timePeriod = monthlyBatchFrequency(timePeriod, relativeTimePoint, uiDisplayStringBuilder);
                    break;
                case Weekly:
                    timePeriod = weeklyBatchFrequency(timePeriod, relativeTimePoint, uiDisplayStringBuilder);
                    break;
                case Quarterly:
                    timePeriod = quarterlyBatchFrequency(timePeriod, relativeTimePoint, uiDisplayStringBuilder);
                    break;
                case Yearly:
                    timePeriod = yearlyBatchFrequency(timePeriod, relativeTimePoint, uiDisplayStringBuilder);
                    break;
                case NULL_TERMINAL:
                    break;
                default:
                    break;
                }
                if (displayStringMap.containsKey(batchFrequency)) {
                    displayStringList = displayStringMap.get(batchFrequency);
                    displayStringList.add(new Pair<RelativeTimePoint, String>(relativeTimePoint, uiDisplayStringBuilder
                            .toString()));
                } else {
                    displayStringList = new ArrayList<>();
                    displayStringList.add(new Pair<RelativeTimePoint, String>(relativeTimePoint, uiDisplayStringBuilder
                            .toString()));
                    displayStringMap.put(batchFrequency, displayStringList);
                }
            }
        }
    }

	private static int yearlyBatchFrequency(int timePeriod, RelativeTimePoint relativeTimePoint,
			StringBuilder uiDisplayStringBuilder) {
		int newTimePeriod = timePeriod;
		if(relativeTimePoint.equals(RelativeTimePoint.T0)){
			uiDisplayStringBuilder.append(CURRENT_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(YEARLY_DISPLAY_STRING);
		} else if(relativeTimePoint.equals(RelativeTimePoint.T1)){
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(YEARLY_DISPLAY_STRING);
		} else{
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(YEARLY_DISPLAY_STRING);
			uiDisplayStringBuilder.append(TIME_PERIOD_SEPERATOR);
			uiDisplayStringBuilder.append(timePeriod);
			newTimePeriod++;
		}
		return newTimePeriod;
	}

	private static int quarterlyBatchFrequency(int timePeriod, RelativeTimePoint relativeTimePoint,
			StringBuilder uiDisplayStringBuilder) {
		int newTimePeriod = timePeriod;
		if(relativeTimePoint.equals(RelativeTimePoint.T0)){
			uiDisplayStringBuilder.append(CURRENT_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(QUARTERLY_DISPLAY_STRING);
		} else if(relativeTimePoint.equals(RelativeTimePoint.T1)){
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(QUARTERLY_DISPLAY_STRING);
		} else{
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(QUARTERLY_DISPLAY_STRING);
			uiDisplayStringBuilder.append(TIME_PERIOD_SEPERATOR);
			uiDisplayStringBuilder.append(timePeriod);
			newTimePeriod++;
		}
		return newTimePeriod;
	}

	private static int weeklyBatchFrequency(int timePeriod, RelativeTimePoint relativeTimePoint,
			StringBuilder uiDisplayStringBuilder) {
		int newTimePeriod = timePeriod;
		if(relativeTimePoint.equals(RelativeTimePoint.T0)){
			uiDisplayStringBuilder.append(CURRENT_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(WEEKLY_DISPLAY_STRING);
		} else if(relativeTimePoint.equals(RelativeTimePoint.T1)){
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(WEEKLY_DISPLAY_STRING);
		} else{
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(WEEKLY_DISPLAY_STRING);
			uiDisplayStringBuilder.append(TIME_PERIOD_SEPERATOR);
			uiDisplayStringBuilder.append(timePeriod);
			newTimePeriod++;
		}
		return newTimePeriod;
	}

	private static int monthlyBatchFrequency(int timePeriod, RelativeTimePoint relativeTimePoint,
			StringBuilder uiDisplayStringBuilder) {
		int newTimePeriod = timePeriod;
		if(relativeTimePoint.equals(RelativeTimePoint.T0)){
			uiDisplayStringBuilder.append(CURRENT_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(MONTHLY_DISPLAY_STRING);
		} else if(relativeTimePoint.equals(RelativeTimePoint.T1)){
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(MONTHLY_DISPLAY_STRING);
		} else{
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(MONTHLY_DISPLAY_STRING);
			uiDisplayStringBuilder.append(TIME_PERIOD_SEPERATOR);
			uiDisplayStringBuilder.append(timePeriod);
			newTimePeriod++;
		}
		return newTimePeriod;
	}

	private static int dailyBatchFrequency(int timePeriod, RelativeTimePoint relativeTimePoint,
			StringBuilder uiDisplayStringBuilder) {
		int newTimePeriod = timePeriod;
		if(relativeTimePoint.equals(RelativeTimePoint.T0)){
			uiDisplayStringBuilder.append(CURRENT_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(DAILY_DISPLAY_STRING);
		} else if(relativeTimePoint.equals(RelativeTimePoint.T1)){
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(DAILY_DISPLAY_STRING);
		} else{
			uiDisplayStringBuilder.append(PRIOR_DISPLAY_STRING);
			uiDisplayStringBuilder.append(SPACE_SEPERATOR);
			uiDisplayStringBuilder.append(DAILY_DISPLAY_STRING);
			uiDisplayStringBuilder.append(TIME_PERIOD_SEPERATOR);
			uiDisplayStringBuilder.append(timePeriod);
			newTimePeriod++;
		}
		return newTimePeriod;
	}

	private static void initDisplayStringMap() {
		if(displayStringMap == null)
			prepareDisplayStrings();
	}

	private static String getTimePeriodFromUIDisplayString(String uiDisplayString) {
		return uiDisplayString.substring(0, uiDisplayString.indexOf(OPEN_PARENTHESIS)-1);
	}
	
	private static RelativeTimePoint getRelativeTimePointFromUIDisplayString(String uiDisplayString) {
		
		initDisplayStringMap();
		
		for (Entry<BatchFrequency, List<Pair<RelativeTimePoint, String>>> entry : displayStringMap.entrySet()) {
			for (Pair<RelativeTimePoint, String> relativeTimeAnddisplayStringPair : entry.getValue()) {
				if (getTimePeriodFromUIDisplayString(uiDisplayString).equals(relativeTimeAnddisplayStringPair.getSecond())) {
					return relativeTimeAnddisplayStringPair.getFirst();
				}
			}
		}
		
		return RelativeTimePoint.T0;
	}

	private static BatchFrequency getBatchFrequencyFromUIDisplayString(String uiDisplayString) {
		initDisplayStringMap();
		for (Entry<BatchFrequency, List<Pair<RelativeTimePoint, String>>> entry : displayStringMap.entrySet()) {
			final BatchFrequency batchFrequency = entry.getKey();
			for (Pair<RelativeTimePoint, String> relativeTimeAnddisplayStringPair : entry.getValue()) {
				if(getTimePeriodFromUIDisplayString(uiDisplayString).equals(relativeTimeAnddisplayStringPair.getSecond())){
					return batchFrequency;
				}
			}
		}
		return BatchFrequency.Daily;
	}

	private static class TimeMarkStringComparator implements Comparator<String>{
		@Override
		public int compare(String uiDisplayString1, String uiDisplayString2) {
			BatchFrequency batchFrequency1 = getBatchFrequencyFromUIDisplayString(uiDisplayString1);
			BatchFrequency batchFrequency2 = getBatchFrequencyFromUIDisplayString(uiDisplayString2);
			if(batchFrequency1.equals(batchFrequency2)){
				RelativeTimePoint relativeTimePoint1 = getRelativeTimePointFromUIDisplayString(uiDisplayString1);
				RelativeTimePoint relativeTimePoint2 = getRelativeTimePointFromUIDisplayString(uiDisplayString2);
				return relativeTimePoint1.compareTo(relativeTimePoint2);
			}else{
				return diffBatchFrequencyDeal(batchFrequency1, batchFrequency2);
			}
		}

		private int diffBatchFrequencyDeal(BatchFrequency batchFrequency1, BatchFrequency batchFrequency2) {
			switch (batchFrequency1){
			case Daily:
				return -1;
			case Monthly:
				return dealFrequency2Daily(batchFrequency2);
			case Weekly:
				return dealFrequency2DailyOrMonthly(batchFrequency2);
			case Quarterly:
				return dealFrequency2DailyOrMonthlyOrWeekly(batchFrequency2);
			default:
				return 1;
			}
		}

		private int dealFrequency2DailyOrMonthlyOrWeekly(BatchFrequency batchFrequency2) {
			if(batchFrequency2.equals(BatchFrequency.Daily) || batchFrequency2.equals(BatchFrequency.Monthly)
					|| batchFrequency2.equals(BatchFrequency.Weekly)){
				return 1;
			}else{
				return -1;
			}
		}

		private int dealFrequency2DailyOrMonthly(BatchFrequency batchFrequency2) {
			if(batchFrequency2.equals(BatchFrequency.Daily) || batchFrequency2.equals(BatchFrequency.Monthly)){
				return 1;
			}else{
				return -1;
			}
		}

		private int dealFrequency2Daily(BatchFrequency batchFrequency2) {
			if(batchFrequency2.equals(BatchFrequency.Daily)){
				return 1;
			}else{
				return -1;
			}
		}
	}
	
	@SuppressWarnings("all")
	public static TimeMark getTimeMark(DataDomain domain, TimeMark timeMark) {
		for (DataKey dataKey : CRFGuiceContext.getInjector()
				.getInstance(CacheManager.class).searchDataAvailabilities()) {
			if (dataKey.getDomain().equals(domain)) {
				TimeMark r = dataKey.getTimeMark();
				if (r.equals(timeMark))
					return r;
			}
		}
		return timeMark;
	}

	@SuppressWarnings("all")
	public static TimeMark getTimeMark(DataDomain domain, String timeMarkKey) {
		for (DataKey dataKey : CRFGuiceContext.getInjector()
				.getInstance(CacheManager.class).searchDataAvailabilities()) {
			if (dataKey.getDomain().equals(domain)) {
				TimeMark r = dataKey.getTimeMark();
				if (r.getTimeMarkKey().equals(timeMarkKey))
					return r;
			}
		}
		return DefaultTimeMark.getTimeMarkfromKey(timeMarkKey);
	}
	
	@SuppressWarnings("all")
	public static TimeMark getTimeMarkWithRelativePosition(DataDomain domain, TimeMark basedTimeMark, int relativePosition) {
		Set<TimeMark> timeMarks = new TreeSet<>();
		for (DataKey dataKey : CRFGuiceContext.getInjector().getInstance(CacheManager.class).searchDataAvailabilities()) {
			if (dataKey.getDomain().equals(domain)) {
				TimeMark i = dataKey.getTimeMark();
				if (i.getBatchFrequency().equals(basedTimeMark.getBatchFrequency()))
					timeMarks.add(i);
			}
		}
		int position = 0;
		for (TimeMark t : timeMarks) {
			if (t.equals(basedTimeMark)) {
				int newPosition = position - relativePosition;
				int j = 0;
				for (TimeMark s : timeMarks) {
					if (newPosition == j++)
						return s;
				}
				break;
			}
			position++;
		}
		return null;
	}
	
	@SuppressWarnings("all")
	public static int getTimeMarkRelativePosition(DataDomain domain, TimeMark basedTimeMark, TimeMark nonControlledTimeMark) {
		if (!basedTimeMark.getBatchFrequency().equals(nonControlledTimeMark.getBatchFrequency())) {
			throw new IllegalArgumentException(basedTimeMark.getTimeMarkKey() + " has different batch frequency with " + nonControlledTimeMark.getTimeMarkKey());
		}
		
		Set<TimeMark> timeMarks = new TreeSet<>();
		for (DataKey dataKey : CRFGuiceContext.getInjector().getInstance(CacheManager.class).searchDataAvailabilities()) {
			if (dataKey.getDomain().equals(domain)) {
				TimeMark i = dataKey.getTimeMark();
				if (i.getBatchFrequency().equals(basedTimeMark.getBatchFrequency()))
					timeMarks.add(i);
			}
		}
		
		int beforePosition = getRealPosition(basedTimeMark, timeMarks);
		
		int afterPosition = getRealPosition(nonControlledTimeMark, timeMarks);
		
		return beforePosition - afterPosition;
	}

	private static int getRealPosition(TimeMark timeMark, Set<TimeMark> timeMarks) {
		boolean valid = false;
		int realPosition = 0;
		for (TimeMark t : timeMarks) {
			if (t.equals(timeMark)) {
				valid = true;
				break;
			}
			realPosition++;
		}
		if (!valid) {
			throw new IllegalArgumentException(timeMark.getTimeMarkKey()
					+ " is invalid");
		}
		return realPosition;
	}
}