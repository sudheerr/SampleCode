package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.*;
import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.bean.CriterionBean;
import com.citi.risk.core.data.store.api.BusinessDays;
import com.citi.risk.core.data.store.api.BusinessDays.DailyBusinessDays;
import com.citi.risk.core.data.store.api.BusinessDays.MonthlyBusinessDays;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.dictionary.api.*;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.businessobject.TimeMarkPath;
import com.citi.risk.core.lang.collection.Pair;
import com.citi.risk.core.lang.create.api.Create;
import com.citi.risk.core.lang.table.SimpleTable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import javax.persistence.OrderBy;
import java.util.*;

@Entity
@Table(name = "DefaultView")
public class DefaultView implements View {
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultView.class);
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Create create;
	@Inject
	private BusinessDays businessDays;
	@Inject
	protected DictionaryParser parser;
	private Dictionary dictionary;
	private Criteria criteria;
	private CriteriaWrapper globalCriteriaWrapper;
	private CriteriaWrapper viewCriteriaWrapper;
	
	@Inject
	private DefaultSearchElement searchElement;	
	@Inject
	private TableBasedElementFactory tableBasedElementFactory;
	@Inject
	private CacheManager cacheManager;

	private Integer id;
	private Integer displayIndex;
	private Boolean selected = false;
	private String domainName;
	private String viewType;
	@ToBeCompared
	private String viewName;
	private Integer sourceId;
	private String templateName;
	private Boolean loadAllWithNonCriteria = true;
	@ToBeCompared
	private Boolean hidden;
	@ToBeCompared
	private Boolean shared;
	private String uipath;
	private String viewClassString;

	private Perspective perspective;
	private ViewContext viewContext;
	private FormBasedElement formBasedElement;
	private GraphBasedElement graphBasedElement;
	private List<Navigation> menuList;
	private List<TableBasedElement> tableBasedElementList = Lists.newArrayList();
	private List<DefaultFilter> defaultFilterList = Lists.newArrayList();
	private List<Element> dataElements = new ArrayList<>();

	public DefaultView(){
		super();
	}

	public DefaultView(String dvstring){
		super();
		String[] dvsplits = dvstring.split("!");
		this.domainName = dvsplits[0];
		this.hidden = Boolean.valueOf(dvsplits[1]);
		this.viewName = dvsplits[2];
		this.viewType = dvsplits[3];
	}

	@Override
	public List<Pair<List<ColumnHeader>, SimpleTable>> loadAllTableBasedElements() {
		List<Pair<List<ColumnHeader>, SimpleTable>> list = new ArrayList<>();
		for (TableBasedElement tableBasedElement : tableBasedElementList) {
			tableBasedElement.initHeader();
			List<ColumnHeader> headerList = tableBasedElement.getHeader();
			SimpleTable table = tableBasedElement.onLoad();
			list.add(new Pair<List<ColumnHeader>, SimpleTable>(headerList, table));
		}
		return list;
	}

	@Override
	@Column(nullable = false, length = 50)
	public String getName() {
		return viewName;
	}

	@Override
	public void setName(String viewName) {
		this.viewName = viewName;
	}

	@Override
	@Column(nullable = false, name="SELECTED")
	public Boolean getSelected() {
		return this.selected;
	}

	@Override
	public void setSelected(Boolean selected) {
		this.selected=selected;
	}

	@Override
	@Column(length = 100)
	public String getViewType() {
		return viewType;
	}

	@Override
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	@Transient
	@Override
	public Boolean isToolkitView() {
		return TOOLKIT_VIEW_TYPE.equals(viewType);
	}

	@Transient
	@Override
	public SearchElement getSearchElement() {
		return searchElement;
	}

	public void setSearchElement(DefaultSearchElement searchElement) {
		this.searchElement = searchElement;
	}

	@Override
	public void addTableElement(TableBasedElement tableBasedElement) {
		tableBasedElementList.add((DefaultTableBasedElement)tableBasedElement);
	}

	@Override
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = DefaultTableBasedElement.class, orphanRemoval=true)
	@JoinColumn(name="viewId")
	@Fetch(FetchMode.SUBSELECT)
	@OrderBy(value = "displayIndex")
	public List<TableBasedElement> getTableBasedElementList() {
		return tableBasedElementList;
	}

	@Override
	public void setTableBasedElementList(
			List<TableBasedElement> tableBasedElementList) {
		this.tableBasedElementList = tableBasedElementList;
	}

	@Override
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,  targetEntity = DefaultFilter.class, orphanRemoval = true)
	@JoinColumn(name = "viewId")
	@Fetch(FetchMode.SUBSELECT)
	public List<DefaultFilter> getDefaultFilterList() {
		return defaultFilterList;
	}

	@Override
	public void setDefaultFilterList(List<DefaultFilter> defaultFilterList) {
		this.defaultFilterList = defaultFilterList;
	}

	@Override
	public void setDefaultCriteria() {
		if (this.getDomain() != null) {
			parser.parseDomain(TimeMark.class);
			DataRelationship toBusinessDateRelationship = this.getDomain().getRelationship("Time mark");
			DataPath timeMarkYear = toBusinessDateRelationship.append(create.getInstance(TimeMarkPath.FiscalYear.class));
			DataPath timeMarkMonth = toBusinessDateRelationship.append(create.getInstance(TimeMarkPath.FiscalMonth.class));
			DataPath timeMarkDay = toBusinessDateRelationship.append(create.getInstance(TimeMarkPath.FiscalDay.class));
			TimeMark timeMark = businessDays.getCurrentBusinessPeriodFor(BatchFrequency.Daily);
			int y = timeMark.getFiscalYear();
			int m = timeMark.getFiscalMonth();
			int d = timeMark.getFiscalDay();

			this.setCriteria(timeMarkYear.eq(y).and(timeMarkMonth.eq(m).and(timeMarkDay.eq(d))));
		}
	}

	@Override
	public void setDictionary(Dictionary dictionary) {
		this.dictionary = dictionary;
	}

	@Transient
	@Override
	public Criteria getCriteria() {
		return this.criteria;
	}

	@Override
	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}

	@Transient
	@Override
	public Dictionary getDictionary() {
		return dictionary;
	}

	@Column
	public Boolean getLoadAllWithNonCriteria() {
		return loadAllWithNonCriteria;
	}

	public void setLoadAllWithNonCriteria(Boolean loadAllWithNonCriteria) {
		this.loadAllWithNonCriteria = loadAllWithNonCriteria==null? true : loadAllWithNonCriteria;
	}

	@Override
	public void setLoadAllWithNonCriteria() {		
		boolean localLoadAllWithNonCriteria = getLoadAllWithNonCriteria();
		for (TableBasedElement tableBasedElement : this.getTableBasedElementList()) {
			tableBasedElement.setLoadAllWithNonCriteria(localLoadAllWithNonCriteria);
		}
	}

	@Transient
	@Override
	public Map<String, DataDomain> getAvailableDomainMap() {
		Map<String, DataDomain> domainMap = Maps.newHashMap();
		domainMap.put(this.getDomain().getName(), this.getDomain());
		return domainMap;
	}

	@Transient
	private DateTime getFiscalDateFromTimeMark(TimeMark timemark){
			if(timemark.getBatchFrequency().equals(BatchFrequency.Daily))
			{
				return new DateTime().withYear(timemark.getFiscalYear()).withMonthOfYear(timemark.getFiscalMonth()).withDayOfMonth(timemark.getFiscalDay()).toDateMidnight().toDateTime();
			}
			
			if(timemark.getBatchFrequency().equals(BatchFrequency.Monthly))
			{
				return new DateTime().withYear(timemark.getFiscalYear()).withMonthOfYear(timemark.getFiscalMonth()).dayOfMonth().withMaximumValue().toDateMidnight().toDateTime();
			}
			
			return new DateTime().withYear(timemark.getFiscalYear()).withWeekOfWeekyear(timemark.getFiscalWeek()).dayOfWeek().withMaximumValue().toDateMidnight().toDateTime();
	} 

	@Transient
	@Override
	public Map<String, TimeMark> getAvailableDailyBusinessDays(TimeMark currentTimeMark) {
		Map<String, TimeMark> availableDailyBusinessDays = Maps.newHashMap();
		Set<DataKey> availableDataKeys = cacheManager.searchDataAvailabilities();
		List<TimeMark> allTimeMarks = Lists.newArrayList();
		for (DataKey dataKey : availableDataKeys) {
			int minusValue = 0;
			if (isDailyBatchFrequency(dataKey) && isViewContextDomain(dataKey)) {

				if (allTimeMarks.contains(dataKey.getTimeMark()))
					continue;
				allTimeMarks.add(dataKey.getTimeMark());
				DateTime candicateDateTime = getFiscalDateFromTimeMark(dataKey.getTimeMark());
				while (minusValue < DailyBusinessDays.values().length) {
					putExpectedTimeMarkToMap(currentTimeMark, availableDailyBusinessDays, dataKey, minusValue,
							candicateDateTime);
					minusValue++;
				}
			}
		}
		return availableDailyBusinessDays;
	}

	private void putExpectedTimeMarkToMap(TimeMark currentTimeMark, Map<String, TimeMark> availableDailyBusinessDays,
			DataKey dataKey, int minusValue, DateTime candicateDateTime) {
		TimeMark prepardCandidateTimeMark = currentTimeMark;
		DateTime expectedCandidateDateTime = minusTimeToDateTimeByDay(prepardCandidateTimeMark,
				minusValue);
		if (candicateDateTime.getMillis() == expectedCandidateDateTime.getMillis()) {
			availableDailyBusinessDays.put(DailyBusinessDays.fromOrdinal(minusValue).toString(),
					dataKey.getTimeMark());
		}
	}

	private boolean isViewContextDomain(DataKey dataKey) {
		return dataKey.getDomain().equals(this.getDomain()) || dataKey.getDomain().equals(this.getViewContext().getDomain());
	}

	private boolean isDailyBatchFrequency(DataKey dataKey) {
		return dataKey.getTimeMark().getBatchFrequency().equals(BatchFrequency.Daily);
	}

	
	
	@Transient
	@Override
	public DateTime minusTimeToDateTimeByDay(TimeMark origianlTimeMark, int minusValue) {
		DateTime prepardCandidateDateTime = getFiscalDateFromTimeMark(origianlTimeMark);
		for (int count = minusValue; count > 0; --count) {
			prepardCandidateDateTime = prepardCandidateDateTime.minusDays(1);
			if (prepardCandidateDateTime.getDayOfWeek() == 7)
				prepardCandidateDateTime = prepardCandidateDateTime.minusDays(2);
		}
		return prepardCandidateDateTime;
	}

	@Transient
	@Override
	public Map<String, TimeMark> getAvailableMonthlyBusinessDays(TimeMark currentTimeMark) {
		Map<String, TimeMark> availableMonthlyBusinessDays = Maps.newHashMap();
		Set<DataKey> availableDataKeys = cacheManager.searchDataAvailabilities();
		List<TimeMark> allTimeMarks = Lists.newArrayList();
		for(DataKey dataKey : availableDataKeys) {
			int minusValue = 0;
			if (isMonthlyBatchFrequency(dataKey) && isViewContextDomain(dataKey)) {
				if (allTimeMarks.contains(dataKey.getTimeMark()))
					continue;
				DateTime candicateDateTime = getFiscalDateFromTimeMark(dataKey.getTimeMark()).withDayOfMonth(1);
				while (minusValue < MonthlyBusinessDays.values().length) {
					DateTime expectedCandicateDateTime = minusTimeToDateTimeByMonth(currentTimeMark, minusValue);
					putTimeMarkToMap(availableMonthlyBusinessDays, dataKey, minusValue, candicateDateTime,
							expectedCandicateDateTime);
					minusValue++;
				}
			}
		}
		return availableMonthlyBusinessDays;
	}

	private void putTimeMarkToMap(Map<String, TimeMark> availableMonthlyBusinessDays, DataKey dataKey, int minusValue,
			DateTime candicateDateTime, DateTime expectedCandicateDateTime) {
		if (expectedCandicateDateTime.getMillis() == candicateDateTime.getMillis()) {
			String bd = "";
			if (dataKey.getTimeMark().getBDNumber() != null) {
				bd = "BD" + dataKey.getTimeMark().getBDNumber();
			}
			availableMonthlyBusinessDays.put(MonthlyBusinessDays.fromOrdinal(minusValue).toString() + bd,
					dataKey.getTimeMark());
		}
	}

	private boolean isMonthlyBatchFrequency(DataKey dataKey) {
		return dataKey.getTimeMark().getBatchFrequency().equals(BatchFrequency.Monthly);
	}

	@Transient
	@Override
	public DateTime minusTimeToDateTimeByMonth(TimeMark origianlTimeMark, int minusValue) {
		DateTime baseDateTime = getFiscalDateFromTimeMark(origianlTimeMark).withDayOfMonth(1);
		return baseDateTime.withDayOfMonth(1).minusMonths(minusValue);
	}

	@Override
	public void updateViewWithNewDomain(String domainName) {
		// do nothing by default.
	}

	@Transient
	private DataDomain getDomain() {
		if(this.getViewContext() == null) {
			return null;
		}
		return this.getViewContext().getDomain();
	}

	@Override
	public void setCriteria(List<CriterionBean> criterionList) {
		Criteria localCriteria = null;
		Iterator<CriterionBean> listIter = criterionList.listIterator();

		while (listIter.hasNext()) {
			if (localCriteria == null) {
				localCriteria = listIter.next().toSingleNormalCriteria(this.dictionary);
			} else {
				localCriteria = localCriteria.and(listIter.next().toSingleNormalCriteria(this.dictionary));
			}
		}

		this.setCriteria(localCriteria);
	}

	@Transient
	@Override
	public List<CriterionBean> getCriteriaDetail() {
		List<CriterionBean> criterionBeanList = Lists.newArrayList();

		if (this.criteria == null) {
			return criterionBeanList;
		}

		Collection<Criterion<?>> allCriterions = this.criteria.getAllCriterion();

		CriterionBean criterionBean;
		for (Criterion<?> criterion : allCriterions) {
			criterionBean = new CriterionBean(criterion);
			criterionBeanList.add(criterionBean);
		}
		return criterionBeanList;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		this.viewContext = viewContext;
	}

	@Transient
	@Override
	public ViewContext getViewContext() {
		return this.viewContext;
	}

	@Override
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DefaultView_Seq")  //generator setting in orm.xml in apps project 
	@Column(name = "id", nullable = false)
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	@Column(nullable = false, length = 100)
	public String getDomainName() {
		return domainName;
	}

	@Override
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	@Override
	@Column(columnDefinition="varchar2(255 char) default 'default'")
	public String getUiPath() {
		return uipath;
	}

	@Override
	public void setUiPath(String uipath) {
		this.uipath = uipath;
	}

	@Override
	public Integer getDisplayIndex() {
		return displayIndex;
	}

	@Override
	public void setDisplayIndex(Integer displayIndex) {
		this.displayIndex = displayIndex;
	}

	@Override
	@ManyToOne(targetEntity = DefaultPerspective.class)
	@JoinColumn(name="perspectiveId", insertable=true, updatable=true)
	public Perspective getPerspective() {
		return perspective;
	}

	@Override
	public void setPerspective(Perspective perspective) {
		this.perspective = perspective;
	}

	@Transient
	@Override
	public FormBasedElement getFormBasedElement() {
		return formBasedElement;
	}

	@Override
	public void setFormBasedElement(FormBasedElement formBasedElement) {
		this.formBasedElement = formBasedElement;
	}

	@Transient
	@Override
	public GraphBasedElement getGraphBasedElement() {
		return graphBasedElement;
	}

	@Override
	public void setGraphBasedElement(GraphBasedElement graphBasedElement) {
		this.graphBasedElement = graphBasedElement;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultView other = (DefaultView) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "View {id = " + getId() + 
				", name = " + getName() + 
				", displayIndex = " + displayIndex + 
			    ", domainName = " + domainName + 
			    ", hidden = " + hidden + 
			    ", loadAllWithNonCriteria = " + loadAllWithNonCriteria + 
			    ", sourceId = " + sourceId + 
			    ", viewType = " + viewType + 
			    ", selected = " + selected + 
			    ", shared = " + shared + 
			    ", uipath = " + uipath + 
			    ", viewClassString = " + viewClassString + 
			    ", perspectiveId = " + (perspective != null ? perspective.getId() : null) + 
			    "}";
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		DefaultView view = (DefaultView) super.clone();
		List<TableBasedElement> elements = null;
		if (view.getTableBasedElementList() != null) {
			elements = new ArrayList<>();
			int localDisplayIndex = 0;
			for (TableBasedElement el : view.getTableBasedElementList()) {
				TableBasedElement cloneElement = (DefaultTableBasedElement) el.clone();
				cloneElement.setDisplayIndex(localDisplayIndex++);
				elements.add(cloneElement);
			}
		}
		view.setTableBasedElementList(elements);
		List<DefaultFilter> defaultFilters = null;
		if (view.getDefaultFilterList() != null){
			defaultFilters = new ArrayList<>();
			for (DefaultFilter df : view.getDefaultFilterList()){
				defaultFilters.add((DefaultFilter) df.clone());
			}
		}
		view.setDefaultFilterList(defaultFilters);
		List<Element> elementList = new ArrayList<>();
		for (Element element : this.dataElements) {
			elementList.add((Element)element.clone());
		}
		view.setId(null);
		view.setPerspective(null);
		return view;
	}

	@Override
	public View copy(Perspective p) {
		DefaultView view = null;
		try {
		    view = (DefaultView) super.clone();
		    List<TableBasedElement> elements = null;
		    if (view.getTableBasedElementList() != null) {
			elements = new ArrayList<>();
			for (TableBasedElement el : view.getTableBasedElementList()) {
				elements.add((DefaultTableBasedElement) el.copy(view));
			}
		    }
		    view.setTableBasedElementList(elements);
		    view.setPerspective(p);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy View", e);
		}
		return view;
	}

	@Override
	public Boolean getHidden() {
		return hidden;
	}

	@Override
	public void setHidden(Boolean hidden) {
		this.hidden = hidden;
	}

	@Override
	public Boolean isShared() {
		return shared;
	}

	@Override
	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	@Override
	public Integer getSourceId() {
		return sourceId;
	}

	@Override
	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	@Override
	public String getTemplateName() {
	    return templateName;
	}

	@Override
	public void setTemplateName(String templateName) {
	    this.templateName = templateName;
	}

	@Transient
	@Override
	public List<Navigation> getMenuList() {
		return menuList;
	}

	@Transient
	@Override
	public void setMenuList(List<Navigation> menuList) {
		this.menuList = menuList;
	}

	@Transient
	@Override
	public Navigation getNavigation(String itemName) {
		for (Navigation item : getMenuList()) {
			if (item.getItemName().equals(itemName)) {
				return item;
			}
		}
		return null;
	}

	@Transient
	@Override
	public CriteriaWrapper getGlobalCriteriaWrapper() {
		return globalCriteriaWrapper;
	}

	@Override
	public void setGlobalCriteriaWrapper(CriteriaWrapper globalCriteriaWrapper) {
		this.globalCriteriaWrapper = globalCriteriaWrapper;
	}

	@Transient
	@Override
	public CriteriaWrapper getNavigationContextCriteriaWrapper() {
		return viewCriteriaWrapper;
	}

	@Override
	public void setNavigationContextCriteriaWrapper(CriteriaWrapper viewCriteriaWrapper) {
		this.viewCriteriaWrapper = viewCriteriaWrapper;
	}

	@Transient
	@Override
	public Map<String, TimeMark> getAllBussinessDays(TimeMark basetimemark) {
		Map<String, TimeMark> allbussinessDays = Maps.newHashMap();
		allbussinessDays.putAll(getAvailableDailyBusinessDays(basetimemark));
		allbussinessDays.putAll(getAvailableMonthlyBusinessDays(basetimemark));
		return allbussinessDays;
	}

	@Transient
	@Override
	public Map<String, TimeMark> getAvailableDataKeys() {
		Map<String, TimeMark> availableDataKeyMap = Maps.newHashMap();
		Set<DataKey> availableDataKeySet =  cacheManager.searchDataAvailabilities();
		List<TimeMark> allTimeMarks = Lists.newArrayList();
		for(DataKey dataKey : availableDataKeySet) {
			if (isViewContextDomain(dataKey)) {
				if (allTimeMarks.contains(dataKey.getTimeMark()))
					continue;
				allTimeMarks.add(dataKey.getTimeMark());
				switch (dataKey.getTimeMark().getBatchFrequency()) {
					case Daily : 
						availableDataKeyMap.put(dataKey.getTimeMark().getRelativeTimePointAndBatchFrequency(), 
								dataKey.getTimeMark());
						break;
					case Monthly : 
						availableDataKeyMap.put(dataKey.getTimeMark().getRelativeTimePointAndBatchFrequency() + TimeMark.DELIMITER + dataKey.getTimeMark().getBDNumber(), 
								dataKey.getTimeMark());
						break;
					default:
						break;
				}
			}
		}
		return availableDataKeyMap;
	}

	@Override
	@Column(columnDefinition="varchar2(255 char) default 'default'")
	public String getViewClass() {
		return viewClassString;
	}

	@Override
	public void setViewClass(String viewClassString) {
		this.viewClassString = viewClassString;
	}

	@Override
	@JsonIgnore
	@Transient
	public List<TableBasedElement> getChildren() {
		return getTableBasedElementList();
	}

	@Override
	@JsonIgnore
	@Transient
	public Perspective getRoot() {
		return getPerspective();
	}

	@Override
	@JsonIgnore
	@Transient
	public Boolean hasRoot() {
		return true;
	}
}
