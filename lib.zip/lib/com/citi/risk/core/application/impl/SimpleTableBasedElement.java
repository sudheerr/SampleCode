package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * The Class CacheTableBasedElement.
 */
public class SimpleTableBasedElement extends DefaultTableBasedElement{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	@Inject
	@Named("DownloadExcelNavigation")
	private Navigation downloadExcelNavigationItem;


	@Override
	public List<Navigation> getMenuList() {
		List<Navigation> list = new ArrayList<>();
		return list;
	}

	@Override
	public List<Navigation> getTableOperatorList() {
		List<Navigation> list = new ArrayList<>();
		list.add(downloadExcelNavigationItem);
		return list;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
