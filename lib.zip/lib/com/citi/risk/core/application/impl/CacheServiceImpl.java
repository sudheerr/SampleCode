package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import com.citi.risk.core.data.store.cache.impl.DefaultDataKeyPredicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.application.api.CacheService;
import com.citi.risk.core.application.bean.CriterionBean;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion.Op;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataMember;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.businessobject.TimeMark.RelativeTimePoint;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.google.inject.Inject;

public class CacheServiceImpl implements CacheService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheServiceImpl.class);

	@Inject private CacheManager cacheManager;
	@Inject	private DictionaryParser parser;
	@Inject	private Dictionary dictionary;

	private static final String DataAvailabilities="DataAvailabilities";
	private static final String EEMS_PERSPECTIVE="EemsPerspective";
	private static final String CRAC_PERSPECTIVE="CracPerspective";
	private static final String IS_FOR_HISTORICAL_COLOUMN = "isForHistoricalColumn";
	private static final String IS_FOR_AGGREGATED_COLOUMN = "isForAggregatedColumn";
	
	private static final Set<String> skippedDomains = new HashSet<>();

	public CacheServiceImpl() {
		skippedDomains.add(DataAvailabilities);
		skippedDomains.add(EEMS_PERSPECTIVE);
		skippedDomains.add(CRAC_PERSPECTIVE);
	}
	
	@Override
	public String getDomainName(String pathString){
		StringTokenizer pathPartTokenizer = new StringTokenizer(pathString, DataPath.PATH_SEPARATOR);
		if (pathPartTokenizer.hasMoreElements()) {
			String pathSegment = (String) pathPartTokenizer.nextElement();
			StringTokenizer domainPartTokenizer = new StringTokenizer(pathSegment, DataPath.PART_SEPARATOR);
			String domainPart = domainPartTokenizer.nextToken();
			Pair<String, String> typeNamePair = getTypeAndName(domainPart);
			if (!typeNamePair.getFirst().equals(DataPath.DOMAIN_MARKER)) 
				throw new UserVisibleException("Invalid path segment:" + pathSegment);
			return typeNamePair.getSecond();
		}
		return null;
	}

	private Pair<String, String> getTypeAndName(String domainPartString) {
		StringTokenizer partTokenizer = new StringTokenizer(domainPartString, DataPath.TYPE_NAME_SEPARATOR);
		String typeString = partTokenizer.nextToken();
		String nameString = partTokenizer.nextToken();
		return new Pair<>(typeString, nameString);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public DataDomain getDomain(String domainName){
		DataDomain domain = getAvailableDomainMap().get(domainName);
		if (domain == null) {
			throw new UserVisibleException("Domain with name " + domainName + " is not available.");
		}
		return domain;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map<String, DataDomain> getAvailableDomainMap() {
		Map<String, DataDomain> domainMap = Maps.newHashMap();
		Collection<DataDomain> domains = cacheManager.getDomains();
		for (DataDomain domain : domains) {
			domainMap.put(domain.getFullName(), domain);
		}
		return domainMap;
	}

	@SuppressWarnings("rawtypes")	
	@Override
	public List<Map<String, String>> loadDomainList(boolean aliasEnabled) {
		List<Map<String, String>> domainStr = new ArrayList<>();
		Collection<DataDomain> domains = cacheManager.getDomains();
		final String displayName = "displayName";
		for (DataDomain domain : domains) {
			if (checkDomainsToSkip(domain))
				continue;
			if (!isInCache(domain)) {
				Map<String, String> domainName = new HashMap<>();
				domainName.put(displayName, getDomainName(domain, aliasEnabled));
				domainName.put("domainName", domain.getDomainClass().getName());
				domainStr.add(domainName);
			}

		}
		Collections.sort(domainStr,new Comparator<Map<String, String>>(){
			@Override
			public int compare(Map<String, String> arg0, Map<String, String> arg1) {
				return arg0.get(displayName).compareToIgnoreCase(arg1.get(displayName));
			}
		});
		return domainStr;
	}

	private boolean isInCache(DataDomain domain) {
		return cacheManager.getMatchedDataKeys(new DefaultDataKeyPredicate(domain)).isEmpty();
	}

	private String getDomainName(DataDomain domain, boolean aliasEnabled) {
		String domainNameString = domain.getName() != null ? domain.getName() : domain.getDomainClass().getSimpleName();
		if(aliasEnabled) 
			domainNameString = !Strings.isNullOrEmpty(domain.getAlias()) ? domain.getAlias() : domainNameString;
		return domainNameString;
	}

	@Override
	public String getTerminatingItemName(String pathString, boolean aliasEnabled) {
		DataItem dataItem = dictionary.newPath(pathString).getTerminatingItem();
		return getTerminatingItemName(dataItem, aliasEnabled);
	}

	@Override
	public String getTerminatingItemName(DataItem dataItem, boolean aliasEnabled) {
		String terminatingItemName = dataItem.getName();
		if (aliasEnabled) {
			terminatingItemName = 
					Strings.isNullOrEmpty(dataItem.getAlias()) ? dataItem.getName() : dataItem.getAlias();
		}
		return terminatingItemName;
	}

	private boolean checkDomainsToSkip(DataDomain domain) {
		if(skippedDomains.contains(domain.getName())){
			return true;
		}
		return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Dictionary getDictionary(DataDomain domain){
		return dictionary;
	}

	@SuppressWarnings("rawtypes")	
	@Override
	public DataDomain parseDomain(Class<?> klass){
		return parser.parseDomain(klass);
	}

	@Override
	public DataDomain parseDomain(String domainFullKlassName){
		DataDomain domain = null;
		try {
			Class<?> domainKlass = Class.forName(domainFullKlassName);
			if (domainKlass != null && domainKlass != Void.class) {
				domain = parser.parseDomain(domainKlass);
			}
		}catch(Exception e){
			throw new UserVisibleException("Domain Class parse failed : " + domainFullKlassName, e);
		}
		return domain;
	}

	@Override
	public String getDomainNameFromFullClassName(String fullDomainClassName){
		String domainName = null;
		try {
			Class<?> domainClass = Class.forName(fullDomainClassName);
			if (domainClass != null && domainClass != Void.class) {
				domainName = parser.parseDomain(domainClass).getName();
			}
		}catch(Exception e){
			throw new UserVisibleException("Domain Class parse failed : " + fullDomainClassName, e);
		}
		return domainName;
	}

	@Override
	public String getDataTypeForPathString(String pathString){
		if(dictionary.newPath(pathString).isTerminatedWithAnItem()){
			return DataTypeUtil.getDataTypeString(dictionary
					.newPath(pathString)
					.getTerminatingItem()
					.getJavaSimpleType());
		}
		return null;
	}

	//Should use DataDomain
	@Override
	public boolean isTerminatingItemTimeMarkKey(String pathString){
		try {
			return dictionary
					.newPath(pathString)
					.getTerminatingItem().getName().equalsIgnoreCase(TIMEMARK_KEY);
		}catch(UserVisibleException exception){
			LOGGER.debug("Failed to get Path for path: " + pathString, exception);
			return pathString.endsWith(TIMEMARK_KEY);
		}
	}

	@Override
	public TimeMark getTimeMarkFromRelativeTimePoint(RelativeTimePoint relativeTimePoint, BatchFrequency batchFrequency, String pathString){
		Set<TimeMark> availableCOBs = getAvailableCOBs(dictionary.newPath(pathString).getStartingDomain());
		for(TimeMark availableCOB : availableCOBs){
			if(availableCOB.getBatchFrequency().equals(batchFrequency) && 
					availableCOB.getRelativeTimePoint().equals(relativeTimePoint)){
				return availableCOB;
			}
		}
		return null;
	}

	@Override
	public List<String> getBusinessDatesAsTimeMarkDisplayFormatString(DataDomain domain)
	{
		Set<TimeMark> timeMarks = getAvailableCOBs(domain);
		List<String> dateStringList = new ArrayList<>();
		for(TimeMark timeMark : timeMarks){
			dateStringList.add(CustomDate.getUIDisplayStringForTimeMark(timeMark));
		}
		return CustomDate.sortTimeMarkString(dateStringList);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public TimeMark getTimeMarkFromDisplayFormatString(DataDomain domain, String dateString){
		return CustomDate.findTimeMarkWithDisplayString(dateString, getAvailableCOBs(domain));
	}

	@Override
	public String getUIDisplayString(String pathString, String dateString){
		TimeMark timeMark = getTimeMarkFromDisplayFormatString(dictionary.newPath(pathString).getStartingDomain(), dateString);
		return CustomDate.getUIDisplayStringForTimeMark(timeMark);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ArrayList<TimeMark> getTimeMarksFromCriterionMapList(DataDomain domain, List<Map<String, Object>> criterionMapList){
		ArrayList<TimeMark> timeMarks = new ArrayList<>();
		for(Map<String, Object> criterion : criterionMapList){
			if(criterion.get("pathString").toString().contains(CacheService.TIMEMARK_KEY)){
				String dateString = ((ArrayList<String>)criterion.get("operandsString")).get(0);
				timeMarks.add(getTimeMarkFromDisplayFormatString(domain, dateString));
			}
		}
		return timeMarks;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Criteria getTimeMarkCriteria(List<Map<String, Object>> criteriaMap, DataDomain domain) {
		if (criteriaMap == null) {
			return null;
		}
		Criteria criteria = null;
		try {
			Iterator<Map<String, Object>> it = criteriaMap.iterator();
			while (it.hasNext()) {
				Map<String, Object> criterionMap = it.next();

				criteria = createTimeMarkCriteria(domain, criteria, it, criterionMap);
			}
		} catch (RuntimeException e) {
			LOGGER.error("Failed to parse TimeMark Criteria.", e);
			throw new UserVisibleException("Failed to parse TimeMark Criteria.");
		}
		return criteria;
	}

	private Criteria createTimeMarkCriteria(DataDomain domain, Criteria criteria, Iterator<Map<String, Object>> it,
			Map<String, Object> criterionMap) {
		Criteria newCriteria = criteria;
		if (null != criterionMap) {
			boolean isForHistoricalColumn = criterionMap.get(IS_FOR_HISTORICAL_COLOUMN) == null ? false
					: Boolean.valueOf(criterionMap.get(IS_FOR_HISTORICAL_COLOUMN).toString());

			boolean isForAggregatedColumn = criterionMap.get(IS_FOR_AGGREGATED_COLOUMN) == null ? false
					: Boolean.valueOf(criterionMap.get(IS_FOR_AGGREGATED_COLOUMN).toString());

			if (isForHistoricalColumn || isForAggregatedColumn)
				return newCriteria;

			DataPath timeMarkPath = dictionary.newPath((String) criterionMap.get("pathString"));

			if (timeMarkPath.getTerminatingItem().getName().equals(TIMEMARK_KEY)) {
				newCriteria = getCriteria(domain, criteria, criterionMap, timeMarkPath);
				it.remove();
			}
		}
		return newCriteria;
	}

	private Criteria getCriteria(DataDomain domain, Criteria criteria, Map<String, Object> criterionMap,
			DataPath timeMarkPath) {
		Criteria newCriteria = criteria;
		List<String> sTimeMark = new ArrayList<>();
		String operator = criterionMap.get("operator").toString();
		ArrayList<String> operandsStrings = (ArrayList<String>) criterionMap.get("operandsString");
		for (String operand : operandsStrings) {
			sTimeMark.add(getTimeMarkFromDisplayFormatString(domain, operand).getTimeMarkKey());
		}
		if (Op.in.toString().equalsIgnoreCase(operator)) {
			newCriteria = timeMarkPath.in(sTimeMark);
		} else if (Op.eq.toString().equalsIgnoreCase(operator)) {
			newCriteria = timeMarkPath.eq(sTimeMark.get(0));
		} else if (Op.ne.toString().equalsIgnoreCase(operator)) {
			newCriteria = getNotEqualToCriteria(criteria, timeMarkPath, sTimeMark);
		}
		return newCriteria;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Criteria getNotEqualToCriteria(Criteria criteria, DataPath calPath, Collection<String> sCal){
		Criteria newCriteria = criteria;
		for(String cal:sCal){
			if(newCriteria == null){
				newCriteria = calPath.ne(cal);
			}else{
				newCriteria = newCriteria.and(calPath.ne(cal));
			}
		}
		return newCriteria;
	}
	
	@SuppressWarnings("rawtypes")
	private Set<TimeMark> getAvailableCOBs(DataDomain domain) {
		Set<TimeMark> timeMarks = new TreeSet<>(new Comparator<TimeMark>(){
			@Override
			public int compare(TimeMark timeMark1, TimeMark timeMark2){
		        return timeMark1.compareTo(timeMark2);
		    }
		});
		Set<DataKey> availableDataKeys = cacheManager.searchDataAvailabilities();
		for (DataKey dataKey : availableDataKeys) {
			if (dataKey.getDomain().equals(domain)) {
				timeMarks.add(dataKey.getTimeMark());
			}
		}
		return timeMarks;
	}
	
	/**
	 * This method will transform TimerMarkCriteria to the back end needed format. that is one GUI side
	 * date criterion to three criteria
	 * 					"/D:TimeMark-I:Fiscal Year"
					"/D:TimeMark-I:Fiscal Month"
					"/D:TimeMark-I:Fiscal Day"
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public CriteriaWrapper toCriteriaWrapper(List<Map<String, Object>> criterionMapList, DataDomain domain) {
		Criteria timeMarkCriteria = getTimeMarkCriteria(criterionMapList, domain);
		CriteriaWrapper criteriaWrapper = toCriteriaWrapper(criterionMapList);
		
		Criteria normalCriteria=null;
		Criteria furtherCriteria=null;
		List<Criteria> disabledNormalCriterias=null;
		List<Criteria> disabledFurtherCriterias=null;
		if(criteriaWrapper!=null){
			normalCriteria=criteriaWrapper.getNormalCriteria();
			furtherCriteria=criteriaWrapper.getFurtherCriteria();
			disabledNormalCriterias=criteriaWrapper.getDisabledNormalCriterias();
			disabledFurtherCriterias=criteriaWrapper.getDisabledFurtherCriterias();
		}
		
		if(timeMarkCriteria!=null){
			normalCriteria = normalCriteria==null ? timeMarkCriteria : normalCriteria.and(timeMarkCriteria);
		}
		return new CriteriaWrapper(normalCriteria,furtherCriteria,disabledNormalCriterias,disabledFurtherCriterias);
	}
	
	/**
	 * This method will not transform TimerMarkCriteria to the back end needed format. e.g:
	 * the TimeMarkCriteria will be as the following:
	 * 2013-1-2-00-00-00-Daily
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public CriteriaWrapper toCriteriaWrapper(List<Map<String, Object>> criterionMapList) {
		if (criterionMapList == null) {
			return null;
		}
		
		Criteria normalCriteria = null;
		Criteria furtherCriteria=null;
		List<Criteria> disabledNormalCriterias=new ArrayList<>();
		List<Criteria> disabledFurtherCriterias=new ArrayList<>();
		
		CriteriaWrapper criteriaWrapper=new CriteriaWrapper();
		for (int i = 0; i < criterionMapList.size(); i++) {
			Map<String, Object> criterionMap = criterionMapList.get(i);
			if(criterionMap==null)
				continue;
			
			boolean isForHistoricalColumn= criterionMap.get(IS_FOR_HISTORICAL_COLOUMN)==null?false:Boolean.valueOf(criterionMap.get(IS_FOR_HISTORICAL_COLOUMN).toString());
			boolean isForAggregatedColumn= criterionMap.get(IS_FOR_AGGREGATED_COLOUMN)==null?false:Boolean.valueOf(criterionMap.get(IS_FOR_AGGREGATED_COLOUMN).toString());
			//When reload persisted filter, it does not have "disabled" attribute. 
			//If filter's criteria have different starting domain, actually one of the criteria should be "disabled" but this attribute is missing. 
			//Here is a workaround to firstly set all of them "disabled" is true, to avoid following exception on "Criteria.and(Criteria)" with their different starting domains. 
			//That would be no problem, because the code (in navigation.navigateTo(navigationParameter) accordingly) afterward will update "disabled" attribute to correct status as expected. 
			//"focus on", "exclude on", and "switch tab" functions are not impacted, because in those cases attributes are not reload from persistence, but from JS side where guaranteed attribute "disable" is correctly set. 
			
			if(isForHistoricalColumn || isForAggregatedColumn){
				furtherCriteria = histoOrAggreColumnCriteria(furtherCriteria, disabledFurtherCriterias, criterionMap);
			}else{
				normalCriteria = normalCriteria(normalCriteria, disabledNormalCriterias, criterionMap);			
			}
		}
		
		criteriaWrapper.setNormalCriteria(normalCriteria);
		criteriaWrapper.setFurtherCriteria(furtherCriteria);
		criteriaWrapper.setDisabledNormalCriterias(disabledNormalCriterias);
		criteriaWrapper.setDisabledFurtherCriterias(disabledFurtherCriterias);
		
		return criteriaWrapper;
	}

	private Criteria normalCriteria(Criteria normalCriteria, List<Criteria> disabledNormalCriterias,
			Map<String, Object> criterionMap) {
		Criteria newNormalCriteria = normalCriteria;
		boolean disabled= isCriterionDisable(criterionMap);
		Criteria newSingleCriteria=CriterionBean.toNormalCriteria(criterionMap, dictionary);	
		if(disabled){
			disabledNormalCriterias.add(newSingleCriteria);
		}else{
			if (normalCriteria == null) {
				newNormalCriteria = newSingleCriteria;
			} else {
				newNormalCriteria = normalCriteria.and(newSingleCriteria);
			}				
		}
		return newNormalCriteria;
	}

	private Criteria histoOrAggreColumnCriteria(Criteria furtherCriteria, List<Criteria> disabledFurtherCriterias,
			Map<String, Object> criterionMap) {
		boolean disabled= isCriterionDisable(criterionMap);
		Criteria singleFurtherCriteria=CriterionBean.toFurtherCriteria(criterionMap, dictionary);
		Criteria newFurtherCriteria = furtherCriteria;
		if(disabled){
			disabledFurtherCriterias.add(singleFurtherCriteria);
		}else{
			if(furtherCriteria==null){
				newFurtherCriteria=singleFurtherCriteria;
			}else{
				newFurtherCriteria=furtherCriteria.and(singleFurtherCriteria);
			}
		}
		return newFurtherCriteria;
	}

	private boolean isCriterionDisable(Map<String, Object> criterionMap) {
		return criterionMap.get("disabled")==null?true:Boolean.valueOf(criterionMap.get("disabled").toString());
	}
	
	private static String DISPLAY_PATH_SEPERATOR = " --> ";
	
	@Override
	public String getDomainDataDisplayPathString(DataPath dataPath){
		StringBuilder domainDataDisplayPathString = new StringBuilder();
		domainDataDisplayPathString.append(dataPath.getStartingDomain().getAlias());
		for (DataRelationship relationship : (List<DataRelationship<?,?>>)dataPath.getRelationships()) {
			domainDataDisplayPathString.append(getDomainDataDisplayPathString(relationship));
		}

		if (dataPath.isTerminatedWithAnItem())
			domainDataDisplayPathString.append(getDomainDataDisplayPathString(dataPath.getTerminatingItem()));
		return domainDataDisplayPathString.toString();
	}

	@Override
	public DataPath getTimeMarkPath(DataDomain domain) {

		DataRelationship timeMarkRelationship = domain.getRelationship("Time mark");
		DataItem timeMarkKey = timeMarkRelationship.getEndingDomain().getItem("TimeMark Key");
		DataPath path = timeMarkRelationship.path().append(timeMarkKey);

		return path;
	}

	private String getDomainDataDisplayPathString(DataMember<?,?> member) {
		StringBuilder stringBuffer = new StringBuilder(100);
		if(!Strings.isNullOrEmpty(member.getGroupId())){
			stringBuffer.append(DISPLAY_PATH_SEPERATOR);
			stringBuffer.append(member.getGroupId());
		}
		stringBuffer.append(DISPLAY_PATH_SEPERATOR);
		stringBuffer.append(member.getAlias());
		return stringBuffer.toString();
	}
}