package com.citi.risk.core.application.impl;

/**
 * @author bh30850
 */
public enum AuthoringType {

    FOLDER,
    PERSPECTIVE,
    VIEW,
    USER,
    OTHER,

}
