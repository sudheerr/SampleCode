package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.*;
import com.google.inject.Inject;

import java.util.List;

public class DefaultPerspectiveFactory implements PerspectiveFactory {

	@Inject
	ViewFactory viewFactory;

	@Override
	public Perspective createPerspective() {
		return new AdminGUIPerspective(viewFactory);
	}

	@Override
	public Perspective configurePerspective(Perspective defaultPerspective) {
		if (defaultPerspective.getViewList() != null && !defaultPerspective.getViewList().isEmpty()) {
			int displayIndex = 0;
			for(View view : defaultPerspective.getViewList()){
				viewFactory.configView( view);
				view.setDisplayIndex(displayIndex++);
			}
		}
		return defaultPerspective;
	}
}
