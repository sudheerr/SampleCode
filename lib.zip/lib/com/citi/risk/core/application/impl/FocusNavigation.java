package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.dictionary.api.Criteria;

public class FocusNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Focus";
	private static final NavigationFlow TYPE = NavigationFlow.FILTER;
	
	public FocusNavigation() {
		super(ITEMNAME,TYPE);
	}
	
	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		View targetView = navigationParameter.getTargetView();
		CriteriaWrapper criteriaWrapper = navigationParameter.getFocusCriteriaWrapper();
		Criteria criteria = criteriaWrapper.getNormalCriteria();
		
		if(targetView == null)
			throw new RuntimeException("cannot navigate to null");
		if(criteria == null){
			throw new RuntimeException("cannot focus on empty");
		}

		targetView.setGlobalCriteriaWrapper(criteriaWrapper);
		
		return targetView;
	}
}
