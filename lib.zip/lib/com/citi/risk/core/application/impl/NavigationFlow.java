package com.citi.risk.core.application.impl;

public enum NavigationFlow {
	REPORT,
	CONFIG,
	FILTER,
	TOOLKIT_VIEW,
	TOOLKIT_PERSPECTIVE;
}
