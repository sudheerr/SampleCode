package com.citi.risk.core.application.impl;

import java.util.List;

import com.citi.risk.core.application.api.FormBasedElement;
import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.data.query.api.Query;


@SuppressWarnings("serial")
public class DefaultFormBasedElement implements FormBasedElement {
	private Query query;
	private ViewContext viewContext;
	private String name;
	private List<Field<String, List<String>>> fields;
	private Navigation navigation;

	@Override
	public Object onLoad() {
		return getFields();
	}

	@Override
	public Query getQuery() {
		return this.query;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	@Override
	public ViewContext getViewContext() {
		return this.viewContext;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		this.viewContext = viewContext;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public List<Field<String, List<String>>> getFields() {
		return this.fields;
	}

	@Override
	public void setFields(List<Field<String, List<String>>> fields) {
		this.fields = fields;
	}

	public static class DefaultField implements Field<String, List<String>>{
		String key;
		List<String> value;

		public DefaultField(String key, List<String> value) {
			super();
			this.key = key;
			this.value = value;
		}

		@Override
		public String getKey() {
			return key;
		}

		@Override
		public List<String> getValue() {
			return value;
		}
	}

	@Override
	public Navigation getNextNavigation() {
		return navigation;
	}

	@Override
	public void setNextNavigation(Navigation navigation) {
		this.navigation = navigation;
	}

	@Override
	public Object clone() {
		//TODO
		throw new RuntimeException("Method is not implemented yet");
	}
}