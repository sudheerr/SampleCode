package com.citi.risk.core.application.impl;

import java.util.concurrent.ExecutionException;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.CacheOperations;
import com.citi.risk.core.data.store.cache.api.CacheTask;
import com.citi.risk.core.data.store.cache.impl.DefaultCacheTask;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class LoadNewCacheNavigation extends DefaultNavigation {
	
	private static final String ITEMNAME = "Load new Cache";
	
	@Inject
	private Injector injector;
	
	@Inject
	private CacheManager cacheManager;
	
	public LoadNewCacheNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		
		Loader loader = null;
		try {
			loader = (Loader) injector.getInstance(Class
					.forName(navigationParameter.getLoaderClassName()));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Fail to instantiate the class", e);
		}

		CreatedBy createdBy = null;
		try {
			createdBy = navigationParameter.getCreateBy().withLoaderClass((Class<Loader>)Class.forName(navigationParameter.getLoaderClassName()));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
		CacheOperations operation = CacheOperations.Load;
		TimeMark timeMark = navigationParameter.getTimeMark();
		CacheTask task = new DefaultCacheTask().domain(loader.getDomain())
				.loaderClass(loader.getClass()).timeMark(timeMark)
				.createdBy(createdBy).operation(operation);
		task.setUserInitiated(true);
		try {
			cacheManager.load(task).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		
		return null;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
