package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.TableBasedElement;
import com.citi.risk.core.application.api.TableConfiguration;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.data.query.api.Query;

public class DefaultTableConfiguration implements TableConfiguration {

	private String tableId;
	private String tableName;
	private Class<?> domainClass;
	private Class<? extends TableBasedElement> tableBasedElementClass;
	private Class<? extends Query> queryClass;
	private ViewContext viewContext;
	
	public DefaultTableConfiguration(){
		//intentionally-blank override
	}
	
	public DefaultTableConfiguration(String tableName, Class<?> domainClass,
			Class<? extends TableBasedElement> tableBasedElementClass,
			Class<? extends Query> queryClass, ViewContext viewContext) {
		this.tableName = tableName;
		this.domainClass = domainClass;
		this.tableBasedElementClass = tableBasedElementClass;
		this.queryClass = queryClass;
		this.viewContext = viewContext;
	}
	
	public DefaultTableConfiguration(String tableId, String tableName, Class<?> domainClass,
			Class<? extends TableBasedElement> tableBasedElementClass,
			Class<? extends Query> queryClass, ViewContext viewContext) {
		this.tableId = tableId;
		this.tableName = tableName;
		this.domainClass = domainClass;
		this.tableBasedElementClass = tableBasedElementClass;
		this.queryClass = queryClass;
		this.viewContext = viewContext;
	}
	
	@Override
	public String getTableName() {
		return this.tableName;
	}

	@Override
	public Class<?> getDomainClass() {
		return this.domainClass;
	}

	@Override
	public Class<? extends TableBasedElement> getTableBasedElementClass() {
		return this.tableBasedElementClass;
	}

	@Override
	public Class<?> getQueryClass() {
		return this.queryClass;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public void setDomainClass(Class<?> domainClass) {
		this.domainClass = domainClass;
	}

	public void setTableBasedElementClass(
			Class<? extends TableBasedElement> tableBasedElementClass) {
		this.tableBasedElementClass = tableBasedElementClass;
	}

	public void setQueryClass(Class<? extends Query> queryClass) {
		this.queryClass = queryClass;
	}

	@Override
	public ViewContext getViewContext() {
		return this.viewContext;
	}
	
	public void setViewContext(ViewContext viewContext){
		this.viewContext = viewContext;
	}

	@Override
	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
	
	
	
}
