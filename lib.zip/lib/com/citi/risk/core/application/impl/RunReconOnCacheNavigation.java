package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;

public class RunReconOnCacheNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Run Recon On Cache";

	public RunReconOnCacheNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		return null;
	}

}
