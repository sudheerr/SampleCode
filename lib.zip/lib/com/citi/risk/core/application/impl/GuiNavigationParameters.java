package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.View;
import com.citi.risk.core.application.impl.CriteriaWrapper;
import com.citi.risk.core.lang.table.SimpleTable;

public interface GuiNavigationParameters {

	View getTargetView();

	void setTargetView(View targetView);

	void setSimpleTable(SimpleTable simpleTable);

	SimpleTable getSimpleTable();

	CriteriaWrapper getSwitchCriteriaWrapper();

	void setSwitchCriteriaWrapper(CriteriaWrapper switchCriteriaWrapper);

}
