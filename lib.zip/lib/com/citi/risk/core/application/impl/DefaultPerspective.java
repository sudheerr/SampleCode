package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.*;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Entity
@Table(name = "DefaultPerspective")
public class DefaultPerspective implements EemsPerspective, CracPerspective {
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultPerspective.class);
	ViewFactory viewFactory;

	public static final String NAME_ATTR = "name";
	public static final String APP_ALIAS_ATTR = "appAlias";
	public static final String SOEID_ATTR = "soeId";
	public static final String SHARED_ATTR = "shared";

	private Integer id;
	@ToBeCompared
	private String name;
	@ToBeCompared
	private String alias;
	@ToBeCompared
	private String type;
	private String startupUrl;
	private Boolean active;
	private String soeId;
	private Integer sourceId;
	private String perspectiveCategory;
	@ToBeCompared
	private String appAlias;
	@ToBeCompared
	private Boolean shared;
	private String folderPath = "";

	private List<View> viewList = new ArrayList<>();
	private List<IntegrationTabMenuItem> integrationTabMenuItems;

	public DefaultPerspective() {
		super();
	}

	public static Perspective newInstance(){
		return new DefaultPerspective();
	}

	public DefaultPerspective(String dpstring) {
		super();
		String dpsplits[] = dpstring.split("!");
		this.name = dpsplits[0];
	}

	public DefaultPerspective(ViewFactory viewFactory) {
		this.viewFactory = viewFactory;
		Class<? extends View>[] viewClasses = getViewInstances();
		for (Class<? extends View> viewClass : viewClasses) {
			this.addViewClass(viewClass);
		}
	}

	@Transient
	private Class<? extends View>[] getViewInstances() {
		PerspectiveConfiguration perspectiveConfiguration = (PerspectiveConfiguration) this.getClass().getAnnotation(
				PerspectiveConfiguration.class);
		if (perspectiveConfiguration == null)
			throw new RuntimeException(this.getClass().getCanonicalName() + " is not a Perspective Class");

		Class<? extends View>[] viewClasses = perspectiveConfiguration.viewClasses();
		return viewClasses;
	}

	//TODO ==> getContent(String name)
	@Override
	@Transient
	public View getViewByName(String name) {
		Iterator<View> iterator = viewList.iterator();
		while (iterator.hasNext()) {
			View view = iterator.next();
			if (view.getName().equals(name)) {
				return view;
			}
		}
		return null;
	}

	private void addViewClass(Class<? extends View> viewClass) {
		View view = viewFactory.newView(viewClass);
		viewList.add(view);
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DefaultPerspective_Seq")  //generator setting in orm.xml in apps project 
	@Column(name = "id", nullable = false)
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	@Column(nullable = false, length = 50)
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	@Column(nullable = false, length = 50)
	public String getAlias() {
	    return alias;
	}

	@Override
	public void setAlias(String alias) {
	    this.alias = alias;
	}

	@Override
	@Transient
	public Boolean isActive() {
	    return active;
	}

	@Override
	public void setActive(Boolean active) {
	    this.active = active;
	}

	@Override
	@Column(columnDefinition="varchar2(100 char) default 'navigator'")
	public String getType() {
	    return type;
	}

	@Override
	public void setType(String type) {
	    this.type = type;
	}

	@Override
	@Column(columnDefinition="varchar2(255 char) default 'default'")
	public String getStartupUrl() {
	    return startupUrl;
	}

	@Override
	public void setStartupUrl(String startupUrl) {
	    this.startupUrl = startupUrl;
	}

	@Override
	@Column(length = 10)
	public String getSoeId() {
		return soeId;
	}

	@Override
	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	//TODO getContents()
	@Override
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = DefaultView.class, orphanRemoval = true)
	@JoinColumn(name = "perspectiveId")
	@Fetch(FetchMode.SUBSELECT)
	@OrderBy(value = "displayIndex")
	public List<View> getViewList() {
		return viewList;
	}

	@Override
	public void setViewList(List<View> viewList) {
		this.viewList = viewList;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultPerspective other = (DefaultPerspective) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		if (soeId == null) {
			if (other.soeId != null)
				return false;
		} else if (!soeId.equals(other.soeId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DefaultPerspective {id = " + id + 
				", name = " + name + 
				", alias = " + alias + 
				", type = " + type + 
				", startupUrl = " + startupUrl + 
				", soeId = " + soeId + 
				", sourceId = " + sourceId + 
				", appAlias = " + appAlias + 
				", shared = " + shared +
				"}";
	}

	@Override
	public Integer getSourceId() {
		return sourceId;
	}

	@Override
	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	@Override
	public String getPerspectiveCategory() {
		return perspectiveCategory;
	}

	@Override
	public void setPerspectiveCategory(String perspectiveCategory) {
		this.perspectiveCategory = perspectiveCategory;
	}

	@Override
	@Column(nullable = false, length = 50)
	public String getAppAlias() {
	    return appAlias;
	}

	@Override
	public void setAppAlias(String appAlias) {
	    this.appAlias = appAlias;
	}

	@Override
	public Boolean isShared() {
		return shared;
	}

	@Override
	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		DefaultPerspective perspective = (DefaultPerspective) super.clone();
		List<View> views = new ArrayList<>();
		if (perspective.getViewList() != null) {
			int displayIndex = 0;
			for (View view : perspective.getViewList()) {
				View cloneView = (View) view.clone();
				cloneView.setDisplayIndex(displayIndex++);
				views.add(cloneView);
			}
		}
		perspective.setViewList(views);
		return perspective;
	}

	@Override
	public Perspective copy() {
		DefaultPerspective perspective = null;
		try {
		    perspective = (DefaultPerspective) super.clone();
		    List<View> views = new ArrayList<>();
		    if (perspective.getViewList() != null) {
			for (View view : perspective.getViewList()) {
				views.add((View) view.copy(perspective));
			}
		    }
		    perspective.setViewList(views);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy perspective", e);
		}
		return perspective;
	}

	@Override
	@Transient
	public List<IntegrationTabMenuItem> getViewCreationMenuItems() {
		return integrationTabMenuItems;
	}

	@Override
	public void setViewCreationMenuItems(List<IntegrationTabMenuItem> integrationTabMenuItems) {
		this.integrationTabMenuItems = integrationTabMenuItems;
	}

	@Override
	public Integer key() {
		return id;
	}

	@Transient
	@Override
	public TimeMark getTimeMark() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		// TODO Auto-generated method stub
		
	}

	@Transient
	@Override
	public CreatedBy getCreatedBy() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		// TODO Auto-generated method stub
		
	}

	@Transient
	@Override
	public String getTimeMarkString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTimeMarkString(String timeMarkKey) {
		// TODO Auto-generated method stub
		
	}

	@Transient
	@Override
	public String getCreatedByString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setCreatedByString(String createdByKey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transient
	public IntegrationTabMenuItem getViewCreationMenuItem(String itemName) {

		for (IntegrationTabMenuItem integrationTabMenuItem : integrationTabMenuItems) {
			if (integrationTabMenuItem.getItemName().equals(itemName))
				return integrationTabMenuItem;
		}

		return null;
	}

	@Override
	@Transient
	public String getFolderPath() {
		return folderPath;
	}

	@Override
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	@Override
	@JsonIgnore
	@Transient
	public List<View> getChildren() {
		return getViewList();
	}
}
