package com.citi.risk.core.application.impl;

import java.util.List;

import com.citi.risk.core.application.api.GraphBasedElement;
import com.citi.risk.core.application.api.GraphElementType;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.bean.GraphData;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.lang.table.SimpleTable;

public class DefaultGraphBasedElement implements GraphBasedElement<Object, List<Object>> {

	private static final long serialVersionUID = -2963665428133083945L;

	private Query query;
	private ViewContext viewContext;
	private GraphElementType graphType;
	private SimpleTable tableData;
	private GraphData graphData;
	private List<String> headers;
	private List<ColumnHeader> tableHeaders;

	private String link;

	@Override
	public SimpleTable onLoad() {
		return null;
	}

	@Override
	public Query getQuery() {
		return this.query;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	@Override
	public ViewContext getViewContext() {
		return this.viewContext;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		this.viewContext = viewContext;
	}

	@Override
	public void setGraphType(GraphElementType type) {
		this.graphType = type;
	}

	@Override
	public GraphElementType getGraphType() {
		return this.graphType;
	}

	@Override
	public void setGraphData(GraphData graphData) {
		this.graphData = graphData;
	}

	@Override
	public GraphData getGraphData() {
		return graphData;
	}

	@Override
	public SimpleTable getTableData() {
		return tableData;
	}

	@Override
	public void setTableData(SimpleTable tableData) {
		this.tableData = tableData;
	}

	@Override
	public void setHeaders(List<String> headers) {
		this.headers = headers;
	}

	@Override
	public List<String> getHeaders() {
		return this.headers;
	}

	@Override
	public void setTableHeaders(List<ColumnHeader> tableHeaders) {
		this.tableHeaders = tableHeaders;
	}

	@Override
	public List<ColumnHeader> getTableHeaders() {
		return this.tableHeaders;
	}

	@Override
	public Object clone() {
		// TODO
		throw new RuntimeException("Method is not implemented yet");
	}

	@Override
	public void setDownloadLink(String link) {
		this.link = link;
	}

	@Override
	public String getDownloadLink() {
		return link;
	}

}