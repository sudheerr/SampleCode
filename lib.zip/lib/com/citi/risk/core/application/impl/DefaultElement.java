package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.Element;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.data.query.api.Query;

public class DefaultElement implements Element<Object> {

	@Override
	public Object clone() throws CloneNotSupportedException{
		Object o = super.clone();
		Element element = (Element)o;
		return element;
	}

	/*
	 * **************************************
	 * FROM /Commons
	 * **************************************
	 */

	@Override
	public Object onLoad() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Query getQuery() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setQuery(Query query) {
		// TODO Auto-generated method stub
	}

	@Override
	public ViewContext getViewContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		// TODO Auto-generated method stub
		
	}
}