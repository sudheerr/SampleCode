package com.citi.risk.core.application.impl;

import java.util.Map;
import java.util.Set;

import com.citi.risk.core.application.api.TableBasedElement;
import com.citi.risk.core.application.api.ViewConfiguration;
import com.citi.risk.core.data.query.impl.DataCachesQuery;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.common.collect.Maps;
import com.google.inject.Inject;

@ViewConfiguration(name = "Object Browser", domainClass = Void.class, tableBasedElementClasses = ObjectBrowserTableBasedElement.class, queryClass = DataCachesQuery.class)
public class ObjectBrowserView extends DefaultView {

	@Inject
	private CacheManager cacheManager;

	@Override
	public Map<String, DataDomain> getAvailableDomainMap() {
		Map<String, DataDomain> domainMap = Maps.newHashMap();
		Set<DataKey> availableDataKeys = cacheManager.searchDataAvailabilities();
		for (DataKey dataKey : availableDataKeys) {
			domainMap.put(dataKey.getDomain().getName(), dataKey.getDomain());
		}
		return domainMap;
	}


	@Override
	public void updateViewWithNewDomain(String domainName) {
		DataDomain domain = this.getAvailableDomainMap().get(domainName);
		if (domain == null) {
			throw new RuntimeException("Domain with name " + domainName + " is not available.");
		}

		this.getViewContext().setDomain(domain);
		this.setDictionary(parser.parse(domain.getDomainClass()));

		// need update the view info.
		for(TableBasedElement tableBasedElement : this.getTableBasedElementList()) {
			tableBasedElement.setHeader(null);
			tableBasedElement.setCriteria(null);
		}

		this.setDefaultCriteria();
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
