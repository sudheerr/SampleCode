package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.PerspectiveConfiguration;
import com.citi.risk.core.application.api.ViewFactory;
import com.citi.risk.core.configuration.application.impl.ConfigurationView;
import com.citi.risk.core.data.store.cache.application.impl.CacheView;
import com.citi.risk.core.dictionary.application.impl.MetaDataView;
import com.citi.risk.core.execution.application.impl.TaskView;
import com.citi.risk.core.regression.application.impl.RegressionView;
import com.google.inject.Inject;

@PerspectiveConfiguration(viewClasses = { ConfigurationView.class, CacheView.class, TaskView.class, ObjectBrowserView.class, MetaDataView.class})

public class AdminGUIPerspective extends DefaultPerspective {
	@Inject
	public AdminGUIPerspective(ViewFactory viewFactory) {
		super(viewFactory);
	}
}
