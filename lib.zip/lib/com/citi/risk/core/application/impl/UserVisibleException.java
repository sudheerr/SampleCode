package com.citi.risk.core.application.impl;

/**
 * The exception messages enclosed by this class will be displayed on GUI.
 *
 */
public class UserVisibleException extends RuntimeException {
    public UserVisibleException(String message) {
        super(message);
    }

    public UserVisibleException(String message, Throwable cause) {
        super(message, cause);
    }
}
