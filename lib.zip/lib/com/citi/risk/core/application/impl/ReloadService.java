package com.citi.risk.core.application.impl;

import java.util.Collection;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.lang.annotation.Service;

@Service
public interface ReloadService {
	 public void reload(CacheManager cacheManager, Collection<DataKey> dataKeys);
}
