package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import com.citi.risk.core.application.api.GraphBasedElement;
import com.citi.risk.core.application.api.GraphElementType;
import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.bean.GraphData;
import com.citi.risk.core.application.function.DsiConvertor;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysis;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysisRequest;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysisResult;
import com.citi.risk.core.data.query.impl.AbstractQuery;
import com.citi.risk.core.data.query.impl.DataCachesQuery;
import com.citi.risk.core.data.query.impl.DefaultSimpleQuery;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.inject.Inject;

public class TimeSeriesCurveViewNavigation extends DefaultNavigation {

	private static final String X_FIELD_NAME = "Tenors";
	private static final String ITEMNAME = "View Time Series Curve Result";
	private static final String TIMEMARK_DOMAIN_NAME = "TimeMark";

	@Inject
	private TimeSeriesAnalysis timeSeriesAnalysis;

	@Inject
	private DefaultSimpleQuery query;

	public TimeSeriesCurveViewNavigation() {
		super(ITEMNAME);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
	public View navigateTo(NavigationParameter navigationParameter) {
		View targetView = navigationParameter.getTargetView();
		GraphBasedElement graphBasedElement = new DefaultGraphBasedElement();
		graphBasedElement.setGraphType(GraphElementType.LINE);

		String timeSeriesCurveMeasure = navigationParameter.getTimeSeriesCurveMeasure();
		SimpleTable selectedRows = navigationParameter.getSimpleTable();
		Set<DataSelectionItem> columnKeys = selectedRows.columnKeySet();

		List<DataSelectionItem> dsiList = Lists.newArrayList();
		List<DataSelectionItem> criterionList = Lists.newArrayList();
		List<DataSelectionItem> ddlDsiList = Lists.newArrayList();

		DataDomain startDomain = null;
		for (DataSelectionItem dsi : columnKeys) {
			startDomain = dsi.getUnderlyingPath().getStartingDomain();
			if (!dsi.getUnderlyingPath().isTerminatedWithAnItem()) {
				continue;
			}
			if (timeSeriesCurveMeasure.equalsIgnoreCase(dsi.getUnderlyingPath().getTerminatingItem().getName())) {
				dsiList.add(dsi);
				ddlDsiList.add(dsi);
			}
			if (dsi.getUnderlyingPath().getTerminatingItem().isDimension() && dsi.getSelectedAggregateMeasure() == null) {
				dsiList.add(dsi);
				criterionList.add(dsi);
			}
		}

		DataSelection<?> dataSelection = generateDataSelection(dsiList);
		Criteria criteria = generateCriteria(selectedRows, criterionList);
		QueryRequest queryRequest = dataSelection.asQueryRequest();
		if (criteria != null) {
			queryRequest.addCriteria(criteria);
		}
		TimeSeriesAnalysisResult tsResult = analyzeQueryRequest(navigationParameter, queryRequest);
		SimpleTable rsTable = tsResult.getTable();
		Set<ColumnHeader> columnHeaders = generateColumnHeadersFromDSI(rsTable);
		graphBasedElement.setTableHeaders(new ArrayList<ColumnHeader>(columnHeaders));
		graphBasedElement.setTableData(rsTable);
		GraphData graphData = generateGraphData(timeSeriesCurveMeasure, ddlDsiList, startDomain, rsTable);
		graphBasedElement.setGraphData(graphData);
		targetView.setGraphBasedElement(graphBasedElement);
		return targetView;
	}

    private DataSelection<?> generateDataSelection(List<DataSelectionItem> dsiList) {
        Iterator<DataSelectionItem> dsIter = dsiList.iterator();
		DataSelection<?> dataSelection;
		if (dsIter.hasNext()) {
			DataSelectionItem tmpDSI = dsIter.next();
			if (tmpDSI.getSelectedAggregateMeasure() == null) {
				dataSelection = tmpDSI.getUnderlyingPath().select();
			} else {
				dataSelection = tmpDSI.getUnderlyingPath().aggregateTo(tmpDSI.getSelectedAggregateMeasure());
			}

			while (dsIter.hasNext()) {
				tmpDSI = dsIter.next();
				if (tmpDSI.getSelectedAggregateMeasure() == null) {
					dataSelection.and(tmpDSI.getUnderlyingPath());
				} else {
					dataSelection.and(tmpDSI.getUnderlyingPath().aggregateTo(tmpDSI.getSelectedAggregateMeasure()));
				}
			}
		} else {
			throw new NoSuchElementException("Invalid data selections.");
		}
        return dataSelection;
    }

    private Criteria generateCriteria(SimpleTable selectedRows, List<DataSelectionItem> criterionList) {
        Iterator<DataSelectionItem> criterionIter = criterionList.iterator();
		Criteria criteria = null;
		if (criterionIter.hasNext()) {
			DataSelectionItem tmpDSI = criterionIter.next();
			Class<?> terminatingItemType = tmpDSI.getUnderlyingPath().getTerminatingItem().getJavaSimpleType();
			String stringValue = selectedRows.column(tmpDSI).values().iterator().next().toString();
			if (terminatingItemType.isEnum()) {
				criteria = tmpDSI.getUnderlyingPath().eq(Enum.valueOf((Class) terminatingItemType, stringValue));
			} else if(Strings.isNullOrEmpty(stringValue)){
				criteria = tmpDSI.getUnderlyingPath().isNull();
			} else {
				criteria = tmpDSI.getUnderlyingPath().eq(selectedRows.column(tmpDSI).values().iterator().next().toString());
			}

			while (criterionIter.hasNext()) {
				tmpDSI = criterionIter.next();
				terminatingItemType = tmpDSI.getUnderlyingPath().getTerminatingItem().getJavaSimpleType();
				stringValue = selectedRows.column(tmpDSI).values().iterator().next().toString();
				if (terminatingItemType.isEnum()) {
					criteria = criteria.and(tmpDSI.getUnderlyingPath().eq(Enum.valueOf((Class) terminatingItemType, stringValue)));
				} else {
					criteria = andCriteriaWithNotEnumTerminatingItemType(criteria, tmpDSI, stringValue);
				}
			}
		}
        return criteria;
    }

    private TimeSeriesAnalysisResult analyzeQueryRequest(NavigationParameter navigationParameter,
            QueryRequest queryRequest) {
        List<TimeMark> cOBs = navigationParameter.getCOBs();
		Collections.sort(cOBs);
		TimeSeriesAnalysisRequest tsRequest = queryRequest.forTimeSeriesAnalysis(cOBs);
		TimeSeriesAnalysisResult tsResult = null;
		timeSeriesAnalysis.setQuery(query);
		try {
			tsResult = (TimeSeriesAnalysisResult) timeSeriesAnalysis.analyze(tsRequest).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new IllegalStateException("Failed to perform time series anlysis.", e);
		}
        return tsResult;
    }

    private Set<ColumnHeader> generateColumnHeadersFromDSI(SimpleTable rsTable) {
        Set<ColumnHeader> columnHeaders = new LinkedHashSet<>();
		for (Integer rowKey : rsTable.rowKeySet()) {
			Map<DataSelectionItem, Object> rowValues = rsTable.row(rowKey);
			Iterator it = rowValues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<DataSelectionItem, Object> pairs = (Map.Entry<DataSelectionItem, Object>) it.next();
				columnHeaders.add(DsiConvertor.convertDSIToColumnHeader(pairs.getKey()));
				
				Object pairValue = pairs.getValue();
				if(pairValue.getClass().equals(Date.class)){
					pairs.setValue(CustomDate.toDefaultDisplayString(pairValue));
				}
			}
		}
        return columnHeaders;
    }

    private GraphData generateGraphData(String timeSeriesCurveMeasure, List<DataSelectionItem> ddlDsiList,
            DataDomain startDomain, SimpleTable rsTable) {
        List<String> yField = Lists.newArrayList();
		Map<String, List<Object>> dataMap = new LinkedHashMap<>();
		String[] labels = startDomain.getItemLists(timeSeriesCurveMeasure).getLabels();
		for (DataSelectionItem columnKey : rsTable.columnKeySet()) {
			String key = null;
			List<Object> values = Lists.newArrayList();
			Map<Integer, Object> columnValues = rsTable.column(columnKey);
			Iterator it = columnValues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<Integer, Object> pairs = (Map.Entry<Integer, Object>) it.next();
				if (columnKey.getUnderlyingPath().toPathString().contains(TIMEMARK_DOMAIN_NAME)) {
					yField.add(String.valueOf(pairs.getValue()));
				} else if (ddlDsiList.contains(columnKey)) {
					values.add(pairs.getValue());
					int elementIndex = columnKey.getUnderlyingPath().elementIndex();
					key = labels[elementIndex];
				}
			}
			if (key != null) {
				dataMap.put(key,  values);
			}
		}
		
	    GraphData graphData = new GraphData();
	    graphData.setxField(X_FIELD_NAME);
		graphData.setGraphData(dataMap);
		graphData.setyField(yField);
        return graphData;
    }

	private Criteria andCriteriaWithNotEnumTerminatingItemType(Criteria criteria, DataSelectionItem tmpDSI,
			String stringValue) {
		Criteria returnedCriteria;
		if(Strings.isNullOrEmpty(stringValue)){
			returnedCriteria = criteria.and(tmpDSI.getUnderlyingPath().isNull());
		}else{
			returnedCriteria = criteria.and(tmpDSI.getUnderlyingPath().eq(stringValue));
		}
		return returnedCriteria;
	}

	public void setQuery(DefaultSimpleQuery query) {
		this.query = query;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
