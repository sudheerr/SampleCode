package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.*;
import com.citi.risk.core.data.query.impl.DataCachesQuery;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;

import java.util.List;

public class DefaultTableBasedElementFactory implements TableBasedElementFactory {

	@Inject
	private Injector injector;
	
	@Inject
	private NavigationHolder navigationHolder;
	
	@Override
	public TableBasedElement configElement(TableBasedElement element) {
		element.setQuery(injector.getInstance(DataCachesQuery.class));
		element.setViewContext(element.getView().getViewContext());
		
		List<Navigation> menuList = Lists.newArrayList();
		
		ViewContext context = element.getView().getViewContext();
		if(context != null){
			DataDomain domain = element.getView().getViewContext().getDomain();
			if(domain != null){
				menuList = navigationHolder.getNavigations(element.getView().getViewContext().getDomain(),
					element.getTemplateName());

			}
		}
		
		menuList.add(0, new FocusNavigation());
		menuList.add(1, new ExcludeNavigation());
		element.setMenuList(menuList);
		
		return element;
	}
	
}
