package com.citi.risk.core.application.impl;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.google.inject.Inject;

public class DeserializeCacheNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Deserialize Cache from File";
	
	@Inject
	private CacheManager cacheManager;

	public DeserializeCacheNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		List<File> fileList = navigationParameter.getFileList();
		if (fileList == null || fileList.isEmpty()) {
			return null;
		}
		try {
			cacheManager.deserializeFromFiles(fileList).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		
		return null;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
