package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.application.api.ViewFactory;
import com.citi.risk.core.data.query.impl.DefaultSimpleQuery;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.application.impl.ValidateCacheView;
import com.citi.risk.core.data.store.cache.impl.CacheValidationManager;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.collect.Iterables;
import com.google.common.collect.Table;
import com.google.inject.Inject;
import com.google.inject.Injector;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class ValidateCacheNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Validate";

	@Inject
	private Injector injector;
	@Inject
	private DictionaryParser parser;
	@Inject
	private CacheManager cacheManager;
	@Inject
	private CacheValidationManager cacheValidationManager;
	@Inject
	private ViewFactory viewFactory;

	public ValidateCacheNavigation() {
		super(ITEMNAME);
	}

	@Override
	public List<View> popUp(NavigationParameter navigationParameter) {

		try {
			List<Future<Pair<List<? extends IdentifiedBy<?>>, Boolean>>> futures = new ArrayList<>();
			List<View> viewList = new ArrayList<>();
			List<String> domainNames = new ArrayList<>();

			for (DataKey dataKey : populateDatakeyList(navigationParameter.getSimpleTable())) {
				Future<Pair<List<? extends IdentifiedBy<?>>, Boolean>> future = cacheValidationManager.cacheValidate(dataKey);
				domainNames.add(dataKey.getKeyString());
				futures.add(future);
			}
			Iterator<String> iterator = domainNames.iterator();
			for (Future<Pair<List<? extends IdentifiedBy<?>>, Boolean>> future : futures) {
				String name = iterator.next();
				Pair<List<? extends IdentifiedBy<?>>, Boolean>  pair = future.get();
				List<? extends IdentifiedBy<?>> cacheValidatedInfoList = pair.getFirst();
				if (CollectionUtils.isNotEmpty(cacheValidatedInfoList)) {
					Class<?> domainImplClass = Iterables.getFirst(cacheValidatedInfoList, null).getClass().getInterfaces()[0];
					DataDomain domain = parser.parseDomain(domainImplClass);
					
					DefaultSimpleQuery simpleQuery = injector.getInstance(DefaultSimpleQuery.class);
					simpleQuery.withItemsToSearch(cacheValidatedInfoList);

					View view = viewFactory.newView(ValidateCacheView.class);

					view.getViewContext().setQuery(simpleQuery);
					view.setDictionary(parser.parse(domainImplClass));
					view.getViewContext().setDomain(domain);
					name = nameWithStatus(name, pair);
					view.setName(name);
					view.setDefaultCriteria();
					viewList.add(view);
				}
			}
			return viewList;
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException("Failed to cacheValidate dataKey", e);
		}

	}

	private String nameWithStatus(String name, Pair<List<? extends IdentifiedBy<?>>, Boolean> pair) {
		String newName;
	    if(pair.getSecond()){
	    	newName = "[Passed]" + name;
	    }else{
	    	newName = "[Failed]"+ name;
	    }
	    return newName;
    }

	protected List<DataKey> populateDatakeyList(Table<Integer, DataSelectionItem, Object> selectedTable) {
		List<DataKey> dataKeyList = new ArrayList<>();
		for (Map<DataSelectionItem, Object> row : selectedTable.rowMap().values()) {
			for (Entry<DataSelectionItem, Object> entry : row.entrySet()) {
				if (currentItemIsKey(entry)) {
					addNotNullDataKeyToList(dataKeyList, entry);
				}
			}
		}
		return dataKeyList;
	}

	private void addNotNullDataKeyToList(List<DataKey> dataKeyList, Entry<DataSelectionItem, Object> entry) {
	    DataKey dataKey = createDataKeyFromObject(entry.getValue());
	    if (dataKey != null)
	    	dataKeyList.add(dataKey);
    }

	private Boolean currentItemIsKey(Entry<DataSelectionItem, Object> entry) {
		return entry.getKey().getUnderlyingPath().getTerminatingItem().isKey();
	}

	private DataKey createDataKeyFromObject(Object value) {
		DataKey dataKey;
		if (value instanceof DataKey) {
			dataKey = (DataKey) value;
		} else if (value instanceof String) {
			String strValue = (String) value;
			dataKey = searchDataKey(strValue);
		} else {
			throw new RuntimeException("Creating DataKey from string value failed.");
		}
		return dataKey;
	}

	private DataKey searchDataKey(String dataKeyString) {
		for (DataKey dk : this.cacheManager.getAllDataKeys()) {
			if (dk.getKeyString().equals(dataKeyString))
				return dk;
		}
		return null;
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		return null;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
