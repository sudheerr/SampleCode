package com.citi.risk.core.application.impl;

import com.citi.risk.core.lang.collection.list.Lists;

import java.util.List;

/**
 * @author bh30850
 */
public class AuthoringNode {

    private Integer entityId;
    private Integer sourceEntityId;

    private String name;
    private String path;
    private List<Integer> route = Lists.newArrayList();
    private String soeId;
    private String appAlias;
    private Boolean shared = false;

    private AuthoringType type;

    private Boolean leaf = true;
    private Boolean expanded = false;

    private Boolean shareStatusUpdated = false;
    private Boolean deleted = false;
    private Boolean copied = false;
    private Boolean renamed = false;
    private Boolean created = false;

    private AuthoringNode parent;
    private List<AuthoringNode> children;

    public static AuthoringNode newInstance() {
        return new AuthoringNode();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getSoeId() {
        return soeId;
    }

    public void setSoeId(String soeId) {
        this.soeId = soeId;
    }

    public Boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(Boolean leaf) {
        this.leaf = leaf;
    }

    public Boolean isShareStatusUpdated() {
        return shareStatusUpdated;
    }

    public Boolean isDeleted() {
        return deleted;
    }

    public Boolean isCopied() {
        return copied;
    }

    public void setShareStatusUpdated(Boolean shareStatusUpdated) {
        this.shareStatusUpdated = shareStatusUpdated;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public void setCopied(Boolean copied) {
        this.copied = copied;
    }

    public void setRenamed(Boolean renamed) {
        this.renamed = renamed;
    }

    public Boolean isRenamed() {
        return renamed;
    }

    public AuthoringNode getParent() {
        return parent;
    }

    public void setParent(AuthoringNode parent) {
        this.parent = parent;
    }

    public List<AuthoringNode> getChildren() {
        return children;
    }

    public void setChildren(List<AuthoringNode> children) {
        this.children = children;
    }

    public void addChild(AuthoringNode child) {
        children.add(child);
    }

    public AuthoringType getType() {
        return type;
    }

    public void setType(AuthoringType type) {
        this.type = type;
    }

    public Integer getEntityId() {
        return entityId;
    }

    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    public Integer getSourceEntityId() {
        return sourceEntityId;
    }

    public void setSourceEntityId(Integer sourceEntityId) {
        this.sourceEntityId = sourceEntityId;
    }

    public List<Integer> getRoute() {
        return route;
    }

    public Boolean isCreated() {
        return created;
    }

    public void setCreated(Boolean created) {
        this.created = created;
    }

    public void setRoute(List<Integer> route) {
        this.route = route;
    }

    public Boolean isShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

    public Boolean getExpanded() {
        return expanded;
    }

    public void setExpanded(Boolean expanded) {
        this.expanded = expanded;
    }

    public String getAppAlias() {
        return appAlias;
    }

    public void setAppAlias(String appAlias) {
        this.appAlias = appAlias;
    }

    public Boolean hasChildren() {
        return children != null && !children.isEmpty();
    }
}
