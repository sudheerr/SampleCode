package com.citi.risk.core.application.impl;

import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.api.SearchElement;
import com.citi.risk.core.application.api.TableBasedElement;
import com.citi.risk.core.application.api.TableBasedElementFactory;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.application.api.ViewConfiguration;
import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.application.api.ViewFactory;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.impl.DataCachesQuery;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultViewFactory implements ViewFactory {
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultViewFactory.class);
	@Inject
	private Injector injector;
	@Inject
	private DictionaryParser parser;
	@Inject
	private TableBasedElementFactory tableBasedElementFactory;
	
	@Override
	public View newView(Class<? extends View> viewClass) {
		ViewConfiguration viewConfiguration = (ViewConfiguration) viewClass.getAnnotation(ViewConfiguration.class);

		View view = injector.getInstance(viewClass);

		if (viewConfiguration == null)
			throw new RuntimeException(viewClass.getCanonicalName() + " is not a View Class");

		String viewName = viewConfiguration.name();
		Class<?> queryClass = viewConfiguration.queryClass();
		Class<?>[] tableBasedElementClasses = viewConfiguration.tableBasedElementClasses();
		
		nullExceptionDeal(viewClass, viewName, queryClass, tableBasedElementClasses);

		Query query = (Query) injector.getInstance(queryClass);

		Class<?> domainClass = viewConfiguration.domainClass();
		DataDomain domain = null;
		if (domainClass != null && domainClass != Void.class) {
			domain = parser.parseDomain(domainClass);
			view.setDictionary(parser.parse(domainClass));
		}
		ViewContext viewContext = (ViewContext) injector.getInstance(ViewContext.class);
		viewContext.setDomain(domain);
		viewContext.setQuery(query);
		view.setViewContext(viewContext);
		view.setDefaultCriteria();

		SearchElement searchElement = view.getSearchElement();
		searchElement.setQuery(query);
		searchElement.setViewContext(viewContext);

		for (Class<?> tableBasedElementClass : tableBasedElementClasses) {
			TableBasedElement tableBasedElement = (TableBasedElement) injector.getInstance(tableBasedElementClass);
			tableBasedElement.setQuery(query);
			tableBasedElement.setViewContext(viewContext);
			view.addTableElement(tableBasedElement);
		}
		view.setLoadAllWithNonCriteria();
		view.setName(viewName);
		return view;
	}

	private void nullExceptionDeal(Class<? extends View> viewClass, String viewName, Class<?> queryClass,
			Class<?>[] tableBasedElementClasses) {
		if (viewName == null)
			throw new RuntimeException(viewClass.getCanonicalName() +" In annotation ViewConfiguration which the name can not be null.");

		if (queryClass == null)
			throw new RuntimeException(viewClass.getCanonicalName() +" In annotation ViewConfiguration which the queryClass can not be null.");

		if (tableBasedElementClasses == null ||tableBasedElementClasses.length==0)
			throw new RuntimeException(viewClass.getCanonicalName() +" In annotation ViewConfiguration which the tableBasedElementClasses can not be null.");
	}

	@Override
	public View configView(View view) {
		String domainStr = view.getDomainName();
		if(domainStr == null){
			throw new RuntimeException("domain is null");
		}
		injector.injectMembers(view);
		try {
			DataDomain domain = parser.parseDomain(Class.forName(domainStr));
			view.setDictionary(parser.parse(domain.getDomainClass()));
			ViewContext viewContext = injector.getInstance(ViewContext.class);
			viewContext.setDomain(domain);
			view.setViewContext(viewContext);
			view.setDefaultCriteria();
			
			List<Navigation> menuList = Lists.newArrayList();
			view.setMenuList(menuList);
			
			SearchElement searchElement = view.getSearchElement();
			searchElement.setQuery(injector.getInstance(DataCachesQuery.class));
			searchElement.setViewContext(viewContext);
			
			if (view.getTableBasedElementList() != null && !view.getTableBasedElementList().isEmpty()) {
				int displayIndex = 0;
				for(TableBasedElement element : view.getTableBasedElementList()){
					tableBasedElementFactory.configElement(element);
					element.setDisplayIndex(displayIndex++);
				}
			}
			
		} catch (ClassNotFoundException e) {
			LOGGER.error("Can't find class " + domainStr, e);
		}
		return view;
	}

}
