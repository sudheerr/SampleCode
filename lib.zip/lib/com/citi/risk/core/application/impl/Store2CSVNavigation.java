package com.citi.risk.core.application.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.api.StorerSpecification;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.CacheOperations;
import com.citi.risk.core.data.store.cache.api.CacheTask;
import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.data.store.cache.impl.DefaultCacheTask;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import com.google.inject.Binding;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Key;

public class Store2CSVNavigation extends DefaultNavigation {
	
	private static final String ITEMNAME = "Store to CSV";
	
	@Inject
	private CacheManager cacheManager;
	
	@Inject
	private Injector injector;
	
	public Store2CSVNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		CacheTask cacheStoreTask;
		Cache cache;
		Class storeClass;

		for(DataKey dataKey : populateDatakeyList(navigationParameter.getSimpleTable())) {
			cache = (Cache)cacheManager.getCache(dataKey);
			storeClass = this.getStorerMap().get(new Pair(cache.getDomainClass(), cache.getDomainImplClass()));
			if (storeClass == null) {
				throw new RuntimeException("Failed to get storer class related to this domain class!");
			}
			cacheStoreTask = new DefaultCacheTask();
			File outputDir= new File(navigationParameter.getDumpLocation());
			cacheStoreTask.domain(dataKey.getDomain()).createdBy(dataKey.getCreatedBy()).timeMark(dataKey.getTimeMark()).targetDirectoryPath(outputDir.getAbsolutePath()).operation(CacheOperations.Store);
			cacheStoreTask.storerClass(storeClass);
			try {
				cacheManager.store(cacheStoreTask).get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		}
		
		return null;
	}
	
	protected List<DataKey> populateDatakeyList(Table<Integer, DataSelectionItem, Object> selectedTable) {
		List<DataKey> dataKeyList = new ArrayList<>();
		for (Map<DataSelectionItem, Object> row : selectedTable.rowMap().values()) {
			for (Entry<DataSelectionItem, Object> entry : row.entrySet()) {
				if (currentItemIsKey(entry)) {
					dataKeyList.add(createDataKeyFromObject(entry.getValue()));
				}
			}
		}
		return dataKeyList;
	}

	private Map<Pair<Class<?>, Class<?>>, Class<?>> getStorerMap() {
		Map<Key<?>, Binding<?>> map = injector.getBindings();
		Map<Pair<Class<?>, Class<?>>, Class<?>> storerMap = Maps.newHashMap();
		for (Entry<Key<?>, Binding<?>> e : map.entrySet()) {
			Key mapKey = e.getKey();
			Class<?> klass = mapKey.getTypeLiteral().getRawType();
			StorerSpecification storerSpecification = (StorerSpecification) klass.getAnnotation(StorerSpecification.class);
			if (storerSpecification == null) {
				continue;
			}
			Storer storer = (Storer) injector.getInstance(klass);
			Class domainClass = storer.getDomainClass();
			Class domainImplClass = storer.getDomainImplClass();

			storerMap.put(new Pair<Class<?>, Class<?>>(domainClass, domainImplClass), klass);
		}
		return storerMap;
	}
	
	private Boolean currentItemIsKey(Entry<DataSelectionItem, Object> entry) {
		return entry.getKey().getUnderlyingPath().getTerminatingItem().isKey();
	}

	private DataKey createDataKeyFromObject(Object value) {
		DataKey dataKey;
		if (value instanceof DataKey) {
			dataKey = (DataKey) value;
		} else if (value instanceof String) {
			String strValue = (String) value;
			dataKey = searchDataKey(strValue);
		} else {
			throw new RuntimeException("Creating DataKey from string value failed.");
		}
		return dataKey;
	}
	
	/**
	 * Search DataKey corresponding to the given datakeyString in cacheManager. If dataKey is not found, throw RuntimeException.
	 * 
	 * @param dataKeyString
	 * @return
	 */
	private DataKey searchDataKey(String dataKeyString) {
		for (DataKey dk : this.cacheManager.searchDataAvailabilities()) {
			if (dk.getKeyString().equals(dataKeyString))
				return dk;
		}
		throw new RuntimeException("specified datakey not found: " + dataKeyString);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
