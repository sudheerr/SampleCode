package com.citi.risk.core.application.impl;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.TableBasedElement;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.common.collect.Lists;

public class DefaultNavigationParameter implements NavigationParameter {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultNavigationParameter.class);
	
	private static final String INVALIDSTRING = "Invalid timeMark String.";

	private SimpleTable simpleTable;

	private String operationName;

	private String dumpLocation;

	private String loaderClassName;

	private TimeMark timeMark;

	private CreatedBy createBy;

	private List<File> fileList;

	private View targetView;

	private Criteria criteria;

	private Criteria furtherCriteria;

	private List<Criteria> disabledNormalCriterias;

	private List<Criteria> disabledFurtherCriterias;

	private String domainName;

	private List<DataSelectionItem> timeSeriesMeasures;

	private String movementKeyName;

	private DataSelectionItem movementTarget;

	private List<TimeMark> cOBs;

	private String timeSeriesCurveMeasure;

	private String exposureMeasureType;

	private String timeMarkKey;

	private String batchName;

	private String bdRunId;

	private CriteriaWrapper focusCriteriaWrapper;

	private CriteriaWrapper switchCriteriaWrapper;

	private CriteriaWrapper excludeCriteriaWrapper;

	private TableBasedElement tableBasedElement;

	private int pageSize;

	private boolean enableFacilityCriteria;
	
	private String startDate;
	
	private String endDate;
	
	private boolean aliasEnabled;
	
	private String selectLevel;
	
	private String cobKeyName;

	@Override
	public CriteriaWrapper getFocusCriteriaWrapper() {
		return focusCriteriaWrapper;
	}

	@Override
	public void setFocusCriteriaWrapper(CriteriaWrapper focusCriteriaWrapper) {
		this.focusCriteriaWrapper = focusCriteriaWrapper;
	}

	@Override
	public CriteriaWrapper getSwitchCriteriaWrapper() {
		return this.switchCriteriaWrapper;
	}

	@Override
	public void setSwitchCriteriaWrapper(CriteriaWrapper switchCriteriaWrapper) {
		this.switchCriteriaWrapper = switchCriteriaWrapper;
	}

	@Override
	public String getOperationName() {
		return operationName;
	}

	@Override
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	@Override
	public void setSimpleTable(SimpleTable simpleTable) {
		this.simpleTable = simpleTable;
	}

	@Override
	public SimpleTable getSimpleTable() {
		return simpleTable;
	}

	@Override
	public String getDumpLocation() {
		return dumpLocation;
	}

	@Override
	public void setDumpLocation(String dumpLocation) {
		this.dumpLocation = dumpLocation;
	}

	@Override
	public String getLoaderClassName() {
		return loaderClassName;
	}

	@Override
	public void setLoaderClassName(String loaderClassName) {
		this.loaderClassName = loaderClassName;
	}

	@Override
	public void setFileList(List<File> files) {
		this.fileList = files;
	}

	@Override
	public List<File> getFileList() {
		return this.fileList;
	}

	@Override
	public TimeMark getTimeMark() {
		return timeMark;
	}

	@Override
	public void setTimeMark(String timeMarkStr, String batchFrequencyStr) {
		TimeMark localTimeMark = this
				.convertTimeMark(timeMarkStr, batchFrequencyStr);
		this.timeMark = localTimeMark;
	}

	private TimeMark convertTimeMark(String timeMarkStr, String batchFrequencyStr) {
		DefaultTimeMark localTimeMark;

		if (timeMarkStr != null && timeMarkStr.indexOf('~') != -1) {
			return DefaultTimeMark.getTimeMarkfromKey(timeMarkStr);
		}

		if (timeMarkStr == null || batchFrequencyStr == null) {
			throw new IllegalArgumentException(INVALIDSTRING);
		}
		String[] strs = timeMarkStr.split("-");
		if (strs.length < 3) {
			throw new IllegalArgumentException(INVALIDSTRING);
		}

		localTimeMark = getTimeMark(batchFrequencyStr, strs);
		
		return localTimeMark;
	}

	private DefaultTimeMark getTimeMark(String batchFrequencyStr, String[] strs) {
		DefaultTimeMark tempTimeMark;
		if (TimeMark.BatchFrequency.Monthly.name().equalsIgnoreCase(
				batchFrequencyStr)) {
			// month should add 1 to the range of 1~12.
			tempTimeMark = DefaultTimeMark.newMonthlyTimeMark(Integer.valueOf(strs[0]), Integer.valueOf(strs[1]), Integer.valueOf(strs[2]));
		} else if (TimeMark.BatchFrequency.Daily.name().equalsIgnoreCase(
				batchFrequencyStr)) {
			// month should add 1 to the range of 1~12.
			tempTimeMark = DefaultTimeMark.newDailyTimeMark(Integer.valueOf(strs[0]), Integer.valueOf(strs[1]), Integer.valueOf(strs[2]), 0);
		}
		else{
			//TODO: leave it as is now
			tempTimeMark = new DefaultTimeMark();
		}
		return tempTimeMark;
	}

	/**
	 * Example of timeMarkStr:</br> 1) 2013-9-10-Daily (September 10, 2013);<br>
	 * 2) 2013-9-10-Monthly (2013 September BD10)
	 * 
	 * @param timeMarkStr
	 * @return
	 */
	private TimeMark convertTimeMark(String timeMarkStr) {
		DefaultTimeMark localTimeMark;

		if (timeMarkStr != null && timeMarkStr.indexOf(" (") != -1) {
			return DefaultTimeMark.getTimeMarkfromKey(timeMarkStr.split(" \\(")[1].split("\\)")[0]);
		}
		
		if (timeMarkStr != null && timeMarkStr.indexOf('~') != -1) {
			return DefaultTimeMark.getTimeMarkfromKey(timeMarkStr);
		}
		localTimeMark = (DefaultTimeMark)getTimeMarkFromString(timeMarkStr);

		return localTimeMark;
	}

	private TimeMark getTimeMarkFromString(String timeMarkString){
		if (timeMarkString == null) {
			throw new IllegalArgumentException(INVALIDSTRING);
		}

		String[] strs = timeMarkString.split("-");
		String batchFrequencyStr = strs[3];
		
		if (null == batchFrequencyStr || "".equals(batchFrequencyStr)
				|| strs.length < 4) {
			throw new IllegalArgumentException(INVALIDSTRING);
		}
		return getTimeMark(batchFrequencyStr, strs);
	}
	
	@Override
	public CreatedBy getCreateBy() {
		return createBy;
	}

	@Override
	public void setCreateBy(String versionNumber, String module, String process) {
		CreatedBy localCreateBy = convertCreateBy(versionNumber, module, process);
		this.createBy = localCreateBy;
	}

	private CreatedBy convertCreateBy(String versionNumberStr, String module,
			String process) {
		Integer versionNumber = 0;
		try {
			versionNumber = Integer.valueOf(versionNumberStr);
		} catch (NumberFormatException e) {
			LOGGER.info("Number format exception:{}",e);
		}

		CreatedBy localCreateBy = new DefaultCreatedBy();
		localCreateBy.withModule(module).withProcess(process)
				.withVerionNumber(versionNumber);
		return localCreateBy;
	}

	@Override
	public View getTargetView() {
		return targetView;
	}

	@Override
	public void setTargetView(View targetView) {
		this.targetView = targetView;
	}

	@Override
	public Criteria getCriteria() {
		return criteria;
	}

	@Override
	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}

	@Override
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	@Override
	public String getDomainName() {
		return domainName;
	}

	@Override
	public List<DataSelectionItem> getTimeSeriesMeasures() {
		return timeSeriesMeasures;
	}

	@Override
	public void setTimeSeriesMeasures(List<DataSelectionItem> timeSeriesMeasures) {
		this.timeSeriesMeasures = timeSeriesMeasures;
	}

	@Override
	public List<TimeMark> getCOBs() {
		return cOBs;
	}

	@Override
	public void setCOBs(List<String> cOBs, String batchFrequencyStr) {
		List<TimeMark> timeMarks = Lists.newArrayList();
		for (String cob : cOBs) {
			timeMarks.add(convertTimeMark(cob, batchFrequencyStr));
		}
		this.cOBs = timeMarks;
	}

	@Override
	public void setCOBs(List<String> cobs) {
		List<TimeMark> timeMarks = Lists.newArrayList();
		for (String cob : cobs) {
			timeMarks.add(convertTimeMark(cob));
		}
		this.cOBs = timeMarks;
	}

	@Override
	public void setTimeSeriesCurveMeasure(String measure) {
		this.timeSeriesCurveMeasure = measure;
	}

	@Override
	public String getTimeSeriesCurveMeasure() {
		return this.timeSeriesCurveMeasure;
	}

	@Override
	public String getExposureMeasureType() {
		return exposureMeasureType;
	}

	@Override
	public void setExposureMeasureType(String exposureMeasureType) {
		this.exposureMeasureType = exposureMeasureType;
	}

	@Override
	public String getTimeMarkKey() {
		return timeMarkKey;
	}

	@Override
	public void setTimeMarkKey(String timeMarkKey) {
		this.timeMarkKey = timeMarkKey;
	}

	@Override
	public String getMovementKeyName() {
		return movementKeyName;
	}

	@Override
	public void setMovementKeyName(String movementKeyName) {
		this.movementKeyName = movementKeyName;
	}

	@Override
	public DataSelectionItem getMovementTarget() {
		return movementTarget;
	}

	@Override
	public void setMovementTarget(DataSelectionItem movementTarget) {
		this.movementTarget = movementTarget;
	}

	@Override
	public void setFurtherCriteria(Criteria criteria) {
		this.furtherCriteria = criteria;
	}

	@Override
	public Criteria getFurtherCriteria() {
		return this.furtherCriteria;
	}

	@Override
	public List<Criteria> getDisabledNormalCriterias() {
		return disabledNormalCriterias;
	}

	@Override
	public void setDisabledNormalCriterias(
			List<Criteria> disabledNormalCriterias) {
		this.disabledNormalCriterias = disabledNormalCriterias;
	}

	@Override
	public List<Criteria> getDisabledFurtherCriterias() {
		return disabledFurtherCriterias;
	}

	@Override
	public void setDisabledFurtherCriterias(
			List<Criteria> disabledFurtherCriterias) {
		this.disabledFurtherCriterias = disabledFurtherCriterias;
	}

	@Override
	public String getBatchName() {
		return batchName;
	}

	@Override
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	@Override
	public String getBdRunId() {
		return bdRunId;
	}

	@Override
	public void setBdRunId(String bdRunId) {
		this.bdRunId = bdRunId;
	}

	@Override
	public CriteriaWrapper getExcludeCriteriaWrapper() {
		return excludeCriteriaWrapper;
	}

	@Override
	public void setExcludeCriteriaWrapper(CriteriaWrapper excludeCriteriaWrapper) {
		this.excludeCriteriaWrapper = excludeCriteriaWrapper;
	}

	@Override
	public void setTableBasedElement(TableBasedElement tableBasedElement) {
		this.tableBasedElement = tableBasedElement;
	}

	@Override
	public TableBasedElement getTableBasedElement() {
		return tableBasedElement;
	}

	@Override
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	@Override
	public int getPageSize() {
		return this.pageSize;
	}

	@Override
	public void setEnableFacilityCriteria(boolean enableFacilityCriteria ) {
		this.enableFacilityCriteria = enableFacilityCriteria;
	}

	@Override
	public boolean getEnableFacilityCriteria() {
		return enableFacilityCriteria;
	}

	@Override
	public String getStartDate() {
		return startDate;
	}

	@Override
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	@Override
	public String getEndDate() {
		return endDate;
	}

	@Override
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public boolean isAliasEnabled() {
		return aliasEnabled;
	}

	@Override
	public void setAliasEnabled(boolean aliasEnabled) {
		this.aliasEnabled = aliasEnabled;
	}

	@Override
	public void setSelectLevel(String selectLevel) {
		this.selectLevel=selectLevel;
		
	}

	@Override
	public String getSelectLevel() {
		return selectLevel;
	}

	@Override
	public String getCobKeyName() {
		return cobKeyName;
	}

	@Override
	public void setCobKeyName(String cobKeyName) {
		this.cobKeyName=cobKeyName;
		
	}

}
