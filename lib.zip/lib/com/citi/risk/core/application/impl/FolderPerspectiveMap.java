package com.citi.risk.core.application.impl;

import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.navigator.api.NavigatorFolderPerspectiveMap;

import javax.persistence.*;

/**
 * @author bh30850
 */
@Entity
@Table(name = "FolderPerspective")
public class FolderPerspectiveMap implements NavigatorFolderPerspectiveMap {

    private Integer folderId;
    private Integer perspectiveId;

    @Column(name = "folder_id")
    public Integer getFolderId() {
        return folderId;
    }

    public void setFolderId(Integer folderId) {
        this.folderId = folderId;
    }

    @Id
    @Column(name = "perspective_id", nullable = false, unique = true)
    public Integer getPerspectiveId() {
        return perspectiveId;
    }

    public void setPerspectiveId(Integer perspectiveId) {
        this.perspectiveId = perspectiveId;
    }

    @Override
    public String key() {
        return null;
    }

    @Override
    @Transient
    public TimeMark getTimeMark() {
        return null;
    }

    @Override
    public void setTimeMark(TimeMark timeMark) {

    }

    @Override
    @Transient
    public CreatedBy getCreatedBy() {
        return null;
    }

    @Override
    public void setCreatedBy(CreatedBy createdBy) {

    }

    @Override
    @Transient
    public String getTimeMarkString() {
        return null;
    }

    @Override
    public void setTimeMarkString(String timeMarkKey) {

    }

    @Override
    @Transient
    public String getCreatedByString() {
        return null;
    }

    @Override
    public void setCreatedByString(String createdByKey) {

    }
}
