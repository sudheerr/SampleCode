package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;

public class DownloadExcelNavigation extends DefaultNavigation {

	private static final String ITEMNAME = "Export Excel File";

	public DownloadExcelNavigation() {
		super(ITEMNAME);
	}

	@Override
	public View navigateTo(NavigationParameter navigationParameter) {
		return null;
	}
}
