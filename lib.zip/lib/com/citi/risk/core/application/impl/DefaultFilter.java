package com.citi.risk.core.application.impl;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.citi.risk.core.application.api.View;
import com.google.common.collect.Lists;
import org.slf4j.Logger;

@Entity
@Table(name = "DefaultFilter")
public class DefaultFilter implements Serializable, Cloneable {
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(DefaultFilter.class);
	private Integer id;
	private View view;
	private String criteriaString;

	private static final String SEPARATOR = ",";
	private static final String PATH_STRING = "pathString";
	private static final String OPERATOR = "operator";
	private static final String OPERANDS = "operandsString";
	private static final String VIEW_ID = "viewId";
	private static final String OPERAND_SEPARATOR = "~";

	public DefaultFilter() {
		//intentionally-blank override
	}
	
	public DefaultFilter(Integer id, View view, String criteriaString){
		this.id = id;
		this.view = view;
		this.criteriaString = criteriaString;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DefaultFilter_Seq")
	@Column(name = "id", nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(targetEntity = DefaultView.class)
	@JoinColumn(name="viewId", insertable=true, updatable=true)
	public View getView() {
		return view;
	}

	public void setView(View view) {
		this.view = view;
	}

	@Column
	public String getCriteriaString() {
		return criteriaString;
	}

	public void setCriteriaString(String criteriaString) {
		this.criteriaString = criteriaString;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultFilter other = (DefaultFilter) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "DefaultFilter - [ id= " + id + ", viewId= " + view.getId()
				+ ", criteriaString= " + criteriaString + "]";
	}

	@Override
	public Object clone() {
		DefaultFilter filter = null;
		try {
			filter = (DefaultFilter) super.clone();
			filter.setId(null);
			filter.setView(null);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy filter", e);
		}
		return filter;
	}

	public Map<String, Object> toCriterion() {
		String[] criterions = this.criteriaString.split(SEPARATOR);
		Map<String, Object> criterionMap = new LinkedHashMap<>();
		if (criterions.length > 0) {
			criterionMap.put(PATH_STRING, criterions[0]);
			criterionMap.put(OPERATOR, criterions[1]);
			String[] ops = ((String) criterions[2]).split(OPERAND_SEPARATOR);
			List<String> operands = Lists.newArrayList(ops);
			criterionMap.put(OPERANDS, operands);
			criterionMap.put(VIEW_ID, view.getId());
		}
		return criterionMap;
	}
}