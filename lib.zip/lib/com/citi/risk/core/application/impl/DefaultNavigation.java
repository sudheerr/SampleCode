package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.api.NavigationParameter;
import com.citi.risk.core.application.api.View;
import com.citi.risk.core.gui.api.Widget;

public abstract class DefaultNavigation implements Navigation {
	private String itemName;
	private String targetDomainName;
	private NavigationFlow navigationFlow;
	private String displayName;

	private transient NavigationParameter navigationParameter;

	public DefaultNavigation(String itemName, String displayName) {
		this.itemName = itemName;
		this.displayName = displayName;
	}
	
	public DefaultNavigation(String itemName, NavigationFlow navigationFlow, String displayName) {
		this.itemName = itemName;
		this.navigationFlow = navigationFlow;
		this.displayName = displayName;
	}
	
	public DefaultNavigation(String itemName, String targetDomainName, NavigationFlow navigationFlow, String displayName) {
		this.itemName = itemName;
		this.targetDomainName = targetDomainName;
		this.navigationFlow = navigationFlow;
		this.displayName = displayName;
	}
	
	public DefaultNavigation(String itemName) {
		this(itemName, itemName);
	}
	
	public DefaultNavigation(String itemName, NavigationFlow navigationFlow) {
		this(itemName, navigationFlow, itemName);
	}
	
	public DefaultNavigation(String itemName, String targetDomainName, NavigationFlow navigationFlow) {
		this(itemName, targetDomainName, navigationFlow, itemName);
	}

	@Override
	public NavigationFlow getNavigationFlow() {
		return navigationFlow;
	}

	@Override
	public void setNavigationFlow(NavigationFlow navigationFlow) {
		this.navigationFlow = navigationFlow;
	}
	
	@Override
	public String getTargetDomainName() {
		return targetDomainName;
	}

	@Override
	public void setTargetDomainName(String targetDomainName) {
		this.targetDomainName = targetDomainName;
	}
	
	@Override
	public List<View> popUp(NavigationParameter navigationParameter){
		return new ArrayList<>(0);		
	}
	
	@Override
	public void setNavigationParameter(NavigationParameter navigationParameter) {
		this.navigationParameter = navigationParameter;
	}

	public NavigationParameter getNavigationParameter() {
		return navigationParameter;
	}

	@Override
	public String getItemName() {
		return this.itemName;
	}

	@Override
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Override
	public String toString(){
		return "itemName:" + itemName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		return result;
	}
	
	@Override
	public String getDisplayName() {
		return displayName;
	}

	@Override
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) 
			return true;
		if (obj == null) 
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultNavigation other = (DefaultNavigation) obj;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName)) 
			return false;
		return true;
	}
	
	@Override
	public Widget navigateTo(GuiNavigationParameters navigationParameter) {
		// TODO Auto-generated method stub
		return null;
	}
}
