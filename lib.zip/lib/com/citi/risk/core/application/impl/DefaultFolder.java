package com.citi.risk.core.application.impl;

import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.collection.set.Sets;
import com.citi.risk.core.navigator.api.NavigatorFolder;
import com.citi.risk.core.navigator.api.NavigatorFolderPerspectiveMap;

import javax.persistence.*;
import java.util.Set;

/**
 * @author bh30850
 * @date 8/14/2015
 */
@Entity
@Table(name = "DefaultFolder")
public class DefaultFolder implements NavigatorFolder {

    private Integer id;
    private String name;
    private Integer parentId;
    private Set<NavigatorFolderPerspectiveMap> perspectiveMaps = Sets.newHashSet();
    private String soeId;
    private Boolean shared;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "name", nullable = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "parentid")
    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
    	this.parentId = parentId;
    }


    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = FolderPerspectiveMap.class, orphanRemoval = false)
    @JoinColumn(name = "folder_id")
    public Set<NavigatorFolderPerspectiveMap> getPerspectiveMaps() {
        return perspectiveMaps;
    }

    @Override
    public void setPerspectiveMaps(Set<NavigatorFolderPerspectiveMap> perspectiveMaps) {
        this.perspectiveMaps = perspectiveMaps;
    }

    @Override
    public void addPerspectiveMap(NavigatorFolderPerspectiveMap perspectiveMap) {
        this.perspectiveMaps.add(perspectiveMap);
    }

    @Column(name = "soeId", nullable = false)
    public String getSoeId() {
        return soeId;
    }

    public void setSoeId(String soeId) {
        this.soeId = soeId;
    }

    @Column(name = "shared")
	public Boolean isShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

    @Override
    public Integer key() {
        return null;
    }

    @Override
    @Transient
    public TimeMark getTimeMark() {
        return null;
    }

    @Override
    public void setTimeMark(TimeMark timeMark) {

    }

    @Override
    @Transient
    public CreatedBy getCreatedBy() {
        return null;
    }

    @Override
    public void setCreatedBy(CreatedBy createdBy) {

    }

    @Override
    @Transient
    public String getTimeMarkString() {
        return null;
    }

    @Override
    public void setTimeMarkString(String timeMarkKey) {

    }

    @Override
    @Transient
    public String getCreatedByString() {
        return null;
    }

    @Override
    public void setCreatedByString(String createdByKey) {

    }
}

