package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.CacheOperations;
import com.citi.risk.core.data.store.cache.api.CacheTask;
import com.citi.risk.core.data.store.cache.impl.DefaultCacheTask;

public class ReloadServiceImpl implements ReloadService {
	@Override
	 public void reload(CacheManager cacheManager, Collection<DataKey> dataKeys) {
		 List<Future> reloadTaskFutures = new ArrayList<>();
		 for (DataKey dataKey : dataKeys) {
				CacheTask cacheTask = new DefaultCacheTask().domain(dataKey.getDomain()).timeMark(dataKey.getTimeMark())
						.loaderClass(dataKey.getCreatedBy().getLoaderClass()).createdBy(dataKey.getCreatedBy())
						.operation(CacheOperations.Reload);
				cacheTask.setUserInitiated(true);
				reloadTaskFutures.add(cacheManager.reload(cacheTask));
			}

			try {
				for (Future future : reloadTaskFutures) {
					future.get();
				}
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
	 }
}
