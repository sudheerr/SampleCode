package com.citi.risk.core.application.impl;

import java.util.ArrayList;
import java.util.List;

import com.citi.risk.core.dictionary.api.Criteria;

public class CriteriaWrapper {
	private Criteria normalCriteria;
	
	/**
	 * Criteria for historical or aggregated column
	 */
	private Criteria furtherCriteria;
	
	private List<Criteria> disabledNormalCriterias = new ArrayList<>();
	
	private List<Criteria> disabledFurtherCriterias = new ArrayList<>();
	
	public CriteriaWrapper(){
		//intentionally-blank override
	}
	
	public CriteriaWrapper(Criteria normalCriteria, Criteria furtherCriteria){
		this.normalCriteria=normalCriteria;
		this.furtherCriteria=furtherCriteria;
	}
	
	public CriteriaWrapper(Criteria normalCriteria, Criteria furtherCriteria, List<Criteria> disabledNormalCriterias, List<Criteria> disabledFurtherCriterias){
		this(normalCriteria, furtherCriteria);
		this.disabledNormalCriterias=disabledNormalCriterias;
		this.disabledFurtherCriterias=disabledFurtherCriterias;
	}
	
	public Criteria getNormalCriteria() {
		return normalCriteria;
	}
	public void setNormalCriteria(Criteria normalCriteria) {
		this.normalCriteria = normalCriteria;
	}
	public Criteria getFurtherCriteria() {
		return furtherCriteria;
	}
	public void setFurtherCriteria(Criteria furtherCriteria) {
		this.furtherCriteria = furtherCriteria;
	}

	public List<Criteria> getDisabledNormalCriterias() {
		return disabledNormalCriterias;
	}

	public void setDisabledNormalCriterias(List<Criteria> disabledNormalCriterias) {
		this.disabledNormalCriterias = disabledNormalCriterias;
	}

	public List<Criteria> getDisabledFurtherCriterias() {
		return disabledFurtherCriterias;
	}

	public void setDisabledFurtherCriterias(List<Criteria> disabledFurtherCriterias) {
		this.disabledFurtherCriterias = disabledFurtherCriterias;
	}
}
