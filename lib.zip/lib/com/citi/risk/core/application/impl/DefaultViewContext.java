package com.citi.risk.core.application.impl;

import com.citi.risk.core.application.api.ViewContext;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.inject.Inject;

public class DefaultViewContext implements ViewContext{


	@Inject
	private Dictionary dictionary;
	private DataDomain domain;
	private Query query;
	private TimeMark basedTimeMark;

	@Override
	public TimeMark getBasedTimeMark() {
		return basedTimeMark;
	}

	@Override
	public void setBasedTimeMark(TimeMark basedTimeMark) {
		this.basedTimeMark = basedTimeMark;
	}

	@Override
	public void setDictionary(Dictionary dictionary) {
		//intentionally-blank override
	}

	@Override
	public Dictionary getDictionary() {
		return this.dictionary;
	}

	@Override
	public void setDomain(DataDomain domain) {
		this.domain = domain;
	}

	@Override
	public DataDomain getDomain() {
		return this.domain;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	@Override
	public Query getQuery() {
		return this.query;
	}

}
