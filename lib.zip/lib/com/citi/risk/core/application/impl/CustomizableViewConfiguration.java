package com.citi.risk.core.application.impl;

import java.util.Collection;

import com.citi.risk.core.application.api.TableConfiguration;
import com.citi.risk.core.application.api.View;

public class CustomizableViewConfiguration {

	private String viewId;
	private String name;
	private Class<?> domainClass;
	private Class<? extends View> viewClass;
	private Collection<? extends TableConfiguration> tableConfigurations;
	private String viewType;
	
	public CustomizableViewConfiguration(String name, Class<?> domainClass,
			Class<? extends View> viewClass, Collection<? extends TableConfiguration> tableConfigurations) {
		super();
		this.name = name;
		this.domainClass = domainClass;
		this.viewClass = viewClass;
		this.tableConfigurations = tableConfigurations;
	}
	
	public CustomizableViewConfiguration(String viewId, String name, Class<?> domainClass,
			Class<? extends View> viewClass, Collection<? extends TableConfiguration> tableConfigurations,
			String viewType) {
		super();
		this.viewId = viewId;
		this.name = name;
		this.domainClass = domainClass;
		this.viewClass = viewClass;
		this.tableConfigurations = tableConfigurations;
		this.viewType = viewType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public Class<?> getDomainClass() {
		return domainClass;
	}

	public void setDomainClass(Class<?> domainClass) {
		this.domainClass = domainClass;
	}

	public Class<? extends View> getViewClass() {
		return viewClass;
	}

	public void setViewClass(Class<? extends View> viewClass) {
		this.viewClass = viewClass;
	}

	public Collection<? extends TableConfiguration> getTableConfigurations() {
		return tableConfigurations;
	}

	public void setTableConfigurations(
			Collection<? extends TableConfiguration> tableConfigurations) {
		this.tableConfigurations = tableConfigurations;
	}

	public String getViewId() {
		return viewId;
	}

	public void setViewId(String viewId) {
		this.viewId = viewId;
	}
}
