package com.citi.risk.core.application.impl;

public class DataTypeUtil {
	
	private DataTypeUtil(){}
	
	public static String getDataTypeString(Class<?> clazz){
		String result;
		if(clazz == null || clazz.isEnum()){
			return "auto";
		}else{
			int startIndex = clazz.getCanonicalName().lastIndexOf('.');
			String suffix = clazz.getName().substring(startIndex > 0 ? startIndex + 1 : 0);
			result = getTypeString(suffix);
		}
		return result;
	}

	private static String getTypeString(String suffix) {
		String result;
		switch(suffix){
		case "Boolean":
			result = "boolean";
			break;
		case "Integer":
			result = "int";
			break;
		case "Long":
		case "Float":
		case "Double":
			result = "float";
			break;
		case "Date":
			result = "date";
			break;
		case "String":
		default:
			result = "string";
			break;
		}
		return result;
	}
}
