package com.citi.risk.core.application.impl;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.citi.risk.core.application.api.*;
import com.citi.risk.core.data.query.impl.DataCachesQuery;
import com.citi.risk.core.dictionary.api.*;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.ui.config.GuiceInjectorFactory;
import com.citi.risk.ui.config.NavigatorConstants;
import com.google.inject.Injector;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.data.pivot.api.PivotTable;
import com.citi.risk.core.data.query.api.PivotQueryResult;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.execution.api.InterruptedTaskTimeOutException;
import com.citi.risk.core.lang.table.DefaultSimpleTable;
import com.citi.risk.core.lang.table.SimpleTable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Ordering;

/**
 * The Class AbstractTableBasedElement.
 */
@Entity
@Table(name = "DefaultTableBasedElement")
public class DefaultTableBasedElement implements TableBasedElement {
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultTableBasedElement.class);
	private static final long serialVersionUID = 1L;
	private Query query;
	private ViewContext viewContext;
	private Integer pageIndex = 0;
	@ToBeCompared
	private Integer pageSize = Integer.MAX_VALUE;
	@ToBeCompared
	private Integer currency;
	private Integer pageCount;
	private Integer resultCount;
	private OutputStream out;
	private List<ColumnHeader> header;
	/**
	 * criteria for normal column
	 */
	private Criteria criteria;
	/**
	 * criteria for historical(comparable) column and aggregated column
	 */
	private Criteria furtherCriteria;
	private boolean loadAllByDefault;

	private Integer id;
	@ToBeCompared
	private String name;
	@ToBeCompared
	private String domainName;
	private Integer sourceId;
	private String templateName;
	@ToBeCompared
	private Boolean hidden;
	@ToBeCompared
	private String type;
	private Integer displayIndex;
	private View view;
	private List<Navigation> menuList;
	private Boolean isSubtotalDisplayed = false;
	
    private Integer isGlobalFilterDisabled;
    private String elementCriteriaString;
    private List<Map<String, Object>> elementCriteria;

    private Ordering<ColumnHeader> orderTableColumnsByProminence = new Ordering<ColumnHeader>() {
        @Override
        public int compare(ColumnHeader left, ColumnHeader right) {
            if (left.getPath().getTerminatingItem().getProminence() == Prominence.Med
                    && right.getPath().getTerminatingItem().getProminence() == Prominence.Low) {
                return 0;
            }
            if (left.getPath().getTerminatingItem().getProminence() == Prominence.High
                    && right.getPath().getTerminatingItem().getProminence() != Prominence.High) {
                return -1;
            }
            if (left.getPath().getTerminatingItem().getProminence() == right.getPath().getTerminatingItem()
                    .getProminence()) {
                return 1;
            }
            return 0;
        }
    };

    private Ordering<ColumnHeader> orderTableColumnsByKeyFirst = new Ordering<ColumnHeader>() {
        @Override
        public int compare(ColumnHeader left, ColumnHeader right) {
            if (left.getPath().getTerminatingItem().isKey() && right.getPath().getTerminatingItem().isKey()) {
                return 0;
            }
            if (left.getPath().getTerminatingItem().isKey()) {
                return -1;
            }
            if (right.getPath().getTerminatingItem().isKey()) {
                return 1;
            }
            return 0;
        }
    };

    private Ordering<ColumnHeader> orderTableColumnsByNameSecond = new Ordering<ColumnHeader>() {
        @Override
        public int compare(ColumnHeader left, ColumnHeader right) {
            if (StringUtils.equalsIgnoreCase(left.getPath().getTerminatingItem().getName(),"Name")
                    && StringUtils.equalsIgnoreCase(right.getPath().getTerminatingItem().getName(),"Name")) {
                return 0;
            }
            if (StringUtils.equalsIgnoreCase(left.getPath().getTerminatingItem().getName(),"Name")) {
                return -1;
            }
            if (StringUtils.equalsIgnoreCase(right.getPath().getTerminatingItem().getName(),"Name")) {
                return 1;
            }
            return 0;
        }
    };


	public DefaultTableBasedElement() {
		//intentionally-blank override
	}

	public DefaultTableBasedElement(String tbstring){
		super();
		String[] tbsplits = tbstring.split("!");
		this.domainName = tbsplits[0];
		this.hidden = Boolean.valueOf(tbsplits[1]);
		this.name = tbsplits[2];
		this.type = tbsplits[3];

	}

	@Override
	public SimpleTable onLoad() {
		if (!this.isCriteriaValidForLoadAll()) {
			return DefaultSimpleTable.create();
		}
		return populateTable();
	}

	@Transient
	@Override
	public boolean isCriteriaValidForLoadAll() {
		final boolean nullValue = this.criteria == null && this.furtherCriteria == null;
		boolean emptyValue = false;
		if (!nullValue) {
			emptyValue = this.criteria.getAllCriterion().isEmpty() && this.furtherCriteria.getAllCriterion().isEmpty();
		}
		return !(( nullValue || emptyValue) && !loadAllByDefault);
	}

	@Override
	public PivotTable onLoadByPivotQuery() {
		if (!this.isCriteriaValidForLoadAll()) {
			return null;
		}
		return populatePivotTable();
	}

	private PivotTable populatePivotTable() {
		PivotQueryResult queryResult = null;
		PivotQueryRequest queryRequest = null;
		try {
			Injector injector = GuiceInjectorFactory.getInjector();
			DataCachesQuery pivotQuery = injector.getInstance(DataCachesQuery.class);
			queryResult = (PivotQueryResult) pivotQuery.execute((queryRequest = (PivotQueryRequest) populateQueryRequest()).includeSubtotals());
		} catch (Exception e){
			throw new IllegalStateException("Failed to query table due to Exception.", e);
		}
		this.setPageCount(queryResult.getResultPageCount());
		this.setResultCount(queryResult.getResultRowCount());
		return queryResult.getPivotTable(
				(DataSelectionItem) Iterables.getFirst(queryRequest.getRowDimension().getSelectionItems(), null),
				(DataSelectionItem) Iterables.getFirst(queryRequest.getColumnDimension().getSelectionItems(), null));
	}

	@Override
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "elementId")
	@Fetch(FetchMode.SUBSELECT)
	@OrderBy(value = "displayIndex")
	public List<ColumnHeader> getHeader() {
		return header;
	}

	@Override
	@Column(name = "isPivot")
	public Boolean isSubtotalDisplayed() {
		return isSubtotalDisplayed;
	}

	@Override
	public void setSubtotalDisplayed(Boolean isSubtotalDisplayed) {
		this.isSubtotalDisplayed = isSubtotalDisplayed;
	}

	@Override
	public void setHeader(List<ColumnHeader> header) {
		this.header = header;
	}

	@Override
	public void initHeader() {
		if (header == null || header.isEmpty()) {
			this.header = populateDefaultColumnHeaderList();
		}
	}

	/**
	 * Instantiates a new cache table based element.
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	private SimpleTable populateTable() {
		QueryResult queryResult = null;
		try {
			queryResult = (QueryResult) getQuery().submit(populateQueryRequest()).get();
		} catch (InterruptedTaskTimeOutException e){
		    throw new IllegalStateException(e.getMessage(), e);
		} catch (InterruptedException e) {
			throw new IllegalStateException("Failed to query table due to Interrupted Exception.", e);
		} catch (ExecutionException e) {
			throw new IllegalStateException("Failed to query table due to Execution Exception.", e);
		} catch (Exception e){
			throw new IllegalStateException("Failed to query table due to Exception.", e);
		}
		this.setPageCount(queryResult.getResultPageCount());
		this.setResultCount(queryResult.getResultRowCount());
		return queryResult.getTable();
	}

	/**
	 * Generated excel file.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void populateExcelOutputStream() {
		try {
			getQuery().submit(populateQueryRequestWithAllResults()).get();
		} catch (Exception e) {
			throw new IllegalStateException("Failed to query table.", e);
		}
	}

	@SuppressWarnings("rawtypes")
	public QueryRequest populateQueryRequest() {
		QueryRequest queryRequest;
		Boolean needPagination = true;
		if (isSubtotalDisplayed()!=null && isSubtotalDisplayed()) {
			queryRequest = this.getPivotDataSelection().asPivotQueryRequest();
			needPagination = CoreModule.getConfiguration().getBoolean(NavigatorConstants.PAGE_GRAND_TOTAL, false);
		}
		else
			queryRequest = this.getDataSelection().asQueryRequest();
		if (needPagination) {
			queryRequest.setPageSize(pageSize);
			queryRequest.setPageIndex(pageIndex);
		}
		if (criteria != null) {
			queryRequest.addCriteria(criteria);
		}
		if (furtherCriteria != null) {
			updateFurtherCriteria();
			queryRequest.addFurtherCriteria(furtherCriteria);
		}
		return queryRequest;
	}

	private void updateFurtherCriteria() {

		for(int i = 0; i< furtherCriteria.getNumberOfCriterion(); i++){

			Criterion criterion = furtherCriteria.getCriterion(i);
			DataPath path = criterion.getDataSelectionItem().getUnderlyingPath();

			for (int j = 0; j < header.size(); j++) {
				if (header.get(j).getPath().equals(path)) {
					criterion.getDataSelectionItem().setSequenceNumber(j);
				}
			}
		}
	}

	@JsonIgnore
	@Transient
	private DataSelection getPivotDataSelection() {
		if (header == null || header.isEmpty()) {
			initHeader();
		}
		return convertColumnHeaderListToPivotDataSelection(header);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	private DataSelection convertColumnHeaderListToPivotDataSelection(List<ColumnHeader> columnHeaders) {
		List clonedColumnHeaders = Lists.newLinkedList(columnHeaders);
		Collections2.filter(clonedColumnHeaders, new Predicate<ColumnHeader>() {
			@Override
			public boolean apply(ColumnHeader columnHeader) {
				return columnHeader.getQueryCompareMeasure() == null;
			}
		});
		return toPivotDataSelection(clonedColumnHeaders);
	}


	@SuppressWarnings("rawtypes")
	private QueryRequest populateQueryRequestWithAllResults() {
		QueryRequest queryRequest = this.getDataSelection().asQueryRequest();
		queryRequest.setPageSize(Integer.MAX_VALUE);
		queryRequest.setPageIndex(0);
		queryRequest.addCriteria(criteria);
		queryRequest.shouldGenerateExcel(getOutputStream());
		return queryRequest;
	}

	void addCriteriaToDataSelection() {
		if (this.header == null) {
			this.header = populateDefaultColumnHeaderList();
		}
		List<DataPath> currentPathList = convertHeaderListToPathList(header);
		if (this.criteria != null) {
			Collection<Criterion<?>> allCriterion = this.criteria.getAllCriterion();
			DataPath criterionPath;
			for (Criterion<?> criterion : allCriterion) {
				criterionPath = criterion.getDataSelectionItem().getUnderlyingPath();
				if (criterionPath.isTerminatedWithAnItem() && !currentPathList.contains(criterionPath)) {
					this.addColumn(new ColumnHeader(criterionPath, null));
				}
			}
		}
	}

	@Override
	public void updateCell(String key, String updatePathString, Object toValue) {
		/*intentionally-blank override*/
	}

	@Override
	public void addColumn(ColumnHeader columnHeader) {
		if (columnHeader == null) {
			return;
		}

		if (header == null) {
			initHeader();
		}

		if (!columnHeader.getPath().getTerminatingItem().isDimension()) {
			header.add(columnHeader);
		} else {
			int insertIndex = 0;
			for (ColumnHeader ch : header) {
				if (!ch.getPath().getTerminatingItem().isDimension()) {
					break;
				} else {
					insertIndex++;
				}
			}
			header.add(insertIndex, columnHeader);
		}

		int position = 0;
		for (ColumnHeader oneHeader : getHeader()) {
			oneHeader.getDataSelectionItem().setSequenceNumber(position);
			position++;
		}
	}

	@Override
	public void removeColumn(ColumnHeader columnHeader) {
		if (columnHeader == null) {
			return;
		}

		if (header == null) {
			throw new NullPointerException("headerlist should not be null.");
		}

		header.remove(columnHeader);
	}

	@Override
	public void setSortColumn(ColumnHeader columnHeader) {
		if (columnHeader == null) {
			return;
		}

		if (header == null) {
			initHeader();
		}

		int index = header.indexOf(columnHeader);
		header.remove(index);
		header.add(index, columnHeader);
	};

	@Override
	public void setFurtherCriteria(Criteria furtherCriteria) {
		this.furtherCriteria = furtherCriteria;
	}

	@JsonIgnore
	@Transient
	public Criteria getFurtherCriteria() {
		return this.furtherCriteria;
	}

	@Override
	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}

	@JsonIgnore
	@Transient
	public Criteria getCriteria() {
		return this.criteria;
	}

	private List<DataPath> convertHeaderListToPathList(List<ColumnHeader> columnHeaderList) {
		List<DataPath> pathList = Lists.newArrayList();
		for (ColumnHeader columnHeader : columnHeaderList) {
			pathList.add(columnHeader.getPath());
		}
		return pathList;
	}

	@SuppressWarnings("rawtypes")
	@Transient
	@JsonIgnore
	public DataSelection getDataSelection() {
		if (header == null || header.isEmpty()) {
			initHeader();
		}
		return convertColumnHeaderListToDataSelection(header);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	private List<ColumnHeader> populateDefaultColumnHeaderList() {
		DataDomain domain = this.getViewContext().getDomain();
		if (domain == null) {
			throw new NullPointerException("Domain should not be null.");
		}

		Collection<DataItem> allItems = domain.getAllItems();
		if (allItems == null || allItems.isEmpty()) {
			return Lists.newArrayList();
		}
		List<ColumnHeader> columnHeaderListDimensionsPart = Lists.newArrayList();
		List<ColumnHeader> columnHeaderListMeasuresPart = Lists.newArrayList();
		for (DataItem item : allItems) {
			if (!item.isDimension()) {
				columnHeaderListMeasuresPart.add(new ColumnHeader(item.path(), null));
			} else {
				columnHeaderListDimensionsPart.add(new ColumnHeader(item.path(), null));
			}
		}
		Collections.sort(columnHeaderListMeasuresPart, orderTableColumnsByProminence);
		Collections.sort(
				columnHeaderListDimensionsPart,
				orderTableColumnsByKeyFirst.compound(orderTableColumnsByNameSecond).compound(
						orderTableColumnsByProminence));
		columnHeaderListDimensionsPart.addAll(columnHeaderListMeasuresPart);

		List<DataSelectionItem> dataSelectionItems = convertColumnHeaderListToDataSelection(
				columnHeaderListDimensionsPart).getSelectionItems();

		List<ColumnHeader> retColumnHeaderList = Lists.newArrayList();

		for (DataSelectionItem dataSelectionItem : dataSelectionItems) {
			retColumnHeaderList.add(new ColumnHeader(dataSelectionItem));
		}

		return retColumnHeaderList;
	}

    
	@SuppressWarnings({"rawtypes", "unchecked"})
	private DataSelection convertColumnHeaderListToDataSelection(List<ColumnHeader> columnHeaders) {
		List clonedColumnHeaders = Lists.newLinkedList(columnHeaders);
		Collections.sort(clonedColumnHeaders, new Comparator<ColumnHeader>() {
			@Override
			public int compare(ColumnHeader c1, ColumnHeader c2) {
				return (c1.getSortIndex() == null ? -1 : c1.getSortIndex()) - (c2.getSortIndex() == null ? -1 : c2.getSortIndex());
			}
		});
		return toDataSelection(clonedColumnHeaders);
	}

	@Transient
	public boolean isLoadAllByDefault() {
		return loadAllByDefault;
	}

	@Override
	public void setLoadAllWithNonCriteria(boolean loadAllWithNonCriteria) {
		this.loadAllByDefault = loadAllWithNonCriteria;
	}

	@Transient
	@Override
	public Query getQuery() {
		return this.query;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	@Transient
	@Override
	public ViewContext getViewContext() {
		return viewContext;
	}

	@Override
	public void setViewContext(ViewContext viewContext) {
		this.viewContext = viewContext;
	}

	@Override
	public Integer getPageSize() {
		return pageSize;
	}

	@Override
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	@Transient
	public Integer getPageIndex() {
		return pageIndex;
	}

	@Override
	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	@Transient
	@Override
	public Integer getPageCount() {
		return pageCount;
	}

	@Transient
	public void setPageCount(Integer pageCount) {
		this.pageCount = pageCount;
	}

	@Transient
	@Override
	public Integer getResultCount() {
		return resultCount;
	}

	public void setResultCount(Integer resultCount) {
		this.resultCount = resultCount;
	}

	@Transient
	@Override
	public OutputStream getOutputStream() {
		return out;
	}

	@Override
	public void setOutputStream(OutputStream out) {
		this.out = out;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DefaultTableBasedElement_Seq")
	// generator setting in orm.xml in apps project
	@Column(name = "id", nullable = false)
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	@Column(length = 50)
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	@Column(length = 100)
	public String getDomainName() {
		return domainName;
	}

	@Override
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	@Override
	@Column(length = 100)
	public String getType() {
		return type;
	}

	@Override
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public Integer getDisplayIndex() {
		return displayIndex;
	}

	@Override
	public void setDisplayIndex(Integer displayIndex) {
		this.displayIndex = displayIndex;
	}

	@Override
	@ManyToOne(targetEntity = DefaultView.class)
	@JoinColumn(name = "viewId", insertable = true, updatable = true)
	public View getView() {
		return view;
	}

	@Override
	public void setView(View view) {
		this.view = view;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultTableBasedElement other = (DefaultTableBasedElement) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TableElement {id = " + getId() +
				", name = " + getName() +
				", type = " + type +
				", pageSize = " + pageSize +
				", currency = " + currency +
				", displayIndex = " + displayIndex +
				", domainName = " + domainName +
				", hidden = "+ hidden +
				", sourceId = " + sourceId +
				", viewId = "+ (view != null ? view.getId() : null) +
				", isGlobalFilterDisabled = " + isGlobalFilterDisabled +
				", elementCriteriaString = " + elementCriteriaString +
				", isPivot = " + isSubtotalDisplayed
				+"}";
	}

	@Override
	public Object clone() {

		DefaultTableBasedElement element = null;
		try {
			element = (DefaultTableBasedElement) super.clone();
			List<ColumnHeader> columns = null;
			if (element.getHeader() != null) {
				columns = new ArrayList<>();
				int localDisplayIndex = 0;
				for (ColumnHeader cl : element.getHeader()) {
					ColumnHeader cloneColumnHeader = (ColumnHeader) cl.clone();
					cloneColumnHeader.setDisplayIndex(localDisplayIndex++);
					columns.add(cloneColumnHeader);
				}
			}
			element.setHeader(columns);
			element.setId(null);
			element.setView(null);

		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy element", e);
		}
		return element;
	}

	@Override
	public TableBasedElement copy(View v) {
		DefaultTableBasedElement element = null;
		try {
			element = (DefaultTableBasedElement) super.clone();
			List<ColumnHeader> columns = null;
			if (element.getHeader() != null) {
				columns = new ArrayList<>();
				for (ColumnHeader cl : element.getHeader()) {
					columns.add((ColumnHeader) cl.copy(element));
				}
			}
			element.setHeader(columns);
			element.setView(v);
		} catch (CloneNotSupportedException e) {
			LOGGER.error("Can't copy element", e);
		}
		return element;
	}

	@Transient
	@Override
	public List<Navigation> getMenuList() {
		return menuList;
	}

	@Override
	public void setMenuList(List<Navigation> menuList) {
		this.menuList = menuList;
	}

	@Transient
	@Override
	public List<Navigation> getTableOperatorList() {
		return new ArrayList<>();
	}

	@Transient
	@Override
	public Navigation getNavigation(String itemName) {

		for (Navigation item : getMenuList()) {
			if (item.getItemName().equals(itemName)) {
				return item;
			}
		}

		for (Navigation item : getTableOperatorList()) {
			if (item.getItemName().equals(itemName)) {
				return item;
			}
		}

		return null;
	}

	@Override
	public View navigateTo(String itemName, NavigationParameter parameter) {
		Navigation item = getNavigation(itemName);
		if (item == null) {
			throw new IllegalArgumentException(new Exception("Fail to do navigation!"));
		}
		return item.navigateTo(parameter);
	}

	@Override
	public List<View> popUp(String itemName, NavigationParameter parameter) {
		Navigation item = getNavigation(itemName);
		if (item == null) {
			throw new IllegalArgumentException(new Exception("Fail to do navigation!"));
		}
		return item.popUp(parameter);
	}

	@Override
	public Boolean getHidden() {
		return hidden;
	}

	@Override
	public void setHidden(Boolean hidden) {
		this.hidden = hidden;
	}

	@Override
	public Integer getSourceId() {
		return sourceId;
	}

	@Override
	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}

	@Override
	public String getTemplateName() {
		return templateName;
	}

	@Override
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	@SuppressWarnings("rawtypes")
	protected void populateAggMeasureAndSetHeader(List<ColumnHeader> originalHeaderList) {

		for (ColumnHeader _header : originalHeaderList) {

			DataPath path = _header.getPath();
			Collection<AggregateInfo<?>> infos = path.getTerminatingItem().getAvailableAggregates();
			List<Map<String, String>> measurelist = new ArrayList<>();
			for (AggregateInfo<?> info : infos) {
				if (info != null) {
					generateMeasureList(measurelist, info);
				}
			}
			_header.setAvailableAggregateMeasureList(measurelist);
		}

		this.header = originalHeaderList;
	}

	private void generateMeasureList(List<Map<String, String>> measurelist, AggregateInfo<?> info) {
	    for (AggregateMeasure measure : info.getAvailableMeasures()) {
	    	if (measure != null) {
	    		Map<String, String> measureMap = new HashMap<>();
	    		measureMap.put("text", measure.getMeasureName());
	    		measureMap.put("value", measure.getMeasureName()
	    				+ DataSelectionItem.MEASURE_CLASS_SEPARATOR + info.getAggregateClass().getName());
	    		measurelist.add(measureMap);
	    	}
	    }
    }

	@Column(name="units", nullable=false, columnDefinition="number(10, 0) default 1")
	@Override
	public Integer getCurrency() {
		return this.currency;
	}

	@Override
	public void setCurrency(Integer currency) {
		this.currency = currency;
	}

	@Column(name = "isGlobalFilterDisabled", nullable = false, columnDefinition = "number(1, 0) default 0")
	@Override
	public Integer getIsGlobalFilterDisabled() {
		return this.isGlobalFilterDisabled;
	}

	@Override
	public void setIsGlobalFilterDisabled(Integer isGlobalFilterDisabled) {
		this.isGlobalFilterDisabled = isGlobalFilterDisabled;
	}


	@JsonIgnore
	@Override
	@Column(length = 1500)
	public String getElementCriteriaString() {
		return this.elementCriteriaString;
	}

	@Override
	public void setElementCriteriaString(String elementCriteriaString) {
		this.elementCriteriaString = elementCriteriaString;
	}

	@Transient
	@Override
	public List<Map<String, Object>> getElementCriteria() {
		return this.elementCriteria;
	}

	@Override
	public void setElementCriteria(List<Map<String, Object>> elementCriteria) {
		this.elementCriteria = elementCriteria;
	}

	@Override
	public DataSelection toDataSelection(List<ColumnHeader> columnHeaders) {
		DataSelection dataSelection = null;
		Iterator<ColumnHeader> iterator = columnHeaders.iterator();
		ColumnHeader columnHeader;

		if (!columnHeaders.isEmpty()) {
			columnHeader = iterator.next();
			dataSelection = getFirstColumnHeaderDataSelection(columnHeader);
			while (iterator.hasNext()) {
				columnHeader = iterator.next();
				if (columnHeader.getSortBy() == null) {
					appendDataSelectionWithoutSortBy(dataSelection, columnHeader);
				} else {
					appendDataSelectionWithSortBy(dataSelection, columnHeader);
				}
			}
		}
		return dataSelection;
	}

	private void appendDataSelectionWithSortBy(DataSelection dataSelection, ColumnHeader columnHeader) {
		if (columnHeader.getSelectedAggregateMeasure() == null) {
			if (columnHeader.getQueryCompareMeasure() == null) {
				dataSelection.and(columnHeader.getPath().sortBy(columnHeader.getSortBy()));
			} else {
				dataSelection.and(columnHeader.getPath().sortBy(columnHeader.getSortBy()).compareWith(columnHeader.getQueryCompareMeasure()));
			}
		} else {
			if (columnHeader.getQueryCompareMeasure() == null) {
				dataSelection.and(columnHeader.getPath().aggregateToSortBy(columnHeader.getSelectedAggregateMeasure(), columnHeader.getSortBy()));
			} else {
				dataSelection.and(columnHeader.getPath().aggregateToSortBy(columnHeader.getSelectedAggregateMeasure(), columnHeader.getSortBy()).compareWith(columnHeader.getQueryCompareMeasure()));
			}
		}
	}

	private void appendDataSelectionWithoutSortBy(DataSelection dataSelection, ColumnHeader columnHeader) {
		if (columnHeader.getSelectedAggregateMeasure() == null) {
			if (columnHeader.getQueryCompareMeasure() == null) {
				dataSelection.and(columnHeader.getPath());
			} else {
				dataSelection.and(columnHeader.getPath().select().compareWith(columnHeader.getQueryCompareMeasure()));
			}
		} else {
			if (columnHeader.getQueryCompareMeasure() == null) {
				dataSelection.and(columnHeader.getPath().aggregateTo(columnHeader.getSelectedAggregateMeasure()));
			} else {
				dataSelection.and(columnHeader.getPath().aggregateTo(columnHeader.getSelectedAggregateMeasure()).compareWith(columnHeader.getQueryCompareMeasure()));
			}
		}
	}

	private DataSelection getFirstColumnHeaderDataSelection(ColumnHeader columnHeader) {
		DataSelection dataSelection;
		if (columnHeader.getSortBy() == null) {
			if (columnHeader.getSelectedAggregateMeasure() == null) {
				dataSelection = columnHeader.getPath().select();
			} else {
				dataSelection = columnHeader.getPath().aggregateTo(columnHeader.getSelectedAggregateMeasure());
			}
		} else {
			if (columnHeader.getSelectedAggregateMeasure() == null) {
				dataSelection = columnHeader.getPath().sortBy(columnHeader.getSortBy());
			} else {
				dataSelection = columnHeader.getPath().aggregateToSortBy(columnHeader.getSelectedAggregateMeasure(), columnHeader.getSortBy());
			}
		}
		if (columnHeader.getQueryCompareMeasure() != null) {
			dataSelection.compareWith(columnHeader.getQueryCompareMeasure());
		}
		return dataSelection;
	}

	@Override
	public DataSelection toPivotDataSelection(List<ColumnHeader> columnHeaders) {
		DataSelection dataSelection = null;
		Iterator<ColumnHeader> iterator = columnHeaders.iterator();
		ColumnHeader columnHeader;

		while (iterator.hasNext()) {
			columnHeader = iterator.next();
			if (columnHeader.getSortBy() == null) {
				dataSelection = generateDataSelectionWithNotSortBy(dataSelection, columnHeader);
			} else {
				dataSelection = generateDataSelectionWithSortBy(dataSelection, columnHeader);
			}
		}
		return dataSelection;
	}

    private DataSelection generateDataSelectionWithSortBy(DataSelection dataSelection, ColumnHeader columnHeader) {
        DataSelection localDataSelection = dataSelection;
        if (columnHeader.getSelectedAggregateMeasure() == null) {
        	if (dataSelection == null) {
        	    localDataSelection = columnHeader.getPath().sortBy(columnHeader.getSortBy()).selectAsRowDimension();
        	} else {
        	    localDataSelection.and(columnHeader.getPath().sortBy(columnHeader.getSortBy()).selectAsRowDimension());
        	}
        } else {
        	if (dataSelection == null) {
        	    localDataSelection = columnHeader.getPath().sortBy(columnHeader.getSortBy()).selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure());
        	} else {
				if(columnHeader.getQueryCompareMeasure() != null){
					localDataSelection.and(columnHeader.getPath().sortBy(columnHeader.getSortBy()).selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure()).compareWith(columnHeader.getQueryCompareMeasure()));
				}else{
					localDataSelection.and(columnHeader.getPath().sortBy(columnHeader.getSortBy()).selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure()));
				}
        	}
        }
        return localDataSelection;
    }

    private DataSelection generateDataSelectionWithNotSortBy(DataSelection dataSelection, ColumnHeader columnHeader) {
        DataSelection localDataSelection = dataSelection;
        if (columnHeader.getSelectedAggregateMeasure() == null) {
        	if (dataSelection == null) {
        	    localDataSelection = columnHeader.getPath().selectAsRowDimension();
        	} else {
        	    localDataSelection.and(columnHeader.getPath().selectAsRowDimension());
        	}
        } else {
        	if (dataSelection == null) {
        	    localDataSelection = columnHeader.getPath().selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure());
        	} else {
				if(columnHeader.getQueryCompareMeasure() != null){
					localDataSelection.and(columnHeader.getPath().selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure()).compareWith(columnHeader.getQueryCompareMeasure()));
				}else{
					localDataSelection.and(columnHeader.getPath().selectAsAggregateMeasure(columnHeader.getSelectedAggregateMeasure()));
				}
        	}
        }
        return localDataSelection;
    }

	@Override
	@JsonIgnore
	@Transient
	public List<ColumnHeader> getChildren() {
		return getHeader();
	}

	@Override
	@JsonIgnore
	@Transient
	public Perspective getRoot() {
		return getView().getPerspective();
	}

	@Override
	@JsonIgnore
	@Transient
	public Boolean hasRoot() {
		return true;
	}
}