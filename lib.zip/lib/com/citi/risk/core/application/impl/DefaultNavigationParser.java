package com.citi.risk.core.application.impl;

import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.api.NavigationHolder;
import com.citi.risk.core.application.api.NavigationParser;
import com.citi.risk.core.application.api.TargetDomains;
import com.citi.risk.core.application.api.TargetElementsUnion;
import com.citi.risk.core.application.api.TargetElementsIntersection;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public final class DefaultNavigationParser implements NavigationParser {

	@Inject
	NavigationHolder navigationHolder;

	@Override
	public final NavigationHolder parse(List<Class<? extends Navigation>> clazzes) {
		for (Class<? extends Navigation> clazz : clazzes) {
			parseTargetDomains(clazz, navigationHolder);
			parseTargetElementsIntersection(clazz, navigationHolder);
			parseTargetElementsUnion(clazz, navigationHolder);
		}
		return navigationHolder;
	}

	private final void parseTargetDomains(Class<? extends Navigation> navKlazz, NavigationHolder navigationHolder) {
		TargetDomains targetDomainAnnotation = (TargetDomains) navKlazz.getAnnotation(TargetDomains.class);
		if (targetDomainAnnotation == null || !Navigation.class.isAssignableFrom(navKlazz)) {
			return;
		}

		Class[] domains = targetDomainAnnotation.domains();
		for (Class domainClass : domains) {
			navigationHolder.addNavigation(domainClass, navKlazz);
		}
	}

	private final void parseTargetElementsIntersection(Class<? extends Navigation> navKlazz, NavigationHolder navigationHolder) {
		TargetElementsIntersection targetElementsIntersectionAnnotation = (TargetElementsIntersection) navKlazz.getAnnotation(TargetElementsIntersection.class);
	    if (targetElementsIntersectionAnnotation == null) {
	    	return;
	    }
	    
	    String[] elementNames = targetElementsIntersectionAnnotation.elementNames();
	    for (String elementName : elementNames) {
	    	navigationHolder.addNavigationElementIntersection(elementName, navKlazz);
	    	navigationHolder.addNavigationElementIntersection(navKlazz, elementName);
	    }
	}

	private final void parseTargetElementsUnion(Class<? extends Navigation> navKlazz, NavigationHolder navigationHolder) {
		TargetElementsUnion targetElementsUnionAnnotation = (TargetElementsUnion) navKlazz.getAnnotation(TargetElementsUnion.class);
	    if (targetElementsUnionAnnotation == null) {
	    	return;
	    }
	    
	    String[] elementNames = targetElementsUnionAnnotation.elementNames();
	    for (String elementName : elementNames) {
	    	navigationHolder.addNavigationElementUnion(elementName, navKlazz);
	    }
	}
}
