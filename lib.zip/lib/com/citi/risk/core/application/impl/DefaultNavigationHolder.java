package com.citi.risk.core.application.impl;

import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.api.NavigationHolder;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;

@Singleton
public class DefaultNavigationHolder implements NavigationHolder {

	@Inject
	DictionaryParser parser;
	@Inject
	Injector injector;

	private final ArrayListMultimap<DataDomain, Class<? extends Navigation>> navigationsByDomain 
		= ArrayListMultimap.create();

	private final ArrayListMultimap<String, Class<? extends Navigation>> navigationsByElementNameIntersection 
		= ArrayListMultimap.create();

	private final ArrayListMultimap<Class<? extends Navigation>, String> navigationsByClassIntersection 
		= ArrayListMultimap.create();

	private final ArrayListMultimap<String, Class<? extends Navigation>> navigationsByElementNameUnion 
	= ArrayListMultimap.create();

	@Override
	public List<Navigation> getNavigations(DataDomain domain) {
		List<Class<? extends Navigation>> navigationClassess = navigationsByDomain
				.get(domain);
		List<Navigation> navList = Lists.newArrayList();
		for (Class<? extends Navigation> navClazz : navigationClassess) {
			Navigation navigation;
			if (navClazz != null) {
				navigation = injector.getInstance(navClazz);
				navList.add(navigation);
			}
		}

		return navList;
	}

	@Override
	public void addNavigation(Class<?> domainClass,
			Class<? extends Navigation> navigationClass) {
		DataDomain domain = null;
		if (domainClass != null) {
			domain = parser.parseDomain(domainClass);
		}
		if (domain != null && navigationClass != null) {
			navigationsByDomain.put(domain, navigationClass);
		}
	}

	@Override
	public List<Navigation> getNavigationsIntersection(String elementName) {
		List<Class<? extends Navigation>> navigationClassess = navigationsByElementNameIntersection
				.get(elementName);
		List<Navigation> navList = Lists.newArrayList();
		for (Class<? extends Navigation> navClazz : navigationClassess) {
			Navigation navigation;
			if (navClazz != null) {
				navigation = injector.getInstance(navClazz);
				navList.add(navigation);
			}
		}

		return navList;
	}

	@Override
	public List<String> getElementNamesIntersection(
			Class<? extends Navigation> navigationClass) {
		return navigationsByClassIntersection.get(navigationClass);
	}

	@Override
	public void addNavigationElementIntersection(String elementName,
			Class<? extends Navigation> navigationClass) {
		if (elementName != null && navigationClass != null) {
			navigationsByElementNameIntersection.put(elementName, navigationClass);
		}
	}

	@Override
	public void addNavigationElementIntersection(Class<? extends Navigation> navigationClass,
			String elementName) {
		if (elementName != null && navigationClass != null) {
			navigationsByClassIntersection.put(navigationClass, elementName);
		}
	}

	@Override
	public void addNavigationElementUnion(String elementName,
			Class<? extends Navigation> navigationClass) {
		if (elementName != null && navigationClass != null) {
			navigationsByElementNameUnion.put(elementName, navigationClass);
		}
	}

	@Override
	public List<Navigation> getNavigations(DataDomain domain, String elementName) {
		List<Class<? extends Navigation>> navigationClassessByDomain 
			= navigationsByDomain.get(domain);
		List<Navigation> navList = Lists.newArrayList();
		Navigation navigation;

		for (Class<? extends Navigation> navClazz : navigationClassessByDomain) {
			if (navClazz != null) {
				navigation = injector.getInstance(navClazz);
				if (navigationsByClassIntersection.get(navClazz).isEmpty()
						|| navigationsByClassIntersection.get(navClazz).contains(
								elementName)) {
					navList.add(navigation);
				}
			}
		}

		List<Class<? extends Navigation>> navigationsToAppend 
			= navigationsByElementNameUnion.get(elementName);
		for (Class<? extends Navigation> navClazz : navigationsToAppend) {
			if (navClazz != null) {
				navigation = injector.getInstance(navClazz);
				if (!navList.contains(navigation)) {
					navList.add(navigation);
				}
			}
		}

		return navList;
	}

	@Override
	public void clearHolder() {
		navigationsByDomain.clear();
		navigationsByElementNameIntersection.clear();
		navigationsByClassIntersection.clear();
		navigationsByElementNameUnion.clear();
	}

}
