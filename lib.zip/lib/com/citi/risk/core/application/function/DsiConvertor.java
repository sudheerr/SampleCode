package com.citi.risk.core.application.function;

import com.citi.risk.core.application.bean.ColumnHeader;
import com.citi.risk.core.application.impl.DataTypeUtil;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.ItemList;

public class DsiConvertor {
	
	private DsiConvertor(){}
	
	public static ColumnHeader convertDSIToColumnHeader(DataSelectionItem dsi) {
		ColumnHeader columnHeader = new ColumnHeader();
        DataPath path = dsi.getUnderlyingPath();
        DataItem item = path.getTerminatingItem();
        String headerName = item instanceof ItemList?((ItemList)item).getName(path): item.getName();
        columnHeader.setPath(path);
        columnHeader.setPathString(path.toPathString());
        columnHeader.setDataTypeString(DataTypeUtil.getDataTypeString(item.getJavaSimpleType()));
        columnHeader.setMeasureTypeString(item.getMeasureType());
        columnHeader.setIsMeasure(!item.isDimension());
        columnHeader.setHeaderName(headerName);
        columnHeader.setTooltip(item.getDescription());
        columnHeader.setDisplayAlign(columnHeader.getIsMeasure()? "right" : "left");
        return columnHeader;
	}
}
