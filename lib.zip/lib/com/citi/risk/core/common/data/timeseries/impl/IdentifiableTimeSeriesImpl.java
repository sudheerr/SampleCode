package com.citi.risk.core.common.data.timeseries.impl;

import com.citi.risk.core.common.data.timeseries.api.IdentifiableTimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.api.WithTime;
import com.citi.risk.core.lang.businessobject.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.lang3.StringUtils;

public final class IdentifiableTimeSeriesImpl<K, E extends IdentifiedBy<K>> 
			extends TimeSeriesImpl<E> implements IdentifiableTimeSeries<K, E> {

	private static final long serialVersionUID = 7138618201855473995L;
	private TimeMark timeMark;
	private CreatedBy createdBy;

	public IdentifiableTimeSeriesImpl(TimeSeriesContext<E> context) {
		super(context);
	}
	
	public IdentifiableTimeSeriesImpl(WithTime<E> withTime, TimeSeriesContext<E> context) {
		super(withTime, context);
	}

	@Override
	public K key() {
		if (size() == 0) {
			return null;
		}
		return getWithTimes().get(0).getEntry().key();
	}

	@Override
	public String getKeyAsString() {
		return key() == null ? StringUtils.EMPTY : key().toString();
	}

	@Override
	@JsonIgnore
	public TimeMark getTimeMark() {
		return this.timeMark;
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		this.timeMark = timeMark;
	}

	@Override
	@JsonIgnore
	public CreatedBy getCreatedBy() {
		return this.createdBy;
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public void setCreatedByString(String createdByKey) {
		this.createdBy = DefaultCreatedBy.newCreatedBy(createdByKey);
	}

	@Override
	public String getCreatedByString() {
		return createdBy == null ? "" : createdBy.toString();
	}

	@Override
	public String getTimeMarkString() {
		return this.timeMark == null ? "" : this.timeMark.toString();
	}

	@Override
	public void setTimeMarkString(String timeMarkKey) {
		this.timeMark = DefaultTimeMark.getTimeMarkfromKey(timeMarkKey);
	}
}
