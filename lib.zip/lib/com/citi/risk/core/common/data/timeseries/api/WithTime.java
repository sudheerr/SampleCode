package com.citi.risk.core.common.data.timeseries.api;

import java.util.Date;

import com.citi.risk.core.common.data.api.TrackChanges;
import com.citi.risk.core.dictionary.api.DDR;
import com.citi.risk.core.dictionary.api.Prominence;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface WithTime<E> extends TrackChanges<E> {
	
	static final Long MAX_DATE_TIME = Long.MAX_VALUE;

	Date getFromDate();
	Date getTillDate();

	WithTime<E> till(Date validTillDate);
	WithTime<E> from(Date validFromDate);

	Boolean doesContainNow();
	Boolean doesContain(Date timePoint);
	Boolean isOpen();
	Boolean doesBecomeValidInTheFuture();
	Boolean didBecomeInvalidInThePast();

	void validate();

	TimeSeries<E> concat(E entry, Date validFromDate, Date validTillDate);

	Boolean hasTimeOverlapWith(WithTime<?> withTime);
	Boolean isTimePeriodWithin(WithTime<?> withTime);
	Boolean doesContain(WithTime<?> withTime);
	Boolean isContiguousAtTheEnd(WithTime<?> temporal);
	Boolean isContiguousAtTheBeginning(WithTime<?> temporal);

	E get(Date timePoint);
	E getNow();
	E getEntry();

	TimeSeriesContext<E> getContext();
	void setContext(TimeSeriesContext<E> context);

	TimeSeries<E> getAssociatedTimeSeries();
	void setAssociatedTimeSeries(TimeSeries<E> associatedTimeSeries);
}
