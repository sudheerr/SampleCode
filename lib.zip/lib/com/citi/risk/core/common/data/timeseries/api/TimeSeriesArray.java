package com.citi.risk.core.common.data.timeseries.api;

import java.util.Date;

import com.citi.risk.core.common.data.api.TrackChanges;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;

@DDD(name = "Time Series Array")
public interface TimeSeriesArray<E> extends TrackChanges<E> {
	
	E[] getArray();
	E[] getArray(Date date);

	TimeSeries<E> get(int i);
	
	@DDI(name = "Time Series Array Size")
	int size();
	
	Class<E> getClazz();
	
	@DDI(name = "Entity Class Name")
	String getClassName();

	TimeSeries<E> remove(int i);

	void add(int index, TimeSeries<E> timeSeries);
	void set(int index, TimeSeries<E> timeSeries);

	Boolean allowSet();
	Boolean allowRemoval();
	Boolean allowAddition();

	TimeSeriesContext<E> getContext();
	void setContext(TimeSeriesContext<E> context);
}
