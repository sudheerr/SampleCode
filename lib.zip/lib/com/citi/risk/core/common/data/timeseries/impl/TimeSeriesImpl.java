package com.citi.risk.core.common.data.timeseries.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.citi.risk.core.common.data.api.TrackChanges;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.api.WithTime;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class TimeSeriesImpl<E> extends WithTimeImpl<E> implements TimeSeries<E>, Serializable {

	private ArrayList<WithTime<E>> withTimes = new ArrayList();

	public TimeSeriesImpl(TimeSeriesContext<E> context) {
		super(context);
	}

	public TimeSeriesImpl(WithTime<E> withTime, TimeSeriesContext<E> context) {
		super(context);
		withTimes.add(withTime);
	}

	private TimeSeriesImpl(List<WithTime<E>> withTimes, TimeSeriesContext<E> context) {
		super(context);
		this.withTimes.addAll(withTimes);
	}

	@Override
	public Date getFromDate() {
		if (this.withTimes.isEmpty()) {
			return new Date();
		}
		return getEarliestWithTime().getFromDate();
	}

	@Override
	public Date getTillDate() {
		if (this.withTimes.isEmpty()) {
			return new Date(WithTime.MAX_DATE_TIME);
		}
		return getLatestWithTime().getTillDate();
	}

	@Override
	public WithTime<E> till(Date tillDate) {
		if (!getWithTimes().isEmpty()){
			super.till(tillDate);
		}
		return this;
	}

	@Override
	protected void setTillDate(Date tillDate) {
		if (getLatestWithTime() != null) {
			getLatestWithTime().till(tillDate);
		}
	}

	@Override
	protected void setFromDate(Date fromDate) {
		if ( getEarliestWithTime() != null) {
			getEarliestWithTime().from(fromDate);
		}
	}

	@Override
	public WithTime<E> from(Date fromDate) {
		if (!getWithTimes().isEmpty()) {
			super.from(fromDate);
		}
		return this;
	}

	@Override
	public TimeSeries<E> concat(TimeSeries<E> anotherTimeSeries) {
		if (anotherTimeSeries.isContiguousAtTheBeginning(this)) {
			ArrayList<WithTime<E>> newWithTimes = new ArrayList(size() + anotherTimeSeries.size());
			newWithTimes.addAll(anotherTimeSeries.getWithTimes());
			newWithTimes.addAll(this.getWithTimes());
			getContext().handlePreAdditions(this, anotherTimeSeries.getWithTimes());
			this.withTimes = newWithTimes;
			getContext().handlePostAdditions(this, anotherTimeSeries.getWithTimes());
			setupNewAdditions(anotherTimeSeries.getWithTimes());
			return this;
		}

		if (anotherTimeSeries.isContiguousAtTheEnd(this)) {
			getContext().handlePreAdditions(this, anotherTimeSeries.getWithTimes());
			this.withTimes.addAll(anotherTimeSeries.getWithTimes());
			getContext().handlePostAdditions(this, anotherTimeSeries.getWithTimes());
			setupNewAdditions(anotherTimeSeries.getWithTimes());
			return this;
		}

		throw new RuntimeException("Cannot add non-contiguous WithTime");
	}

	@Override
	public TimeSeries<E> concat(E entry, Date fromDate, Date tillDate) {
		if (!getContext().getAdditionFilter().isSelected(entry)) {
			return this;
		}
		WithTime<E> withTime = new WithTimeImpl(entry, getContext());
		withTime.from(fromDate).till(tillDate);
		if (withTime.isContiguousAtTheBeginning(this)) {
			getContext().handlePreAddition(this, withTime);
			this.withTimes.add(0, withTime);
			setupNewAddition(withTime);
			getContext().handlePostAddition(this, withTime);
			return this;
		}

		if (withTime.isContiguousAtTheEnd(this)) {
			getContext().handlePreAddition(this, withTime);
			this.withTimes.add(withTime);
			getContext().handlePostAddition(this, withTime);
			setupNewAddition(withTime);
			return this;
		}

		throw new RuntimeException("Cannot add non-contiguous WithTime");
	}

	private void setupNewAddition(WithTime<E> withTime) {
		withTime.setAssociatedTimeSeries(this);
		withTime.setContext(getContext());
	}

	private void setupNewAdditions(Collection<WithTime<E>> withTimes) {
		for (WithTime<E> withTime : withTimes) {
			withTime.setAssociatedTimeSeries(this);
		}
	}

	@Override
	public List<WithTime<E>> getWithTimes() {
		return new ArrayList(this.withTimes);
	}

	@Override
	public List<E> getAll() {
		ArrayList<E> returnList = new ArrayList(size());
		for (int i = 0; i < size(); i++) {
			returnList.add(get(i));
		}
		return returnList;
	}

	@Override
	public Boolean isEmpty() {
		return getWithTimes().isEmpty();
	}

	private WithTime<E> removeLatestWithTime() {
		if (isEmpty()) {
			return null;
		}
		getContext().handlePreRemoval(this, withTimes.get(0));
		WithTime<E> removed = this.withTimes.remove(0);
		clearUpRemoved(removed);
		getContext().handlePostRemoval(this, removed);
		return removed;
	}

	private WithTime<E> removeEarliestWithTime() {
		if (isEmpty()) {
			return null;
		}
		getContext().handlePreRemoval(this, withTimes.get(size() - 1));
		WithTime<E> removed = this.withTimes.remove(size() - 1);
		clearUpRemoved(removed);
		getContext().handlePostRemoval(this, removed);
		return removed;
	}

	private void clearUpRemoved(WithTime<E> removed) {
		removed.setAssociatedTimeSeries(null);
	}

	@Override
	public int size() {
		return getWithTimes().size();
	}

	@Override
	public String getClassName() {
		if (getEarliest() == null) {
			return "";
		}
		return getEarliest().getClass().getName();
	}

	@Override
	public E get(int i) {
		return getWithTimes().get(i).getEntry();
	}

	@Override
	public TimeSeries<E> subSeries(int from, int to) {
		return new TimeSeriesImpl(getWithTimes().subList(from, to), getContext());
	}

	private WithTime<E> getLatestWithTime() {
		if (getWithTimes().isEmpty()) {
			return null;
		}
		return getWithTimes().get(0);
	}

	private WithTime<E> getEarliestWithTime() {
		if (getWithTimes().isEmpty()) {
			return null;
		}
		return getWithTimes().get(getWithTimes().size() - 1);
	}

	@Override
	public E getEarliest() {
		if (getEarliestWithTime() == null) {
			return null;
		}
		return getEarliestWithTime().getEntry();
	}

	@Override
	public E getLatest() {
		if (getLatestWithTime() == null) {
			return null;
		}
		return getLatestWithTime().getEntry();
	}

	@Override
	public TimeSeries<E> removeLatest() {
		removeLatestWithTime();
		return this;
	}

	@Override
	public TimeSeries<E> removeEarliest() {
		removeEarliestWithTime();
		return this;
	}

	@Override
	public void validate() {
		super.validate();
		for (int i = 0; i < size() - 2; i++) {
			if (!withTimes.get(i).isContiguousAtTheBeginning(withTimes.get(i + 1))) {
				throw new RuntimeException("WithTimeEntries are not contiguous");
			}
		}
	}

	@Override
	public E get(Date timePoint) {
		for (WithTime<E> withTime : this.withTimes) {
			if (withTime.doesContain(timePoint))
				return withTime.getEntry();
		}
		return null;
	}

	@JsonIgnore
	@Override
	public E getEntry() {
		throw new UnsupportedOperationException();
	}

	@Override
	public TimeSeries<E> removeAll() {
		getContext().handlePreRemovals(this, this.withTimes);
		List<WithTime<E>> removed = this.withTimes;
		this.withTimes = new ArrayList();
		clearUpRemoved(removed);
		getContext().handlePostRemovals(this, removed);
		return null;
	}

	private void clearUpRemoved(List<WithTime<E>> removed) {
		for (WithTime<E> withTime : removed) {
			clearUpRemoved(withTime);
		}
	}

	@Override
	public Collection<TrackChanges<?>> getAllTrackChangesMembers() {
		List<TrackChanges<?>> returnList = new ArrayList(size());
		for (WithTime<E> withTime : withTimes) {
			returnList.addAll(withTime.getAllTrackChangesMembers());
		}
		return returnList;
	}
}
