package com.citi.risk.core.common.data.timeseries.impl;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.citi.risk.core.common.data.api.TrackChanges;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesArray;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;

public class TimeSeriesArrayImpl<E> implements TimeSeriesArray<E> {

	private List<TimeSeries<E>> timeSerieses;
	private TimeSeriesContext<E> timeSeriesContext;
	private Class<E> entityClass;
	private boolean isAllowSet;
	private boolean isAllowRemoval;
	private boolean isAllowAddition;

	public TimeSeriesArrayImpl(TimeSeriesContext<E> timeSeriesContext, Class<E> entityClass) {
		this.timeSeriesContext = timeSeriesContext;
		this.timeSerieses = new ArrayList();
		this.entityClass = entityClass;
		this.isAllowAddition = true;
		this.isAllowRemoval = true;
		this.isAllowSet = true;
	}

	@Override
	public Collection<E> getAdditions() {
		return this.timeSeriesContext.getAdditions();
	}

	@Override
	public Collection<E> getRemovals() {
		return this.timeSeriesContext.getRemovals();
	}

	@Override
	public Collection<E> getModifications() {
		return this.timeSeriesContext.getModifications();
	}

	@Override
	public void clearTrackings() {
		this.timeSeriesContext.clearTrackings();

	}

	@Override
	public void startTracking() {
		this.timeSeriesContext.startTracking();
	}

	@Override
	public void stopTracking() {
		this.timeSeriesContext.stopTracking();
	}

	@Override
	public Collection<TrackChanges<?>> getAllTrackChangesMembers() {
		return Collections.emptyList();
	}

	@Override
	public void notifyModification(E entry) {
		this.timeSeriesContext.notifyModification(entry);
	}

	@Override
	public E[] getArray() {
		return getArray(new Date());
	}

	@Override
	public E[] getArray(Date date) {
		List<E> result = new ArrayList();
		for (TimeSeries<E> ts : this.timeSerieses) {
			if (ts != null) {
				E e = ts.get(date);
				if (e != null) {
					result.add(e);
				}
			}
		}

		E[] outputArray = (E[]) Array.newInstance(this.entityClass, result.size());
		return result.toArray(outputArray);
	}

	@Override
	public TimeSeries<E> get(int i) {
		return this.timeSerieses.get(i);
	}

	@Override
	public int size() {
		return this.timeSerieses.size();
	}
	
	@Override
	public Class<E> getClazz() {
		return this.entityClass;
	}

	@Override
	public String getClassName() {
		return this.entityClass == null ? null : this.entityClass.getName();
	}

	@Override
	public TimeSeries<E> remove(int i) {
		return this.timeSerieses.remove(i);
	}

	@Override
	public void add(int index, TimeSeries<E> timeSeries) {
		this.timeSerieses.add(index, timeSeries);
	}

	@Override
	public void set(int index, TimeSeries<E> timeSeries) {
		this.timeSerieses.set(index, timeSeries);
	}

	@Override
	public Boolean allowSet() {
		return this.isAllowSet;
	}

	@Override
	public Boolean allowRemoval() {
		return this.isAllowRemoval;
	}

	@Override
	public Boolean allowAddition() {
		return this.isAllowAddition;
	}

	@Override
	public TimeSeriesContext<E> getContext() {
		return this.timeSeriesContext;
	}

	@Override
	public void setContext(TimeSeriesContext<E> context) {
		this.timeSeriesContext = context;
	}

}
