package com.citi.risk.core.common.data.api;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.NoOp;

import com.citi.risk.core.common.data.impl.proxy.EnhancedPersistenceCallback;
import com.citi.risk.core.common.data.impl.proxy.EnhancedPersistenceProxyCallbackFilter;
import com.citi.risk.core.common.data.impl.proxy.PersistenceBeanCallback;

public final class EnhancedPersistenceProxies {
	
	private static Class[] callbackTypes = new Class[] { EnhancedPersistenceCallback.class, PersistenceBeanCallback.class, NoOp.INSTANCE.getClass() };
	private final static ConcurrentHashMap<Class, Class> cacheMap = new ConcurrentHashMap();
	
	private EnhancedPersistenceProxies() {}

	public static <E> E proxyForExistingEntry(Class<E> klass) {
		return EnhancedPersistenceProxies.proxyForEntry(klass, null, true);
	}
	
	private synchronized static Class buildProxyClass(Class klass) {
		Class proxyClass = cacheMap.get(klass);
		if (proxyClass == null) {
			Enhancer enhancer = new Enhancer();
			enhancer.setClassLoader(klass.getClassLoader());
			enhancer.setInterceptDuringConstruction(false);
			enhancer.setUseFactory(true);
			enhancer.setSuperclass(klass);
			enhancer.setInterfaces(new Class[] { EnhancedPersistenceProxy.class });
			BeanInfo beanInfo = null;
			try {
				beanInfo = Introspector.getBeanInfo(klass);
			} catch (IntrospectionException e) {
				throw new RuntimeException(e);
			}
			enhancer.setCallbackFilter(new EnhancedPersistenceProxyCallbackFilter(beanInfo));
			enhancer.setCallbackTypes(callbackTypes);
			proxyClass = enhancer.createClass();
			cacheMap.put(klass, proxyClass);
		}
		return proxyClass;
	}
	
	private static <E> E proxyForEntry(Class<E> klass, E delegate, boolean isNew){
		Class proxClass = EnhancedPersistenceProxies.buildProxyClass(klass);
		net.sf.cglib.proxy.Factory factory;
		try {
			factory = (net.sf.cglib.proxy.Factory)proxClass.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		factory.setCallbacks(buildCallbacks(delegate, isNew));
		return (E) factory;	
	}
	
	private static <E> Callback[] buildCallbacks(E delegate, boolean isNew) {
		Callback[] callbacks = new Callback[callbackTypes.length];
		EnhancedPersistenceCallback<?> enhancedPersistenceCallback = new EnhancedPersistenceCallback(delegate, isNew);
		callbacks[0] = enhancedPersistenceCallback;
		callbacks[1] = new PersistenceBeanCallback(enhancedPersistenceCallback);
		callbacks[2] = NoOp.INSTANCE;
		return callbacks;
	}

}
