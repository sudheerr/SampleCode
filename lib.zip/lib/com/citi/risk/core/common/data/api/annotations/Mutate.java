package com.citi.risk.core.common.data.api.annotations;

public @interface Mutate {

}
