package com.citi.risk.core.common.data.impl.proxy;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

public class PersistenceBeanCallback implements MethodInterceptor {
	
	private EnhancedPersistenceCallback enhancedPersistenceCallback;
	
	public PersistenceBeanCallback(EnhancedPersistenceCallback enhancedPersistenceCallback) {
		this.enhancedPersistenceCallback = enhancedPersistenceCallback;
	}

	@Override
	public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
		enhancedPersistenceCallback.setDirty();
		return proxy.invokeSuper(obj, args);
	}
	
}
