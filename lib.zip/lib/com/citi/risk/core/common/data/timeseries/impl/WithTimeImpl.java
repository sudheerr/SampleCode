package com.citi.risk.core.common.data.timeseries.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.citi.risk.core.common.data.api.TrackChanges;
import com.citi.risk.core.common.data.api.TrackChangesAware;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.api.WithTime;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class WithTimeImpl<E> implements WithTime<E>, Serializable {
	
	private E entry;
	private transient TimeSeriesContext<E> context;
	private TimeSeries<E> associatedTimeSeries;
	
	private Date fromDate = new Date();
	private Date tillDate = new Date(WithTime.MAX_DATE_TIME);

	protected WithTimeImpl(TimeSeriesContext<E> context) {
		this.context = context;
	}

	public WithTimeImpl(E entry, TimeSeriesContext<E> context) {
		this.entry = entry;
		if (entry instanceof TrackChangesAware) {
			((TrackChangesAware<E>) entry).add(this);
		}
		this.context = context;
	}

	@Override
	public Date getFromDate() {
		return this.fromDate;
	}

	@Override
	public Date getTillDate() {
		return this.tillDate;
	}

	protected void setTillDate(Date tillDate) {
		getContext().handlePreTillDateChange(this, tillDate);
		this.tillDate = tillDate;
		getContext().handlePostTillDateChange(this, tillDate);
	}

	protected void setFromDate(Date fromDate) {
		getContext().handlePreFromDateChange(this, fromDate);
		this.fromDate = fromDate;
		getContext().handlePostFromDateChange(this, fromDate);
	}

	@Override
	public WithTime<E> from(Date fromDate) {
		if (fromDate.getTime() >= getTillDate().getTime()) {
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		}

		Date priorDate = getFromDate();

		setFromDate(fromDate);
		try {
			validate();
		} catch (Exception e) {
			setFromDate(priorDate);
			throw e;
		}
		return this;
	}

	@Override
	public WithTime<E> till(Date tillDate) {
		if (tillDate.getTime() <= getFromDate().getTime()) {
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		}
		Date priorDate = this.getTillDate();

		setTillDate(tillDate);
		try {
			validate();
		} catch (Exception e) {
			setTillDate(priorDate);
			throw e;
		}
		return this;
	}

	@Override
	public Boolean doesContainNow() {
		return doesContain(new Date());
	}

	@Override
	public Boolean doesContain(Date timePoint) {
		if (getTillDate().getTime() == WithTime.MAX_DATE_TIME) {
			return (getFromDate().getTime() <= timePoint.getTime()) && (getTillDate().getTime() >= timePoint.getTime());
		}
		return (getFromDate().getTime() <= timePoint.getTime()) && (getTillDate().getTime() > timePoint.getTime());
	}

	@Override
	public Boolean doesBecomeValidInTheFuture() {
		return this.getFromDate().getTime() > (new Date()).getTime();
	}

	@Override
	public Boolean didBecomeInvalidInThePast() {
		return this.getTillDate().getTime() < (new Date().getTime());
	}

	@Override
	public Boolean isOpen() {
		return getTillDate().getTime() == WithTime.MAX_DATE_TIME;
	}

	@Override
	public void validate() {
		if (getFromDate().getTime() >= getTillDate().getTime()) {
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		}
		if (getAssociatedTimeSeries() != null) {
			getAssociatedTimeSeries().validate();
		}
	}

	@Override
	public TimeSeries<E> getAssociatedTimeSeries() {
		return this.associatedTimeSeries;
	}

	@Override
	public void setAssociatedTimeSeries(TimeSeries<E> associatedTimeSeries) {
		this.associatedTimeSeries = associatedTimeSeries;
	}

	@Override
	public TimeSeries<E> concat(E entry, Date fromDate, Date tillDate) {
		if (getAssociatedTimeSeries() == null) {
			setAssociatedTimeSeries(new TimeSeriesImpl<E>(this, getContext()));
		}
		getAssociatedTimeSeries().concat(entry, fromDate, tillDate);
		return getAssociatedTimeSeries();
	}

	@Override
	public Boolean hasTimeOverlapWith(WithTime<?> withTime) {
		return doesContain(withTime.getFromDate()) 
				|| doesContain(getTillDate()) 
				|| (withTime.getTillDate().getTime() == getTillDate().getTime());
	}

	@Override
	public Boolean isTimePeriodWithin(WithTime<?> withTime) {
		return withTime.doesContain(this);
	}

	@Override
	public Boolean doesContain(WithTime<?> withTime) {
		return (getFromDate().getTime() <= withTime.getFromDate().getTime()) 
					&& (withTime.getTillDate().getTime() <= getTillDate().getTime());
	}

	@Override
	public Boolean isContiguousAtTheEnd(WithTime<?> withTime) {
		return (withTime.getFromDate().getTime()) == this.getTillDate().getTime();
	}

	@Override
	public Boolean isContiguousAtTheBeginning(WithTime<?> withTime) {
		return (withTime.getTillDate().getTime()) == this.getFromDate().getTime();
	}

	@Override
	public E get(Date timePoint) {
		if (doesContain(timePoint)) {
			return getEntry();
		}
		return null;
	}

	@Override
	public E getNow() {
		return get(new Date());
	}

	@Override
	public E getEntry() {
		return this.entry;
	}

	@JsonIgnore
	@Override
	public TimeSeriesContext<E> getContext() {
		return this.context;
	}

	@Override
	public void setContext(TimeSeriesContext<E> context) {
		this.context = context;
	}

	@Override
	public Collection<E> getAdditions() {
		return getContext().getAdditions();
	}

	@Override
	public Collection<E> getModifications() {
		return getContext().getModifications();
	}

	@Override
	public Collection<E> getRemovals() {
		return getContext().getRemovals();
	}

	@Override
	public void clearTrackings() {
		getContext().clearTrackings();

	}

	@Override
	public void startTracking() {
		getContext().startTracking();
	}

	@Override
	public void stopTracking() {
		getContext().stopTracking();
	}

	@Override
	public Collection<TrackChanges<?>> getAllTrackChangesMembers() {
		List<TrackChanges<?>> returnList = new ArrayList(1);
		if (getEntry() instanceof TrackChanges<?>) {
			returnList.add((TrackChanges<?>) getEntry());
		}
		return returnList;
	}

	@Override
	public void notifyModification(E entry) {
		getContext().notifyModification(entry);
	}
}
