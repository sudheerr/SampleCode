package com.citi.risk.core.common.data.api;

import java.util.Collection;

public interface TrackChanges<E> {
	
	Collection<E> getAdditions();

	Collection<E> getRemovals();

	Collection<E> getModifications();

	void clearTrackings();

	void startTracking();

	void stopTracking();

	void notifyModification(E entry);

	Collection<TrackChanges<?>> getAllTrackChangesMembers();
}
