package com.citi.risk.core.common.data.timeseries.impl;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.citi.risk.core.common.data.timeseries.api.WithTime;

public class AbsoluteDateRange<E> extends AbstractDateRange<E> {
	
	private Date fromDate = new Date();
	private Date tillDate = new Date(WithTime.MAX_DATE_TIME);
	
	public AbsoluteDateRange(WithTime<E> withTime) {
		super(withTime);
	}
	
	@Override
	public Date getFromDate() {
		return this.fromDate;
	}

	@Override
	public Date getTillDate() {
		return this.tillDate;
	}
	
	protected void setTillDate(Date tillDate) {
		getContext().handlePreTillDateChange(getWithTime(), tillDate);
		this.tillDate = tillDate;
		getContext().handlePostTillDateChange(getWithTime(), tillDate);
	}

	protected void setFromDate(Date fromDate) {
		getContext().handlePreFromDateChange(getWithTime(), fromDate);
		this.fromDate = fromDate;
		getContext().handlePostFromDateChange(getWithTime(), fromDate);
	}

	@Override
	public WithTime<E> from(Date fromDate) {
		if(fromDate.getTime()>=getTillDate().getTime()) {
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		}

		Date priorDate=getFromDate();
		
		setFromDate(fromDate);
		try
		{
			getWithTime().validate();			
		}
		catch(Exception e)
		{
			setFromDate(priorDate);
			throw e;
		}
		return getWithTime();
	}
	
	@Override
	public WithTime<E> till(Date tillDate) {
		if(tillDate.getTime()<=getFromDate().getTime()) {
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		}
		Date priorDate=this.getTillDate();
		
		setTillDate(tillDate);
		try
		{
			getWithTime().validate();			
		}
		catch(Exception e)
		{
			setTillDate(priorDate);
			throw e;
		}
		return getWithTime();
	}
	
	@Override
	public WithTime<E> forDurationOf(TimeUnit timeUnit, Long duration) {
		Long duraitionInLong = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
		till(new Date(getFromDate().getTime() + duraitionInLong));
		return getWithTime();
	}


}
