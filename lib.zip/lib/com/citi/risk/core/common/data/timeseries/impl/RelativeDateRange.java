package com.citi.risk.core.common.data.timeseries.impl;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.citi.risk.core.common.data.timeseries.api.WithTime;

public class RelativeDateRange<E> extends AbstractDateRange<E> {
	
	private Long fromDistanceFromBaseDate = 0L;
	private Long tillDistanceFromBaseDate = WithTime.MAX_DATE_TIME;

	public RelativeDateRange(WithTime<E> withTime) {
		super(withTime);
	}

	public Date getBaseDate() {
		Date baseDate = getWithTime().getContext().getDateRangeBaseDate();
		if (baseDate == null)
			return getWithTime().getContext().getNow();
		return baseDate;
	}

	@Override
	public WithTime<E> from(Date from) {
		if (from.getTime() < getBaseDate().getTime())
			throw new RuntimeException("Invalid fromDate & baseDate combo");

		Long _fromDistanceFromBaseDate = from.getTime() - getBaseDate().getTime();

		if (tillDistanceFromBaseDate <= _fromDistanceFromBaseDate)
			throw new RuntimeException("Invalid fromDate & tillDate combo");

		Long priorFromDistanceFromBaseDate = this.fromDistanceFromBaseDate;
		getContext().handlePreFromDistanceFromBaseDateChange(getWithTime(), _fromDistanceFromBaseDate);
		this.fromDistanceFromBaseDate = _fromDistanceFromBaseDate;
		getContext().handlePostTillDistanceFromBaseDateChange(getWithTime(), _fromDistanceFromBaseDate);

		try {
			getWithTime().validate();
		} catch (Exception e) {
			getContext().handlePreFromDistanceFromBaseDateChange(getWithTime(), priorFromDistanceFromBaseDate);
			this.fromDistanceFromBaseDate = priorFromDistanceFromBaseDate;
			getContext().handlePostTillDistanceFromBaseDateChange(getWithTime(), priorFromDistanceFromBaseDate);

			throw e;
		}
		return getWithTime();
	}

	@Override
	public Date getFromDate() {
		return new Date(getBaseDate().getTime() + fromDistanceFromBaseDate);
	}

	@Override
	public Date getTillDate() {
		return new Date(getBaseDate().getTime() + tillDistanceFromBaseDate);
	}

	@Override
	public WithTime<E> till(Date till) {
		return forDurationOf(TimeUnit.MILLISECONDS, till.getTime() - getFromDate().getTime());
	}

	@Override
	public WithTime<E> forDurationOf(TimeUnit timeUnit, Long duration) {
		Long _tillDistanceFromBaseDate = this.fromDistanceFromBaseDate + TimeUnit.MILLISECONDS.convert(duration, timeUnit);

		if (_tillDistanceFromBaseDate <= fromDistanceFromBaseDate)
			throw new RuntimeException("Invalid fromDate & tillDate combo");
		Long priorTillDistanceFromBaseDate = this.tillDistanceFromBaseDate;

		getContext().handlePreTillDistanceFromBaseDateChange(getWithTime(), _tillDistanceFromBaseDate);
		this.tillDistanceFromBaseDate = _tillDistanceFromBaseDate;
		getContext().handlePostTillDistanceFromBaseDateChange(getWithTime(), _tillDistanceFromBaseDate);

		try {
			getWithTime().validate();
		} catch (Exception e) {
			getContext().handlePreTillDistanceFromBaseDateChange(getWithTime(), priorTillDistanceFromBaseDate);
			this.tillDistanceFromBaseDate = priorTillDistanceFromBaseDate;
			getContext().handlePostTillDistanceFromBaseDateChange(getWithTime(), priorTillDistanceFromBaseDate);

			throw e;
		}
		return getWithTime();
	}
}
