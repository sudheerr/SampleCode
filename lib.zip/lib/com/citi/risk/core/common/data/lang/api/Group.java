package com.citi.risk.core.common.data.lang.api;

import java.util.Collection;
import java.util.Map;

public interface Group<G, E> {

	G groupOf(E entry);

	Map<G, Collection<E>> group(Collection<E> entries);
	
}
