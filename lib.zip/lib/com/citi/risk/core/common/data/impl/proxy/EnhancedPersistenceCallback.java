package com.citi.risk.core.common.data.impl.proxy;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import com.citi.risk.core.common.data.api.EnhancedPersistenceProxy;

public class EnhancedPersistenceCallback<E> implements MethodInterceptor, EnhancedPersistenceProxy<E> {
	
	private static final String GET_METHOD_NAME = "get";
	private static final String IS_NEW_METHOD_NAME = "isNew";
	private static final String SET_TO_NEW_METHOD_NAME = "setToNew";
	private static final String IS_DELETED_METHOD_NAME = "isMarkedDeleted";
	private static final String SET_TO_DELETED_METHOD_NAME = "setToDeleted";
	private static final String IS_DIRTY_METHOD_NAME = "isDirty";
	private static final String UNSET_DIRTY_FLAG_METHOD_NAME = "unsetDirtyFlag";
	private static final String IS_EXISTING_METHOD_NAME = "isExisting";
	private static final String SET_TO_EXISTING_METHOD_NAME = "setToExisting";
	
	private E delegate;
	private Boolean _new = Boolean.FALSE;
	private Boolean deleted = Boolean.FALSE;
	private Boolean dirty = Boolean.FALSE;
	private Boolean existing = Boolean.FALSE;
	
	public EnhancedPersistenceCallback(E delegate, boolean isNew) {
		this.delegate = delegate;
		this._new = isNew;
	}

	@Override
	public final Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
		if (GET_METHOD_NAME.equals(method.getName())) {
			return obj;
		} else if (IS_NEW_METHOD_NAME.equals(method.getName())) {
			return isNew();
		} else if (SET_TO_NEW_METHOD_NAME.equals(method.getName())) {
			setToNew();
		} else if (IS_DELETED_METHOD_NAME.equals(method.getName())) {
			return isDeleted();
		} else if (SET_TO_DELETED_METHOD_NAME.equals(method.getName())) {
			setToDeleted();
		} else if (IS_DIRTY_METHOD_NAME.equals(method.getName())) {
			return isDirty();
		} else if (UNSET_DIRTY_FLAG_METHOD_NAME.equals(method.getName())) {
			unsetDirtyFlag();
		} else if (IS_EXISTING_METHOD_NAME.equals(method.getName())) {
			return existing;
		} else if (SET_TO_EXISTING_METHOD_NAME.equals(method.getName())) {
			setToExisting();
		}
		return null;
	}
	
	protected void setDirty() {
		if (!_new && !deleted) {
			dirty = true;
		}
	}

	@Override
	public E get() {
		return delegate;
	}

	@Override
	public Boolean isNew() {
		return _new;
	}

	@Override
	public void setToNew() {
		_new = Boolean.TRUE;
	}

	@Override
	public Boolean isDeleted() {
		return deleted;
	}

	@Override
	public void setToDeleted() {
		deleted = Boolean.TRUE;
	}

	@Override
	public Boolean isDirty() {
		return dirty;
	}

	@Override
	public void unsetDirtyFlag() {
		dirty = Boolean.FALSE;
	}

	@Override
	public Boolean isExisting() {
		return existing;
	}

	@Override
	public void setToExisting() {
		existing = Boolean.TRUE;
		_new = Boolean.FALSE;
	}

}
