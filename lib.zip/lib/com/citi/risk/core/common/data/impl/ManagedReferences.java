package com.citi.risk.core.common.data.impl;

public class ManagedReferences 
{
	
}
