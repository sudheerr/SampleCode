package com.citi.risk.core.common.data.timeseries.impl;

import java.util.Collection;
import java.util.Date;

import com.citi.risk.core.common.data.temporal.api.HasTemporal;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.WithTime;

public class HasTemporalContext<E extends HasTemporal> extends AbstractTimeSeriesContext<E> {
	
	@Override
	public void handlePostFromDateChange(WithTime<E> withTime, Date from) {
		super.handlePostTillDateChange(withTime, from);
		if (!(withTime.getEntry() instanceof HasTemporal)) {
			return;
		}
		HasTemporal hasTemporal = (HasTemporal) (withTime.getEntry());
		hasTemporal.getTemporal().validFrom(from);
	}

	@Override
	public void handlePreFromDateChange(WithTime<E> withTime, Date from) {
		//intentionally-blank override
	}

	@Override
	public void handlePostTillDateChange(WithTime<E> withTime, Date till) {
		super.handlePostTillDateChange(withTime, till);
		if (!(withTime.getEntry() instanceof HasTemporal)) {
			return;
		}
		HasTemporal hasTemporal = (HasTemporal) (withTime.getEntry());
		hasTemporal.getTemporal().validFrom(withTime.getFromDate());
		hasTemporal.getTemporal().validTill(till);
	}

	@Override
	public void handlePreTillDateChange(WithTime<E> withTime, Date till) {
		//intentionally-blank override
	}

	@Override
	public void handlePreAddition(TimeSeries<E> timeSeries, WithTime<E> withTime) {
		//intentionally-blank override
	}

	@Override
	public void handlePreAdditions(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes) {
		//intentionally-blank override
	}

	@Override
	public void handlePreRemoval(TimeSeries<E> timeSeries, WithTime<E> withTime) {
		//intentionally-blank override
	}

	@Override
	public void handlePreRemovals(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes) {
		//intentionally-blank override
	}
}
