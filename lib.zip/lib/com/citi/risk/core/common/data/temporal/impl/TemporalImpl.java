package com.citi.risk.core.common.data.temporal.impl;

import java.util.Date;

import com.citi.risk.core.common.data.temporal.api.Temporal;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;

public class TemporalImpl implements Temporal {
	
	private Date validFromDate = new Date();;
	private Date validTillDate = new Date(TimeSeries.MAX_DATE_TIME);

	public TemporalImpl() {
		//intentionally-blank override
	}

	public TemporalImpl(Date fromDate, Date tillDate) {
		validFromDate = fromDate;
		validTillDate = tillDate;
	}

	@Override
	public Date getValidFromDate() {
		return validFromDate;
	}

	@Override
	public Date getValidTillDate() {
		return validTillDate;
	}

	@Override
	public Temporal validTill(Date validTillDate) {
		this.validTillDate = validTillDate;
		return this;
	}

	@Override
	public Temporal validFrom(Date validFromDate) {
		this.validFromDate = validFromDate;
		return this;
	}

}
