package com.citi.risk.core.common.data.api;

public interface TrackChangesAware<E> 
{
	void add(TrackChanges<E> trackChanges);
}
