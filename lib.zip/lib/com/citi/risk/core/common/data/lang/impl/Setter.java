package com.citi.risk.core.common.data.lang.impl;

public interface Setter<S, T> {
	
	void set(S source, T target);
	
}