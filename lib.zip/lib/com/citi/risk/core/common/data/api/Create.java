package com.citi.risk.core.common.data.api;

import com.citi.risk.core.common.data.api.annotations.EnhancedPersistence;

public class Create {

	public static <E> E newInstance(Class<E> klass) {
		if (isEnhancedPersistence(klass)) {
			return EnhancedPersistenceProxies.proxyForExistingEntry(klass);
		}
		try {
			return klass.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}
	
	private static Boolean isEnhancedPersistence(Class<?> klass) {
		return klass.isAnnotationPresent(EnhancedPersistence.class);
	}

}
