package com.citi.risk.core.common.data.timeseries.api;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public interface DateRange<E> {
	
	WithTime<E> from(Date from);
	Date getFromDate();

	Date getTillDate();
	WithTime<E> till(Date till);
	
	Long getDuration(TimeUnit timeUnit);
	WithTime<E> forDurationOf(TimeUnit timeUnit, Long duration);
	
	WithTime<E> shiftOut(TimeUnit timeUnit, Long duration);
	WithTime<E> shiftBack(TimeUnit timeUnit, Long duration);
	
	WithTime<E> extendAnother(TimeUnit timeUnit, Long duration);
	WithTime<E> shrinkBy(TimeUnit timeUnit, Long duration);
	
}
