package com.citi.risk.core.common.data.timeseries.io.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;

import com.citi.risk.core.common.data.lang.impl.Setter;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesArray;
import com.google.common.base.Function;

public class DimensionTimeSeriesStitcher<S, T> {
	
	private Collection<T> targets;
	private Function<T, ?> targetMatchingFunction;
	private Function<S, ?> sourceMatchingFunction;

	public DimensionTimeSeriesStitcher(Collection<T> targets) {
		this.targets = targets;
	}

	public DimensionTimeSeriesStitcher<S, T> matchTargetWith(Function<T, ?> matchingFunction) {
		this.targetMatchingFunction = matchingFunction;
		return this;
	}

	public DimensionTimeSeriesStitcher<S, T> matchSourceWith(Function<S, ?> matchingFunction) {
		this.sourceMatchingFunction = matchingFunction;
		return this;
	}

	public void with(Setter<TimeSeries<S>, T> setter, Collection<TimeSeries<S>> sources) {
		Map<Object, TimeSeries<S>> sourcesByKey = new HashMap();
		for (TimeSeries<S> timeSeries : sources) {
			Object sourceTSKey = this.sourceMatchingFunction.apply(timeSeries.getEarliest());
			if (sourceTSKey != null) {
				sourcesByKey.put(sourceTSKey, timeSeries);
			}
		}
		if (this.targetMatchingFunction == null) {
			throw new IllegalArgumentException();
		}
		for (T target : targets) {
			Object targetKey = this.targetMatchingFunction.apply(target);
			setter.set(sourcesByKey.get(targetKey), target);
		}
	}
	
	public void withArray(Setter<TimeSeriesArray<S>, T> setter, Collection<TimeSeriesArray<S>> sources) {
		Map<Object, TimeSeriesArray<S>> sourcesByKey = new HashMap();
		for (TimeSeriesArray<S> timeSeriesArray : sources) {
			if (ArrayUtils.isEmpty(timeSeriesArray.getArray())) {
				continue;
			}
			Object sourceTSKey = this.sourceMatchingFunction.apply(timeSeriesArray.getArray()[0]);
			if (sourceTSKey != null) {
				sourcesByKey.put(sourceTSKey, timeSeriesArray);
			}
		}
		if (this.targetMatchingFunction == null) {
			throw new IllegalArgumentException();
		}
		for (T target : targets) {
			Object targetKey = this.targetMatchingFunction.apply(target);
			setter.set(sourcesByKey.get(targetKey), target);
		}
	}

}
