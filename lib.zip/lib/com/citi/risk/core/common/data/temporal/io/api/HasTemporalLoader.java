package com.citi.risk.core.common.data.temporal.io.api;

import com.citi.risk.core.common.data.temporal.api.HasTemporal;
import com.citi.risk.core.common.data.timeseries.api.IdentifiableTimeSeries;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface HasTemporalLoader<K, E extends HasTemporal & IdentifiedBy<K>> extends Loader<K, IdentifiableTimeSeries<K, E>> {

}
