package com.citi.risk.core.common.data.timeseries.impl;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.citi.risk.core.common.data.timeseries.api.DateRange;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.api.WithTime;

public abstract class AbstractDateRange<E> implements DateRange<E> {
	
	private WithTime<E> withTime;

	public AbstractDateRange() {
	}

	public AbstractDateRange(WithTime<E> withTIme) {
		this.withTime = withTIme;
	}

	public void setWithTime(WithTime<E> withTime) {
		this.withTime = withTime;
	}

	protected WithTime<E> getWithTime() {
		return this.withTime;
	}

	protected TimeSeriesContext<E> getContext() {
		return getWithTime().getContext();
	}

	protected Date getNow() {
		Date now = getWithTime().getContext().getNow();
		if (now == null)
			return new Date();
		return now;
	}

	@Override
	public Long getDuration(TimeUnit timeUnit) {
		Long duration = getTillDate().getTime() - getFromDate().getTime();
		return timeUnit.convert(duration, TimeUnit.MILLISECONDS);
	}

	@Override
	public WithTime<E> shiftOut(TimeUnit timeUnit, Long duration) {
		Long duraitionInLong = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
		till(new Date(getTillDate().getTime() + duraitionInLong));
		from(new Date(getFromDate().getTime() + duraitionInLong));
		return getWithTime();
	}

	@Override
	public WithTime<E> shiftBack(TimeUnit timeUnit, Long duration) {
		Long duraitionInLong = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
		from(new Date(getFromDate().getTime() - duraitionInLong));
		till(new Date(getTillDate().getTime() - duraitionInLong));
		return getWithTime();
	}

	@Override
	public WithTime<E> extendAnother(TimeUnit timeUnit, Long duration) {
		Long duraitionInLong = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
		till(new Date(getTillDate().getTime() + duraitionInLong));
		return getWithTime();
	}

	@Override
	public WithTime<E> shrinkBy(TimeUnit timeUnit, Long duration) {
		Long duraitionInLong = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
		till(new Date(getTillDate().getTime() - duraitionInLong));
		return getWithTime();
	}
}
