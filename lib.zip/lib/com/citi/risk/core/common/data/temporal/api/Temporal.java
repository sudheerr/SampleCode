package com.citi.risk.core.common.data.temporal.api;

import java.util.Date;

public interface Temporal {

	Date getValidFromDate();
	Date getValidTillDate();

	Temporal validTill(Date date);
	Temporal validFrom(Date validFromDate);

}
