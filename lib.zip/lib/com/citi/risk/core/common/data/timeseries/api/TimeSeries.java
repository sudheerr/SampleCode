package com.citi.risk.core.common.data.timeseries.api;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;

import java.util.List;

@DDD(name = "TimeSeries")
public interface TimeSeries<E> extends WithTime<E> {
	
	TimeSeries<E> concat(TimeSeries<E> anotherTimeSeries);

	List<E> getAll();

	Boolean isEmpty();

	TimeSeries<E> removeLatest();
	TimeSeries<E> removeEarliest();
	TimeSeries<E> removeAll();

	@DDI(name = "Size")
	int size();

	@DDI(name = "Entity Class Name")
	String getClassName();

	E get(int i);
	TimeSeries<E> subSeries(int from, int to);

	E getLatest();
	E getEarliest();

	List<WithTime<E>> getWithTimes();

}
