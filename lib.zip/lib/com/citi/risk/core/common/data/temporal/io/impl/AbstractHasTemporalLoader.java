package com.citi.risk.core.common.data.temporal.io.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.citi.risk.core.common.data.lang.impl.GroupByFunctions;
import com.citi.risk.core.common.data.temporal.api.HasTemporal;
import com.citi.risk.core.common.data.temporal.api.HasTemporalsToTimeSeries;
import com.citi.risk.core.common.data.temporal.io.api.HasTemporalLoader;
import com.citi.risk.core.common.data.timeseries.api.IdentifiableTimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesArray;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.impl.IdentifiableTimeSeriesImpl;
import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.base.Function;

public abstract class AbstractHasTemporalLoader<K, E extends HasTemporal & IdentifiedBy<K>> 
			extends AbstractLoader<K, IdentifiableTimeSeries<K, E>, IdentifiableTimeSeriesImpl<K, E>> 
			implements HasTemporalLoader<K, E> {
	

	@Override
	protected void resolveReferences(Collection<? extends IdentifiableTimeSeries<K, E>> items) {
		List<E> rawItems = new ArrayList();
		for(IdentifiableTimeSeries<K, E> item : items) {
			rawItems.addAll(item.getAll());
		}
		this.resolveRawReferences(rawItems);
	}
	
	protected abstract void resolveRawReferences(Collection<E> items);
	
	protected <E extends HasTemporal> Collection<TimeSeries<E>> 
			newSeriesByFunction(Collection<E> hasTemporals, Class<? extends TimeSeriesContext> contextClass, Function... functions) {
		Map<?, Collection<E>> hasTemporalsByGroup = (new GroupByFunctions(functions)).group(hasTemporals);

		List<TimeSeries<E>> returnList = new ArrayList();
		Comparator<HasTemporal> comparator = new HasTemporalsToTimeSeries.ByTemporalComparator();

		for (Entry<?, Collection<E>> entry : hasTemporalsByGroup.entrySet()) {
			if ((entry.getKey() == null) || (entry.getValue() == null)) {
				continue;
			}
			List<E> valueList = new ArrayList();
			valueList.addAll(entry.getValue());
			Collections.sort(valueList, comparator);
			try {
				returnList.add(HasTemporalsToTimeSeries.newTimeSeries(valueList, contextClass.newInstance()));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return returnList;
	}
	
	protected <E extends HasTemporal> Collection<TimeSeriesArray<E>> 
			newSeriesArrayByFunction(Collection<E> hasTemporals, Class<? extends TimeSeriesContext> contextClass, Function... functions) {
		Map<?, Collection<E>> hasTemporalsByGroup = (new GroupByFunctions(functions)).group(hasTemporals);
		
		List<TimeSeriesArray<E>> returnList = new ArrayList();
		Comparator<HasTemporal> comparator = new HasTemporalsToTimeSeries.ByTemporalComparator();
		
		for (Entry<?, Collection<E>> entry : hasTemporalsByGroup.entrySet()) {
			if ((entry.getKey() == null) || (entry.getValue() == null)) {
				continue;
			}
			List<E> valueList = new ArrayList();
			valueList.addAll(entry.getValue());
			Collections.sort(valueList, comparator);
			try {
				returnList.add(HasTemporalsToTimeSeries.newTimeSeriesArray(valueList, contextClass.newInstance()));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		
		return returnList;
	}

}
