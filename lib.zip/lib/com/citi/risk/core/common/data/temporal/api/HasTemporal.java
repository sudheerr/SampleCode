package com.citi.risk.core.common.data.temporal.api;

public interface HasTemporal {
	Temporal getTemporal();
}
