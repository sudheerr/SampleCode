package com.citi.risk.core.common.data.api;


public interface EnhancedPersistenceProxy<E> {
	
	E get();
	Boolean isNew();	
	void setToNew();
	
	Boolean isDeleted();
	void setToDeleted();
	
	Boolean isDirty();
	void unsetDirtyFlag();

	Boolean isExisting();
	void setToExisting();
	
}
