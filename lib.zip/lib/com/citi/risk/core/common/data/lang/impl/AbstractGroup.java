package com.citi.risk.core.common.data.lang.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.citi.risk.core.common.data.lang.api.Group;

public abstract class AbstractGroup<G, E> implements Group<G, E> {

	@Override
	public Map<G, Collection<E>> group(Collection<E> entries) {
		Map<G, Collection<E>> returnMap = new HashMap(entries.size());
		for (E entry : entries) {
			G group = groupOf(entry);
			Collection<E> values = returnMap.get(group);
			if (values != null) {
				values.add(entry);
				continue;
			}
			values = new ArrayList();
			values.add(entry);
			returnMap.put(group, values);
		}
		return returnMap;
	}
}
