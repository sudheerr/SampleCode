package com.citi.risk.core.common.data.impl.proxy;

import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import javax.persistence.Column;

import net.sf.cglib.proxy.CallbackFilter;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.common.data.api.EnhancedPersistenceProxy;

public class EnhancedPersistenceProxyCallbackFilter implements CallbackFilter {

	private BeanInfo beanInfo = null;
	
	public EnhancedPersistenceProxyCallbackFilter(BeanInfo beanInfo) {
		this.beanInfo = beanInfo;
	}

	@Override
	public int accept(Method method) {
		if (method.getDeclaringClass() == EnhancedPersistenceProxy.class) {
			return 0;
		} else if (isColumnMethod(method)) {
			return 1;
		} else {
			return 2;
		}
	}
	
	private boolean isColumnMethod(Method method) {
		for (PropertyDescriptor desc : this.beanInfo.getPropertyDescriptors()) {
			if (desc.getWriteMethod() != null
					&& desc.getReadMethod() != null
					&& StringUtils.equals(desc.getWriteMethod().getName(), method.getName()) 
					&& desc.getReadMethod().isAnnotationPresent(Column.class)) {
				return true;
			}
		}
		return false;
	}
	
}
