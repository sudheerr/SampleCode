package com.citi.risk.core.common.data.timeseries.impl;

import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.api.WithTime;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public abstract class AbstractTimeSeriesContext<E> implements TimeSeriesContext<E> {

	private Collection<E> removals = new ArrayList();
	private Collection<E> modifications = new ArrayList();;
	private Collection<E> additions = new ArrayList();
	private Select<E> additonFilter = new AlwayTrueSelect();
	private Object enclosingObject;
	private Boolean shouldTrack = false;
	private Date dateRangeBaseDate;
	private Date now;

	@Override
	public Date getNow() {
		if (now == null) {
			return new Date();
		}
		return now;
	}

	@Override
	public void setNow(Date now) {
		this.now = now;
	}

	@Override
	public Date getDateRangeBaseDate() {
		return this.dateRangeBaseDate;
	}

	@Override
	public void setDateRangeBaseDate(Date date) {
		this.dateRangeBaseDate = date;
	}

	@Override
	public Object getEnclosingObject() {
		return enclosingObject;
	}

	@Override
	public void setEnclosingObject(Object enclosingObject) {
		this.enclosingObject = enclosingObject;
	}

	@JsonIgnore
	@Override
	public TimeSeriesContext.Select<E> getAdditionFilter() {
		return additonFilter;
	}

	@Override
	public void setAdditionFilter(TimeSeriesContext.Select<E> filter) {
		this.additonFilter = filter;
	}

	@Override
	public void handlePostFromDateChange(WithTime<E> withTime, Date from) {
		if (shouldTrack == true) {
			modifications.add(withTime.getEntry());
		}
	}

	@Override
	public void handlePostTillDateChange(WithTime<E> withTime, Date till) {
		if (shouldTrack == true) {
			modifications.add(withTime.getEntry());
		}
	}

	@Override
	public void handlePostAddition(TimeSeries<E> timeSeries, WithTime<E> withTime) {
		if (shouldTrack == true) {
			additions.add(withTime.getEntry());
		}
	}

	@Override
	public void handlePostAdditions(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes) {
		if (shouldTrack == false) {
			return;
		}
		for (WithTime<E> withTime : withTimes) {
			additions.add(withTime.getNow());
		}
	}

	@Override
	public void handlePostRemoval(TimeSeries<E> timeSeries, WithTime<E> withTime) {
		if (shouldTrack == true) {
			removals.add(withTime.getEntry());
		}
	}

	@Override
	public void handlePostRemovals(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes) {
		if (shouldTrack == false) {
			return;
		}
		for (WithTime<E> withTime : withTimes) {
			removals.add(withTime.getNow());
		}
	}

	@Override
	public Collection<E> getAdditions() {
		List<E> returnList = new ArrayList(additions.size());
		returnList.addAll(additions);
		return returnList;
	}

	@Override
	public Collection<E> getRemovals() {
		List<E> returnList = new ArrayList(removals.size());
		returnList.addAll(removals);
		return returnList;
	}

	@Override
	public Collection<E> getModifications() {
		List<E> returnList = new ArrayList(modifications.size());
		returnList.addAll(modifications);
		return returnList;
	}

	@Override
	public void clearTrackings() {
		additions.clear();
		removals.clear();
		modifications.clear();
	}

	@Override
	public void startTracking() {
		this.shouldTrack = true;
	}

	@Override
	public void stopTracking() {
		this.shouldTrack = false;
	}

	@Override
	public void notifyModification(E entry) {
		if (shouldTrack == false)
			return;
		this.modifications.add(entry);
	}
	
	@Override
	public void handlePreFromDistanceFromBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate) {
	}

	@Override
	public void handlePostTillDistanceFromBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate) {
	}

	@Override
	public void handlePreTillDistanceFromBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate) {
	}

	@Override
	public void handlePostDistanceTillBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate) {
	}	

	public static class AlwayTrueSelect<E> implements Select<E> {
		@Override
		public boolean isSelected(E entry) {
			return true;
		}

		@Override
		public Collection<E> select(Collection<E> entries) {
			return entries;
		}
	}
}
