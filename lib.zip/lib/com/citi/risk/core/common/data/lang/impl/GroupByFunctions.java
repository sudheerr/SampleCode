package com.citi.risk.core.common.data.lang.impl;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Function;

public class GroupByFunctions<E> extends AbstractGroup<List, E> {
	
	private Function<E, ?>[] functions;

	public GroupByFunctions(Function<E, ?>... functions) {
		this.functions = functions;
	}

	@Override
	public List groupOf(E entry) {
		List returnList = new ArrayList(functions.length);
		for (int i = 0; i < functions.length; i++) {
			if (entry == null) {
				returnList.add(null);
			} else {
				returnList.add(functions[i].apply(entry));
			}
		}
		return returnList;
	}
}
