package com.citi.risk.core.common.data.temporal.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.common.data.lang.impl.GroupByFunctions;
import com.citi.risk.core.common.data.timeseries.api.IdentifiableTimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeries;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesArray;
import com.citi.risk.core.common.data.timeseries.api.TimeSeriesContext;
import com.citi.risk.core.common.data.timeseries.impl.HasTemporalContext;
import com.citi.risk.core.common.data.timeseries.impl.IdentifiableTimeSeriesImpl;
import com.citi.risk.core.common.data.timeseries.impl.TimeSeriesArrayImpl;
import com.citi.risk.core.common.data.timeseries.impl.TimeSeriesImpl;
import com.citi.risk.core.common.data.timeseries.impl.WithTimeImpl;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.base.Function;
import com.google.common.collect.Iterables;

public class HasTemporalsToTimeSeries {
	private static final Logger LOGGER=LoggerFactory.getLogger(HasTemporalsToTimeSeries.class);
	
	private HasTemporalsToTimeSeries() {
	}

	public static <K, E extends IdentifiedBy<K> & HasTemporal> Collection<IdentifiableTimeSeries<K, E>> 
				newIdentifiableSeriesByFunction(Collection<E> hasTemporals, TimeSeriesContext<E> context) {
		
		LOGGER.info("HasTemporals size : " + hasTemporals.size());
		Collection<E> hasTemorals = new ArrayList();
		
		Map<?, Collection<E>> hasTemporalsByGroup = (new GroupByFunctions(new ToKey())).group(hasTemorals);

		List<IdentifiableTimeSeries<K, E>> returnList = new ArrayList();
		
		Comparator<HasTemporal> comparator = new HasTemporalsToTimeSeries.ByTemporalComparator();

		for (Entry<?, Collection<E>> entry : hasTemporalsByGroup.entrySet()) {
			if ((entry.getKey() == null) || (entry.getValue() == null)) {
				continue;
			}
			List<E> valueList = new ArrayList();
			valueList.addAll(entry.getValue());
			Collections.sort(valueList, comparator);
			returnList.add(newIdentifiableTimeSeries(valueList, context));
		}
		return returnList;
	}

	private static class ToKey<K, E extends IdentifiedBy<K> & HasTemporal> implements Function<E, K> {
		@Override
		public K apply(E entry) {
			return entry.key();
		}
	}
	
	
	public static <E extends HasTemporal> Collection<TimeSeries<E>> 
			newSeriesByFunction(Collection<E> hasTemporals, TimeSeriesContext<E> context, Function... functions) {
		
		LOGGER.info("HasTemporals size : " + hasTemporals.size() + " | context : " + context.toString());
		
		Collection<E> hasTemorals = new ArrayList();
		Map<?, Collection<E>> hasTemporalsByGroup = (new GroupByFunctions(functions)).group(hasTemorals);

		List<TimeSeries<E>> returnList = new ArrayList();
		Comparator<HasTemporal> comparator = new HasTemporalsToTimeSeries.ByTemporalComparator();

		for (Entry<?, Collection<E>> entry : hasTemporalsByGroup.entrySet()) {
			if ((entry.getKey() == null) || (entry.getValue() == null)) {
				continue;
			}
			List<E> valueList = new ArrayList();
			valueList.addAll(entry.getValue());
			Collections.sort(valueList, comparator);
			returnList.add(newTimeSeries(valueList, new HasTemporalContext()));
		}
		return returnList;
	}

	public static <K, E extends IdentifiedBy<K> & HasTemporal> IdentifiableTimeSeries<K, E> 
			newIdentifiableTimeSeries(List<E> sortedTemporals, TimeSeriesContext<E> context) {
		IdentifiableTimeSeries<K, E> returnSeries = new IdentifiableTimeSeriesImpl(context);

		for (E hasTemporal : sortedTemporals) {
			returnSeries.concat(hasTemporal, hasTemporal.getTemporal().getValidFromDate(), hasTemporal.getTemporal().getValidTillDate());
		}
		return returnSeries;
	}

	public static <E extends HasTemporal> TimeSeries<E>	newTimeSeries(List<E> sortedTemporals, TimeSeriesContext<E> context) {
		if (CollectionUtils.isEmpty(sortedTemporals)) {
			return null;
		}
		context.stopTracking();
		TimeSeriesImpl<E> returnSeries = null;
		for (E hasTemporal : sortedTemporals) {
			if (returnSeries == null) {
				returnSeries = new IdentifiableTimeSeriesImpl(new WithTimeImpl<E>(hasTemporal, context).from(hasTemporal.getTemporal().getValidFromDate()).till(hasTemporal.getTemporal().getValidTillDate()), context);
			} else {
				returnSeries.concat(hasTemporal, hasTemporal.getTemporal().getValidFromDate(), hasTemporal.getTemporal().getValidTillDate());
			}
		}
		context.clearTrackings();
		return returnSeries;
	}
	
	public static <E extends HasTemporal> TimeSeriesArray<E> newTimeSeriesArray(List<E> sortedTemporals, TimeSeriesContext<E> context) {
		if (CollectionUtils.isEmpty(sortedTemporals)) {
			return null;
		}
		context.stopTracking();
		Class<? extends HasTemporal> entityClass = Iterables.getFirst(sortedTemporals, null).getClass();
		TimeSeriesArrayImpl<E> returnSeries = new TimeSeriesArrayImpl(context, (Class<E>) entityClass);
		for (int i = 0; i < sortedTemporals.size(); i++) {
			E hasTemporal = sortedTemporals.get(i);
			returnSeries.add(i, new IdentifiableTimeSeriesImpl(
									new WithTimeImpl<E>(hasTemporal, context)
										.from(hasTemporal.getTemporal().getValidFromDate())
										.till(hasTemporal.getTemporal().getValidTillDate()), context));
		}
		
		context.clearTrackings();
		return returnSeries;
	}

	public static class ByTemporalComparator<E extends HasTemporal> implements Comparator<E> {
		@Override
		public int compare(E o1, E o2) {
			return o1.getTemporal().getValidFromDate().compareTo(o2.getTemporal().getValidFromDate());
		}
	}
}
