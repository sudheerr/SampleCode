package com.citi.risk.core.common.data.timeseries.api;

import com.citi.risk.core.common.data.timeseries.impl.IdentifiableTimeSeriesImpl;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

import java.util.Date;

@DDD(subject = IdentifiableTimeSeries.class, name = "IdentifiableTimeSeries", reportOnly=false, domainImplClasses = { IdentifiableTimeSeriesImpl.class })
public interface IdentifiableTimeSeries<K, E extends IdentifiedBy<K>> extends TimeSeries<E>, IdentifiedBy<K> {

    @DDI(name = "Key", prominence = Prominence.High)
    String getKeyAsString();

    @DDI(name = "From Date")
    @Override
    Date getFromDate();

    @DDI(name = "Till Date")
    @Override
    Date getTillDate();

    @DDI(name = "TimeMark String",  prominence = Prominence.Low)
    @Override
    String getTimeMarkString();

    @DDI(name = "CreatedBy String", prominence = Prominence.Low)
    @Override
    String getCreatedByString();
}
