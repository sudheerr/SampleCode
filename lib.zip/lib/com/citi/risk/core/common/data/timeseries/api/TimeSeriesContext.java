package com.citi.risk.core.common.data.timeseries.api;

import java.util.Collection;
import java.util.Date;

public interface TimeSeriesContext<E> {
	
	Select<E> getAdditionFilter();
	void setAdditionFilter(Select<E> filter);
	
	Object getEnclosingObject();
	void setEnclosingObject(Object enclosingObject);
	
	void handlePreFromDateChange(WithTime<E> withTime, Date from);
	void handlePostFromDateChange(WithTime<E> withTime, Date from);

	void handlePreTillDateChange(WithTime<E> withTime, Date till);
	void handlePostTillDateChange(WithTime<E> withTime, Date till);

	void handlePostAddition(TimeSeries<E> timeSeries, WithTime<E> withTime);
	void handlePostAdditions(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes);

	void handlePostRemoval(TimeSeries<E> timeSeries, WithTime<E> withTime);
	void handlePostRemovals(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes);

	void handlePreAddition(TimeSeries<E> timeSeries, WithTime<E> withTime);
	void handlePreAdditions(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes);

	void handlePreRemoval(TimeSeries<E> timeSeries, WithTime<E> withTime);
	void handlePreRemovals(TimeSeries<E> timeSeries, Collection<WithTime<E>> withTimes);
	
	void handlePreFromDistanceFromBaseDateChange(WithTime<E>withTime, Long fromDistanceFromBaseDate);
	void handlePostTillDistanceFromBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate);
	
	void handlePreTillDistanceFromBaseDateChange(WithTime<E>withTime, Long fromDistanceFromBaseDate);
	void handlePostDistanceTillBaseDateChange(WithTime<E> withTime, Long fromDistanceFromBaseDate);
		
	Collection<E> getAdditions();
	Collection<E> getRemovals();
	Collection<E> getModifications();
	void clearTrackings();
	void startTracking();
	void stopTracking();
	
	void notifyModification(E entry);
	
	Date getDateRangeBaseDate();
	void setDateRangeBaseDate(Date date);

	Date getNow();
	void setNow(Date now);
	
	public interface Select<E> {
		boolean isSelected(E entry);
		Collection<E> select(Collection<E> entries);
	}
	
}
