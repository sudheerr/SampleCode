package com.citi.risk.core.data.file.fff.parser.api;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.Group;

public class PojoFieldSetMapper<T> extends BeanWrapperFieldSetMapper<T> {
	private String[] properties;
	private String[] formats;
	private Class<T> pojoClass;
	
	public PojoFieldSetMapper() {
		super();
	}
	
	public void initialize(final Class<T> pojoClass, final String[] properties, final String[] formats) throws Exception {
		if(ArrayUtils.isEmpty(properties) || (ArrayUtils.isEmpty(formats)) || (properties.length != formats.length))
			throw new RuntimeException("Null/Empty Properties/Formats. Or size of properties and formats arrays don't match");
		super.setTargetType(pojoClass);
		this.pojoClass = pojoClass;
		this.properties = properties;
		this.formats = formats;
	}
		
	@Override
	public void registerCustomEditors(PropertyEditorRegistry registry) {
		super.registerCustomEditors(registry);
		try {
			final BeanInfo pojoInfo = Introspector.getBeanInfo(pojoClass);
			final PropertyDescriptor[] pojoPropDescs = pojoInfo.getPropertyDescriptors();
			final Group<String, PropertyDescriptor> pojoPropDescGroupByName=new PojoPropDescGroupByName();
			final Map<String, PropertyDescriptor> pojoPropDescsByName = pojoPropDescGroupByName.groupUniqueIntoMap(Arrays.asList(pojoPropDescs));
			for(int i = 0; i < properties.length; ++i) {
				if(StringUtils.isBlank(properties[i]) || StringUtils.isBlank(formats[i])) continue;
				final String propName = StringUtils.trim(properties[i]);
				final String formatSpec = StringUtils.trim(formats[i]);
				if(!pojoPropDescsByName.containsKey(propName)) continue;
				if(Date.class.isAssignableFrom(pojoPropDescsByName.get(propName).getPropertyType())) {
					SimpleDateFormat dateformat = new SimpleDateFormat(formatSpec); 
					registry.registerCustomEditor(Date.class, propName, new CustomDateEditor(dateformat, true));
				}
			}
		} catch (IntrospectionException e) {
			throw new RuntimeException(e);
		}
	}
	
	private static class PojoPropDescGroupByName extends AbstractGroup<String, PropertyDescriptor> {
		@Override
		public String groupOf(final PropertyDescriptor value) {
			return value.getName();
		}
	}
}