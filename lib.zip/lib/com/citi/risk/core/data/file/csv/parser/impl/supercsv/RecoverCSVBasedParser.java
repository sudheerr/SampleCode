package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import com.citi.risk.core.data.store.impl.IQBeanUtilsFileStoreStrategy;


public class RecoverCSVBasedParser<E> extends SuperCSVBasedParser<E>
{

	char quoteChar = IQBeanUtilsFileStoreStrategy.getFieldDelimiterChar("0x12");
	@Override
	char getQuoteChar() {
		return quoteChar;
	}
}
