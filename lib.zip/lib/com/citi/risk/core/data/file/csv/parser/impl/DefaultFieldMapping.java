package com.citi.risk.core.data.file.csv.parser.impl;

import java.util.Collection;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.file.transform.Range;

import com.citi.risk.core.data.file.csv.parser.api.FieldMapping;
import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.citi.risk.core.data.file.csv.parser.impl.supercsv.FieldMappingItemGroups;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class DefaultFieldMapping implements FieldMapping
{
	private Of of;
	private Collection<FieldMappingItem> mappingItems=Lists.newArrayList();
	
	public DefaultFieldMapping(Of of)
	{
		this.of = of;
	}
	
	@Override
	public Of of() {
		return of;
	}

	@Override
	public FieldMappingItem map(int fldNumber) {
		FieldMappingItem newItem=new DefaultFieldMappingItem(this);
		mappingItems.add(newItem);
		return newItem.map(fldNumber);
	}
	
	@Override
	public FieldMappingItem map(String rangeSpec) {
		FieldMappingItem newItem=new DefaultFieldMappingItem(this);
		mappingItems.add(newItem);
		return newItem.map(rangeSpec);
	}
	
	@Override
	public FieldMappingItem map(int fldStartPos, int fldEndPos) {
		FieldMappingItem newItem=new DefaultFieldMappingItem(this);
		mappingItems.add(newItem);
		return newItem.map(fldStartPos, fldEndPos);
	}

	@Override
	public String toString() {
		return "DefaultFieldMapping Of["+of+"] on [Mapping Items=" + mappingItems + "]";
	}

	@Override
	public Collection<FieldMappingItem> allMappings() {
		return Lists.newArrayList(mappingItems);
	}
	
	@Override
	public Collection<FieldMappingItem> allMappingsFillingNulls(int fieldCount) {
		Map<Integer, FieldMappingItem> fieldMappingItemsByFieldNum = Maps.<Integer, FieldMappingItem>newTreeMap();
		for(int i=0;i<fieldCount;i++)
		{
			fieldMappingItemsByFieldNum.put(Integer.valueOf(i), mapToNull(i));
		}
		fieldMappingItemsByFieldNum.putAll(FieldMappingItemGroups.ByMappedFieldNum.groupUniqueIntoMap(allMappings()));
		return fieldMappingItemsByFieldNum.values();
	}

	private FieldMappingItem mapToNull(int fldNumber) 
	{
		return new DefaultFieldMappingItem(this, fldNumber, null, As.Null, null);
	}
	
	public static final class Ranges
	{
		private Ranges() {
		}
		
		public static final Range getRange(String rangeSpec)
		{
			if(StringUtils.isBlank(rangeSpec) || (StringUtils.countMatches(rangeSpec, "-") != 1))
				throw new IllegalArgumentException("RangeSpec: " +rangeSpec+ " cannot be Null/Empty. It Should have one and only one separator: '-'");
			final String[] range = rangeSpec.split("-");
			if (ArrayUtils.isEmpty(range) || (range.length != 2))
				throw new IllegalArgumentException("RangeSpec: " +rangeSpec+ " needs to one and only one left and right range values");
			if(StringUtils.isBlank(range[0]) || StringUtils.isBlank(range[1]))
				throw new IllegalArgumentException("RangeSpec: " +rangeSpec+ " needs non-null/non-empty left and right range values");
			if (!StringUtils.isNumeric(range[0]) || !StringUtils.isNumeric(range[1]))
				throw new IllegalArgumentException("RangeSpec: " +rangeSpec+ " needs need to be a numberic for left and right");
			return new Range(Integer.parseInt(StringUtils.trim(range[0])), Integer.parseInt(StringUtils.trim(range[1])));
		}
	}
	
	public static class DefaultFieldMappingItem implements FieldMappingItem
	{
		private FieldMapping enclosingFieldMapping;
		private int fldNumber;
		private Range fldRange;
		private String toPropertyName;
		private As as;
		private String format;
		private Object defaultValue;
		private Class<?> enumClass;
	
		private DefaultFieldMappingItem(FieldMapping enclosingMapping)
		{
			this.enclosingFieldMapping=enclosingMapping;
		}
		
		private DefaultFieldMappingItem(FieldMapping enclosingMapping, int fldNumber, String propertyName, As as, String format)
		{
			this(enclosingMapping);
			if(!Of.DelimitedFields.equals(of()))
				throw new IllegalArgumentException("Wrong contructor call for Mapping of "+of());
			this.fldNumber=fldNumber;
			this.toPropertyName=propertyName;
			this.as=as;
			this.format=format;
		}
		
		@Override
		public Of of() {
			return enclosingFieldMapping.of();
		}

		@Override
		public FieldMapping and() {
			return enclosingFieldMapping;
		}
		
		@Override
		public Collection<FieldMappingItem> allMappings() {
			return enclosingFieldMapping.allMappings();
		}
		
		@Override
		public FieldMappingItem map(int fldNumber) {
			if(Of.DelimitedFields.equals(of())) {
				this.fldNumber=fldNumber;
			}
			return this;
		}
	
		@Override
		public FieldMappingItem map(String rangeSpec) {
			if(Of.FixedWidthFields.equals(of())) {
				this.fldRange=Ranges.getRange(rangeSpec);
			}
			return this;
		}

		@Override
		public FieldMappingItem map(int fldStartPos, int fldEndPos) {
			if(Of.FixedWidthFields.equals(of())) {
				this.fldRange=new Range(fldStartPos, fldEndPos);
			}
			return this;
		}

		@Override
		public FieldMappingItem to(String propertyName) {
			this.toPropertyName=propertyName;
			return this;
		}
		
		@Override
		public FieldMappingItem asString() {
			this.as=As.String;
			return this;
		}
		

		@Override
		public FieldMappingItem asChar() {
			this.as=As.Char;
			return this;
		}		

		@Override
		public FieldMappingItem asBoolean() {
			this.as = As.Boolean;
			return this;
		}

		@Override
		public FieldMappingItem asBigDecimal() {
			this.as = As.BigDecimal;
			return this;
		}
	
		@Override
		public FieldMappingItem asDate() {
			this.as=As.Date;
			return this;
		}
		
		@Override
		public FieldMappingItem asDateTime() {
			this.as=As.DateTime;
			return this;
		}

		@Override
		public FieldMappingItem asDouble() {
			this.as=As.Double;
			return this;
		}
		
		@Override
		public FieldMappingItem asLong() {
			this.as=As.Long;
			return this;
		}
		
		@Override
		public FieldMappingItem asInteger() {
			this.as=As.Integer;
			return this;
		}

		@Override
		public FieldMappingItem asEnum() {
			this.as=As.Enum;
			return this;
		}
		
		@Override
		public FieldMappingItem asNull() {
			this.as=As.Null;
			return this;
		}
		
		@Override
		public FieldMappingItem asTimeMark() {
			this.as=As.TimeMark;
			return this;
		}
		
		@Override
		public FieldMappingItem asCreatedBy() {
			this.as=As.CreatedBy;
			return this;
		}

		@Override
		public FieldMappingItem as(As as)
		{
			this.as=as;
			return this;
		}
		@Override
		public FieldMappingItem format(String format) {
			this.format=format;
			return this;
		}
		@Override
		public FieldMappingItem type(Class<?> enumClass) {
			this.enumClass = enumClass;
			return this;
		}

		@Override
		public FieldMappingItem setDefaultValue(Object defaultValue) {
			this.defaultValue = defaultValue;
			return this;
		}

		@Override
		public As as() { 
			return as;
		}
		
		@Override
		public Integer fieldNumber() {
			return fldNumber;
		}
		
		@Override
		public Range fieldRange() {
			return fldRange;
		}

		@Override
		public String toPropertyName() {
			return toPropertyName;
		}

		@Override
		public String format() {
			return format;
		}

		@Override
		public Object defaultValue() {
			return defaultValue;
		}
		
		@Override
		public Class<?> type() {
			return enumClass;
		}

		@Override
		public String toString() {
			StringBuilder toStringBuf = new StringBuilder("DefaultFieldMappingItem - [");
			if(Of.FixedWidthFields.equals(of())) toStringBuf.append(", fldRange="+fldRange);
			else toStringBuf.append(", fldNumber="+fldNumber);
			toStringBuf.append(", toProperty="+toPropertyName);
			toStringBuf.append(", as="+as);
			toStringBuf.append(", format="+format+"]");
			return toStringBuf.toString();
		}

		@Override
		public Collection<FieldMappingItem> allMappingsFillingNulls(
				int fieldCount) {
			return enclosingFieldMapping.allMappingsFillingNulls(fieldCount);
		}

		@Override
		public boolean equals(Object other) {
			if(other == null)
				return false;
			if(this.getClass() != other.getClass())
				return false;
			DefaultFieldMappingItem toCheck = (DefaultFieldMappingItem)other;
			if(this == toCheck)
				return true;
			if(toPropertyName.equals(toCheck.toPropertyName))
				if(as != null)
					return as.equals(toCheck.as);
				else
					return toCheck.as == null;
			return false;
		}
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((as == null) ? 0 : as.hashCode());
			result = prime
					* result
					+ ((toPropertyName == null) ? 0 : toPropertyName.hashCode());
			return result;
		}
	}
	
	@Override
	public boolean equals(Object other) {
		if(other == null)
			return false;
		if(this.getClass() != other.getClass())
			return false;
		DefaultFieldMapping toCheck = (DefaultFieldMapping)other;
		if(this == toCheck)
			return true;
		return of.equals(toCheck.of) && mappingItems.equals(toCheck.mappingItems);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((of == null) ? 0 : of.hashCode());
		result = prime
				* result
				+ ((mappingItems == null) ? 0 : mappingItems.hashCode());
		return result;
	}
}
