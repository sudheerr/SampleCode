package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.Group;

public class FieldMappingItemGroups 
{
	private FieldMappingItemGroups() {
	}
	
	public static final Group<Integer, FieldMappingItem> ByMappedFieldNum = new ByMappedFieldNum();
	private static final class ByMappedFieldNum extends AbstractGroup<Integer, FieldMappingItem>
	{
		@Override
		public Integer groupOf(FieldMappingItem item) 
		{
			return (item == null) ? null : Integer.valueOf(item.fieldNumber());
		}
	}

}
