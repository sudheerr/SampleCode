package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.util.CsvContext;

public class UnkownTypeCellProcessor extends CellProcessorAdaptor {

	@Override
	public Object execute(Object value, CsvContext context) {

		return null;
	}

}
