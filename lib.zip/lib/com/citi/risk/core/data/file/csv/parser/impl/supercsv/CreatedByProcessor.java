package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.exception.SuperCsvCellProcessorException;
import org.supercsv.util.CsvContext;

import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;

public class CreatedByProcessor extends CellProcessorAdaptor {

	public CreatedByProcessor() {
		super();
	}

	public CreatedByProcessor(CellProcessor next) {
		super(next);
	}

	@Override
	public Object execute(Object value, CsvContext context) {
		validateInputNotNull(value, context);
		try{
			CreatedBy createdby = DefaultCreatedBy.newCreatedBy(value.toString());
			return next.execute(createdby, context);
		} catch (Exception e) {
			throw new SuperCsvCellProcessorException(
                    String.format("Could not parse '%s' as a CreatedBy", value), context, this, e);
		}
	}
}
