package com.citi.risk.core.data.file.parser.api;

import com.citi.risk.core.data.file.csv.parser.api.FieldMapping;
import com.google.common.base.Predicate;

public interface FlatFileParser<E> {
	public FlatFileParser<E> withColumnCount(int columnCount);
	public FlatFileParser<E> forBeanClass(Class<E> klass);
	public FlatFileParser<E> byFieldMapping(FieldMapping mapping);
	public FlatFileParser<E> predicatedBy(Predicate<E> filter);
	public FlatFileParser<E> skipHeader();
}
