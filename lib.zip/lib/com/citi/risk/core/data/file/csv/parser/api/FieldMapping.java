package com.citi.risk.core.data.file.csv.parser.api;

import java.util.Collection;

public interface FieldMapping 
{
	public Of of();
	public FieldMappingItem map(int fldNumber);
	public FieldMappingItem map(String rangeSpec);
	public FieldMappingItem map(int fldStartPos, int fldEndPos);
	public Collection<FieldMappingItem> allMappings();
	public Collection<FieldMappingItem> allMappingsFillingNulls(int fieldCount);
	public enum Of {DelimitedFields, FixedWidthFields};
	public enum As {Null, Boolean, BigDecimal, String, Char, Double, Float, Long, Integer, Date, DateTime, Enum, TimeMark, CreatedBy};
}
