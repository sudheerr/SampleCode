package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.CsvContext;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RepeatingDelimiterCsvBeanReader extends CommonCsvBeanReader {
    public RepeatingDelimiterCsvBeanReader(Reader reader, CsvPreference preferences) {
        super(reader, preferences);
    }

    @Override
    public void executeCellProcessors(final List<Object> destination, final List<?> source,
                                      final CellProcessor[] processors, final int lineNo, final int rowNo) {

        parametersValidation(destination, source, processors);

        // the context used when cell processors report exceptions
        final CsvContext context = new CsvContext(lineNo, rowNo, 1);
        context.setRowSource(new ArrayList<Object>(source));

        destination.clear();
        Iterator<?> iterator = source.iterator();
        for (int i = 0; i < processors.length; i++) {
            context.setColumnNumber(i + 1); // update context (columns start at
            // 1)
            //skip null values
            Object item = iterator.next();
            while (item == null && iterator.hasNext()) {
                item = iterator.next();
            }
            if (processors[i] == null) {
                destination.add(item); // no processing required
            } else {
                destination.add(processors[i].execute(item, context));
            }
        }
    }

	private void parametersValidation(final List<Object> destination, final List<?> source,
			final CellProcessor[] processors) {
		if (destination == null) {
            throw new NullPointerException("destination should not be null");
        } else if (source == null) {
            throw new NullPointerException("source should not be null");
        } else if (processors == null) {
            throw new NullPointerException("processors should not be null");
        }
	}
}
