package com.citi.risk.core.data.file.csv.parser.api;

import java.io.File;

import com.citi.risk.core.data.file.parser.api.FlatFileParser;

public interface DelimitedFieldParser<E> extends FlatFileParser<E> {
	public Iterable<E> parse(File file, char fieldDelimiter, String lineDelimiter);

    /**
     * parse files in a directory
     * @param file data file directory, if <tt>file.isDir() return false</tt>, then this method is equivalent to {@link #parse(File file, char fieldDelimiter, String lineDelimiter)}
     * @param fieldDelimiter
     * @param lineDelimiter
     * @param pattern regex to match data file name, if null, all files will be matched
     * @return loaded domain Iterable
     */
    Iterable<E> parse(File file, char fieldDelimiter, String lineDelimiter, String pattern);

    /**
     * parse files in a directory
     * @param file data file directory, if <tt>file.isDir() return false</tt>, then this method is equivalent to {@link #parse(File file, char fieldDelimiter, String lineDelimiter)}
     * @param fieldDelimiter
     * @param lineDelimiter
     * @param pattern regex to match data file name, if null, all files will be matched
     * @param isRecursive need recursiveley work through directory tree or not
     * @return loaded domain Iterable
     */
    Iterable<E> parse(File file, char fieldDelimiter, String lineDelimiter, String pattern,Boolean isRecursive);

    /**
     * enable capability of parsing file with repeating char as delimiter
     * @param isRepeatingDelimiter
     * @return
     */
    DelimitedFieldParser<E> withRepeatingDelimiter(Boolean isRepeatingDelimiter);
}
