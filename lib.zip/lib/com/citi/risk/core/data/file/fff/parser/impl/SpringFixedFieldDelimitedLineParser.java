package com.citi.risk.core.data.file.fff.parser.impl;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.separator.DefaultRecordSeparatorPolicy;
import org.springframework.batch.item.file.separator.RecordSeparatorPolicy;
import org.springframework.batch.item.file.separator.SuffixRecordSeparatorPolicy;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.citi.risk.core.data.file.csv.parser.api.FieldMapping;
import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.citi.risk.core.data.file.csv.parser.impl.supercsv.FieldMappingItemFunctions;
import com.citi.risk.core.data.file.fff.parser.api.FixedFieldParser;
import com.citi.risk.core.data.file.fff.parser.api.PojoFieldSetMapper;
import com.citi.risk.core.data.file.parser.api.FlatFileParser;
import com.google.common.base.Charsets;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.io.Files;

public class SpringFixedFieldDelimitedLineParser<E> implements FixedFieldParser<E> {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringFixedFieldDelimitedLineParser.class);
	
	private int columnCount;
	private Class<E> beanClass;
	private FieldMapping fieldMapping;
	private Predicate<E> discriminator;
	private boolean skipHeader;
	
	@Override
	public FlatFileParser<E> withColumnCount(int columnCount) {
		this.columnCount=columnCount;
		return this;
	}

	@Override
	public FlatFileParser<E> forBeanClass(Class<E> klass) {
		this.beanClass=klass;
		return this;
	}

	@Override
	public FlatFileParser<E> byFieldMapping(FieldMapping mapping) {
		this.fieldMapping=mapping;
		return this;
	}

	@Override
	public FlatFileParser<E> predicatedBy(Predicate<E> filter) {
		this.discriminator=filter;
		return this;
	}

	@Override
	public FlatFileParser<E> skipHeader() {
		this.skipHeader = true;
		return this;
	}

	@Override
	public Iterable<E> parse(final File file, final String lineDelimiter) {
		final Collection<E> toReturn = Lists.<E>newArrayList();
		FlatFileItemReader<E> itemReader = null;
		DefaultLineMapper<E> lineMapper = null;
		FixedLengthTokenizer lineTokenizer = null;
		PojoFieldSetMapper<E> pojoFieldSetMapper = null;
		Resource inputFileResource = null;
		ExecutionContext executionContext = null;
		RecordSeparatorPolicy recordSeparatorPolicy = null;

		final Collection<FieldMappingItem> allMappingItems = fieldMapping.allMappings();
		final Range[] ranges = Collections2.transform(allMappingItems, FieldMappingItemFunctions.ToMappedFieldRange).toArray(new Range[]{});
		final String[] formats = Collections2.transform(allMappingItems, FieldMappingItemFunctions.ToMappedFormat).toArray(new String[]{});
		final String[] properties = Collections2.transform(allMappingItems, FieldMappingItemFunctions.ToMappedProperty).toArray(new String[]{});

		Assert.isTrue(ranges.length == columnCount, "FieldMapping - Number of Ranges# "+ranges.length+" to equal Column Count# "+columnCount);
		Assert.isTrue(formats.length == columnCount, "FieldMapping - Number of Formats# "+formats.length+" to equal Column Count# "+columnCount);
		Assert.isTrue(properties.length == columnCount, "FieldMapping - Number of Properties# "+properties.length+" to equal Column Count# "+columnCount);
		
		try {
			executionContext = new ExecutionContext();
			
			pojoFieldSetMapper = new PojoFieldSetMapper();
     		pojoFieldSetMapper.initialize(beanClass, properties, formats);
			
			lineTokenizer = new FixedLengthTokenizer();
			lineTokenizer.setColumns(ranges);
			lineTokenizer.setNames(properties);
			
			lineMapper = new DefaultLineMapper();
			lineMapper.setLineTokenizer(lineTokenizer);
			lineMapper.setFieldSetMapper(pojoFieldSetMapper);

			inputFileResource = new FileSystemResource(file);
			
			if (lineDelimiter == null) {
				recordSeparatorPolicy = new DefaultRecordSeparatorPolicy();
			}
			else
			{
				recordSeparatorPolicy = new SuffixRecordSeparatorPolicy();
				((SuffixRecordSeparatorPolicy) recordSeparatorPolicy).setSuffix(lineDelimiter);
			}
			
			itemReader = new FlatFileItemReader();
			itemReader.setStrict(true);
			itemReader.setResource(inputFileResource);
			itemReader.setRecordSeparatorPolicy(recordSeparatorPolicy);
			itemReader.setLineMapper(lineMapper);
			
			itemReader.open(executionContext);
			
			addRecord(file, toReturn, itemReader);
		} catch (Exception t) {
			throw new RuntimeException("Exception Reading/Parsing File: "+file.getAbsolutePath()+ " with LineDelimiter: "+lineDelimiter + "skipHeader: " + skipHeader, t);
		} finally {
			if(itemReader != null) {
				try {
					itemReader.close();
				} catch(Exception t) {
					LOGGER.debug(t.getMessage(), t);
				}
			}
		}
		return toReturn;
	}

	private void addRecord(final File file, final Collection<E> toReturn, FlatFileItemReader<E> itemReader)
			throws Exception {
		final File errorRowFile = new File(file.getParentFile(), file.getName().concat(".row"));
		final File errorMsgFile = new File(file.getParentFile(), file.getName().concat(".msg"));
		E record = null;
		do {
			try {
				record = itemReader.read();
				if ((record != null) && ((discriminator == null) || (discriminator.apply(record)))) {
					toReturn.add(record);
				}
			} catch (FlatFileParseException ffpe) {
				final String errorRow = ffpe.getInput();
				final String errorMsg = "Line# "+ffpe.getLineNumber()+", Error# "+ffpe.getMessage();
				Files.write(errorRow, errorRowFile, Charsets.UTF_8);
				Files.write(errorMsg, errorMsgFile, Charsets.UTF_8);
				LOGGER.debug(ffpe.getMessage(), ffpe);
			}
		} while (record != null);
	}
}
