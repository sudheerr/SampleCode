package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.supercsv.cellprocessor.ConvertNullTo;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseBigDecimal;
import org.supercsv.cellprocessor.ParseBool;
import org.supercsv.cellprocessor.ParseChar;
import org.supercsv.cellprocessor.ParseDate;
import org.supercsv.cellprocessor.ParseDouble;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.Token;
import org.supercsv.cellprocessor.Trim;
import org.supercsv.cellprocessor.ift.CellProcessor;

import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.google.common.base.Function;
import com.google.inject.Inject;
import com.google.inject.Singleton;
@Singleton
public class ToMappedProcessor  implements Function<FieldMappingItem, CellProcessor>
{
	@Override
	public CellProcessor apply(FieldMappingItem item) 
	{
		if(item == null) return null;
		CellProcessor processor = getCellProcessor(item);
		return (processor == null) ? null : new ConvertNullTo(item.defaultValue(), processor); 
	}
	
	@Inject
	private InternCellProcessor internCellProcessor;
	@Inject
	private UnkownTypeCellProcessor unkownTypeCellProcessor;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private CellProcessor getCellProcessor(FieldMappingItem item) {
		
		if (item.as() == null) {
			return new Optional(unkownTypeCellProcessor);
		}
		
		switch(item.as())
		{
			case String:
				return new Optional(internCellProcessor);
			case Char:
				return new Optional(new ParseChar(internCellProcessor));
			case Boolean:
				return new Optional(new ParseBool());
			case BigDecimal:
				return new Optional(new Trim(new Token("",null,new Token("nan",null,new Token("N/A",null,new Token("null", null, new ParseBigDecimal(internCellProcessor)))))));
			case Integer:
				return new Optional(new Trim(new Token("",null,new Token("nan",null,new Token("N/A",null,new Token("null", null, new ParseInt(internCellProcessor)))))));
			case Double:
				return new Optional(new Trim(new Token("",null,new Token("nan",null,new Token("N/A",null,new Token("null", null, new ParseDouble(internCellProcessor)))))));
			case Long:
				return new Optional(new Trim(new Token("",null,new ParseLong(internCellProcessor))));
			case Date:
				return new Optional(new ParseDate(item.format(), internCellProcessor));
			case DateTime:
				return new Optional(new ParseDate(item.format(), internCellProcessor));
			case Enum:
				return new Optional(new EnumProcessor(item.type()));
			case TimeMark:
				return new Optional(new TimeMarkProcessor(internCellProcessor));
			case CreatedBy:
				return new Optional(new CreatedByProcessor(internCellProcessor));
			case Null:
			default:
				return null;
		}
	}
}