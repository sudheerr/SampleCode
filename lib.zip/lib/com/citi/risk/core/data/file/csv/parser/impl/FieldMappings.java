package com.citi.risk.core.data.file.csv.parser.impl;

import com.citi.risk.core.data.file.csv.parser.api.FieldMapping;
import com.citi.risk.core.data.file.csv.parser.api.FieldMapping.Of;

public class FieldMappings 
{
	private FieldMappings() {
	}
	
	public static FieldMapping of(Of of)
	{
		return new DefaultFieldMapping(of);
	}
}
