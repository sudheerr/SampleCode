package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import java.util.HashMap;
import java.util.Map;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.exception.SuperCsvCellProcessorException;
import org.supercsv.util.CsvContext;

import com.citi.risk.core.lang.businessobject.EnumByIdLookup;
import com.citi.risk.core.lang.businessobject.EnumByNameLookup;

public class EnumProcessor<T extends Enum<T>> extends CellProcessorAdaptor {
	private Class<T> enumClass;
	private static final ThreadLocal<Map<String, Integer>> ints = new ThreadLocal<Map<String, Integer>>(){
		@Override protected Map<String, Integer> initialValue(){
			return new HashMap();
		}
	};

	public EnumProcessor(Class<T> enumType) {
		super();
		this.enumClass = enumType;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object execute(Object value, CsvContext context) {
		validateInputNotNull(value, context);
		String valStr = value.toString();
		if (EnumByNameLookup.class.isAssignableFrom(enumClass)) {
			for (Enum<T> type : enumClass.getEnumConstants()) {
				if (((EnumByNameLookup<T>) type).lookup(valStr) != null)
					return next.execute(type, context);
			}
		} else {
			for (Enum<T> type : enumClass.getEnumConstants()) {
				if (type.name().equals(value.toString()))
					return next.execute(type, context);
			}
		}
		if (EnumByIdLookup.class.isAssignableFrom(enumClass)) {
			Integer valInt = null;
			if(ints.get().containsKey(valStr)){
				valInt = ints.get().get(valStr);
			}
			else{
				try {
					valInt = Integer.parseInt(valStr);
				} catch (NumberFormatException e) { }
				ints.get().put(valStr, valInt);
			}
			
			for (Enum<T> type : enumClass.getEnumConstants()) {
				if (((EnumByIdLookup<T>) type).lookup(Integer.valueOf(valInt)) != null)
					return next.execute(type, context);
			}
		}
		
		throw new SuperCsvCellProcessorException(String.format(
				"Could not parse '%s' as %s", value, enumClass.getClass()
						.getName()), context, this);
	}
}
