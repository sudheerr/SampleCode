package com.citi.risk.core.data.file.fff.parser.api;

import java.io.File;

import com.citi.risk.core.data.file.parser.api.FlatFileParser;

public interface FixedFieldParser<E> extends FlatFileParser<E> {
	public Iterable<E> parse(File file, String lineDelimiter);
}
