package com.citi.risk.core.data.file.csv.parser.api;

import org.springframework.batch.item.file.transform.Range;

public interface FieldMappingItem extends FieldMapping
{
	@Override
	FieldMappingItem map(int fldNumber);
	@Override
	FieldMappingItem map(String rangeSpec);
	@Override
	FieldMappingItem map(int fldStartPos, int fldEndPos);
	FieldMappingItem to(String propertyName);
	FieldMappingItem asString();
	FieldMappingItem asChar();
	FieldMappingItem asBoolean();
	FieldMappingItem asBigDecimal();
	FieldMappingItem asInteger();
	FieldMappingItem asDouble();
	FieldMappingItem asLong();
	FieldMappingItem asDate();
	FieldMappingItem asDateTime();
	FieldMappingItem asEnum();
	FieldMappingItem asNull();
	FieldMappingItem asTimeMark();
	FieldMappingItem asCreatedBy();
	FieldMappingItem as(As as);
	FieldMappingItem format(String format);
	FieldMappingItem type(Class<?> enumClass);
	FieldMappingItem setDefaultValue(Object defaultValue);
	FieldMapping and();

	Integer fieldNumber();
	Range fieldRange();
	String toPropertyName();
	Object defaultValue();
	As as();
	String format();
	Class<?> type();
}
