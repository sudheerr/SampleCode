package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.util.zip.GZIPInputStream;
import java.net.URL;
import java.util.Collection;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang3.ObjectUtils;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.file.csv.parser.api.DelimitedFieldParser;
import com.citi.risk.core.data.file.csv.parser.api.FieldMapping;
import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.citi.risk.core.data.file.parser.api.FlatFileParser;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.common.base.Charsets;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.google.inject.Inject;

public class SuperCSVBasedParser<E> implements DelimitedFieldParser<E>
{
	@Inject
	protected Logger logger;

	private int columnCount;
	private Class<E> beanClass;
	private FieldMapping fieldMapping;
	private Predicate<E> discriminator;
	private boolean skipHeader = false;//default
	private boolean isRepeatingDelimiter=false;
	private final static String MATCH_ALL=".*";

	@Override
	public FlatFileParser<E> withColumnCount(int columnCount) {
		this.columnCount=columnCount;
		return this;
	}

	@Override
	public FlatFileParser<E> forBeanClass(Class<E> klass) {
		this.beanClass=klass;
		return this;
	}

	@Override
	public FlatFileParser<E> byFieldMapping(FieldMapping mapping) {
		this.fieldMapping=mapping;
		return this;
	}

	@Override
	public FlatFileParser<E> predicatedBy(Predicate<E> filter) {
		this.discriminator=filter;
		return this;
	}

	@Override
	public FlatFileParser<E> skipHeader() {
		this.skipHeader = true;
		return this;
	}

	@Override
	public DelimitedFieldParser<E> withRepeatingDelimiter(Boolean isRepeatingDelimiter) {
		this.isRepeatingDelimiter=isRepeatingDelimiter;
		return this;
	}

	@Inject
	private ToMappedProcessor toMappedProcessor;

	@Override
	public Iterable<E> parse(File file, char fieldDelimiter, String lineDelimiter, String pattern, Boolean isRecursive) {
		Iterable<E> iterable=Lists.newArrayList();
		if(file.isFile()) return parse(file, fieldDelimiter, lineDelimiter);
		RegexFileFilter filter = pattern == null ? new RegexFileFilter(MATCH_ALL) : new RegexFileFilter(pattern);
		Collection<File> files = FileUtils.listFiles(file,filter, isRecursive? TrueFileFilter.INSTANCE:null);
		for (File oneFile : files) {
			iterable = Iterables.concat(parse(oneFile, fieldDelimiter, lineDelimiter), iterable);
		}
		return iterable;
	}

	@Override
	public Iterable<E> parse(File file, char fieldDelimiter, String lineDelimiter, String pattern) {
		return parse(file,fieldDelimiter,lineDelimiter,pattern,false);
	}


	@Override
	public Iterable<E>  parse(File file, char fieldDelimiter, String lineDelimiter) {
		final Collection<E> toReturn = Lists.<E>newArrayList();
		ICsvBeanReader csvBeanReader = null;

		final CsvPreference csvPreferences = new CsvPreference.Builder(getQuoteChar(), fieldDelimiter, lineDelimiter).build();
		final Collection<FieldMappingItem> allMappingItems = fieldMapping.allMappingsFillingNulls(columnCount);
		final String[] properties = Collections2.transform(allMappingItems, FieldMappingItemFunctions.ToMappedProperty).toArray(new String[]{});
		final CellProcessor[] processors = Collections2.transform(allMappingItems, toMappedProcessor).toArray(new CellProcessor[]{});

		try {
			E record = (E) ObjectUtils.NULL;
			BufferedReader fileReader = getFileReader(file);			
			csvBeanReader = getCSVBeanReader(csvPreferences, fileReader);
			
			final File errorRowFile = new File(file.getParentFile(), file.getName().concat(".row"));
			final File errorMsgFile = new File(file.getParentFile(), file.getName().concat(".msg"));
			if (skipHeader){
				csvBeanReader.getHeader(true);
			}
			Integer errorRowsTolerance = getErrorRowsTolerance();
			int errorRowCount = 0;
			do {
				try {
					record = readRecord(csvBeanReader, properties, processors);
					if (record != null && (discriminator == null || discriminator.apply(record))) {
						toReturn.add(record);
					}
				} catch(IOException ioe) {
					throw ioe;
				} catch (Exception t) {
					if(++errorRowCount >= errorRowsTolerance) {
						break;
					}
					final String errorRow = csvBeanReader.getUntokenizedRow()+"\n";
					final String errorMsg = "Row# "+csvBeanReader.getRowNumber()+", Line# "+csvBeanReader.getLineNumber()+", Error# "+t.getMessage()+"\n";
					Files.append(errorRow, errorRowFile, Charsets.UTF_8);
					Files.append(errorMsg, errorMsgFile, Charsets.UTF_8);
					logger.log(Level.INFO, t.getMessage(), t);
				}
			} while (record != null);
		} catch (Exception t) {
			throw new RuntimeException("Exception Reading/Parsing File: "+file.getAbsolutePath()+ " with FieldDelimiter: "+fieldDelimiter+" and LineDelimiter: "+lineDelimiter, t);
		} finally {
			if(csvBeanReader != null) {
				try {
					csvBeanReader.close();
				} catch(Exception t) {
					logger.log(Level.INFO, "Exception Closing File: "+file.getAbsolutePath()+ " with FieldDelimiter: "+fieldDelimiter+" and LineDelimiter: "+lineDelimiter, t);
				}
			}
		}
		return toReturn;
	}

	private E readRecord(ICsvBeanReader csvBeanReader, String[] properties, CellProcessor[] processors) throws IOException {
		return csvBeanReader.read(beanClass, properties, processors);
	}

	private ICsvBeanReader getCSVBeanReader(CsvPreference csvPreferences, BufferedReader fileReader) {
		if (this.isRepeatingDelimiter) {
			return new RepeatingDelimiterCsvBeanReader(fileReader, csvPreferences);
		} else {
			return  new CommonCsvBeanReader(fileReader, csvPreferences);
		}
	}

	private BufferedReader getFileReader(File file) throws IOException {
		BufferedReader fileReader = null;
		if (file.getName().toLowerCase().endsWith(".gz")) {
			fileReader = new BufferedReader(new InputStreamReader(new GZIPInputStream(tansfer(file).openStream())));
		} else {
			fileReader = new BufferedReader(new InputStreamReader(tansfer(file).openStream()));	
		}
		return fileReader;
	}

	private URL tansfer(File file) {
		String p = file.getPath();
		if (File.separatorChar != '/') {
			p = p.replace(File.separatorChar, '/');
		}
		try {
			if (p.contains(".jar!")) {
				return newJarURL(p);
			} else {
				return newFileURL(p);
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException("Exception Receive URL from: " + file.getAbsolutePath());
		}
	}

	private URL newFileURL(String p) throws MalformedURLException {
		if (p.startsWith("file")) {
			return new URL(p);
		} else {
			return new URL("file", null, p);
		}
	}

	private URL newJarURL(String p) throws MalformedURLException {
		if (p.startsWith("file")) {
			return new URL("jar", null, p);
		} else {
			return new URL("jar:file", null, p);
		}
	}

	char getQuoteChar() {
		Configuration configuration = CoreModule.getConfiguration();
		Properties props = configuration.getPrefixProperties("Storer");
		String propertyValue = props.getProperty("QuoteChar", "\"").trim();
		char quoteChar;
		try {
			quoteChar = (char)(Short.decode(propertyValue).shortValue());
		} catch (NumberFormatException nfe) {
			quoteChar = propertyValue.charAt(0);
		}

		return quoteChar;
	}
	
	Integer getErrorRowsTolerance() {
		Configuration configuration = CoreModule.getConfiguration();
		Integer errorTolerance = configuration.getInteger("Storer.csvparser.error.tolerance", 1000);
		return errorTolerance;
	}
}
