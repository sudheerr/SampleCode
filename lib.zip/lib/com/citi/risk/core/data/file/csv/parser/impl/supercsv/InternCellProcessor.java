package com.citi.risk.core.data.file.csv.parser.impl.supercsv;


import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.cellprocessor.ift.BoolCellProcessor;
import org.supercsv.cellprocessor.ift.DateCellProcessor;
import org.supercsv.cellprocessor.ift.DoubleCellProcessor;
import org.supercsv.cellprocessor.ift.LongCellProcessor;
import org.supercsv.cellprocessor.ift.StringCellProcessor;
import org.supercsv.util.CsvContext;

import com.citi.risk.core.data.intern.api.InternProvider;
import com.citi.risk.core.data.store.impl.IQBeanUtilsFileStoreStrategy;
import com.google.inject.Inject;

public class InternCellProcessor extends CellProcessorAdaptor implements DateCellProcessor, BoolCellProcessor, DoubleCellProcessor, LongCellProcessor, StringCellProcessor{

	@Inject
	private InternProvider internees;
	String delimiterCharString1 = String.valueOf(IQBeanUtilsFileStoreStrategy.delimiterChar1);
	String delimiterCharString2 = String.valueOf(IQBeanUtilsFileStoreStrategy.delimiterChar2);
	@Override
	public Object execute(Object value, CsvContext context) {
		Object result = internees.get(value);

		if (result instanceof String) {
			String resultValue = (String) result;
			
			if (resultValue.indexOf(delimiterCharString1) != -1) {
				result = resultValue.replaceAll(delimiterCharString1, "\r");
			}
			if (resultValue.indexOf(delimiterCharString2) != -1) {
				result = resultValue.replaceAll(delimiterCharString2, "\n");
			}
		}
		return next.execute(result, context);
	}

}
