package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.exception.SuperCsvCellProcessorException;
import org.supercsv.util.CsvContext;

import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;

public class TimeMarkProcessor extends CellProcessorAdaptor {

	public TimeMarkProcessor() {
		super();
	}

	public TimeMarkProcessor(CellProcessor next) {
		super(next);
	}

	@Override
	public Object execute(Object value, CsvContext context) {
		validateInputNotNull(value, context);
		try{
			TimeMark timemark = DefaultTimeMark.getTimeMarkfromKey(value.toString());
			return next.execute(timemark, context);
		} catch (Exception e) {
			throw new SuperCsvCellProcessorException(
                    String.format("Could not parse '%s' as a TimeMark", value), context, this, e);
		}
	}
}
