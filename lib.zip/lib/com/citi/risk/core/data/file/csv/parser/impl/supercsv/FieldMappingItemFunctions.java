package com.citi.risk.core.data.file.csv.parser.impl.supercsv;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.file.transform.Range;

import com.citi.risk.core.data.file.csv.parser.api.FieldMappingItem;
import com.google.common.base.Function;

public class FieldMappingItemFunctions 
{
	private FieldMappingItemFunctions() {
	}
	
	public static final Function<FieldMappingItem, Integer> ToMappedFieldNum = new ToMappedFieldNum();
	private static final class ToMappedFieldNum implements Function<FieldMappingItem, Integer>
	{
		@Override
		public Integer apply(FieldMappingItem item) 
		{
			return (item == null) ? null : Integer.valueOf(item.fieldNumber());
		}
	}
	
	public static final Function<FieldMappingItem, Range> ToMappedFieldRange = new ToMappedFieldRange();
	private static final class ToMappedFieldRange implements Function<FieldMappingItem, Range>
	{
		@Override
		public Range apply(FieldMappingItem item) 
		{
			return (item == null) ? null : item.fieldRange();
		}
	}
	
	public static final Function<FieldMappingItem, String> ToMappedProperty = new ToMappedProperty();
	private static final class ToMappedProperty implements Function<FieldMappingItem, String>
	{
		@Override
		public String apply(FieldMappingItem item) 
		{
			return (item == null) ? null : StringUtils.trim(item.toPropertyName());
		}
	}

	public static final Function<FieldMappingItem, String> ToMappedFormat = new ToMappedFormat();
	private static final class ToMappedFormat implements Function<FieldMappingItem, String>
	{
		@Override
		public String apply(FieldMappingItem item) 
		{
			return (item == null) ? null : StringUtils.trim(item.format());
		}
	}

}
