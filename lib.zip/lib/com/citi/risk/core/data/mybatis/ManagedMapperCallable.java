package com.citi.risk.core.data.mybatis;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.concurrent.Callable;

import org.apache.ibatis.annotations.Select;

import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;

public class ManagedMapperCallable<T> implements ManagedExecution, Callable<Object> {

    private Method method;
    private Object[] args;
    private T value;
    private Class<T> mapperType;
    private String executionName = null;
    private String parameters = null;

    public void appendDataSourceInfo(String param){
    	StringBuilder sb = new StringBuilder();
    	sb.append(parameters).append(System.getProperty("line.separator")).append("DataSource:").append(param);
    	this.parameters = sb.toString();
    }
    
	public void setMapperType(Class<T> mapperType) {
        this.mapperType = mapperType;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public void setArgs(Object[] args) {
        this.args = args;
    }

    public void setMethod(Method method) {
        this.method = method;
        generateNames(method);
    }
    
    private void generateNames(Method method) {
    	if(method == null) {
    		executionName = null;
    		parameters = null;
    		return;
    	}
    	StringBuilder sql = new StringBuilder();
    	executionName = method.getDeclaringClass().getSimpleName() + "." + method.getName();
    	Select select = method.getAnnotation(org.apache.ibatis.annotations.Select.class);
    	if(select!=null){
    		for(int i =0;i<select.value().length;i++){
    			if( i != 0){
    				sql.append(", ");
    			}
    			sql.append(method.getAnnotation(org.apache.ibatis.annotations.Select.class).value()[i]);
    		}
    	}
    	
    	Class<?>[] methodParams = method.getParameterTypes();	
    	StringBuilder sb = new StringBuilder();
		for (int i = 0; i < methodParams.length; i++) {
			if( i != 0){
				sb.append(", ");
			}
			sb.append("Param-").append(i).append(":").append(methodParams[i].getSimpleName());
		}
		if(methodParams.length > 0){
			sb.append(System.getProperty("line.separator"));
		}
		sb.append("SQL:").append(sql);
		parameters = sb.toString();
    }

    @Override
    public String getExecutionName() {
    	return executionName;
    }
    
    @Override
    public Object call() throws Exception {
        if (method == null) {
            throw new NullPointerException("Mapper 'method' is null for executionName: " +
                    executionName + ", mapperType: " + mapperType + " and value: " + value);
        }

        try {
            return method.invoke(value, args);
        }
        catch (InvocationTargetException e) {
            Throwable cause = e.getCause();

            if (cause == null) {
                cause = e;
            }

            throw new RuntimeException("Failed to invoke method: '" + method + "' with args: " +
                    Arrays.toString(args) + " for executionName: " + executionName +
                    ", mapperType: " + mapperType + " and value: " + value, cause);
        }
    }

    @Override
    public TaskType getType() {
        return TaskType.Mapper;
    }

    @Override
    public String getExecutionParameters() {
        return parameters;
    }

    @Override
    public boolean isNewThread() {
        return false;
    }
}
