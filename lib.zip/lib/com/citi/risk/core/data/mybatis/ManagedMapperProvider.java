package com.citi.risk.core.data.mybatis;

import com.citi.risk.core.execution.api.ManagedExecutorService;
import org.apache.ibatis.session.SqlSessionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.sql.DataSource;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.concurrent.Future;

public final class ManagedMapperProvider<T> implements Provider<T>, InvocationHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ManagedMapperProvider.class);

    private final Class<T> mapperType;

    private SqlSessionManager sqlSessionManager;
    private ManagedExecutorService managedExecutorService;

    public ManagedMapperProvider(Class<T> mapperType) {
        if (mapperType == null) {
            throw new IllegalArgumentException("mapperType is null");
        }
        this.mapperType = mapperType;
    }

    @Inject
    public void setSqlSessionManager(SqlSessionManager sqlSessionManager) {
        this.sqlSessionManager = sqlSessionManager;
    }

    @Inject
    public void setManagedExecutorService(ManagedExecutorService managedExecutorService) {
        this.managedExecutorService = managedExecutorService;
    }

    @Override
    public T get() {
        return mapperType.cast(Proxy.newProxyInstance(mapperType.getClassLoader(), new Class[]{mapperType}, this));
    }
    
    public Class<T> getMapperType () {
    	return this.mapperType;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        ManagedMapperCallable<T> managedMapperCallable = new ManagedMapperCallable<>();
        managedMapperCallable.setValue(sqlSessionManager.getMapper(mapperType));
        managedMapperCallable.setMethod(method);
        managedMapperCallable.setArgs(args);
        managedMapperCallable.setMapperType(mapperType);
        DataSource dataSource = sqlSessionManager.getConfiguration().getEnvironment().getDataSource();
        if(dataSource != null){
        	managedMapperCallable.appendDataSourceInfo(dataSource.toString());
        }

        Future<Object> future = managedExecutorService.submit(managedMapperCallable);

        try {
            return future.get();
        }
        catch (Exception t) {
            Throwable cause = t.getCause();

            if (cause == null) {
                cause = t;
            }

            if (LOGGER.isErrorEnabled()) {
                LOGGER.error("failed to invoke method: '{}' with args: {} for mapperType: {}",
                        method, Arrays.toString(args), mapperType, cause);
            }

            throw cause;
        }
    }

	public SqlSessionManager getSqlSessionManager() {
		return sqlSessionManager;
	}
    
    
}
