package com.citi.risk.core.data.mybatis;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.ibatis.reflection.ReflectorFactory;

public class MyBatisReflectorFactory implements ReflectorFactory {
	private boolean classCacheEnabled = true;
	private final ConcurrentMap<Class<?>, MyBatisReflector> reflectorMap = new ConcurrentHashMap<>();
	
	public MyBatisReflectorFactory() {
		//intentionally-blank override
	}
	
	@Override
	public boolean isClassCacheEnabled() {
		return classCacheEnabled;
	}

	@Override
	public void setClassCacheEnabled(boolean classCacheEnabled) {
		this.classCacheEnabled = classCacheEnabled;
	}

	@Override
	public MyBatisReflector findForClass(Class<?> type) {
    if (classCacheEnabled) {
            // synchronized (type) removed see issue #461
    	MyBatisReflector cached = reflectorMap.get(type);
      if (cached == null) {
        cached = new MyBatisReflector(type);
        reflectorMap.put(type, cached);
      }
      return cached;
    } else {
      return new MyBatisReflector(type);
    }
  }
	
}
