package com.citi.risk.core.data.mybatis;

import java.util.Collection;
import java.util.Map;

import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.wrapper.ObjectWrapper;
import org.apache.ibatis.reflection.wrapper.ObjectWrapperFactory;

import com.google.inject.Inject;
import com.google.inject.Injector;

public class IbatisObjectWrapperFactory implements ObjectWrapperFactory {
	@Inject
	private Injector injector; 
	@Override
	public boolean hasWrapperFor(Object object) {
		if(object instanceof Map || object instanceof Collection){
			return false;
		}
		return true;
	}

	@Override
	public ObjectWrapper getWrapperFor(MetaObject metaObject, Object object) {
		IbatisBeanWrapper ibatisBeanWrapper = new IbatisBeanWrapper(metaObject, object);
		injector.injectMembers(ibatisBeanWrapper);
		return ibatisBeanWrapper;
	}

}
