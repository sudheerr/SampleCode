package com.citi.risk.core.data.mybatis;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.ibatis.executor.BaseExecutor;
import org.apache.ibatis.executor.BatchExecutorException;
import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.transaction.Transaction;
import org.springframework.jdbc.support.JdbcUtils;

public class BulkExecutor extends BaseExecutor {
	private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory
			.getLogger(BulkExecutor.class);

	public static final int BATCH_UPDATE_RETURN_VALUE = Integer.MIN_VALUE + 1002;
	
	private final List<BatchResult> batchResultList = new ArrayList<>();

	public BulkExecutor(Configuration configuration, Transaction transaction) {
		super(configuration, transaction);
	}

	@Override
	public int doUpdate(MappedStatement ms, Object parameterObject)	throws SQLException {
		Configuration configuration = ms.getConfiguration();
		StatementHandler handler = configuration.newStatementHandler(this, ms, parameterObject, RowBounds.DEFAULT, null, null);
		BoundSql boundSql = handler.getBoundSql();
		String sql = boundSql.getSql();
		batchResultList.add(new BatchResult(ms, sql, parameterObject));
		return BATCH_UPDATE_RETURN_VALUE;
	}

	@Override
	public <E> List<E> doQuery(MappedStatement ms, Object parameterObject, RowBounds rowBounds, ResultHandler resultHandler, BoundSql boundSql) throws SQLException {
		Statement stmt = null;
		try {
			flushStatements();
			Configuration configuration = ms.getConfiguration();
			StatementHandler handler = configuration.newStatementHandler(this, ms, parameterObject, rowBounds, resultHandler, boundSql);
			Connection connection = getConnection(ms.getStatementLog());
			stmt = handler.prepare(connection);
			handler.parameterize(stmt);
			return handler.<E> query(stmt, resultHandler);
		} finally {
			closeStatement(stmt);
		}
	}

	@Override
	public List<BatchResult> doFlushStatements(boolean isRollback) throws SQLException {
		try {
			if (isRollback) {
				return Collections.emptyList();
			} else {
			    Connection connection = null;
			    Statement statement = null;
			    
				List<BatchResult> sucessedResults = new ArrayList<>(batchResultList.size());
			    List<BatchResult> executedResult = new ArrayList<>(batchResultList.size());
			    boolean failed = false;
			    StringBuilder message = new StringBuilder();
			    BatchUpdateException cause = null;
				for(BatchResult batchResult : this.batchResultList) {
					if (connection == null) {
						connection = getConnection(batchResult.getMappedStatement().getStatementLog());
						if (connection == null) {
							throw new RuntimeException("Can not fetch JDBC Connection");
						}
						statement = connection.createStatement();
					}
					try {
						statement.addBatch(batchResult.getSql());
						executedResult.add(batchResult);
					} catch (SQLException sex) {
						message.append("Can execute SQL [").append(sex.getMessage()).append("] ").append(batchResult.getSql());
						failed = true;
						LOGGER.debug(sex.getMessage(), sex);
					}
				}
				
				if (statement != null) {
					try {
						statement.executeBatch();
					} catch (BatchUpdateException e) {
						int[] executeIndexs = e.getUpdateCounts();
						BatchResult batchResult = null;
						for (int index = 0; index < executeIndexs.length && index < executedResult.size(); index++) {
							batchResult = executedResult.get(index);
							if (batchResult != null) {
								if (executeIndexs[index] == Statement.EXECUTE_FAILED) {
									message.append("(batch index #").append(index + 1).append(" failed. ").append(batchResult.getSql());
									failed  = true;
								} else {
									sucessedResults.add(batchResult);
								}
							}
						}
						cause = e;
					} finally {
						JdbcUtils.closeStatement(statement);
					}
				}
				
				
				if (failed) {
					throw new BatchExecutorException(message.toString(), cause,	sucessedResults, null);
				}
				sucessedResults.clear();
				executedResult.clear();
				return new ArrayList<>(batchResultList);
			}
		} finally {
			batchResultList.clear();
		}
	}

}
