package com.citi.risk.core.data.mybatis;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;


//@MappedJdbcTypes(value = JdbcType.VARCHAR)
//@MappedTypes(value = TimeMark.class)
public class TimeMarkTypeHandler extends BaseTypeHandler<TimeMark>{

	@Override
	public void setNonNullParameter(PreparedStatement ps, int i, TimeMark parameter, JdbcType jdbcType)
			throws SQLException {
		
		ps.setString(i, parameter.toString());
	}

	@Override
	public TimeMark getNullableResult(ResultSet rs, String columnName) throws SQLException {
		return DefaultTimeMark.getTimeMarkfromKey(rs.getString(columnName));
	}

	@Override
	public TimeMark getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
		return DefaultTimeMark.getTimeMarkfromKey(rs.getString(columnIndex));
	}

	@Override
	public TimeMark getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
		return DefaultTimeMark.getTimeMarkfromKey(cs.getString(columnIndex));
	}

}
