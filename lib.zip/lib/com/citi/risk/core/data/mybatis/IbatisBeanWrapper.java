package com.citi.risk.core.data.mybatis;

import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.property.PropertyTokenizer;
import org.apache.ibatis.reflection.wrapper.BeanWrapper;

import com.citi.risk.core.data.intern.api.InternProvider;
import com.google.inject.Inject;

public class IbatisBeanWrapper extends BeanWrapper {
	
	@Inject
	InternProvider internProvider;
	
	public IbatisBeanWrapper(MetaObject metaObject, Object object) {
		super(metaObject, object);
	}

	
	@Override
	public void set(PropertyTokenizer prop, Object value) {
		Object value1 = internProvider.get(value);
		
		super.set( prop,  value1);
	  }
}
