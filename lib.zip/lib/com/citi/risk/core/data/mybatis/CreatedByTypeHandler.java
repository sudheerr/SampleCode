package com.citi.risk.core.data.mybatis;

import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreatedByTypeHandler extends BaseTypeHandler<CreatedBy> {

	@Override
	public void setNonNullParameter(PreparedStatement ps, int i, CreatedBy parameter, JdbcType jdbcType)
			throws SQLException {
		ps.setString(i, parameter.toString());
	}

	@Override
	public CreatedBy getNullableResult(ResultSet rs, String columnName) throws SQLException {
		return DefaultCreatedBy.newCreatedBy(rs.getString(columnName));
	}

	@Override
	public CreatedBy getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
		return DefaultCreatedBy.newCreatedBy(rs.getString(columnIndex));
	}

	@Override
	public CreatedBy getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
		return DefaultCreatedBy.newCreatedBy(cs.getString(columnIndex));
	}

}
