package com.citi.risk.core.data.distribute;

import java.beans.PropertyDescriptor;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.Statement;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ClassUtils;
import org.apache.hadoop.fs.Path;
import org.apache.ibatis.annotations.Insert;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.PrimitiveType;
import org.apache.parquet.schema.PrimitiveType.PrimitiveTypeName;
import org.apache.parquet.schema.Type;
import org.apache.parquet.schema.Type.Repetition;

public class AbstractParquetIO<E> {
	protected Path filePath;
	protected Class<E> entityImplClass;
	protected Class columnDomainMapping;
	protected CCJSqlParserManager sqlParserManager = new CCJSqlParserManager();
	
	public AbstractParquetIO(Path filePath, Class<E> entityImplClass, Class columnDomainMapping) {
		super();
		this.filePath = filePath;
		this.entityImplClass = entityImplClass;
		this.columnDomainMapping = columnDomainMapping;
	}
	
	protected Map<String, PropertyDescriptor> getColumnFieldMapping(Class storerMapperClass, Class<E> entityImplClass) {
		PropertyDescriptor[] propertyDescriptors = PropertyUtils.getPropertyDescriptors(entityImplClass);
		
		net.sf.jsqlparser.statement.insert.Insert insertSQL = parseStorerMapperClass(storerMapperClass);
		List<String> columnNames = getColumnNames(insertSQL);
		removeObjectIdColumn(columnNames);
		List<String> propertyNames = getPropertyNames(insertSQL);
		
		 Map<String, PropertyDescriptor> columnFieldMapping = new HashMap<>();
		for (int i = 0; i<columnNames.size(); i++) {
			String columnName = columnNames.get(i);
			String propertyName = propertyNames.get(i);
			PropertyDescriptor propertyDescriptor = searchProperyDescriptor(propertyName, propertyDescriptors);
			if (propertyDescriptor == null) {
				throw new RuntimeException("cannot get field descriptor" + entityImplClass + "." + propertyName );
			}
			columnFieldMapping.put(columnName, propertyDescriptor);
		}
		
		return columnFieldMapping;
	}
	
	protected MessageType getSchema(Class storerMapperClass, Class<E> entityImplClass) {
		Map<String, PropertyDescriptor> columnFieldMappings = getColumnFieldMapping(storerMapperClass, entityImplClass);
		List<Type> columnTypes = new ArrayList<>();
		for (Entry<String, PropertyDescriptor> columnFieldMapping : columnFieldMappings.entrySet()) {
			String columnName = columnFieldMapping.getKey();
			Class fieldType = columnFieldMapping.getValue().getPropertyType();
			PrimitiveType columnType = new PrimitiveType(Repetition.OPTIONAL, getPrimitiveTypeName(fieldType), columnName);
			columnTypes.add(columnType);
		}
		
		return new MessageType("domain", columnTypes);
	}
	
	protected void addValueInRecord(Group record, String column, Object columnValue) {
//		if (!ClassUtils.isPrimitiveOrWrapper(columnValue.getClass()) && !String.class.isAssignableFrom(columnValue.getClass())) {
//			throw new RuntimeException("column is not primitive: " + column + " with value" + columnValue.toString() + " and value class:" + columnValue.getClass());
//		} 
		if (columnValue instanceof Boolean) {
			record.add(column, (boolean)columnValue);
			return;
		} else if (columnValue instanceof Short) {
			record.add(column, (int)columnValue);
			return;
		} else if (columnValue instanceof Integer) {
			record.add(column, (int)columnValue);
			return;
		} else if (columnValue instanceof Long) {
			record.add(column, (long)columnValue);
			return;
		} else if (columnValue instanceof Float) {
			record.add(column,  (float)columnValue);
			return;
		} else if (columnValue instanceof Double) {
			record.add(column, (double)columnValue);
			return;
		} else if (columnValue instanceof String) {
			record.add(column, (String) columnValue);
			return;
		} else if (columnValue instanceof Enum) {
			record.add(column, columnValue.toString());
			return;
		}else if (columnValue instanceof Date) {
			record.add(column, ((Date)columnValue).getTime());
			return;
		}else if (columnValue instanceof Character) {
			record.add(column, String.valueOf(columnValue));
			return;
		}else if (columnValue instanceof BigDecimal) {
			record.add(column, ((BigDecimal)columnValue).toString());
			return;
		}
		
		throw new RuntimeException("column is not primitive: " + column + " with value" + columnValue.toString() + " and value class:" + columnValue.getClass());
	}
	
	protected Object getRecordValue(Group record, String columnName, Class fieldType) {
//		if (!ClassUtils.isPrimitiveOrWrapper(fieldType) && !String.class.isAssignableFrom(fieldType)) {
//			throw new RuntimeException("Field type should be primitive insteadof " + fieldType);
//		} 
		if (Boolean.class.isAssignableFrom(fieldType) || boolean.class.isAssignableFrom(fieldType)) {
			return record.getBoolean(columnName, 0);
		} else if (Short.class.isAssignableFrom(fieldType) || short.class.isAssignableFrom(fieldType)) {
			return (short)record.getInteger(columnName, 0);
		} else if (Integer.class.isAssignableFrom(fieldType) || int.class.isAssignableFrom(fieldType)) {
			return record.getInteger(columnName, 0);
		} else if (Long.class.isAssignableFrom(fieldType) || long.class.isAssignableFrom(fieldType)) {
			return record.getLong(columnName, 0);
		} else if (Float.class.isAssignableFrom(fieldType) || float.class.isAssignableFrom(fieldType)) {
			return record.getFloat(columnName, 0);
		} else if (Double.class.isAssignableFrom(fieldType) || double.class.isAssignableFrom(fieldType)) {
			return record.getDouble(columnName, 0);
		} else if (String.class.isAssignableFrom(fieldType)) {
			return record.getString(columnName, 0);
		} else if (Enum.class.isAssignableFrom(fieldType)) {
			String enumString = record.getString(columnName, 0);
			for (Object type : fieldType.getEnumConstants()) {
				if (((Enum) type).name().equals(enumString))
					return type;
			}
		} else if (Date.class.isAssignableFrom(fieldType)) {
			long dateLong = record.getLong(columnName, 0);
			return new Date(dateLong);
		} else if (Character.class.isAssignableFrom(fieldType)|| char.class.isAssignableFrom(fieldType)) {
			String characterString = record.getString(columnName, 0);
			return characterString.charAt(0);
		}else if (BigDecimal.class.isAssignableFrom(fieldType)) {
			String bigDecimalString = record.getString(columnName, 0);
			return new BigDecimal(bigDecimalString);
		} 
		
		
		throw new RuntimeException("can not get type :" + fieldType.getClass() + " in the record");
	}
	
	private PropertyDescriptor searchProperyDescriptor(String name, PropertyDescriptor[] propertyDescriptors) {
		for (PropertyDescriptor descriptor : propertyDescriptors) {
			if (descriptor.getName().equals(name)) {
				return descriptor;
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes" })
	private net.sf.jsqlparser.statement.insert.Insert parseStorerMapperClass(Class storerMapperClass) {
		Method[] methods = storerMapperClass.getMethods();
		Method method = null;
		for (Method methodtmp : methods) {
			if ("store".equals(methodtmp.getName())) {
				method = methodtmp;
			}
		}
		if (method == null)
			throw new IllegalArgumentException("Expected method store on " + storerMapperClass.getName());

		Insert storeAnnotation = method.getAnnotation(Insert.class);
		String storeAnnotationClassName = Insert.class.getName();
		if (storeAnnotation == null)
			throw new NullPointerException("Expected Insert annotation");

		String[] toStoreSqls = storeAnnotation.value();
		if (ArrayUtils.isEmpty(toStoreSqls) || (ArrayUtils.getLength(toStoreSqls) != 1))
			throw new IllegalArgumentException("Expected one and only one sql statement as value for " + storeAnnotationClassName + " annotation");
		return (net.sf.jsqlparser.statement.insert.Insert) getStatementFromStoreMethod(toStoreSqls[0]);

	}
	
	private Statement getStatementFromStoreMethod(String toStoreSql) {
		if (StringUtils.isBlank(toStoreSql))
			throw new IllegalArgumentException("Expected non-null/non-empty sql statement as value for Insert annotation");

		Statement statement = null;
		try {
			statement = sqlParserManager.parse(new StringReader(StringUtils.trim(toStoreSql.trim())));
			if (!(statement instanceof net.sf.jsqlparser.statement.insert.Insert))
				throw new IllegalArgumentException("Expected INSERT sql instead of: " + toStoreSql);
		} catch (JSQLParserException e) {
			throw new IllegalArgumentException("Expected INSERT sql instead of: " + toStoreSql, e);
		}
		return statement;
	}
	
	private List<String> getColumnNames(net.sf.jsqlparser.statement.insert.Insert insertStatement) {
		List columns = insertStatement.getColumns();
		List<String> columnNames = getColumnNames(columns);

		return columnNames;
	}
	
	private void removeObjectIdColumn(List<String> columnNames) {
		Iterator<String> iterator = columnNames.iterator();
		while (iterator.hasNext()) {
			String column = iterator.next();
			if ("OBJECT_ID".equals(column)) {
				iterator.remove();
			}
		}
	}
	
	private List<String> getPropertyNames(net.sf.jsqlparser.statement.insert.Insert insertStatement) {
		ExpressionList expressionList = (ExpressionList) insertStatement.getItemsList();
		List properties = expressionList.getExpressions();
		List<String> propertyNames = getColumnNames(properties);

		return propertyNames;
	}
	
	@SuppressWarnings("rawtypes")
	private List<String> getColumnNames(List columns) {
		List<String> columnNames = new ArrayList();
		for (Object columnObj : columns) {
			if ((columnObj == null) || (!Column.class.isAssignableFrom(columnObj.getClass())))
				continue;
			Column column = (Column) columnObj;
			columnNames.add(column.getColumnName());
		}
		return columnNames;
	}
	
	private PrimitiveTypeName getPrimitiveTypeName(Class fieldType) {
//		if (!ClassUtils.isPrimitiveOrWrapper(fieldType) && !String.class.isAssignableFrom(fieldType)) {
//			throw new RuntimeException("type is not primitive: " + fieldType);
//		} 
		if (Boolean.class.isAssignableFrom(fieldType) || boolean.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.BOOLEAN;
		} else if (Short.class.isAssignableFrom(fieldType) || short.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.INT32;
		} else if (Integer.class.isAssignableFrom(fieldType) || int.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.INT32;
		} else if (Long.class.isAssignableFrom(fieldType) || long.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.INT64;
		} else if (Float.class.isAssignableFrom(fieldType) || float.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.FLOAT;
		} else if (Double.class.isAssignableFrom(fieldType) || double.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.DOUBLE;
		} else if (String.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.BINARY;
		} else if (Enum.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.BINARY;
		} else if (Date.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.INT64;
		}else if (Character.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.BINARY;
		}else if (BigDecimal.class.isAssignableFrom(fieldType)) {
			return PrimitiveTypeName.BINARY;
		}
		
		
		throw new RuntimeException("cannot find appropriate primitive type in parquet for the type:" + fieldType);
	}
}
