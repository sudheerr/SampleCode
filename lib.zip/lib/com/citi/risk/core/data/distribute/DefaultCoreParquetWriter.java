package com.citi.risk.core.data.distribute;

import static org.apache.parquet.hadoop.ParquetWriter.DEFAULT_IS_DICTIONARY_ENABLED;
import static org.apache.parquet.hadoop.ParquetWriter.DEFAULT_IS_VALIDATING_ENABLED;
import static org.apache.parquet.hadoop.ParquetWriter.DEFAULT_WRITER_VERSION;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.example.data.simple.SimpleGroup;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.example.GroupWriteSupport;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.apache.parquet.schema.MessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ClassUtils;

import com.citi.risk.core.ioc.impl.guice.CoreModule;

public class DefaultCoreParquetWriter<E> extends AbstractParquetIO<E> implements CoreParquetWriter<E>{
	
	private final static Logger LOGGER = LoggerFactory.getLogger(DefaultCoreParquetWriter.class);
	private ParquetWriter<Group> internalWriter;
	private MessageType schema;
	
	
	public DefaultCoreParquetWriter(Path filePath, Class<E> entityImplClass, Class columnDomainMapper) {
		super(filePath, entityImplClass, columnDomainMapper);
		this.schema = getSchema(columnDomainMapping, entityImplClass);
		initializeInternalWriter(filePath);
	}
	
	@Override
	public void write(Collection<E> items) throws IOException {
		if (CollectionUtils.isEmpty(items)) {
			LOGGER.info("no items is wrote since items passed is empty.");
			return;
		}
		LOGGER.warn("starting to write records");
		Collection<Group> records = convertToRecords(items);
		LOGGER.warn("records converted, size is:" + records.size());
		writeRecords(records);
		LOGGER.warn("finished write records, size is:" + records.size());
	}
	
	@Override
	public Path getFilePath() {
		return this.filePath;
	}
	
	@Override
	public void close() {
		if (this.internalWriter != null) {
			try {
				this.internalWriter.close();
			} catch (IOException e) {
				if (!e.getMessage().equals("Filesystem closed")) {
					throw new RuntimeException(e);
				}
			}
		}
		
	}

	private Collection<Group> convertToRecords(Collection<E> items) {
		Collection<Group> rawRecords = new ArrayList<>();
		Map<String, PropertyDescriptor> columnFieldMappings = getColumnFieldMapping(columnDomainMapping, entityImplClass);
		for (E item : items) {
			Group record = convertToRecord(columnFieldMappings, item);
			rawRecords.add(record);
		}
		return rawRecords;
	}

	private Group convertToRecord(Map<String, PropertyDescriptor> columnFieldMappings, E item) {
		Group record = new SimpleGroup(schema);
		for (Entry<String, PropertyDescriptor> columnFieldMapping : columnFieldMappings.entrySet()) {
			String columnName = columnFieldMapping.getKey();
			PropertyDescriptor descriptor = columnFieldMapping.getValue();
			Object fieldValue;
			try {
				fieldValue = descriptor.getReadMethod().invoke(item);
			} catch (IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				throw new RuntimeException(e);
			}
			addValueInRecord(record, columnName, fieldValue);
		}
		return record;
	}
	
	private void writeRecords(Collection<Group> rawRecords) throws IOException {
		for (Group record : rawRecords) {
			this.internalWriter.write(record);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void initializeInternalWriter(Path filePath) {
		CompressionCodecName snappy = CompressionCodecName.SNAPPY;
		int blockSize = 64 * 1024 * 1024;
		int pageSize = 64 * 1024;
		org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
		String coreSiteXML = CoreModule.getConfiguration().getString("hadoop.conf.coresite");
		String hdfsSiteXML = CoreModule.getConfiguration().getString("hadoop.conf.hdfssite");
		if (!StringUtils.isBlank(coreSiteXML) && !StringUtils.isBlank(hdfsSiteXML)) {
			URL coreSiteXMLUrl = ClassUtils.getDefaultClassLoader().getResource(coreSiteXML);
            URL hdfsSiteXMLUrl = ClassUtils.getDefaultClassLoader().getResource(hdfsSiteXML);
			conf.addResource(new Path(coreSiteXMLUrl.getPath()));
			conf.addResource(new Path(hdfsSiteXMLUrl.getPath()));
			LOGGER.info("add hadoop resource:" + coreSiteXML + " and " + hdfsSiteXML);
		} else {
			LOGGER.info("use local file system since no hadoop conf is provided.");
		}
		try {
			FileSystem fs = FileSystem.get(conf);
			if (fs.exists(filePath)) {
				fs.delete(filePath, true);
			}
			closeFileSystemSafe(fs);
		} catch (IOException e) {
			throw new RuntimeException("delete file" + filePath.getName() + "error", e);
		} 
		
		LOGGER.warn("start to initialize internalWriter on path" + filePath.getName());
		try {
			GroupWriteSupport writeSupport = new GroupWriteSupport();
			writeSupport.setSchema(schema, conf);
			internalWriter = new ParquetWriter(filePath, writeSupport, snappy, blockSize, pageSize,  pageSize, DEFAULT_IS_DICTIONARY_ENABLED, DEFAULT_IS_VALIDATING_ENABLED, DEFAULT_WRITER_VERSION, conf);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		LOGGER.warn("finish to initialize internalWriter on path" + filePath.getName());
	}

	private void closeFileSystemSafe(FileSystem fs) throws IOException {
		Boolean hdfsSafeClose = CoreModule.getConfiguration().getBoolean("hdfs.close.safe", false);
		if (hdfsSafeClose) {
			fs.close();
		}
	}

}
