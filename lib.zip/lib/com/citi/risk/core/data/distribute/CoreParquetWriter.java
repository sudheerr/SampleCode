package com.citi.risk.core.data.distribute;

import java.io.Closeable;
import java.io.IOException;
import java.util.Collection;

import org.apache.hadoop.fs.Path;

public interface CoreParquetWriter<E> extends Closeable{

	/**
	 * write items to {@link #getFilePath()}, if {@link #getFilePath()} is already in the fileSystem, then first delete it and then write 
	 * @param items items to store
	 * @throws IOException if failed to write;
	 */
	public void write(Collection<E> items) throws IOException;
	
	/**
	 * @return file that {@link CoreParquetWriter} will write to
	 */
	public Path getFilePath();
}
