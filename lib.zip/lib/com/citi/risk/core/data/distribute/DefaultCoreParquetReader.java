package com.citi.risk.core.data.distribute;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.hadoop.ParquetReader;
import org.apache.parquet.hadoop.example.GroupReadSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ClassUtils;

import com.citi.risk.core.data.intern.api.InternProvider;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.inject.Inject;

public class DefaultCoreParquetReader<E> extends AbstractParquetIO<E> implements CoreParquetReader<E> {

	private final static Logger LOGGER = LoggerFactory.getLogger(DefaultCoreParquetReader.class);
	private ParquetReader<Group> internalReader;
	private AtomicBoolean internalReaderClosed = new AtomicBoolean(false);
	@Inject
	private InternProvider internProvider;
	
	public DefaultCoreParquetReader(Path filePath, Class<E> entityImplClass, Class columnDomainMapper) {
		super(filePath, entityImplClass, columnDomainMapper);
		initializeInternalReader(filePath);
	}
	

	@Override
	public Collection<E> read() throws IOException {
		if (internalReader == null) {
			return null;
		}
		LOGGER.warn("staring to read records");
		Collection<Group> rawRecords = readRecords();
		LOGGER.warn("records read, size is: " + rawRecords.size());
		Collection<E> items = convertRecords(rawRecords);
		LOGGER.warn("records converted, size is: " + items.size());
		return items;
	}
	
	@Override
	public Path getFilePath() {
		return this.filePath;
	}
	
	@Override
	public synchronized void close() {
		if (this.internalReader != null) {
			if (internalReaderClosed.get()) {
				LOGGER.info("Internal reader wiht path"+ this.filePath.getName() + " already closed.");
				return;
			}
			try {
				this.internalReader.close();
				internalReaderClosed.set(true);
			} catch (IOException e) {
				if ( !e.getMessage().equals("Filesystem closed")) {
					throw new RuntimeException(e);
				}
			}
		}
		
	}

	private Collection<Group> readRecords() throws IOException {
		Collection<Group> rawRecords = new ArrayList<>();
		Group rawRecord;
		while ((rawRecord = internalReader.read()) != null) {
			rawRecords.add(rawRecord);
		}
		return rawRecords;
	}
	
	private Collection<E> convertRecords(Collection<Group> rawRecords) {
		Collection<E> items = new ArrayList<>();
		Map<String, PropertyDescriptor> columnFieldMappings = getColumnFieldMapping(columnDomainMapping, entityImplClass); 
		for (Group record : rawRecords) {
			E item = convertRecord(columnFieldMappings, record);
			items.add(item);
		}
		return items;
	}


	private E convertRecord(Map<String, PropertyDescriptor> columnFieldMappings, Group record) {
		E item;
		try {
			item = entityImplClass.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
		for (Entry<String, PropertyDescriptor> columnFieldMapping : columnFieldMappings.entrySet()) {
			String columnName = columnFieldMapping.getKey();
			PropertyDescriptor descriptor = columnFieldMapping.getValue();
			Object columnValue = getRecordValue(record, columnName, descriptor.getPropertyType());
			if (internProvider != null) {
				columnValue = internProvider.get(columnValue);
			}
			try {
				descriptor.getWriteMethod().invoke(item, columnValue);
			} catch (IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				throw new RuntimeException(e);
			}
		}
		return item;
	}

	@SuppressWarnings("unchecked")
	private void initializeInternalReader(Path filePath) {
		
		org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
		String coreSiteXML = CoreModule.getConfiguration().getString("hadoop.conf.coresite");
		String hdfsSiteXML = CoreModule.getConfiguration().getString("hadoop.conf.hdfssite");
		if (!StringUtils.isBlank(coreSiteXML) && !StringUtils.isBlank(hdfsSiteXML)) {
			URL coreSiteXMLUrl = ClassUtils.getDefaultClassLoader().getResource(coreSiteXML);
            URL hdfsSiteXMLUrl = ClassUtils.getDefaultClassLoader().getResource(hdfsSiteXML);
			conf.addResource(new Path(coreSiteXMLUrl.getPath()));
			conf.addResource(new Path(hdfsSiteXMLUrl.getPath()));
			LOGGER.info("add hadoop resource:" + coreSiteXML + " and " + hdfsSiteXML);
		} else {
			LOGGER.info("use local file system since no hadoop conf is provided.");
		}
		
		try {
			FileSystem fs = FileSystem.get(conf);
			if (!fs.exists(filePath)) {
				LOGGER.info("no file found:" + filePath.getName());
				this.internalReader = null;
				closeFileSystemSafe(fs);
				return;
			}
			closeFileSystemSafe(fs);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} 
		LOGGER.warn("start to initialize internalReader on path" + filePath.getName());
		try {
			this.internalReader = ParquetReader.builder(new GroupReadSupport(), filePath).withConf(conf).build();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		LOGGER.warn("finish to initialize internalReader on path" + filePath.getName());
	}


	private void closeFileSystemSafe(FileSystem fs)
			throws IOException {
		Boolean hdfsSafeClose = CoreModule.getConfiguration().getBoolean("hdfs.close.safe", false);
		if (hdfsSafeClose) {
			fs.close();
		}
	}
	
}
