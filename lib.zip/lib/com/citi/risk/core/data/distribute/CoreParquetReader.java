package com.citi.risk.core.data.distribute;

import java.io.Closeable;
import java.io.IOException;
import java.util.Collection;

import org.apache.hadoop.fs.Path;

public interface CoreParquetReader<E> extends Closeable {
	/**
	 * @return the items stores in parquet file according to {@link #getFilePath()},
	 * returns NULL if {@link #getFilePath()} is not found in the fileSystem.
	 * @throws IOException if failed to read parquet file.
	 */
	public Collection<E> read() throws IOException;
	
	/**
	 * @return file that {@link CoreParquetReader} will read.
	 */
	Path getFilePath();
}
