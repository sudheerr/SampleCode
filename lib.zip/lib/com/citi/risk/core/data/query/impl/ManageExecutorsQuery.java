package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.google.inject.Inject;

public class ManageExecutorsQuery extends AbstractQuery {
	@Inject
	private ManagedExecutorService executorManager;

	@Override
	public final SearchProvider getSearchProvider() {
		return executorManager;
	}

	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.executorManager = (ManagedExecutorService)searchProvider;
	}
}
