package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.dictionary.impl.DomainGraphPathProvider;
import com.google.inject.Inject;

public class ManageDomainGraphPathsQuery extends AbstractQuery {

	@Inject
	private DomainGraphPathProvider provider;

	@Override
	public final SearchProvider getSearchProvider() {
		return provider;
	}


	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.provider = (DomainGraphPathProvider)searchProvider;
		
	}
}
