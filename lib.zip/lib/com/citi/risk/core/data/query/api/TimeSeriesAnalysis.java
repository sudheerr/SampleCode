package com.citi.risk.core.data.query.api;

import java.util.concurrent.Future;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

/**
 * Provides the method to do the timeSeriesAnalysis
 * 
 * <p>
 * Caller can pass in the VarianceAnalysis request via a {@link com.citi.risk.core.data.query.api.TimeSeriesAnalysisRequest TimeSeriesAnalysisRequest} and get the Future of {@link com.citi.risk.core.data.query.api.TimeSeriesAnalysisResult
 * TimeSeriesAnalysisResult}
 * </p>
 * 
 * @param <K>
 *            key type to lookup by
 * @param <E>
 *            value type in cache, extends IdentifiedBy of type K
 * 
 * @author hl80973
 * 
 */
public interface TimeSeriesAnalysis {

	<K, E extends IdentifiedBy<K>> Future<TimeSeriesAnalysisResult> analyze(TimeSeriesAnalysisRequest<E> request);

	void setQuery(Query query);
}
