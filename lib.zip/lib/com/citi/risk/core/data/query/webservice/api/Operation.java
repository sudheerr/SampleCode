package com.citi.risk.core.data.query.webservice.api;


public enum Operation {
	Equal,
	NotEqual,
	Like,
	In,
	Between,
	Lt,
	Le,
	Gt,
	Ge,
	ExistAny,
	ExistAll
}
