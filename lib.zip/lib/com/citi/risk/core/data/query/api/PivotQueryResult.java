package com.citi.risk.core.data.query.api;

import com.citi.risk.core.data.pivot.api.PivotTable;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public interface PivotQueryResult<E> extends QueryResult<E> {
	
	<R, C> PivotTable<E, R, C> getPivotTable();
	
	<R, C> PivotTable<E, R, C> getPivotTable(DataSelectionItem<E, R> topLevelRowDsi, DataSelectionItem<E, C> topLevelColumnDsi);
	
	DataSelection<E> getRowDimension();
	
	DataSelection<E> getColumnDimension();

	DataSelection<E> getAggregateMeasure();

}
