package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.spring.batch.api.ManagedBatchService;
import com.google.inject.Inject;

public class ManageBatchesQuery extends AbstractQuery {
	@Inject
	private ManagedBatchService batchManager;


	@Override
	public SearchProvider getSearchProvider() {
		return batchManager;
	}

	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.batchManager = (ManagedBatchService)searchProvider;
		
	}

}
