package com.citi.risk.core.data.query.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.QueryResultFilter;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.Criterion.Op;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.compare.QueryCompareMeasure;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.select.ComparableSelects;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.lang.select.SelectByTransformed;
import com.google.common.base.Function;

/**
 * Filter class to provide further criteria filter besides the normal search
 * function.
 * 
 * @author hl80973
 * 
 */
class QueryResultFilterImpl implements QueryResultFilter {

	@Override
	public <E> void filterQueryResult(QueryRequest<E> queryRequest,
			QueryResult<E> queryResult) {

		Criteria furtherCriteria = queryRequest.getFurtherCriteria();
		if (furtherCriteria.getAllCriterion().isEmpty()) {
			return;
		}
		Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult = queryResult
				.getComparedResult();
		Collection<Criterion<?>> allCriterion = furtherCriteria
				.getAllCriterion();
		Map<DataSelectionItem, SelectByTransformed> dsiAndSelectMap = new HashMap<>();

		// no aggregation result, only have comparedResult. Will filter on
		// search result
		if (queryResult.getAggregedResult() == null && comparedResult.size() != 0) {
			convertSearchResultToLinkedList(queryResult);
			filterOnComparedResult(queryResult.getSearchResult(), comparedResult, allCriterion,
					dsiAndSelectMap);
		} else if (queryResult.getAggregedResult() != null) {
			convertAggregateResultToLinkedList(queryResult);
			filterOnAggregatedAndComparedResult(queryResult.getAggregedResult(),
					comparedResult, allCriterion, dsiAndSelectMap);
		}

	}

	private <E> void convertSearchResultToLinkedList(QueryResult<E> queryResult) {
		Collection<E> searchResult = queryResult.getSearchResult();
		Collection<E> searchResultLinkedList = new LinkedList<>();
		searchResultLinkedList.addAll(searchResult);
		queryResult.setSearchResult(searchResultLinkedList);
	}

	private <E> void convertAggregateResultToLinkedList(QueryResult<E> queryResult) {
		Collection<Element<List<?>, E>> aggregatedResult = queryResult
				.getAggregedResult();
		Collection<Element<List<?>, E>> aggregateResultLinkedList = new LinkedList<>();
		aggregateResultLinkedList.addAll(aggregatedResult);
		queryResult.setAggregatedResult(aggregateResultLinkedList);
	}
	
	private <E> void filterOnAggregatedAndComparedResult(
			Collection<Element<List<?>, E>> aggregatedResult,
			Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult,
			Collection<Criterion<?>> allCriterion,
			Map<DataSelectionItem, SelectByTransformed> dsiAndSelectMap) {
		for (Criterion<?> criterion : allCriterion) {
			SelectByTransformed select;
			DataSelectionItem dataSelectionItem = criterion
					.getDataSelectionItem();
			QueryCompareMeasure compareMeasure = dataSelectionItem
					.getCompareMeasure();
			AggregateMeasure selectedAggregateMeasure = dataSelectionItem
					.getSelectedAggregateMeasure();
			if (compareMeasure == null && selectedAggregateMeasure != null) {
				Function fromAggrResultToValue = selectedAggregateMeasure
						.getResultTransform();
				select = generateSelect(criterion, fromAggrResultToValue);
				dsiAndSelectMap.put(dataSelectionItem, select);
			} else if (compareMeasure != null) {
				Function comparedResultTransform = compareMeasure
						.getResultTransform();
				select = generateSelect(criterion, comparedResultTransform);
				dsiAndSelectMap.put(dataSelectionItem, select);
			}
		}
		for (Iterator<Element<List<?>, E>> iterator = aggregatedResult
				.iterator(); iterator.hasNext();) {
			removeFilterdResult(comparedResult, dsiAndSelectMap, iterator);
		}
	}

	private <E> void removeFilterdResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult,
			Map<DataSelectionItem, SelectByTransformed> dsiAndSelectMap, Iterator<Element<List<?>, E>> iterator) {
		boolean shouldBeRemoved = false;
		Element<List<?>, E> element = iterator.next();
		for (Entry<DataSelectionItem, SelectByTransformed> entry : dsiAndSelectMap
				.entrySet()) {
			DataSelectionItem dsi = entry.getKey();
			SelectByTransformed select = entry.getValue();
			QueryCompareMeasure compareMeasure = dsi.getCompareMeasure();
			AggregateMeasure selectedAggregateMeasure = dsi
					.getSelectedAggregateMeasure();
			if (compareMeasure == null && selectedAggregateMeasure != null) {
				Object aggregateResult = element
						.getAggregationResult(dsi);
				if (!select.apply(aggregateResult)) {
					shouldBeRemoved = true;
				}
			} else if (compareMeasure != null) {
				E object = element.getMembers().iterator().next();
				if (comparedResult.get(object) != null && !select.apply(comparedResult.get(object).get(dsi))) {
					shouldBeRemoved = true;
				}
			}
		}
		if (shouldBeRemoved) {
			iterator.remove();
		}
	}

	private <E> void filterOnComparedResult(Collection<E> searchResult,
			Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult,
			Collection<Criterion<?>> allCriterion,
			Map<DataSelectionItem, SelectByTransformed> dsiAndSelectMap) {
		for (Criterion<?> criterion : allCriterion) {
			DataSelectionItem dataSelectionItem = criterion
					.getDataSelectionItem();
			Function compareResultTransform = dataSelectionItem
					.getCompareMeasure().getResultTransform();
			SelectByTransformed select = generateSelect(criterion,
					compareResultTransform);
			dsiAndSelectMap.put(dataSelectionItem, select);
		}
		for (Iterator iterator = searchResult.iterator(); iterator.hasNext();) {
			Map<DataSelectionItem<E, ?>, CompareResult> comparedResultMap = comparedResult
					.get(iterator.next());
			for (Entry<DataSelectionItem, SelectByTransformed> entry : dsiAndSelectMap
					.entrySet()) {
				DataSelectionItem dsi = entry.getKey();
				SelectByTransformed select = entry.getValue();
				if (comparedResultMap == null
						|| !select.apply(comparedResultMap.get(dsi))) {
					iterator.remove();
					break;
				}
			}
		}
	}

	private SelectByTransformed generateSelect(Criterion criterion,
			Function transform) {
		Op op = criterion.getOP();
		Select select;
		select = ComparableSelects.getSelect(op,
				(ArrayList) criterion.getAllOperands());
		if (criterion.isNegated()) {
			select = select.not();
		}
		return new SelectByTransformed<>(select, transform);
	}

}
