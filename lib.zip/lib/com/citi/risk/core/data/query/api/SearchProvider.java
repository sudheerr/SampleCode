package com.citi.risk.core.data.query.api;

import java.util.Collection;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;

public interface SearchProvider 
{
	<E extends IdentifiedBy<?>> Collection<E> getAll(DataKey dataKey);

	/**
	 * @deprecated Use getAll(DataKey dataKey) instead
	 */
	@Deprecated
	<E extends IdentifiedBy<?>> Collection<E> getAll(DataDomain domain);
	
	/**
	 * @deprecated Use search(DataKey dataKey, Select<E> select) instead
	 * Gets items from the datasource by domain and select operator, allows you to present a condition on a value vs only equals.<p>
	 * Use search(DataKey dataKey, Select<E> select) instead.
	 *
	 * @param domain domain to search by
	 * @param select function operator on a value
	 * @param <E>    value type in datasource, extends Serializable
	 * @return list of values from the datasource
	 * @throws Exception 
	 * @see com.citi.risk.core.dictionary.api.DataDomain
	 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
	 * @see com.citi.risk.core.lang.select.Select
	 */
	@Deprecated
	<E extends IdentifiedBy<?>>  Collection<E> search(DataDomain domain, Select<E> select);

	/**
	 * Gets items from the datasource by domain and select operator, allows you to present a condition on a value vs only equals.
	 *
	 * @param dataKey dataKey to search by
	 * @param select function operator on a value
	 * @param <E>    value type in datasource, extends Serializable
	 * @return list of values from the datasource
	 * @throws Exception 
	 * @see com.citi.risk.core.data.store.api.DataKey
	 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
	 * @see com.citi.risk.core.lang.select.Select
	 */
	<E extends IdentifiedBy<?>>  Collection<E> search(DataKey dataKey, Select<E> select);
	
	/**
	 * Returns a collection of matched entities for the given criteria and select.
	 * @param criteria for building a select query
	 * @param additionalSelect for additional select
	 * @return
	 */
	<E extends IdentifiedBy<?>> Collection<E> select(Criteria<E> criteria, Select<E> specialSelect);
}
