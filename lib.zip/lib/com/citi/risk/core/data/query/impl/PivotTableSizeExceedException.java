package com.citi.risk.core.data.query.impl;

public class PivotTableSizeExceedException extends RuntimeException {
	private static final long serialVersionUID = -8279942528880717686L;
	private final int limit;
	private final int exceedSize;
	private final String exceedPart;
	
	public PivotTableSizeExceedException(String message, int limit, int exceedSize, String exceedPart) {
		super(message + limit);
		this.limit = limit;
		this.exceedSize = exceedSize;
		this.exceedPart = exceedPart;
	}

	public int getLimit() {
		return limit;
	}

	public int getExceedSize() {
		return exceedSize;
	}

	public String getExceedPart() {
		return exceedPart;
	}
}
