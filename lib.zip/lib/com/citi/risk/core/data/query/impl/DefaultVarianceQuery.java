package com.citi.risk.core.data.query.impl;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.*;

import com.citi.risk.core.dictionary.api.*;
import com.citi.risk.core.dictionary.impl.DefaultVarianceAnalysisRequest;
import com.google.common.collect.Lists;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.VarianceAnalysis;
import com.citi.risk.core.data.query.api.VarianceAnalysisResult;
import com.citi.risk.core.data.query.api.VarianceQuery;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.execution.impl.DefaultManagedExecutorService;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.compare.HistoryComparator;
import com.citi.risk.core.lang.compare.TimeMarkCompareMeasure;
import com.citi.risk.core.lang.group.Group;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;

public class DefaultVarianceQuery implements VarianceQuery{
	
	@Inject
	private ManagedExecutorService managedExecutorService;
	
	@Inject
	Configuration configuration;

	@Inject
	DictionaryParser parser;

	@Inject
	private VarianceAnalysis varianceAnalysis;
	
	private Query query;
	
	private QueryResult controlResult;

	private static final String BATCH_FREQUENCY = "Batch Frequency";
	private static final String BATCH_BD_NUMBER = "BD Number";
	private static final String FISCAL_DAY = "Fiscal Day";
	private static final String FISCAL_MONTH = "Fiscal Month";
	private static final String FISCAL_YEAR = "Fiscal Year";
	private static final String TIME_MARK = "Time mark";
	private static final String TIMEMARK_STRING = "TimeMark";

	@Override
	public <K, E extends IdentifiedBy<K>> VarianceAnalysisResult<E> query(QueryRequest<E> queryRequest) {
		Collection<VarianceAnalysisRequest<E>> varianceReuqests = createVarianceRequestsByTimeMark(queryRequest);
		int partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(varianceReuqests.size(), TaskType.VarianceParallel);
		ForkJoinTask<VarianceAnalysisResult<E>> varianceComputeTask = managedExecutorService.submit(new ComputeVarianceByTimeMarkTask<K, E>(varianceReuqests, partitionSize, configuration.getInteger("query.task.timeout", 60)));
		try {
			return varianceComputeTask.get(configuration.getInteger("query.task.timeout", 60), TimeUnit.SECONDS);
		} catch (InterruptedException | TimeoutException e) {
			if (varianceComputeTask != null) {
				varianceComputeTask.cancel(true);
			}
			throw new TaskTimeoutCancelationException("Query got cancelled because of timeout", e);
		} catch (ExecutionException e) {
			varianceComputeTask.cancel(true);
			throw new RuntimeException(e.getCause());
		}

	}

	@Override
    public <K, E extends IdentifiedBy<K>> void setControlResult(QueryResult<E> controlResult) {
        this.controlResult = controlResult;
    }

    private <E> Collection<VarianceAnalysisRequest<E>> createVarianceRequestsByTimeMark(QueryRequest<E> queryRequest) {
		Collection<VarianceAnalysisRequest<E>> vaRequests = new ArrayList<>();
		if (!CollectionUtils.isEmpty(queryRequest.getTimeMarks())) {
			vaRequests.add(buildVarianceAnalysisRequest(queryRequest, queryRequest.getTimeMarks(), queryRequest.getMovementPath()));
			return vaRequests;
		}
		Multimap<TimeMark, DataSelectionItem<E,?>> timeMarkCompareMeasureDsiMap = createTimeMarkCompareMeasureDsiMap(queryRequest);
		for (TimeMark timeMark : timeMarkCompareMeasureDsiMap.keySet()) {
			VarianceAnalysisRequest<E> varianceRequest = generateVarianceRequestByTimeMark(queryRequest, timeMark);
			varianceRequest.setControlResult(controlResult);
			varianceRequest.setMeasureItems(new ArrayList<>(timeMarkCompareMeasureDsiMap.get(timeMark)));
			vaRequests.add(varianceRequest);
		}
		return vaRequests;
	}

	protected VarianceAnalysisRequest buildVarianceAnalysisRequest(QueryRequest originalRequest,
																   List<TimeMark> timeMarks, DataPath movementPath) {
		if (timeMarks.size() != 2) {
			throw new RuntimeException("Movement only supports two cob");
		}
		TimeMark timeMark1 = timeMarks.get(0);
		TimeMark timeMark2 = timeMarks.get(1);

		// the early timeMark is for control request, the later timeMark is for nonControl request.
		TimeMark timeMarkForControlRequest = (timeMark1.compareTo(timeMark2) < 0) ? timeMark1 : timeMark2;
		TimeMark timeMarkForNonControlRequest = (timeMark1.compareTo(timeMark2) < 0) ? timeMark2 : timeMark1;
		QueryRequest controlRequest = createQueryRequestWithTimeMark(originalRequest, timeMarkForControlRequest);
		QueryRequest nonControlRequest = createQueryRequestWithTimeMark(originalRequest, timeMarkForNonControlRequest);

		VarianceAnalysisRequest vaRequest = new DefaultVarianceAnalysisRequest(controlRequest, nonControlRequest);
		List<DataSelectionItem> selectionItems = originalRequest.getDataSelection().getSelectionItems();
		List<DataSelectionItem> keyItemsForVA = Lists.newArrayList();
		List<DataSelectionItem> measureItemsForVA = Lists.newArrayList();
		for (DataSelectionItem dsi : selectionItems) {
			if (dsi.getUnderlyingPath().equals(movementPath)) {
				measureItemsForVA.add(dsi);
			} else {
				keyItemsForVA.add(dsi);
			}
		}
		vaRequest.setKeyItems(keyItemsForVA);
		vaRequest.setMeasureItems(measureItemsForVA);
		vaRequest.withDifferenceTable(false);
		return vaRequest;
	}

	private QueryRequest createQueryRequestWithTimeMark(QueryRequest originalRequest, TimeMark timeMark) {
		DataDomain domain = originalRequest.getDomain();
		DataDomain timeMarkDomain = parser.parseDomain(TimeMark.class);
		Criteria criteria = originalRequest.getCriteria();
		List<Criterion> criterionsWithoutTimeMark = getCriterionsWithoutTimeMark(criteria);
		QueryRequest resultQueryRequest = this.buildQueryRequestWithCriterion(originalRequest, criterionsWithoutTimeMark);

		DataPath timeMarkYearPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_YEAR)).path();
		DataPath timeMarkMonthPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_MONTH)).path();
		DataPath timeMarkDayPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_DAY)).path();
		DataPath timeMarkBatchFrequencyPath = domain.getRelationship(TIME_MARK)
				.append(timeMarkDomain.getItem(BATCH_FREQUENCY)).path();
		DataPath timeMarkBDNumberPath =  domain.getRelationship(TIME_MARK)
				.append(timeMarkDomain.getItem(BATCH_BD_NUMBER)).path();
		int yearParam = timeMark.getFiscalYear();
		int monthParam = timeMark.getFiscalMonth();
		int dayParam = timeMark.getFiscalDay();
		int bdNumber = timeMark.getBDNumber();
		String batchFrequency = timeMark.getBatchFrequency().name();

		resultQueryRequest.addCriteria(timeMarkYearPath.eq(yearParam));
		resultQueryRequest.addCriteria(timeMarkMonthPath.eq(monthParam));
		resultQueryRequest.addCriteria(timeMarkDayPath.eq(dayParam));
		resultQueryRequest.addCriteria(timeMarkBatchFrequencyPath.eq(batchFrequency));
		resultQueryRequest.addCriteria(timeMarkBDNumberPath.eq(bdNumber));

		return resultQueryRequest;
	}

	private List<Criterion> getCriterionsWithoutTimeMark(Criteria originalCriteria) {
		// get all the criterions without timeMark
		List<Criterion> criterionsWithoutTimeMark = Lists.newArrayList();
		Collection<Criterion<?>> allCriterion;
		if (originalCriteria != null) {
			allCriterion = originalCriteria.getAllCriterion();
			for (Criterion criterion : allCriterion) {
				if (!criterion.getDataSelectionItem().getUnderlyingPath().toPathString().contains(TIMEMARK_STRING)) criterionsWithoutTimeMark.add(criterion);
			}
		}
		return criterionsWithoutTimeMark;
	}

	private QueryRequest buildQueryRequestWithCriterion(QueryRequest queryRequest, List<Criterion> criterionsWithoutTimeMark) {
		QueryRequest newQueryRequest = queryRequest;
		DataSelection originalDataSelection = newQueryRequest.getDataSelection();
		if(originalDataSelection!=null){
			newQueryRequest = originalDataSelection.asQueryRequest();
		}
		Criteria criteria = null;
		for (Criterion criterion : criterionsWithoutTimeMark) {
			if (criteria == null) {
				criteria = criterion.criteria();
			} else {
				criteria = criteria.and(criterion.criteria());
			}
		}
		if (criteria != null) {
			newQueryRequest.addCriteria(criteria);
		}
		return newQueryRequest;
	}

	private <E> VarianceAnalysisRequest<E> generateVarianceRequestByTimeMark(QueryRequest<E> queryRequest,
			final TimeMark timeMark) {
		HistoryComparator<E> historyComparator = new HistoryComparator<E>() {
			@Override
			public TimeMark getTimeMark() {
				return timeMark;
			}

			@Override
			public String getFrequency() {
				return timeMark.getBatchFrequencyString();
			}

			@Override
			public Integer getBdNumber() {
				return timeMark.getBDNumber();
			}
			
		};
		boolean enableOuterJoin = false;
		if(configuration != null){
			enableOuterJoin = configuration.getBoolean("enable.outer.join", false);
		}
		boolean isAggregated = queryRequest.needAggregate(); 
		VarianceAnalysisRequest<E> vaRequest = historyComparator.composeVarianceAnalysisRequest(queryRequest, enableOuterJoin,isAggregated);
		return vaRequest;
	}

	private <E> Multimap<TimeMark, DataSelectionItem<E,?>> createTimeMarkCompareMeasureDsiMap(QueryRequest<E> queryRequest) {
		Multimap<TimeMark, DataSelectionItem<E,?>> timeMarkCompareMeasureMap = HashMultimap.create();
		for (DataSelectionItem<E, ?> dsi : queryRequest.getDataSelection().getSelectionItems()) {
			if (dsi.getCompareMeasure() != null) {
				TimeMarkCompareMeasure compareMeasure = (TimeMarkCompareMeasure) dsi.getCompareMeasure();
				timeMarkCompareMeasureMap.put(compareMeasure.getTimeMark(), dsi);
			}
		}
		return timeMarkCompareMeasureMap;
	}
	
	@Override
	public void setQuery(Query query) {
		this.query = query;
		this.varianceAnalysis.setQuery(query);
	}
	
	private class ComputeVarianceByTimeMarkTask<K, E extends IdentifiedBy<K>> extends RecursiveTask<VarianceAnalysisResult<E>> implements ManagedExecution {

		private static final long serialVersionUID = 1L;
		private Collection<VarianceAnalysisRequest<E>> varianceAnalysisRequests;
		private int partitionSzie = 0;
		private final int timeout;
		private final Stack<ComputeVarianceByTimeMarkTask> tasks = new Stack<>();
		
		public ComputeVarianceByTimeMarkTask(Collection<VarianceAnalysisRequest<E>> varianceAnalysisRequests, int partitionSize, final int timeout) {
			this.varianceAnalysisRequests = varianceAnalysisRequests;
			this.partitionSzie = partitionSize;
			this.timeout = timeout;
		}
		
		@Override
		public boolean cancel(boolean mayInterruptIfRunning) {
			while (!tasks.isEmpty()) {
				tasks.pop().cancel(true);
			}
			return super.cancel(mayInterruptIfRunning);
		}
		
		@Override
		protected VarianceAnalysisResult<E> compute() {
			if (CollectionUtils.isEmpty(varianceAnalysisRequests)) return null;
			if (varianceAnalysisRequests.size()<=partitionSzie) {
				return directComputeVariance();
			} else {
				Iterable<List<VarianceAnalysisRequest<E>>> subRequestsList = Iterables.partition(varianceAnalysisRequests, partitionSzie);
				List<ComputeVarianceByTimeMarkTask<K, E>> subTasks = new ArrayList<>();
				for (List<VarianceAnalysisRequest<E>> subRequests : subRequestsList) {
					ComputeVarianceByTimeMarkTask<K, E> computeVarianceByTimeMarkTask = (ComputeVarianceByTimeMarkTask<K, E>) new ComputeVarianceByTimeMarkTask<>(subRequests, partitionSzie, this.timeout).fork();
					subTasks.add(computeVarianceByTimeMarkTask);
					tasks.push(computeVarianceByTimeMarkTask);
				}
				Collection<VarianceAnalysisResult<E>> vaResults = new ArrayList<>();
				for (ComputeVarianceByTimeMarkTask<K, E> subTask : subTasks) {
					try {
						vaResults.add(subTask.get(2 * this.timeout, TimeUnit.SECONDS));
					} catch (InterruptedException e) {
						cancel(true);
						throw new RuntimeException(e);
					} catch (ExecutionException e) {
						cancel(true);
						throw new RuntimeException(e.getCause());
					} catch (TimeoutException e) {
						cancel(true);
						throw new TaskTimeoutCancelationException("ComputeVarianceByTimeMarkTask timeout", e);
					}
				}
				return mergeVarianceResults(vaResults);
			}
		}
		
		private VarianceAnalysisResult<E> directComputeVariance() {
			Collection<VarianceAnalysisResult<E>> vaResults = new ArrayList<>();
			for (VarianceAnalysisRequest<E> varianceAnalysisRequest : varianceAnalysisRequests) {
				try {
					vaResults.add(varianceAnalysis.analyze(varianceAnalysisRequest).get());
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				} catch (ExecutionException e) {
					throw new RuntimeException(e.getCause());
				} 
			}
			return mergeVarianceResults(vaResults);
		}

		private <V> VarianceAnalysisResult<E> mergeVarianceResults(Collection<VarianceAnalysisResult<E>> vaResults) {
			VarianceAnalysisResult<E> returnResult = new DefaultVarianceAnalysisResult<E>();
			
			Set<Group.Element<List<?>, E>> nonControlOnlyAggregatedResultSet = new HashSet<>();
			Set<E> nonControlOnlySearchResultSet = new HashSet<>();
			Map<E, Map<DataSelectionItem<E, ?>, CompareResult<V>>> compareResultMap = new HashMap<>();
			for (VarianceAnalysisResult<E> vaResult : vaResults) {
				nonControlOnlyAggregatedResultSet.addAll(vaResult.getNonControlOnlyAggregatedResult());
				nonControlOnlySearchResultSet.addAll(vaResult.getNonControlOnlySearchResult());
				mergeCompareResult(compareResultMap, (Map)vaResult.getComparedResult());
			}
			
			//TODO here only get first timeMark Result, If compared with multiple timeMarks, the pivotTableCell will only record the first timeMark nonControl members
			//Need to put the result into a map with <ComparedDSI, Map<List,element>>
			//Also the PivoTalbeCell.getNonControlMembers should be a map<ComparedDSI, Collection<E>>
			returnResult.setNonControlGroupMap(Iterables.getFirst(vaResults, null).getNonControlGroupMap());
			returnResult.setNonControlOnlyAggregatedResult(new ArrayList<>(nonControlOnlyAggregatedResultSet));
			returnResult.setNonControlOnlySearchResult(new ArrayList<>(nonControlOnlySearchResultSet));
			returnResult.setComparedResult((Map)compareResultMap);
			returnResult.setControlQueryResult(Iterables.getFirst(vaResults, null).getControlQueryResult());
			return returnResult;
		}

		@SuppressWarnings("rawtypes")
		private <V> void mergeCompareResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult<V>>> compareResultMap, 
				Map<E, Map<DataSelectionItem<E, ?>, CompareResult<V>>> toMergeMap) {
			for (Entry<E, Map<DataSelectionItem<E, ?>, CompareResult<V>>> entry : toMergeMap.entrySet()) {
				E e = entry.getKey();
				if (!compareResultMap.containsKey(e)) {
					Map<DataSelectionItem<E, ?>, CompareResult<V>> compareResult = toMergeMap.get(e);
					compareResultMap.put(e, compareResult);
				} else {
					Map<DataSelectionItem<E, ?>, CompareResult<V>> existedCompareResult = compareResultMap.get(e);
					Map<DataSelectionItem<E, ?>, CompareResult<V>> compareResult = toMergeMap.get(e);
					for (Entry<DataSelectionItem<E, ?>, CompareResult<V>> dsiEntry : compareResult.entrySet()) {
						existedCompareResult.put(dsiEntry.getKey(), dsiEntry.getValue());
					}
				}
			}
		}

		@Override
		public TaskType getType() {
			return TaskType.VarianceParallel;
		}

		@Override
		public String getExecutionName() {
			return "VarianceQuery";
		}

		@Override
		public String getExecutionParameters() {
			return StringUtils.EMPTY;
		}

		@Override
		public boolean isNewThread() {
			return true;
		}


	}

}
