package com.citi.risk.core.data.query.api;

import java.util.Collection;
import java.util.concurrent.Future;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;


/**
 * A representation of Query. The implementation class will have a ExecutorService
 * that handles the query submit call. 
 * 
 * <p> Caller can pass in the query request via a
 * {@link com.citi.risk.core.dictionary.api.QueryRequest QueryRequest} and get the
 * Future of  {@link com.citi.risk.core.data.query.api.QueryResult QueryResult} 
 * </p>
 *
 * @param <K> key type to lookup by
 * @param <E> value type in cache, extends IdentifiedBy of type K
 * 
 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
 * @see com.citi.risk.core.dictionary.api.QueryRequest
 * @see com.citi.risk.core.data.query.api.QueryResult
 * @see com.citi.risk.core.dictionary.api.DataDomain
 */
public interface Query 
{
	/**
	 * Takes a <code>{@link com.citi.risk.core.dictionary.api.QueryRequest }</code>
	 * as input parameter and returns a Future for  <code>{@link com.citi.risk.core.data.query.api.QueryResult}</code>  
	 * @param queryRequest query request
	 * @return
	 */
	<K, E extends IdentifiedBy<K>> Future<QueryResult<E>> submit(QueryRequest<E> queryRequest);
	

	<E extends IdentifiedBy<?>> Collection<E> getCollection(Criteria criteria);


	
	
}
