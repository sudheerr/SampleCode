package com.citi.risk.core.data.query.webservice.api;

import com.citi.risk.core.data.query.webservice.impl.DataTable;
import com.citi.risk.core.lang.table.ColumnarTable;

public interface QueryResult {

	public DataTable getDataTable();

	public ColumnarTable getColumnarTable();
	
}
