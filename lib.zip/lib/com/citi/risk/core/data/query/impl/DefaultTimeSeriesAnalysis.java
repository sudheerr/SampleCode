package com.citi.risk.core.data.query.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysis;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysisRequest;
import com.citi.risk.core.data.query.api.TimeSeriesAnalysisResult;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.DefaultSimpleTable;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.common.collect.Lists;
import com.google.inject.Inject;

public class DefaultTimeSeriesAnalysis implements TimeSeriesAnalysis {

	private static final String TIME_MARK_KEY = "TimeMark Key";
	private static final String BATCH_FREQUENCY = "Batch Frequency";
	private static final String BATCH_BD_NUMBER = "BD Number";
	private static final String FISCAL_DAY = "Fiscal Day";
	private static final String FISCAL_MONTH = "Fiscal Month";
	private static final String FISCAL_YEAR = "Fiscal Year";
	private static final String TIME_MARK = "Time mark";
	private static final String TIMEMARK_DOMAIN_NAME = "TimeMark";
	private Query query;
	private ExecutorService execService;

	@Inject
	DictionaryParser parser;

	@Inject
	public void setExecutorService(ExecutorService execService) {
		this.execService = execService;
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<TimeSeriesAnalysisResult> analyze(TimeSeriesAnalysisRequest<E> request) {

		if (query == null) {
			throw new RuntimeException("DefaultTimeSeriesAnalysisResult needs a query to do analyzing!");
		}
		return this.execService.submit(new TimeSeriesAnalysisManagedExecution(request));
	}

	private <K, E extends IdentifiedBy<K>> TimeSeriesAnalysisResult execute(TimeSeriesAnalysisRequest<E> request) {
		TimeSeriesAnalysisResult timeSeriesAnalysisResult = new DefaultTimeSeriesAnalysisResult();
		List<TimeMark> timeMarkList = request.getTimeMarks();
		QueryRequest<E> originalQueryRequest = request.getQueryRequest();
		LinkedHashMap<TimeMark, Future<QueryResult<E>>> resultWithTimeMarkMap = new LinkedHashMap<>();
		LinkedHashMap<TimeMark, QueryResult<E>> resultMap = new LinkedHashMap<>();
		QueryRequest<E> queryRequest = null;
		for (TimeMark timeMark : timeMarkList) {
			queryRequest = this.createQueryRequestWithTimeMark(timeMark, originalQueryRequest);
			resultWithTimeMarkMap.put(timeMark, query.submit(queryRequest));
		}
		
		if (queryRequest == null) return timeSeriesAnalysisResult;

		// get the dataSelection for queryResult
		DataSelection dataSelectionForResult = queryRequest.getDataSelection();

		for (Entry<TimeMark, Future<QueryResult<E>>> entry : resultWithTimeMarkMap.entrySet()) {
			QueryResult<E> queryResult = null;
			try {
				queryResult = entry.getValue().get();
			} catch (InterruptedException e) {
				throw new RuntimeException("Interrupted Exceptions trying to submit timeSeriesAnalysisRequest Requests.", e);
			} catch (ExecutionException e) {
				throw new RuntimeException("Concurrence Exceptions trying to submit timeSeriesAnalysisRequest Requests.", e);
			}
			resultMap.put(entry.getKey(), queryResult);
		}

		SimpleTable resultTable = this.combineTableFromResults(resultMap, dataSelectionForResult);
		timeSeriesAnalysisResult.setTable(resultTable);
		timeSeriesAnalysisResult.setTimeMarks(timeMarkList);
		return timeSeriesAnalysisResult;
	}

	private <K, E extends IdentifiedBy<K>> SimpleTable combineTableFromResults(LinkedHashMap<TimeMark, QueryResult<E>> resultMap, DataSelection select) {
		SimpleTable tableToReturn = DefaultSimpleTable.create();
		int rowIndex = 0;
		for (Entry<TimeMark, QueryResult<E>> entry : resultMap.entrySet()) {
			SimpleTable originalTable = entry.getValue().getTable();
			TimeMark currentTimeMark = entry.getKey();
			List<DataSelectionItem> tableColumnKeySet = select.getSelectionItems();
			DataSelectionItem timeMarkDSI = tableColumnKeySet.get(0);
			String formatedTimeMark = currentTimeMark.toString();

			if (originalTable.isEmpty()) {
				tableToReturn.put(rowIndex, timeMarkDSI, formatedTimeMark);
				for (int i = 1; i < tableColumnKeySet.size(); i++) {
					tableToReturn.put(rowIndex, tableColumnKeySet.get(i), null);
				}
				rowIndex++;
			} else {
				Map<DataSelectionItem, Object> columnValueMap = originalTable.row(0);
				for (Entry<DataSelectionItem, Object> entry1 : columnValueMap.entrySet()) {
					Object cellValue = entry1.getKey().equals(timeMarkDSI) ? formatedTimeMark : entry1.getValue();
					tableToReturn.put(rowIndex, entry1.getKey(), cellValue);
				}
				rowIndex++;
			}

		}
		return tableToReturn;
	}

	private <K, E extends IdentifiedBy<K>> QueryRequest<E> createQueryRequestWithTimeMark(TimeMark timeMark, QueryRequest<E> queryRequest) {
		DataDomain domain = queryRequest.getDomain();
		DataDomain timeMarkDomain = parser.parseDomain(TimeMark.class);

		DataPath timeMarkYearPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_YEAR)).path();
		DataPath timeMarkMonthPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_MONTH)).path();
		DataPath timeMarkDayPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(FISCAL_DAY)).path();
		DataPath timeMarkBatchFrequencyPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(BATCH_FREQUENCY)).path();
		DataPath timeMarkBDNumberPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(BATCH_BD_NUMBER)).path();
		DataPath timeMarkPath = domain.getRelationship(TIME_MARK).append(timeMarkDomain.getItem(TIME_MARK_KEY)).path();

		int yearParam = timeMark.getFiscalYear();
		int monthParam = timeMark.getFiscalMonth();
		int dayParam = timeMark.getFiscalDay();
		int bdNumber = timeMark.getBDNumber();

		String batchFrequency = timeMark.getBatchFrequency().name();

		@SuppressWarnings("unchecked")
		DataSelection<E> select = timeMarkPath.select();
		List dsiList = queryRequest.getDataSelection().getSelectionItems();
		for (Object object : dsiList) {
			// Expedient solution
			DataSelectionItem dataSelectionItem = (DataSelectionItem) object;
			if (!dataSelectionItem.getUnderlyingPath().toPathString().contains(TIMEMARK_DOMAIN_NAME)) {
				DataPath path = dataSelectionItem.getUnderlyingPath();
				DataSelection selection = path.aggregateTo(dataSelectionItem.getSelectedAggregateMeasure());
				select.and(selection);
			}
		}
		QueryRequest<E> resultQueryRequest = select.asQueryRequest();

		resultQueryRequest.addCriteria(queryRequest.getCriteria());

		resultQueryRequest.addCriteria(timeMarkYearPath.eq(yearParam));
		resultQueryRequest.addCriteria(timeMarkMonthPath.eq(monthParam));
		resultQueryRequest.addCriteria(timeMarkDayPath.eq(dayParam));
		resultQueryRequest.addCriteria(timeMarkBatchFrequencyPath.eq(batchFrequency));
		resultQueryRequest.addCriteria(timeMarkBDNumberPath.eq(bdNumber));

		return resultQueryRequest;
	}

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}

	private class TimeSeriesAnalysisManagedExecution<K, E extends IdentifiedBy<K>> implements ManagedExecution, Callable<TimeSeriesAnalysisResult> {

		private TimeSeriesAnalysisRequest<E> request;

		public TimeSeriesAnalysisManagedExecution(TimeSeriesAnalysisRequest<E> request) {
			this.request = request;
		}

		@Override
		public TimeSeriesAnalysisResult call() throws Exception {
			return execute(this.request);
		}

		@Override
		public TaskType getType() {
			return TaskType.Query;
		}

		@Override
		public String getExecutionName() {
			return "TimeSeriesAnalysis";
		}

		@Override
		public String getExecutionParameters() {
			return "";
		}

        @Override
        public boolean isNewThread() {
            return true;
        }
    }

}
