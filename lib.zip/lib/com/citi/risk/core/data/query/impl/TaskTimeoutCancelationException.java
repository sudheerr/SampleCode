package com.citi.risk.core.data.query.impl;

public class TaskTimeoutCancelationException extends RuntimeException {

    private static final long serialVersionUID = 5523273087651768338L;

    public TaskTimeoutCancelationException(String message) {
        super(message);
    }
    
    public TaskTimeoutCancelationException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
