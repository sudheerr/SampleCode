package com.citi.risk.core.data.query.api;

public class TaskExecutionRuntimeException extends RuntimeException {

    private static final long serialVersionUID = -4660817093567153910L;

    public TaskExecutionRuntimeException() {
        super();
    }

    public TaskExecutionRuntimeException(Throwable cause) {
        super(cause);
    }

}
