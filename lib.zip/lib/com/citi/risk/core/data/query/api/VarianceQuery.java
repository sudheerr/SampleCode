package com.citi.risk.core.data.query.api;

import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface VarianceQuery {
	<K, E extends IdentifiedBy<K>> VarianceAnalysisResult<E> query(QueryRequest<E> queryRequest);
	
	void setQuery(Query query);
	
	<K, E extends IdentifiedBy<K>> void setControlResult(QueryResult<E> controlResult);
}
