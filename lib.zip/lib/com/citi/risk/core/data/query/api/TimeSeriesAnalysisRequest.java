package com.citi.risk.core.data.query.api;

import java.util.List;

import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.TimeMark;

public interface TimeSeriesAnalysisRequest<E> {

	QueryRequest<E> getQueryRequest();

	List<TimeMark> getTimeMarks();
}
