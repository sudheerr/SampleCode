package com.citi.risk.core.data.query.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface SimpleQuery extends Query{

	SimpleQuery withItemsToSearch(Collection<? extends IdentifiedBy<?>> items);

	public <K, E extends IdentifiedBy<K>> QueryResult<E> execute(QueryRequest<E> queryRequest);
}