package com.citi.risk.core.data.query.impl;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.SimpleQuery;
import com.citi.risk.core.data.service.api.DataAccessService;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.data.store.impl.AnnotationBasedLoaderParser;
import com.citi.risk.core.data.store.impl.LoaderProvider;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DomainGraphPath;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.gui.api.UISession;
import com.citi.risk.core.gui.impl.DefaultSessionManager;
import com.citi.risk.core.i18n.api.I18NResourceDictionary;
import com.citi.risk.core.i18n.api.I18NResourceItem;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.security.api.SecuredBySpecification;
import com.citi.risk.core.security.api.SecurityBackend;
import com.citi.risk.core.security.api.SecurityManager;
import com.citi.risk.core.security.api.SecurityProvider;
import com.citi.risk.core.test.api.CoreTest;
import com.citi.risk.core.test.api.CoreTestDictionaryParser;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;

@Singleton
public class ManageMetaDataQuery implements Query {

	@Inject
	private LoaderQueryBean loaderQueryBean;
	@Inject
	private DomainQueryBean domainQueryBean;
	@Inject
	private ItemQueryBean itemQueryBean;
	@Inject
	private RelationshipQueryBean relationshipQueryBean;
	@Inject
	private StorerQueryBean storerQueryBean;
	@Inject
	private DomainGraphPathsQueryBean domainGraphPathsQueryBean;
	@Inject
	DomainImplQueryBean domainImplQueryBean;
	@Inject
	SecurityQueryBean securityQueryBean;
	@Inject
	I18NResourceQueryBean i18nResourceQueryBean;
	@Inject
	private CoreTestQueryBean coreTestQueryBean;
	@Inject
	private UISessionQueryBean uiSessionQueryBean;

	@Inject
	private Dictionary dictionary;

	@Override
	public <K, E extends IdentifiedBy<K>> Future<QueryResult<E>> submit(QueryRequest<E> queryRequest) {
		DataDomain domain = queryRequest.getDomain();
		Query query = getQueryByDomainClass(domain.getDomainClass());

		return query.submit(queryRequest);

	}

	@Override
	public <E extends IdentifiedBy<?>> Collection<E> getCollection(Criteria criteria) {
		DataDomain domain = criteria.getDomain();
		Query query = getQueryByDomainClass(domain.getDomainClass());

		return query.getCollection(criteria);

	}

	@SuppressWarnings("rawtypes")
	public <K> IdentifiedBy getMetaData(Class<?> domainClass, K key) {
		if (key == null)
			return null;
		IdentifiedBy rtnResult = null;

		Query query = getQueryByDomainClass(domainClass);
		if (query instanceof AbstractQuery) {
			AbstractQuery abstractQuery = (AbstractQuery) query;
			Collection<IdentifiedBy<?>> results = abstractQuery.getSearchProvider().getAll(
					dictionary.getDomain(domainClass));
			for (IdentifiedBy<?> identifiedBy : results) {
				if (key.equals(identifiedBy.key())) {
					rtnResult = identifiedBy;
					break;
				}
			}
		}

		return rtnResult;
	}

	private Query getQueryByDomainClass(Class<?> domainClass) {

		List<QueryBean> list = getQueryBeanList();
		for (QueryBean queryBean : list) {
			if (StringUtils.equals(queryBean.getDomainClass().toString(), domainClass.toString())) {
				return queryBean.getQuery();
			}
		}
		throw new RuntimeException("Domain:" + domainClass + "can not found corresponding Query.");
	}

	public Map<Class<?>, Query> getDomianQueryMap() {
		Map<Class<?>, Query> queryMap = new LinkedHashMap<>();
		List<QueryBean> list = getQueryBeanList();
		for (QueryBean queryBean : list) {
			queryMap.put(queryBean.getDomainClass(), queryBean.getQuery());
		}
		return queryMap;
	}
	
	public List<Class<?>> getSupportedQueryDomain(){
		List<Class<?>> supportedList = Lists.newArrayList();
		List<QueryBean> list = getQueryBeanList();
		for (QueryBean queryBean : list) {
			supportedList.add(queryBean.getDomainClass());
		}
		return supportedList;
	}

	private List<QueryBean> getQueryBeanList() {
		List<QueryBean> list = Lists.newArrayList();
		list.add(loaderQueryBean);
		list.add(domainQueryBean);
		list.add(itemQueryBean);
		list.add(relationshipQueryBean);
		list.add(storerQueryBean);
		list.add(domainGraphPathsQueryBean);
		list.add(securityQueryBean);
		list.add(domainImplQueryBean);
		list.add(coreTestQueryBean);
		list.add(uiSessionQueryBean);
		list.add(i18nResourceQueryBean);
		return list;
	}

	private static class LoaderQueryBean implements QueryBean {
		
		Injector injector;
		    
	    private Collection<Loader<?, ?>> loaders;
		
		@Inject
		public LoaderQueryBean(AnnotationBasedLoaderParser parser, Injector injector) {
			this.loaders = parser.parseAll();
			this.injector = injector;
		}
		
		@Override
		public Class<?> getDomainClass() {
			return Loader.class;
		}

		@Override
		public Query getQuery() {
			SimpleQuery query = injector.getInstance(SimpleQuery.class).withItemsToSearch(loaders);
	        return query;
		}
	}

	private static class DomainQueryBean implements QueryBean {
		@Inject
		private DictionaryParser dictionaryParser;

		@Override
		public Class<?> getDomainClass() {
			return DataDomain.class;
		}

		@Override
		public Query getQuery() {
			dictionaryParser.parseAllInPackage();
			return dictionaryParser.getDictionary().getDomainQuery();
		}
	}

	private static class ItemQueryBean implements QueryBean {

		@Inject
		private DictionaryParser dictionaryParser;

		@Override
		public Class<?> getDomainClass() {
			return DataItem.class;
		}

		@Override
		public Query getQuery() {
			return dictionaryParser.getDictionary().getItemsQuery();
		}
	}

	private static class RelationshipQueryBean implements QueryBean {
		@Inject
		private DictionaryParser dictionaryParser;

		@Override
		public Class<?> getDomainClass() {
			return DataRelationship.class;
		}

		@Override
		public Query getQuery() {
			return dictionaryParser.getDictionary().getRelationshipsQuery();
		}
	}

	private static class StorerQueryBean implements QueryBean {
		@Inject
		private CacheManager cacheManager;

		@Override
		public Class<?> getDomainClass() {
			return Storer.class;
		}

		@Override
		public Query getQuery() {
			return cacheManager.getStorerQuery();
		}
	}

	private static class DomainGraphPathsQueryBean implements QueryBean {
		@Inject
		private ManageDomainGraphPathsQuery manageDomainGraphPathsQuery;

		@Override
		public Class<?> getDomainClass() {
			return DomainGraphPath.class;
		}

		@Override
		public Query getQuery() {
			return manageDomainGraphPathsQuery;
		}
	}

	private static class SecurityQueryBean implements QueryBean {

		@Inject
		@SecurityBackend(securityProvider=SecurityProvider.CRAC)
		private SecurityManager securityManager;

		@Override
		public Class<?> getDomainClass() {
			return SecuredBySpecification.class;
		}

		@Override
		public Query getQuery() {
			return null;
		}
	}

	private static class DomainImplQueryBean implements QueryBean {
		@Inject
		private DomainImplParser domainImplParser;

		@Override
		public Class<?> getDomainClass() {
			return DomainImplSpecification.class;
		}

		@Override
		public Query getQuery() {
			return domainImplParser.getQuery();
		}

	}

	private static class CoreTestQueryBean implements QueryBean {
		@Inject
		private CoreTestDictionaryParser coreTestDictionaryParser;

		@Override
		public Class<?> getDomainClass() {
			return CoreTest.class;
		}

		@Override
		public Query getQuery() {
			return coreTestDictionaryParser.getQuery();
		}

	}
	
	private static class UISessionQueryBean implements QueryBean {
		@Inject
		private DefaultSessionManager defaultSessionManager;

		@Override
		public Class<?> getDomainClass() {
			return UISession.class;
		}

		@Override
		public Query getQuery() {
			return defaultSessionManager.getQuery();
		}

	}

	private static class I18NResourceQueryBean implements QueryBean {
		@Inject
		private I18NResourceDictionary i18nResourceDictionary;

		@Override
		public Class<?> getDomainClass() {
			return I18NResourceItem.class;
		}

		@Override
		public Query getQuery() {
			return i18nResourceDictionary.getResourceQuery();
		}

	}

	private interface QueryBean {

		Class<?> getDomainClass();

		Query getQuery();
	}

}
