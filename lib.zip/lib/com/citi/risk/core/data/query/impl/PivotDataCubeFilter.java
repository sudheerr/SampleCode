package com.citi.risk.core.data.query.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.citi.risk.core.data.pivot.api.PivotDataCube;
import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.Criterion.Op;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.select.ComparableSelects;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.lang.select.SelectByTransformed;
import com.google.common.base.Function;

public class PivotDataCubeFilter {
	public <E> void filterPivotDataCube(PivotDataCube<E, ?, ?, ?> cube, QueryRequest<E> queryRequest) {
		Criteria<?> furtherCriteria = queryRequest.getFurtherCriteria();
		if (furtherCriteria == null || furtherCriteria.getAllCriterion().isEmpty()) {
			return;
		}
		
		Map<DataSelectionItem, Select> dsiToSelectMap = new HashMap<>();
		for (Criterion<?> criterion : furtherCriteria.getAllCriterion()) {
			if (criterion.getDataSelectionItem().getSelectedAggregateMeasure() != null) {
				Select select = generateSelect(criterion, criterion.getDataSelectionItem().getSelectedAggregateMeasure().getResultTransform());
				dsiToSelectMap.put(criterion.getDataSelectionItem(), select);
			}
		}
		
		removePivotData(cube, dsiToSelectMap);
	}

	private <E> void removePivotData(PivotDataCube<E, ?, ?, ?> cube, Map<DataSelectionItem, Select> dsiToSelectMap) {
		Map<PivotDimensionGroup<E>, Collection<E>> dimensionGroupMap = cube.getDimensionGroupMap();
		for (Iterator<Map.Entry<PivotDimensionGroup<E>, Collection<E>>> mapEntryIterator = dimensionGroupMap.entrySet().iterator(); mapEntryIterator.hasNext();) {
			PivotDimensionGroup<E> dimensionGroup = mapEntryIterator.next().getKey();
			boolean shouldRemove = false;
			for (Map.Entry<DataSelectionItem, Select> entry : dsiToSelectMap.entrySet()) {
				DataSelectionItem dsi = entry.getKey();
				Select select = entry.getValue();
				Object value = dimensionGroup.getPivotTableCell().getValueMap().get(dsi);
				if (value != null && !select.apply(value)) {
					shouldRemove = true;
					break;
				}
			}
			if (shouldRemove) {
				mapEntryIterator.remove();
			}
		}
	}
	
	private SelectByTransformed generateSelect(Criterion criterion,
			Function transform) {
		Op op = criterion.getOP();
		Select select;
		select = ComparableSelects.getSelect(op,
				(ArrayList) criterion.getAllOperands());
		if (criterion.isNegated()) {
			select = select.not();
		}
		return new SelectByTransformed<>(select, transform);
	}
}
