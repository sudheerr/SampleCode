package com.citi.risk.core.data.query.impl;

import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang.ObjectUtils;

import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.SortBy;
import com.google.common.base.Function;
import com.google.common.collect.Ordering;

class MultiColumnsComparator<E, V> implements Comparator<E> {

	private final DataSelectionItem<E, V> sortDsi;
	private final List<DataSelectionItem<E, V>> dataSelectionItems;

	public MultiColumnsComparator(DataSelectionItem<E, V> sortDsi, List<DataSelectionItem<E, V>> dataSelectionItems) {
		this.sortDsi = sortDsi;
		this.dataSelectionItems = dataSelectionItems;
	}

	@Override
	public int compare(E left, E right) {
		int compareValue;

		int index = dataSelectionItems.indexOf(sortDsi);

		for (int i = 0; i < index; i++) {
			compareValue = subCompare(left, right, dataSelectionItems.get(i));
			if (compareValue != 0) {
				SortBy before = dataSelectionItems.get(i).getSortBy();
				SortBy current = sortDsi.getSortBy();
				if (!before.equals(current))
					compareValue = compareValue * -1;
				return compareValue;
			}
		}

		return subCompare(left, right, sortDsi);

	}

	@SuppressWarnings("unchecked")
	private int subCompare(E left, E right, DataSelectionItem<E, V> dsi) {
		V leftValue;
		V rightValue;
		int compareValue;
		Function<E, V> fromObjectToValue = (Function<E, V>) dsi.getUnderlyingPath().getTranform();
		leftValue = fromObjectToValue.apply(left);
		rightValue = fromObjectToValue.apply(right);
		if (leftValue == rightValue) {
			return 0;
		}
		if (leftValue == null) {
			return -1;
		}
		if (rightValue == null) {
			return 1;
		}
		if (Comparable.class.isAssignableFrom(leftValue.getClass())) {
			compareValue = Ordering.natural().compare((Comparable<V>) leftValue, (Comparable<V>) rightValue);
		} else {
			compareValue = Ordering.natural()
					.compare(ObjectUtils.toString(leftValue), ObjectUtils.toString(rightValue));
		}
		return compareValue;
	}

}