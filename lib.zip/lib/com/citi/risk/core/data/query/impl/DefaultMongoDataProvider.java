package com.citi.risk.core.data.query.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Tuple;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.data.query.api.MongoDataProvider;
import com.citi.risk.core.data.store.db.api.MongoDBDictionary;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.MongoCriteria;
import com.citi.risk.core.dictionary.api.MongoCriteria.MongoGroupOperator;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.impl.DefaultMongoCriteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.transform.QueryRequest2MongoCriteriaTransform;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.AggregationOptions;
import com.mongodb.Cursor;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

public class DefaultMongoDataProvider implements MongoDataProvider {
	private final String DELIMITER = "~";
	private final String ECORE_REPORTING = "ecore-reporting";
	private final String ECORE_SERVICE = "ecore-service";
			
	@Inject
    private Injector injector;
	
	@Inject
	private QueryRequest2MongoCriteriaTransform queryRequestTransform;
	
	@Inject
    private MongoDBDictionary mongoDBDictionary;
	
	@Override
	public DBCollection getDbCollection(DataDomain domain) {
		String schemaName = getSchemaName(domain);
		String collectionName = getCollectionName(domain);
		return getDBCollectionBySchema(schemaName, collectionName);
	}
	
	private DBCollection getDBCollectionBySchema(String schemaName, String collectionName)
    {
        return mongoDBDictionary.getDB(schemaName).getCollection(collectionName);
    }
	
	private String getCollectionName(DataDomain domain) {
		return domain.getName();
	}
	
	private String getSchemaName(DataDomain domain) {
		return domain.isReportOnly() ? ECORE_REPORTING : ECORE_SERVICE;
	}
	
	@Override
	public <E extends IdentifiedBy<?>> Collection<Tuple> find(QueryRequest<E> queryRequest) {
		DataDomain domain = queryRequest.getDomain();
		
		MongoCriteria<E> mongoCriteria = queryRequestTransform.apply(queryRequest);
		
		Integer pageIndex = mongoCriteria.getPageIndex();
		Integer pageSize = mongoCriteria.getPageSize();
		
		DBObject groupByObject = mongoCriteria.getGroupByObject();
		DBObject matchObject = mongoCriteria.getMatchObject();
		DBObject sortObject = mongoCriteria.getSortObject();
		
		if (mongoCriteria.needGroupBy()) {
			DBObject limitObject = mongoCriteria.getGroupByLimitObject();
			DBObject skipObject = mongoCriteria.getGroupBySkipObject();
			List<DBObject> groupOps = Arrays.asList(matchObject, groupByObject, sortObject, skipObject, limitObject);
			
			List<DBObject> groupPipeline = buildGroupOperations(groupOps);
			Cursor aggCursor = groupWithMongoAggregate(domain, groupPipeline, mongoCriteria.getPageSize());
			return convertToTupleCollectionForGroupResult(aggCursor, mongoCriteria, queryRequest);
		} else {
			DBObject keys = mongoCriteria.getProjectFields();
			
			DBCursor resultCursor;
			if (!isValidDBOBject(sortObject)) {
				resultCursor = getDbCollection(domain).find(matchObject, keys);
			} else {
				resultCursor = getDbCollection(domain).find(matchObject, keys).sort(sortObject);
			}
			resultCursor.skip((pageIndex - 1) * pageSize);
			resultCursor.batchSize(pageSize);
			resultCursor.limit(pageSize);
			return convertToTupleCollection(resultCursor, queryRequest);
		}
	}
	
	private <E extends IdentifiedBy<?>> Collection<Tuple> convertToTupleCollection(DBCursor resultCursor, QueryRequest<E> queryRequest) {
		String[] returnAliases = getReturnAliases(queryRequest);
		Class<?>[] returnAliasesType = getReturnAliasesType(queryRequest);
		
		List<Object> tupleRow = Lists.newArrayList();
		List<Tuple> rtnObjects = Lists.newArrayList();
		while (resultCursor.hasNext()) {
			DBObject dbObject = resultCursor.next();
			for (String aliase : returnAliases) {
				String columnName = getMongoResultColumnName(aliase);
				tupleRow.add(dbObject.get(columnName));
			}
			rtnObjects.add(new TupleImpl(tupleRow.toArray(), returnAliases, returnAliasesType));
			tupleRow.clear();
		}
		resultCursor.close();
		
		return rtnObjects;
	}
	
	private void addByAggMeasureCol(List<Object> tupleRow, DBObject dbObject, String aggMeasureColumnName) {
		if (!StringUtils.equals(aggMeasureColumnName, StringUtils.EMPTY)) {
			// aggregation measure field
			Object object = dbObject.get(aggMeasureColumnName);
			tupleRow.add(object);
		}
	}
	
	private <E extends IdentifiedBy<?>> Collection<Tuple> convertToTupleCollectionForGroupResult(Cursor aggCursor, MongoCriteria<E> mongoCriteria, QueryRequest<E> queryRequest) {
		DBObject groupByObject = mongoCriteria.getGroupByObject();
		
		String[] mongoAggFields = getFieldsWithAggregation(groupByObject);
		String[] mongoGroupByFields = getGroupByFieldsName(groupByObject);
		
		List<Tuple> rtnTuples = Lists.newArrayList();
		List<Object> tupleRow = Lists.newArrayList();
		
		String[] returnAliases = getReturnAliases(queryRequest);
		Class<?>[] returnAliasesType = getReturnAliasesType(queryRequest);
		
		while (aggCursor.hasNext()) {
			DBObject dbObject = aggCursor.next();
			for (String aliase : returnAliases) {
				String columnName = getMongoResultColumnName(aliase);
				
				if (ArrayUtils.contains(mongoGroupByFields, columnName)) {
					// group by field
					Object valueForGroupField = getValueForGroupField(dbObject, columnName);
					tupleRow.add(valueForGroupField);
				} else {
					String aggMeasureColumnName = getAggMeasureColumnName(columnName, mongoAggFields);
					addByAggMeasureCol(tupleRow, dbObject, aggMeasureColumnName); 
				}
				
			}
			rtnTuples.add(new TupleImpl(tupleRow.toArray(), returnAliases, returnAliasesType));
			tupleRow.clear();
		}
		aggCursor.close();
		
		return rtnTuples;
	}
	
	private String getAggMeasureColumnName(String aliase, String[] aggMeasureFieldsName) {
		for (String name : aggMeasureFieldsName) {
			if (aliase.startsWith(name)) {
				return name;
			}
		}
		return StringUtils.EMPTY;
	}
	
	private Object getValueForGroupField(DBObject dbObject, String fieldName) {
		DBObject groupKeyObject = (DBObject)dbObject.get(DefaultMongoCriteria.GROUP_BY_KEY_NAME);
		return groupKeyObject.get(fieldName);
	}
	
	private String getMongoResultColumnName(String alias) {
		String[] split = alias.split(DELIMITER);
		return split[0];
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String[] getFieldsWithAggregation(DBObject groupObject) {
		List<String> fields = Lists.newArrayList();
		
		DBObject groupFields = (DBObject)groupObject.get(MongoGroupOperator.Group.getOperator());
		
		Map map = groupFields.toMap();
		Set<String> keySet = map.keySet();
		for (String key : keySet) {
			if (!DefaultMongoCriteria.GROUP_BY_KEY_NAME.equals(key)) {
				fields.add(key);
			}
		}
		
		return fields.toArray(new String[0]);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String[] getGroupByFieldsName(DBObject groupObject) {
		DBObject groupByObject = (DBObject)groupObject.get(MongoGroupOperator.Group.getOperator());
		
		Map map = groupByObject.toMap();
		Set<String> keySet = map.keySet();
		for (String key : keySet) {
			if (DefaultMongoCriteria.GROUP_BY_KEY_NAME.equals(key)) {
				DBObject groupByKeyObject = (DBObject)groupByObject.get(DefaultMongoCriteria.GROUP_BY_KEY_NAME);
				return (String[])groupByKeyObject.toMap().keySet().toArray(new String[0]);
			}
		}
		
		return ArrayUtils.EMPTY_STRING_ARRAY;
	}
	
	private <E extends IdentifiedBy<?>> Class<?>[] getReturnAliasesType(QueryRequest<E> queryRequest) {
		List<Class<?>> types = Lists.newArrayList();
		DataSelection<E> dataSelection = queryRequest.getDataSelection();
		List<DataSelectionItem<E,?>> selectionItems = dataSelection.getSelectionItems();
		for (DataSelectionItem<E, ?> item : selectionItems) {
			types.add(item.getUnderlyingPath().getTerminatingItem().getJavaSimpleType());
		}
		return types.toArray(new Class<?>[0]);
	}
	
	private <E extends IdentifiedBy<?>> String[] getReturnAliases(QueryRequest<E> queryRequest) {
		List<String> aliases = Lists.newArrayList();
		DataSelection<E> dataSelection = queryRequest.getDataSelection();
		List<DataSelectionItem<E,?>> selectionItems = dataSelection.getSelectionItems();
		for (DataSelectionItem<E, ?> item : selectionItems) {
			aliases.add(item.toString());
		}
		return aliases.toArray(new String[0]);
	}
	
	private boolean isValidDBOBject(DBObject dbObject) {
		return dbObject != null && !dbObject.keySet().isEmpty();
			
	}
	
	private List<DBObject> buildGroupOperations(List<DBObject> groupOps) {
		List<DBObject> operations = Lists.newArrayList();
		
		for (DBObject dbObject : groupOps) {
			if (isValidDBOBject(dbObject)) {
				operations.add(dbObject);
			}
		}
		return operations;
	}
	
	private Cursor groupWithMongoAggregate(DataDomain domain, List<DBObject> groupPipleLine, int batchSize) {
		// mongo support cursor in version 2.6, may have better performance when using cursor, right now use default inline
		AggregationOptions aggregationOptions = AggregationOptions.builder()
		        .batchSize(batchSize)
		        .outputMode(AggregationOptions.OutputMode.INLINE)
		        .build();
		
		Cursor aggregateCursor = getDbCollection(domain).aggregate(groupPipleLine, aggregationOptions);
		return aggregateCursor;
	}


}
