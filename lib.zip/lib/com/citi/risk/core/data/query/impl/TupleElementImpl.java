package com.citi.risk.core.data.query.impl;

import javax.persistence.TupleElement;

public class TupleElementImpl<X> implements TupleElement<X> {
	private final int position;
	private final String alias;
	private Class<?> clazz;
	
	public TupleElementImpl(int position, String alias, Class<?> clazz) {
		this.position = position;
		this.alias = alias;
		this.clazz = clazz;
	}

	@Override
	public Class getJavaType() {
		return clazz;
	}

	@Override
	public String getAlias() {
		return alias;
	}

	public int getPosition() {
		return position;
	}
	
	@Override
	public String toString() {
		return new StringBuilder().append("TupleElement : [").append("alias:").append(this.alias)
				.append(", class: ").append(this.clazz)
				.append(", position: ").append(this.position)
				.append("]").toString();
	}
}
