package com.citi.risk.core.data.query.impl;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.persistence.Tuple;
import javax.persistence.TupleElement;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@SuppressWarnings("rawtypes")
public class TupleImpl implements Tuple {
	private Object[] tuple;
	private Map<String, TupleElement> tupleElementsByAlias;
	private List<TupleElement<?>> tupleElements;
	private String[] aliases;
	private Class[] aliaseTypes;
	
	public TupleImpl(Object[] tuple, String[] aliases, Class[] aliaseTypes) {
		this.tuple = tuple;
		this.aliases = aliases;
		this.aliaseTypes = aliaseTypes;
		
		init();
	}

	private void init() {
		final boolean hasAliases = aliases != null && aliases.length > 0;
		
		tupleElements = Lists.newArrayList();
		tupleElementsByAlias = Collections.<String, TupleElement>emptyMap();
		if (hasAliases) {
			tupleElementsByAlias = Maps.newHashMap();
		} else return; 
		
		for (int i = 0; i < aliases.length; i++) {
			TupleElementImpl<Object> mongoTupleElementImpl = new TupleElementImpl<>(i, aliases[i], aliaseTypes[i]);
			
			tupleElements.add(mongoTupleElementImpl);
			tupleElementsByAlias.put(aliases[i], mongoTupleElementImpl);
		}
	}

	@Override
	public <X> X get(String alias, Class<X> type) {
		return (X) get( alias );
	}

	@Override
	public Object get(String alias) {
		TupleElementImpl tupleElement = (TupleElementImpl)tupleElementsByAlias.get( alias );
		if ( tupleElement == null ) {
			throw new IllegalArgumentException( "Unknown alias [" + alias + "]" );
		}
		return tuple[ tupleElement.getPosition() ];
	}

	@Override
	public <X> X get(int i, Class<X> type) {
		return (X) get( i );
	}

	@Override
	public Object get(int i) {
		if ( i < 0 ) {
			throw new IllegalArgumentException( "requested tuple index must be greater than zero" );
		}
		if ( i > tuple.length ) {
			throw new IllegalArgumentException( "requested tuple index exceeds actual tuple size" );
		}
		return tuple[i];
	}

	@Override
	public Object[] toArray() {
		// todo : make a copy?
		return tuple;
	}

	@Override
	public List<TupleElement<?>> getElements() {
		return tupleElements;
	}

	@Override
	public <X> X get(TupleElement<X> tupleElement) {
		if ( TupleElementImpl.class.isInstance( tupleElement ) ) {
			return get( ( (TupleElementImpl) tupleElement ).getPosition(), tupleElement.getJavaType() );
		}
		else {
			return get( tupleElement.getAlias(), tupleElement.getJavaType() );
		}
	}
	
	@Override
	public String toString() {
		return new StringBuilder().append(getElements()).toString();
	}
}