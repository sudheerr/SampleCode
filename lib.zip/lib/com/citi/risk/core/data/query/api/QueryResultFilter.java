package com.citi.risk.core.data.query.api;

import com.citi.risk.core.dictionary.api.QueryRequest;

/**
 * Provide the method to filter Query Result besides the normal search result filter
 * 
 * @author hl80973
 * 
 */
public interface QueryResultFilter {

	<E> void filterQueryResult(QueryRequest<E> queryRequest, QueryResult<E> queryResult);

}