package com.citi.risk.core.data.query.impl;

import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.query.api.DataAccessQuery;
import com.citi.risk.core.data.query.api.QueryHelper;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.service.api.DataAccessService;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.inject.Inject;

public class DefaultQueryHelper implements QueryHelper {

	@Inject
	private DataAccessQuery query;

	@Inject
	private DataAccessService dataAccessService;

	@Override
	public <D> OngoingQueryStatment<D> select(DataPath<D, ?>... paths) {
		DefaultOngoingQueryStatment<D> statement = new DefaultOngoingQueryStatment<>();
		statement.paths = paths;
		return statement;
	}
	

	@Override
	public <D> OngoingQueryStatment<D> select(DataSelection<D>... dataSelections) {
		DefaultOngoingQueryStatment<D> statement = new DefaultOngoingQueryStatment<>();
		statement.dataSelections = dataSelections;
		return statement;
	}

	
	@Override
	public OngoingQueryStatment selectFrom(Class domainImplClass) {
		DefaultOngoingQueryStatment statement = new DefaultOngoingQueryStatment();
		statement.domainImplClass = domainImplClass;
		return statement;
	}

	

	public class DefaultOngoingQueryStatment<D> implements OngoingQueryStatment<D> {
		private QueryRequest queryRequest;
		private Criteria<D> criteria;
		private Integer topCount;
		private Class<? extends D> domainImplClass;
		private DataSelection<D> sortBySelection;
		private DataPath<D, ?>[] paths;
		protected DataSelection<D>[] dataSelections;

		DefaultOngoingQueryStatment(DataPath<D, ?>[] paths) {
			if (paths == null || paths.length == 0)
				throw new IllegalArgumentException("Given path array has to be not empty!");
			this.paths = paths;
		
		}

		DefaultOngoingQueryStatment() {
		}

		@Override
		public OngoingQueryStatment<D> from(Class<? extends D> clzz) {
			this.domainImplClass = clzz;
			return this;
		}

		@Override
		public OngoingQueryStatment<D> where(Criteria<D> criteria) {
			if (this.criteria == null)
				this.criteria = criteria;
			else
				this.criteria.and(criteria);
			return this;
		}

		@Override
		public OngoingQueryStatment<D> top(int topCount) {
			this.topCount = topCount;
			return this;

		}

		@Override
		public OngoingQueryStatment<D> orderBy(DataPath<D, ?> path, SortBy sorby) {
			this.sortBySelection = path.sortBy(sorby);
			return this;
		}

		@Override
		public Collection<D> queryDomains() {
			QueryResult<D> queryResult = this.executeQuery();
			return queryResult.getSearchResult();
		}
		
		@Override
		public Collection<D> queryDomainsForUpdate() {
			QueryResult<D> queryResult = this.executeQuery();
			Collection searchResult = queryResult.getSearchResult();
			try {
				return (Collection<D>) dataAccessService.makeDeepCopy(searchResult).get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException("DeepCopy collection failed!", e);
			}
		}


		@Override
		public SimpleTable queryTable() {
			QueryResult<D> queryResult = this.executeQuery();
			return queryResult.getTable();
		}
		
		@Override
		public QueryRequest<D> toQueryRequest() {
			return this.instantiateQueryRequest();
		}

		
		private QueryResult<D> executeQuery() {
			populateQueryRequestWithParams();
			Future<QueryResult<D>> querySubmitFuture = query.submit(queryRequest);
			try {
				return querySubmitFuture.get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException("Failed to execute query due to exception: " + e);
			}
		}

		private void populateQueryRequestWithParams() {
			QueryRequest<D> _queryRequest = instantiateQueryRequest();
			if (this.criteria != null)
				_queryRequest.addCriteria(this.criteria);
			if (this.topCount != null)
				_queryRequest.setMaxRowCount(this.topCount);
			if (this.domainImplClass != null)
				_queryRequest.getCriteria().setDomainImplClass(this.domainImplClass);
			if (this.sortBySelection != null)
				_queryRequest.addSelect(sortBySelection);
		}

		private QueryRequest<D> instantiateQueryRequest() {
			DataSelection<D> dataSelection = getDataSelection();
			this.queryRequest = dataSelection.asQueryRequest();
			return queryRequest;
		}

		private DataSelection<D> getDataSelection() {
			if (this.paths != null && this.paths.length > 0) {
				return convertPathsIntoDataSelection(paths);
			}
			else if (this.dataSelections != null && this.dataSelections.length > 0) {
				return mergeDataSelections(this.dataSelections);
			}
			else if (this.criteria != null && !this.criteria.getAllCriterion().isEmpty()) {
				//if no path is given, then any path to start a query would be OK
				Criterion<D> firstCriterion = this.criteria.getCriterion(0);
				DataPath firstCriterionPath = firstCriterion.getDataSelectionItem().getUnderlyingPath();
				return firstCriterionPath.select();
			} else {
				throw new RuntimeException("QueryHelper can not query without any given Path or Criteria!");
			}
		}

		private DataSelection<D> mergeDataSelections(DataSelection<D>[] dataSelections) {
			DataSelection<D> dataSelection = dataSelections[0];
			for(int i = 1; i < dataSelections.length; i++) {
				dataSelection.and(dataSelections[i]);
			}
			return dataSelection;
		}

		private DataSelection<D> convertPathsIntoDataSelection(DataPath<D, ?>[] paths) {
			DataSelection<D> dataSelection = null;
			for (DataPath<D, ?> path : paths) {
				if (dataSelection == null)
					dataSelection = path.select();
				else
					dataSelection.and(path.select());
			}
			return dataSelection;
		}

	}

}
