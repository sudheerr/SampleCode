package com.citi.risk.core.data.query.impl;

import java.util.List;
import java.util.Set;

import com.citi.risk.core.data.query.api.DataAccessQuery;
import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.service.api.DataAccessService;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.inject.Inject;

public class DataCachesQuery extends AbstractQuery implements DataAccessQuery {
	@Inject
	private DataAccessService dataAccessor;

	@Override
	public final SearchProvider getSearchProvider() {
		return dataAccessor;
	}


	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.dataAccessor = (DataAccessService)searchProvider;
	}

	@Override
	public <K, E extends IdentifiedBy<K>> E get(DataDomain domain, K key) {
		return (E) dataAccessor.get(domain, key);
	}

	@Override
	public <K, E extends IdentifiedBy<K>> List<E> get(DataDomain domain, List<K> keys) {
		return dataAccessor.get(domain, keys);
	}

	@Override
	public Set<DataKey> searchDataAvailabilities() {
		return dataAccessor.searchDataAvailabilities();
	}

	@Override
	public Set<DataKey> searchDataAvailabilities(TimeMark timeMark) {
		return dataAccessor.searchDataAvailabilities(timeMark);
	}
}
