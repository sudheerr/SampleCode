package com.citi.risk.core.data.query.webservice.impl;

import java.util.ArrayList;
import java.util.List;

public class DataTable {
	private List<String> columnNames = new ArrayList();
	private List<String> columnPaths = new ArrayList();
	private List<String> columnTypes = new ArrayList();
	private List<DataRow> dataRows = new ArrayList();
	
	public List<String> getColumnNames() {
		return columnNames;
	}
	
	public void setColumnNames(List<String> columnNames) {
		this.columnNames = columnNames;
	}
	
	public List<String> getColumnPaths() {
		return columnPaths;
	}
	
	public void setColumnPaths(List<String> columnPaths) {
		this.columnPaths = columnPaths;
	}

	public List<DataRow> getDataRows() {
		return dataRows;
	}
	
	public void setDataRows(List<DataRow> list) {
		this.dataRows = list;
	}

	public List<String> getColumnTypes() {
		return columnTypes;
	}

	public void setColumnTypes(List<String> columnTypes) {
		this.columnTypes = columnTypes;
	}

}
