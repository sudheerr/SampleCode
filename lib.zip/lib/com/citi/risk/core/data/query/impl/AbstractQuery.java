package com.citi.risk.core.data.query.impl;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.Tuple;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;
import org.supercsv.util.Util;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.pivot.api.PivotDataCube;
import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.data.pivot.impl.AllPivotDimensions;
import com.citi.risk.core.data.pivot.impl.DefaultPivotDataCube;
import com.citi.risk.core.data.pivot.impl.DefaultPivotTable;
import com.citi.risk.core.data.pivot.impl.DefaultPivotTableDataColumnComparator;
import com.citi.risk.core.data.pivot.impl.PivotDimensionsFactory;
import com.citi.risk.core.data.pivot.impl.PivotTableCell;
import com.citi.risk.core.data.pivot.impl.PivotTableChildTree;
import com.citi.risk.core.data.pivot.impl.PivotTableSortAndPaginationTask;
import com.citi.risk.core.data.pivot.impl.PivotTableSortGroup;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.proxy.api.InvocationType;
import com.citi.risk.core.data.proxy.impl.QueryInvocationCallable;
import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.MongoDataProvider;
import com.citi.risk.core.data.query.api.PivotQueryResult;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.QueryResultFilter;
import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.query.api.VarianceAnalysis;
import com.citi.risk.core.data.query.api.VarianceAnalysisResult;
import com.citi.risk.core.data.query.api.VarianceQuery;
import com.citi.risk.core.data.query.webservice.impl.DataRow;
import com.citi.risk.core.data.query.webservice.impl.DataTable;
import com.citi.risk.core.data.service.impl.DefaultDataAccessService;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.impl.DefaultDataKey;
import com.citi.risk.core.dictionary.api.AggregateInfo;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DDType;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.GroupBy;
import com.citi.risk.core.dictionary.api.ItemList;
import com.citi.risk.core.dictionary.api.PathBasedGroup;
import com.citi.risk.core.dictionary.api.PivotQueryRequest;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.api.RollUp;
import com.citi.risk.core.dictionary.api.RollUpItem;
import com.citi.risk.core.dictionary.impl.AggregateOnPath;
import com.citi.risk.core.dictionary.impl.AggregationOnlyGroup;
import com.citi.risk.core.dictionary.impl.DefaultPathBasedGroup;
import com.citi.risk.core.dictionary.impl.DefaultPivotQueryRequest;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.aggregate.AggregateFactory;
import com.citi.risk.core.lang.aggregate.Aggregator;
import com.citi.risk.core.lang.aggregate.Evaluator;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.compare.QueryComparator;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.AbstractGroup.DefaultElement;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.lang.table.ColumnarResults;
import com.citi.risk.core.lang.table.ColumnarTable;
import com.citi.risk.core.lang.table.SimpleTable;
import com.citi.risk.core.security.api.SecurableDictionary;
import com.citi.risk.core.security.api.SecurityRealm;
import com.citi.risk.core.security.api.User;
import com.citi.risk.core.security.api.UserSecurityService;
import com.citi.risk.core.security.impl.SecurityUtil;
import com.citi.risk.core.util.TimeMarkConvertor;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.inject.Inject;

@SuppressWarnings({ "unchecked", "rawtypes" })
public abstract class AbstractQuery implements Query {

	private ExecutorService execService;
	private AggregateFactory aggregateFactory;
	@Inject
	private Logger logger;
	private static final String HEADER_NAME_SEPERATOR = ">";

	@Inject
	protected Configuration configuration;
	
	@Inject
	UserSecurityService userSecurityService;

	@Inject
	VarianceAnalysis varianceAnalysis;

	@Inject
	private DictionaryParser dictionaryParser;
	
	@Inject
	SecurableDictionary securableDictionary;
	
	@Inject
	ManagedExecutorService managedExecutorService;

	@Inject
	private MongoDataProvider mongoDataProvider;
	
	@Inject
	CacheManager cacheManager;
	
	@Inject
	DomainImplParser domainImplParser;
	
	@Inject
    VarianceQuery varianceQuery;

	public abstract SearchProvider getSearchProvider();

	public abstract void setSearchProvider(SearchProvider searchProvider);

	@Inject
	public void setExecutorService(ExecutorService execService) {
		this.execService = execService;
	}

	@Inject
	public void setAggregateFactory(AggregateFactory aggregateFactory) {
		this.aggregateFactory = aggregateFactory;
	}

	@InfraInvocation(type = InvocationType.Query, callable = QueryInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> QueryResult<E> execute(QueryRequest<E> queryRequest) {
		
		filterSecureDataPaths(queryRequest);

		if (queryRequest.isPivotQueryRequest()) {
			return populatePivotResult(createPivotQueryRequest(queryRequest));
		}
		
		DefaultQueryResult<E> queryResult = new DefaultQueryResult<>();
	
		populateSearchResult(queryRequest, queryResult);
		
		populateAggregatedResult(queryRequest, queryResult);

		populateVarianceResult(queryRequest, queryResult);

		populateFilteredResult(queryRequest, queryResult);

		populateGroupByResult(queryRequest, queryResult);

		populateRollupResult(queryRequest, queryResult);

		populateSortedAndPaginatedResult(queryRequest, queryResult);

		populateSimpleTable(queryRequest, queryResult);

		populateSimpleResultSet(queryRequest, queryResult);
		
		generateExcelFile(queryRequest, queryResult);

		generateWebServiceTable(queryRequest, queryResult);

		generateColumnarResults(queryRequest, queryResult);
		
		return queryResult;
	}

	@InfraInvocation(type = InvocationType.Query)
	public <K, E extends IdentifiedBy<K>> QueryResult<E> populatePivotResult(PivotQueryRequest<E> pivotQueryRequest) {
		DefaultPivotQueryResult pivotQueryResult = new DefaultPivotQueryResult(pivotQueryRequest.getRowDimension(), pivotQueryRequest.getColumnDimension(), pivotQueryRequest.getAggregateMeasure());
		populateSearchResult(pivotQueryRequest, pivotQueryResult);
		DefaultPivotDataCube cube = populatePivotDataCube(pivotQueryRequest, pivotQueryResult);
		populateVarianceResultByPivotCube(cube, pivotQueryRequest, pivotQueryResult);
		populatePivotTable(pivotQueryRequest, pivotQueryResult, cube);
		return pivotQueryResult;
	}

	private DefaultPivotDataCube populatePivotDataCube(PivotQueryRequest pivotQueryRequest,
			DefaultPivotQueryResult pivotQueryResult) {
		int groupMaxNum = 50000;
		int timeout = 60;
		if(configuration != null){
			groupMaxNum = configuration.getInteger("aggregation.group.maxnum", 50000);
			timeout = configuration.getInteger("query.task.timeout", 60);
		}
		DefaultPivotDataCube cube = new DefaultPivotDataCube(aggregateFactory, pivotQueryRequest, pivotQueryResult.getSearchResult(), groupMaxNum, timeout);
		cube.populateDataCube();
		PivotDataCubeFilter cubeFilter = new PivotDataCubeFilter();
		cubeFilter.filterPivotDataCube(cube, pivotQueryRequest);
		return cube;
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void populateFilteredResult(QueryRequest<E> queryRequest,
																	   QueryResult<E> queryResult) {
		QueryResultFilter queryResultFilter = new QueryResultFilterImpl();
		queryResultFilter.filterQueryResult(queryRequest, queryResult);
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void populateRollupResult(QueryRequest<E> queryRequest,
																	 QueryResult<E> queryResult) {
		List<Evaluator<E, ?>> evaluators = Lists.<Evaluator<E, ?>>newArrayList();
		RollUp rollUp = queryRequest.getRollUp();
		if (rollUp == null || rollUp.getAllRollUpItems().isEmpty()) {
			return;
		}

		PathBasedGroup<E> group;
		List<DataSelectionItem<E, ?>> dataSelectionItems = queryRequest.getDataSelection().getSelectionItems();
		for (DataSelectionItem<E, ?> dataSelectionItem : dataSelectionItems) {
			DataPath underlyingPath = dataSelectionItem.getUnderlyingPath();
			AggregateMeasure<?, ?> aggregateMeasure = dataSelectionItem.getSelectedAggregateMeasure();

			if (aggregateMeasure != null) {
				AggregateInfo<?> aggregateInfo = aggregateMeasure.getAggregateInfo();
				int size = 0;
				if (underlyingPath.getDDType() == DDType.ITEMLIST) {
					size = ((ItemList) underlyingPath.getTerminatingItem()).getSize();
				}
				Aggregator aggregateObject = (Aggregator<E, ?>) aggregateFactory.getAggregate(aggregateInfo, size);
				Aggregator<E, ?> aggregate = new AggregateOnPath(dataSelectionItem, aggregateObject);
				evaluators.add((Evaluator) aggregate);
			}

		}

		if (evaluators.isEmpty()) {
			return;
		}

		List<RollUpItem> rollUpItems = rollUp.getAllRollUpItems();
		group = new DefaultPathBasedGroup<>();
		group.setEvaluators(evaluators);

		int groupIndex = 0;
		for(RollUpItem rollUpItem : rollUpItems) {
			for (DataSelectionItem dsi : rollUpItem.getAllSelectionItems()) {
				queryResult.addPathToGroupIndex(dsi, groupIndex);
				groupIndex++;
			}
		}

		for (int i=1; i <= rollUpItems.size(); i++) {
			PathBasedGroup<E> subGroup = (PathBasedGroup<E>) populateGroup(rollUpItems.subList(0, i));
			subGroup.setEvaluators(evaluators);
			group.furtherGroupBy(subGroup);
		}

		int groupMaxNum = 50000;
		if(configuration != null){
			groupMaxNum = configuration.getInteger("aggregation.group.maxnum", 50000);
		}
		queryResult.setRollupResult(group.group(queryResult.getSearchResult(),groupMaxNum));
	}

	private PathBasedGroup<?> populateGroup(List<RollUpItem> rollUpItems) {
		PathBasedGroup<?> group = null;
		for (RollUpItem rollUpItem : rollUpItems) {
			for(DataSelectionItem<?, ?> dsi : rollUpItem.getAllSelectionItems()){
				if (group == null) {
					group = dsi.getUnderlyingPath().getGroup();
				} else {
					group.add(dsi.getUnderlyingPath());
				}
			}
		}
		return group;
	}

	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateVarianceResult(QueryRequest<E> queryRequest, QueryResult<E> queryResult) {
	    if (!queryRequest.needVariance()) return;
	    
	    varianceQuery.setQuery(this);
	    varianceQuery.setControlResult(queryResult);
        VarianceAnalysisResult<E> varianceResult = varianceQuery.query(queryRequest);
		
        setVarianceResult(queryResult, varianceResult);
	}

    private <K, E extends IdentifiedBy<K>> void setVarianceResult(QueryResult<E> queryResult, VarianceAnalysisResult<E> varianceResult) {
        Collection<Element<List<?>, E>> aggregatedResult = queryResult.getAggregedResult();
        Collection<E> searchResult = queryResult.getSearchResult();
		queryResult.setNonControlOnlySearchResult(varianceResult.getNonControlOnlySearchResult());
		
		Set<List<String>> nonControlOnlyGroupKeys = new HashSet<>();
        for (Element<List<?>, E> element : varianceResult.getNonControlOnlyAggregatedResult()) {
            List<String> group = (List<String>) element.getGroup();
            group.add(varianceResult.getTargetTimeMarkKeyString());
            nonControlOnlyGroupKeys.add(group);
        }
        queryResult.setNonControlOnlyGroupKeys(nonControlOnlyGroupKeys);
        
		if (varianceResult.getComparedResult() != null)
			queryResult.setComparedResult((Map<E, Map<DataSelectionItem<E, ?>, CompareResult>>)(Map)varianceResult.getComparedResult());
		if (varianceResult.getNonControlGroupMap() != null) {
			((DefaultQueryResult)queryResult).setNonControlGroupMap(varianceResult.getNonControlGroupMap());
		}
		if (aggregatedResult != null)
			aggregatedResult.addAll((Collection<Element<List<?>, E>>)(Collection)varianceResult.getNonControlOnlyAggregatedResult());
		if(searchResult != null)
			searchResult.addAll(varianceResult.getNonControlOnlySearchResult());
    }
	
	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateVarianceResultByPivotCube(PivotDataCube cube, QueryRequest<E> queryRequest, QueryResult<E> queryResult) {
		populateAggregatedResultUsingPivot(queryRequest, queryResult, cube);
		populateVarianceResult(queryRequest, queryResult);
		queryResult.setAggregatedResult(null);
	}
	

	private <K, E extends IdentifiedBy<K>> QueryComparator<E> createResultComparator(DataSelectionItem<E, ?> dsi,
																					 DictionaryParser dictionaryParser) {
		QueryComparator<E> comparator;
		try {
			comparator = dsi.getCompareMeasure().createComparator();
			comparator.setDictionaryParser(dictionaryParser);
		} catch (Exception e) {
			logger.log(Level.INFO, "Got Exception while trying to create QueryComparator" + e.getMessage());
			throw new RuntimeException(e);
		}
		return comparator;
	}
	
	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void generateColumnarResults(QueryRequest<E> queryRequest,
																		QueryResult<E> queryResult) {
		if (!queryRequest.isGenerateColumnarResults()) return;

		// TODO: ADD CORRECT REPORT NAME
		ColumnarTable columnarTable = new ColumnarTable("ReportName");

		ArrayList<List> keyColumnValues = new ArrayList<>();
		for (DataSelectionItem dataSelectionItem : queryRequest.getDataSelection().getSelectionItems()) {
			if (dataSelectionItem.isKeyDataSelectionItem())
				keyColumnValues.add(queryResult.toValues(dataSelectionItem));
		}

		StringBuilder keyColumnValuesForThisRow;
		for (DataSelectionItem dsi : queryRequest.getDataSelection().getSelectionItems()) {
			if (dsi.isKeyDataSelectionItem()) continue;
			ColumnarResults columnarResult = new ColumnarResults(convertStringToPathString(dsi));
			List<?> columnValues = queryResult.toValues(dsi);
			Object columnValue;
			for (int i = 0; i < columnValues.size(); i++) {
				columnValue = columnValues.get(i);
				keyColumnValuesForThisRow = new StringBuilder();
				for (List keyColumn : keyColumnValues) {
					keyColumnValuesForThisRow.append(keyColumn.get(i).toString() + "#");
				}
				logger.log(Level.INFO, "Added FIRST: " + keyColumnValuesForThisRow.toString() + " SECOND: "
						+ columnValue);
				if (columnValue != null) columnarResult.addValue(keyColumnValuesForThisRow.toString(),
						columnValue.toString());
				else columnarResult.addValue(keyColumnValuesForThisRow.toString(), "");
			}
			columnarTable.addColumn(columnarResult);
		}
		queryResult.setColumnarTable(columnarTable);
	}

	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateSimpleTable(QueryRequest<E> queryRequest,
			DefaultQueryResult<E> queryResult) {
		if (queryRequest.isGenerateColumnarResults() || queryRequest.isReturnSimpleResultSet()) {
			return;
		}
		queryResult.populateTable(queryRequest.getDataSelection().getSelectionItems());
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void populateSimpleResultSet(
			QueryRequest<E> queryRequest, DefaultQueryResult<E> queryResult) {
		if (!queryRequest.isReturnSimpleResultSet()) {
			return;
		}
		queryResult.populateSimpleResultSet(queryRequest.getDataSelection().getSelectionItems());
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void generateWebServiceTable(QueryRequest<E> queryRequest,
																		QueryResult<E> queryResult) {
		if (!queryRequest.isFromWebService() || queryRequest.isGenerateColumnarResults()) return;
		RollUp rollUp = queryRequest.getRollUp();
		if (rollUp != null && !rollUp.getAllRollUpItems().isEmpty()) {
			queryResult.setDataTables(this.getDataTableFromHierachicalRollupResult(queryRequest.getDataSelection(), queryResult));
			return;
		}
		SimpleTable simpleTable = queryResult.getTable();
		Class<?> clazz = queryRequest.getDomain().getDomainClass();
		List<DataSelectionItem> dataSelectionItemList = Lists.newArrayList();

		DataTable dataTable = new DataTable();

		if (simpleTable.size() > 0) {
			Map<DataSelectionItem, Object> map = simpleTable.row(0);
			for (Entry<DataSelectionItem, Object> e : map.entrySet()) {
				dataSelectionItemList.add(e.getKey());
			}
		}
		ArrayList<String> list = Lists.newArrayList();
		ArrayList<String> pathList = Lists.newArrayList();
		ArrayList<String> columnTypeList = Lists.newArrayList();
		for (DataSelectionItem dataSelectionItem : dataSelectionItemList) {
			DataSelectionItem item = dictionaryParser.parse(clazz).newDataSelectionItem(dataSelectionItem.toString());
			pathList.add(item.getUnderlyingPath().toPathString());
			list.add(convertStringToPathString(item));
			columnTypeList.add(dataSelectionItem.getUnderlyingPath().isTerminatedWithAnItem() ? dataSelectionItem
					.getUnderlyingPath().getTerminatingItem().getJavaSimpleType().getName() : "");
		}
		if (list.isEmpty()) {
			list.add("No record!");
		}
		dataTable.setColumnNames(list);
		dataTable.setColumnPaths(pathList);
		dataTable.setColumnTypes(columnTypeList);
		for (Integer rowKey : simpleTable.rowKeySet()) {
			ArrayList<Object> rowDatas = Lists.newArrayList(simpleTable.row(rowKey).values());
			DataRow dataRow = new DataRow();
			dataRow.setColumns(Arrays.asList(Util.objectListToStringArray(rowDatas)));
			dataTable.getDataRows().add(dataRow);
		}
		queryResult.setDataTables(Lists.newArrayList(dataTable));
	}

	private <K, E extends IdentifiedBy<K>> List<DataTable> getDataTableFromHierachicalRollupResult(DataSelection<E> dataSelection, QueryResult<E> queryResult) {
		return toDataTableFromHierachicalRollupResultByBFS(dataSelection, queryResult.getRollupResult(), queryResult);
	}

	private <K, E extends IdentifiedBy<K>> List<DataTable> toDataTableFromHierachicalRollupResultByBFS(DataSelection<E> dataSelection, Collection<Group.Element<List<?>, E>> elements, QueryResult<E> queryResult) {
		if (elements == null || elements.isEmpty()) {
			return Collections.emptyList();
		}
		List<DataTable> dataTables = Lists.<DataTable>newArrayList();
		Collection<Group.Element<List<?>, E>> currentElements = Lists.newArrayList(elements);

		while(currentElements!=null && !currentElements.isEmpty()) {
			DataTable dataTable = new DataTable();
			List<DataRow> dataRows = Lists.<DataRow>newArrayList();
			for(Group.Element<List<?>, E> element : currentElements) {
				DataRow dataRow = queryResult.toDataRowFromRollUpResult(dataSelection, element);
				dataRows.add(dataRow);
			}
			dataTable.setColumnNames(toDataTableColumnsFromGroupAggr(dataSelection));
			dataTable.setColumnPaths(toDataTablePathsFromGroupAggr(dataSelection));
			dataTable.setColumnTypes(toDataTableTypesFromGroupAggr(dataSelection));
			dataTable.setDataRows(dataRows);
			dataTables.add(dataTable);

			currentElements = getNextLevelGroupElements(currentElements);
		}

		return dataTables;
	}

	private <K, E extends IdentifiedBy<K>> List<String> toDataTableColumnsFromGroupAggr(DataSelection<E> dataSelection) {
		List<String> columnNames = Lists.newArrayList();
		List<DataSelectionItem<E, ?>> dataSelectionItems = dataSelection.getSelectionItems();

		for (DataSelectionItem<E, ?> dataSelectionItem : dataSelectionItems) {
			columnNames.add(convertStringToPathString(dataSelectionItem));
		}

		return columnNames;
	}

	private <K, E extends IdentifiedBy<K>> List<String> toDataTablePathsFromGroupAggr(DataSelection<E> dataSelection) {
		List<String> pathStrings = Lists.newArrayList();
		List<DataSelectionItem<E, ?>> dataSelectionItems = dataSelection.getSelectionItems();

		for (DataSelectionItem<E, ?> dataSelectionItem : dataSelectionItems) {
			pathStrings.add(dataSelectionItem.getUnderlyingPath().toPathString());
		}

		return pathStrings;
	}

	private <K, E extends IdentifiedBy<K>> List<String> toDataTableTypesFromGroupAggr(DataSelection<E> dataSelection) {
		List<String> types = Lists.newArrayList();
		List<DataSelectionItem<E, ?>> dataSelectionItems = dataSelection.getSelectionItems();

		for (DataSelectionItem<E, ?> dataSelectionItem : dataSelectionItems) {
			types.add(dataSelectionItem.getUnderlyingPath().isTerminatedWithAnItem() ? dataSelectionItem
					.getUnderlyingPath().getTerminatingItem().getJavaSimpleType().getName() : "");
		}
		return types;
	}

	private <K, E extends IdentifiedBy<K>> Collection<Group.Element<List<?>, E>> getNextLevelGroupElements(Collection<Group.Element<List<?>, E>> groupingElement) {
		if (!groupingElement.isEmpty()) {
			Collection<Group.Element<List<?>, E>> result = Lists.<Group.Element<List<?>, E>>newArrayList();
			for (Element<List<?>, E> element : groupingElement) {
				Collection<Group.Element<List<?>, E>> childrenElement = element.getChildren();
				if(childrenElement!=null && !childrenElement.isEmpty()) {
					result.addAll(element.getChildren());
				}
			}
			return result;
		}
		return Collections.emptyList();
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void generateExcelFile(QueryRequest<E> queryRequest,
																  QueryResult<E> queryResult) {

		if (!queryRequest.isGenerateExcel()) return;
		SimpleTable simpleTable = queryResult.getTable();
		OutputStream out = queryRequest.getOutputStream();
		Class<?> clazz = queryRequest.getDomain().getDomainClass();
		try {
			long startTime = System.currentTimeMillis();
			writeCSVFile(simpleTable, clazz, out);
			long endTime = System.currentTimeMillis();

			long duration = (endTime - startTime) / 1000;

			logger.log(Level.INFO, "******Spend " + duration + " seconds in writeCSVFile!******");
		} catch (Exception e) {
			throw new RuntimeException("Failed to write Excel file.", e);
		}

		queryResult.setTable(null);
		queryResult.setSearchResult(null);
		queryResult.setAggregatedResult(null);
	}

	private void writeCSVFile(SimpleTable simpleTable, Class<?> clazz, OutputStream excelOutputStream) throws Exception {
		CsvListWriter csvListWriter = null;
		try {
			if (excelOutputStream == null) {
				return;
			}

			csvListWriter = new CsvListWriter(new BufferedWriter(new OutputStreamWriter(excelOutputStream)),
					CsvPreference.EXCEL_PREFERENCE);

			List<DataSelectionItem> dataSelectionItemList = Lists.newArrayList();
			if (simpleTable.size() > 0) {
				Map<DataSelectionItem, Object> map = simpleTable.row(0);
				for (Entry<DataSelectionItem, Object> e : map.entrySet()) {
					dataSelectionItemList.add(e.getKey());
				}
			}

			List<String> list = Lists.newArrayList();

			for (DataSelectionItem dataSelectionItem : dataSelectionItemList) {
				DataSelectionItem item = dictionaryParser.parse(clazz).newDataSelectionItem(
						dataSelectionItem.toString());
				list.add(convertStringToPathString(item));
			}

			if (list.isEmpty()) {
				list.add("No record!");
			}

			csvListWriter.writeHeader(list.toArray(new String[0]));

			for (Integer rowKey : simpleTable.rowKeySet()) {
				List<Object> rowDatas = Lists.newArrayList(simpleTable.row(rowKey).values());
				csvListWriter.write(rowDatas);
			}

			csvListWriter.flush();
		} catch (Exception e) {
			throw new RuntimeException("Fail to write CSV file!", e);
		} finally {
			if (csvListWriter != null) {
				csvListWriter.close();
			}
		}

	}

	/**
	 * sort and paginate the result
	 *
	 * @param queryRequest
	 * @param queryResult
	 */
	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateSortedAndPaginatedResult(QueryRequest<E> queryRequest,
																				   QueryResult<E> queryResult) {

		if (queryRequest.shouldQueryCacheExtension()) {
			return;
		}

		Collection<DataSelectionItem> dsiToSorts = new ArrayList<>(2);

		for (DataSelectionItem dsi : queryRequest.getDataSelection().getSelectionItems()) {
			if (dsi.getSortBy() != null) {
				dsiToSorts.add(dsi);
			}
		}

		queryResult.orderByWithPagination(dsiToSorts.toArray(new DataSelectionItem[dsiToSorts.size()]), queryRequest.getPageSize(), queryRequest.getPageIndex(),
				queryRequest.getMaxRowCount());
	}
	
	@Inject
	TimeMarkConvertor timeMarkConvertor;
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> getCollection(Criteria criteria){
		Select<E> select = (Select<E>) criteria.getSelect();


		return search(criteria, select);
	}
	
	@SuppressWarnings("deprecation")
	<E extends IdentifiedBy<?>> Collection<E> search(Criteria criteria, Select<E> select) {
        DataDomain domain = criteria.getDomain();
        Collection<TimeMark> timeMarks = null;
        if (timeMarkConvertor != null) {
            timeMarks = timeMarkConvertor.getTimeMarks(criteria);           
        }
        SearchProvider searchProvider = getSearchProvider();
        if (timeMarks == null || timeMarks.isEmpty()) {     
            if ( searchProvider instanceof DefaultDataAccessService && containsTimeMarkCreateBy(criteria) && !domain.equals(cacheManager.getCacheDomain()) ) {
                return ((DefaultDataAccessService)searchProvider).searchOnlyFromCache(criteria, select);
            }
            return searchProvider.search(domain, select);
        }
        Collection<E> cols =new ArrayList<>();
        for(TimeMark timeMark : timeMarks){
            DefaultDataKey dataKey = new DefaultDataKey(domain, timeMark, null);
            Collection<E> col = searchProvider.search(dataKey, select);
            cols.addAll(col);
        }
        return cols;
    }

	<E extends IdentifiedBy<?>> boolean containsTimeMarkCreateBy(Criteria criteria) {		 
		if (criteria == null) {
			return false;
		}
		Collection<Criterion<E>> allCriterion = criteria.getAllCriterion();		
		for(Criterion<E> criterion : allCriterion) {
            if(criterion.getDataSelectionItem().getUnderlyingPath().hasRelationships()) {
            	DataPath<?,?> path = criterion.getDataSelectionItem().getUnderlyingPath();
                DataRelationship reln = path.getRelationships().get(0);
                if (StringUtils.equals(reln.getName(),"Time mark") || StringUtils.equals(reln.getName(),"Created by")) {
        			return true;
        		}
            }
        }
		return false;
	}

	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateSearchResult(QueryRequest<E> queryRequest,
																	   QueryResult<E> queryResult) {
		if (queryRequest.shouldQueryCacheExtension()) {
			Collection<Tuple> mongoSearchResult = mongoDataProvider.find(queryRequest);
			queryResult.setResultTuples(mongoSearchResult);
		} else {
			Collection<E> searchResults;
			Select<E> select = (Select<E>) queryRequest.getCriteria().getSelect();
			if(CollectionUtils.isNotEmpty(queryRequest.getCandidates())) {
				searchResults = (new ParallelSelect<E>(select, 8, 200000, configuration.getInteger("query.task.timeout", 60))).select(queryRequest.getCandidates());
			} else {
				Criteria criteria = queryRequest.getCriteria();
				searchResults = search(criteria, select);
			}
			queryResult.setSearchResult(searchResults);
		}
	}

	public <K, E extends IdentifiedBy<K>> void filterSecureDataPaths(QueryRequest<E> queryRequest) {
		List<DataSelectionItem<E, ?>> selectionItems = queryRequest.getDataSelection().getSelectionItems();

		if (selectionItems.isEmpty())
			return;

		ArrayList<DataPath<?,?>> dataPaths = Lists.newArrayList();
		for (DataSelectionItem<E, ?> dsi : selectionItems) {
			dataPaths.add(dsi.getUnderlyingPath());
		}
		SecurityRealm oldSecurityRealm = ExecutionContexts.getCurrentExecutionContext().getSecurityRealm();
		ExecutionContexts.getCurrentExecutionContext().setSecurityRealm(queryRequest.getSecurityRealm());
		Collection<DataPath<?, ?>> filteredDataPaths=null;
		try {
			SecurityRealm securityRealm = SecurityUtil.getCurrentSecurityRealm();
//			SecurityRealm securityRealm = SecurityUtil.getApplicableSecurityRealm(queryRequest.getDomain().getDomainClass(), securableDictionary);
			if (securityRealm != null) {
				User user = queryRequest.getUserForPathSecurityCheck() == null ? ExecutionContexts.getCurrentExecutionContext().getUser() : queryRequest.getUserForPathSecurityCheck();
				filteredDataPaths = userSecurityService.getAuthorizedDataPathsToView(user, dataPaths, securityRealm);
			}
		} catch(Exception ex){
			logger.log(Level.SEVERE, "Found an exception when trying to get applicabale security realm.", ex);
			return;
		}finally{
			ExecutionContexts.getCurrentExecutionContext().setSecurityRealm(oldSecurityRealm);
		}
		if (filteredDataPaths != null) {
			List<DataSelectionItem<E, ?>> dsiToRemove = Lists.newArrayList();
			for (DataSelectionItem<E, ?> dsi : selectionItems) {
				if (!filteredDataPaths.contains(dsi.getUnderlyingPath())) {
					dsiToRemove.add(dsi);
				}
			}
			selectionItems.removeAll(dsiToRemove);
		}
	}
	
	protected <K, E extends IdentifiedBy<K>> void populateAggregatedResultUsingPivot(QueryRequest<E> queryRequest,
			   QueryResult<E> queryResult, PivotDataCube cube) {
		if (queryRequest.shouldQueryCacheExtension()) {
			return;
		}

		RollUp rollUp = queryRequest.getRollUp();
		if (rollUp != null && !rollUp.getAllRollUpItems().isEmpty()) {
			return;
		}

		DefaultPivotQueryRequest<E> pivotQueryRequest = new DefaultPivotQueryRequest<>(queryRequest.getDomain());
		List<DataSelectionItem<E, ?>> rowDimensions = new ArrayList<>();
		List<DataSelectionItem<E, ?>> aggregateMeasures = new ArrayList<>();
		
		List<DataSelectionItem<E, ?>> dataSelectionItems = queryRequest.getDataSelection().getSelectionItems();
		if(CollectionUtils.isEmpty(dataSelectionItems)) return;
		
		Map<AggregateInfo<?>, Evaluator<E, ?>> evaluatorsByAggregateAndPathInfo = new HashMap<>();
		Group<List<?>, E> group = null;
		int groupIndex = 0;
		for (int i = 0; i < dataSelectionItems.size(); i++) {
			DataSelectionItem<E, ?> dsi = dataSelectionItems.get(i);
			if(dsi.getSelectedAggregateMeasure() != null) {
				aggregateMeasures.add(dsi);
				AggregateMeasure<?, ?> aggregateMeasure = dsi.getSelectedAggregateMeasure();
				AggregateInfo<?> aggregateInfo = aggregateMeasure.getAggregateInfo();
				int size = 0;
				if (dsi.getUnderlyingPath().getDDType() == DDType.ITEMLIST) {
					size = ((ItemList) dsi.getUnderlyingPath().getTerminatingItem()).getSize();
				}
				Aggregator aggregateObject = (Aggregator<E, ?>) aggregateFactory.getAggregate(aggregateInfo, size);
				Aggregator<E, ?> aggregate = new AggregateOnPath(dsi, aggregateObject);
				evaluatorsByAggregateAndPathInfo.put(aggregate.getAggregateInfo(), (Evaluator) aggregate);
			}
			else if(dsi.getCompareMeasure() != null) {
				continue;
			}
			else {
				rowDimensions.add(dsi);
				if (group == null) group = dsi.getUnderlyingPath().getGroup();
				else ((PathBasedGroup<E>)group).add(dsi.getUnderlyingPath());

				queryResult.addPathToGroupIndex(dsi, groupIndex);
				groupIndex++;
			}
		}
		
		if(group == null && !aggregateMeasures.isEmpty()) {
			for(DataSelectionItem<E, ?> dsi : dataSelectionItems) {
				DataPath underlyingPath = dsi.getUnderlyingPath();
				if (group == null) {
					group = new AggregationOnlyGroup<>(underlyingPath);
				} else {
					((PathBasedGroup<E>)group).add(dsi.getUnderlyingPath());
				}
			}
		}
		if (group == null) return;
		group.setEvaluators(evaluatorsByAggregateAndPathInfo.values());
		
		if(aggregateMeasures.isEmpty()) return;
		
		PivotDataCube realCube = cube;
		if (realCube == null) {
			int groupMaxNum = 50000;
			int timeout = 60;
			if(configuration != null){
				groupMaxNum = configuration.getInteger("aggregation.group.maxnum", 50000);
				timeout = configuration.getInteger("query.task.timeout", 60);
			}
			pivotQueryRequest.setAggregateMeasures(aggregateMeasures);
			pivotQueryRequest.setRowDimensions(rowDimensions);
			pivotQueryRequest.setColumnDimensions(Collections.<DataSelectionItem<E,?>>emptyList());
			
			realCube = new DefaultPivotDataCube(aggregateFactory, pivotQueryRequest, queryResult.getSearchResult(), groupMaxNum, timeout);
			((DefaultPivotDataCube)realCube).populateDataCube();
		}
		
		queryResult.setAggregatedResult(buildAggregatedResultFromPivot((DefaultPivotDataCube)realCube, aggregateMeasures, (AbstractGroup)group));
	}
	
	private <E> PivotQueryRequest<E> createPivotQueryRequest(QueryRequest<E> queryRequest) {
		if (queryRequest instanceof PivotQueryRequest) {
			return (PivotQueryRequest)queryRequest;
		}
		DefaultPivotQueryRequest<E> pivotQueryRequest = new DefaultPivotQueryRequest<>(queryRequest.getDomain());
		List<DataSelectionItem<E, ?>> rowDimensions = new ArrayList<>();
		List<DataSelectionItem<E, ?>> aggregateMeasures = new ArrayList<>();
		
		List<DataSelectionItem<E, ?>> dataSelectionItems = queryRequest.getDataSelection().getSelectionItems();
		if(CollectionUtils.isEmpty(dataSelectionItems)) throw new RuntimeException("No aggregate measures found in the query !");

		for (int i = 0; i < dataSelectionItems.size(); i++) {
			DataSelectionItem<E, ?> dsi = dataSelectionItems.get(i);
			if(dsi.getSelectedAggregateMeasure() != null) {
				aggregateMeasures.add(dsi);
			}
			else if(dsi.getCompareMeasure() != null) {
				continue;
			}
			else {
				rowDimensions.add(dsi);
			}
		}

		if(aggregateMeasures.isEmpty()) throw new RuntimeException("No aggregate measures found in the query !");
		
		pivotQueryRequest.setAggregateMeasures(aggregateMeasures);
		pivotQueryRequest.setRowDimensions(rowDimensions);
		pivotQueryRequest.setColumnDimensions(Collections.<DataSelectionItem<E,?>>emptyList());
		
		pivotQueryRequest.addCriteria(queryRequest.getCriteria());
		pivotQueryRequest.addFurtherCriteria(queryRequest.getFurtherCriteria());
		for (DataSelectionItem dsi : pivotQueryRequest.getRowDimension().getSelectionItems()) {
			pivotQueryRequest.getDataSelection().and(dsi);
		}
		for (DataSelectionItem dsi : pivotQueryRequest.getColumnDimension().getSelectionItems()) {
			pivotQueryRequest.getDataSelection().and(dsi);
		}
		for (DataSelectionItem dsi : pivotQueryRequest.getAggregateMeasure().getSelectionItems()) {
			pivotQueryRequest.getDataSelection().and(dsi);
		}
		return pivotQueryRequest;
	}

	private <E> Collection<Element<List<?>, E>> buildAggregatedResultFromPivot(
			DefaultPivotDataCube<E, ?, ?, ?> cube,
			List<DataSelectionItem<E, ?>> aggregateMeasures,
			AbstractGroup<?, ?> abstractGroup) {
		Collection<Element<List<?>, E>> aggregatedResults = new ArrayList(cube.getDimensionGroupMap().size());

		for(Map.Entry<PivotDimensionGroup<E>, Collection<E>> entry : cube.getDimensionGroupMap().entrySet()) {
			PivotDimensionGroup key = entry.getKey();
			DefaultElement nextElement = new DefaultElement(key.getRowDimensionValues(), 
					entry.getValue(),
					abstractGroup);
			for(DataSelectionItem dsi : aggregateMeasures)
				nextElement.setAggregationResult(dsi, key.getPivotTableCell().getValueMap().get(dsi));
			aggregatedResults.add(nextElement);
		}
		
		return aggregatedResults;
	}
	
	@InfraInvocation(type = InvocationType.Query)
	protected <K, E extends IdentifiedBy<K>> void populateAggregatedResult(QueryRequest<E> queryRequest,
																		   QueryResult<E> queryResult) {
			populateAggregatedResultUsingPivot(queryRequest, queryResult, null);
	}

	@InfraInvocation(type = InvocationType.Query)
	private <K, E extends IdentifiedBy<K>> void populateGroupByResult(QueryRequest<E> queryRequest,
																	  QueryResult<E> queryResult) {

		RollUp rollUp = queryRequest.getRollUp();
		if (rollUp != null && !rollUp.getAllRollUpItems().isEmpty()) {
			return;
		}

		GroupBy<E> groupBy = queryRequest.getGroupBy();
		if (groupBy == null || groupBy.getGroupByDataSelectionItems().isEmpty())
			return;

		List<DataSelectionItem<E, ?>> dsiToSortList = new ArrayList<>();

		for (DataSelectionItem<E, ?> dsi : queryRequest.getDataSelection().getSelectionItems()) {
			if (dsi.getSortBy() != null) {
				dsiToSortList.add(dsi);
			}
		}

		queryResult.groupBySearchResult(groupBy, dsiToSortList);
	}
	
	@InfraInvocation
	public <K, E extends IdentifiedBy<K>> void populatePivotTable(PivotQueryRequest<E> queryRequest, PivotQueryResult<E> queryResult, PivotDataCube cube) {
		int maxPivotCellSize = CoreModule.getConfiguration().getInteger("pivot.max.cells", 1000000);
		int maxPivotColSize = CoreModule.getConfiguration().getInteger("pivot.max.columns", 1000000);
		int maxPivotRowSize = CoreModule.getConfiguration().getInteger("pivot.max.rows", 1000000);
		if(cube.getDimensionGroupMap().size() > maxPivotCellSize)
			throw new PivotTableSizeExceedException("Number of total cells is greater than specified limit of ", maxPivotCellSize,
					cube.getDimensionGroupMap().size(), "cell");
		
		DefaultPivotTable<E, ?, ?> pivotTable = generateDefaultPivotTable(queryRequest, queryResult, cube, maxPivotRowSize);
		
		if(pivotTable.getTotalDataRows() > 0 && (cube.getDimensionGroupMap().size()/pivotTable.getTotalDataRows()) > maxPivotColSize)
			throw new PivotTableSizeExceedException("Number of columns exceed the specified limit of ", maxPivotColSize,
					cube.getDimensionGroupMap().size()/pivotTable.getTotalDataRows(), "column");
			
		
		((DefaultPivotQueryResult)queryResult).setPivotTable(pivotTable);
	}
	
	private <K, E extends IdentifiedBy<K>> DefaultPivotTable<E, ?, ?> generateDefaultPivotTable(PivotQueryRequest<E> queryRequest, PivotQueryResult<E> queryResult, PivotDataCube<E, ?, ?, ?> cube, int maxPivotRowSize) {
		DefaultPivotTable rootPivotTable = new DefaultPivotTable(extractAggregators(queryRequest), null, Iterables.getFirst(queryRequest.getRowDimension().getSelectionItems(), null), maxPivotRowSize);
		DefaultPivotTable pivotTable;
		Map<PivotDimensionGroup<E>, Collection<E>> dimensionGroupMap = cube.getDimensionGroupMap();
		Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult = queryResult.getComparedResult();
		Map<List<?>, Element<List<?>, E>> nonControlGroupMap = ((DefaultQueryResult)queryResult).getNonControlGroupMap();
		
		for(Entry<PivotDimensionGroup<E>, Collection<E>> entry : dimensionGroupMap.entrySet()) {
			pivotTable = rootPivotTable;
			List<Object> rowDimensionValues = entry.getKey().getRowDimensionValues();
			List<Object> columnDimensionValues = entry.getKey().getColumnDimensionValues();
			List<Object> cellGroup = new ArrayList<>();
			if (rowDimensionValues != null)cellGroup.addAll(rowDimensionValues);
			if (columnDimensionValues != null)cellGroup.addAll(columnDimensionValues);
			
			PivotTableCell cell = entry.getKey().getPivotTableCell();
			if (cell != null) {
				cell.addMembers(entry.getValue());
				if (nonControlGroupMap != null && nonControlGroupMap.containsKey(cellGroup)) {
					cell.addNonControlMembers(nonControlGroupMap.get(cellGroup).getMembers());
				}
				cell.setCompareResult(comparedResult.get(Iterables.getFirst(entry.getValue(), null)));
			}
			if(CollectionUtils.isNotEmpty(rowDimensionValues)) {
				addRowForPivotTable(queryRequest, pivotTable, entry, rowDimensionValues, cell);
			} else {
				addNullRowForPivotTable(queryRequest, pivotTable, entry, cell);
			}
		}
		rootPivotTable.setNonControlOnlyMembers(((DefaultQueryResult)queryResult).getNonControlOnlySearchResult());
		sortAndPaginateDefaultPivotTable(rootPivotTable, queryRequest, queryResult);
		
		return rootPivotTable;
	}
	

	private <K, E extends IdentifiedBy<K>> void addNullRowForPivotTable(PivotQueryRequest<E> queryRequest, DefaultPivotTable pivotTable,
			Entry<PivotDimensionGroup<E>, Collection<E>> entry, PivotTableCell cell) {
		pivotTable.addDataRow(AllPivotDimensions.getInstance(), 
				PivotDimensionsFactory.createPivotDimensions(entry.getKey().getColumnDimensionValues(), queryRequest.getColumnDimension().getSelectionItems()),
				cell);
	}

	private <K, E extends IdentifiedBy<K>> void addRowForPivotTable(PivotQueryRequest<E> queryRequest, DefaultPivotTable pivotTable,
			Entry<PivotDimensionGroup<E>, Collection<E>> entry, List<Object> rowDimensionValues, PivotTableCell cell) {
		for(int i = 0; i < rowDimensionValues.size(); i++) {
			Object rowDimensionValue = rowDimensionValues.get(i);
			if(i==rowDimensionValues.size()-1) {
				pivotTable.addDataRow(rowDimensionValue, 
						PivotDimensionsFactory.createPivotDimensions(entry.getKey().getColumnDimensionValues(), queryRequest.getColumnDimension().getSelectionItems()),
						cell);
			}
			else 
				pivotTable = pivotTable.addChildPivotTable(rowDimensionValue, queryRequest.getRowDimension().getSelectionItems().get(i+1));
		}
	}
	
	
	private <K, E extends IdentifiedBy<K>> void sortAndPaginateDefaultPivotTable(DefaultPivotTable<E, ?, ?> rootPivotTable, PivotQueryRequest<E> queryRequest, PivotQueryResult<E> queryResult) {
		int pageSize = queryRequest.getPageSize();
		int pageIndex = queryRequest.getPageIndex();
		
		queryResult.setResultRowCount(rootPivotTable.getTotalDataRowsCount());
		
		int startIndex;
		int endIndex;
		
		if(pageSize < Integer.MAX_VALUE) {
			queryResult.setResultPageCount(rootPivotTable.getTotalDataRowsCount()/pageSize);
			startIndex = pageIndex * pageSize;
			if(startIndex >= rootPivotTable.getTotalDataRowsCount()) startIndex = rootPivotTable.getTotalDataRowsCount() - pageSize;
			if(startIndex < 0) startIndex = 0;
			
			endIndex = startIndex + pageSize - 1;
			if(endIndex > rootPivotTable.getTotalDataRowsCount()) endIndex = rootPivotTable.getTotalDataRowsCount() - 1;
		} else {
			queryResult.setResultPageCount(1);
			startIndex = 0;
			endIndex = rootPivotTable.getTotalDataRowsCount() - 1;
		}
		PivotTableSortGroup pivotTableSortGroup = new PivotTableSortGroup(rootPivotTable, startIndex, endIndex);
		int forkJoinPoolSize = CoreModule.getConfiguration().getInteger("threadpool.maxsize.coreparallel", 64);
		int concurrentRequestNum = CoreModule.getConfiguration().getInteger("concurrent.requests.coreparallel", 4);
		int numOfPartitions = forkJoinPoolSize/concurrentRequestNum;
		PivotTableSortAndPaginationTask<E> pivotTableSortAndPaginationTask = new PivotTableSortAndPaginationTask<>(Lists.newArrayList(pivotTableSortGroup), getSortByAggregateMeasures(queryRequest), extractAggregators(queryRequest), numOfPartitions, configuration.getInteger("query.task.timeout", 60));
		ForkJoinTask<List<PivotTableSortGroup>> sortFuture = managedExecutorService.submit(pivotTableSortAndPaginationTask);
		try {
			sortFuture.get(configuration.getInteger("query.task.timeout", 60), TimeUnit.SECONDS);
		} catch (InterruptedException | TimeoutException e) {
			sortFuture.cancel(true);
			throw new TaskTimeoutCancelationException("query timeout", e);
		} catch (ExecutionException e) {
			sortFuture.cancel(true);
			throw new RuntimeException(e.getCause());
		}
		if (needToSortColumn(queryRequest.getColumnDimension().getSelectionItems())) {
			DefaultPivotTableDataColumnComparator columnComparator = new DefaultPivotTableDataColumnComparator(queryRequest.getColumnDimension().getSelectionItems());
			sortDefaultChildTableColumns(rootPivotTable, columnComparator);
			rootPivotTable.setColumnComparator(columnComparator);
		}
	}
	
	private void sortDefaultChildTableColumns(DefaultPivotTable pivotTable, DefaultPivotTableDataColumnComparator columnComparator) {
		if (pivotTable.getChildPivotTables() != null) {
			PivotTableChildTree<?, DefaultPivotTable> childPivotTables = pivotTable.getChildPivotTables();
			for (Entry<?, DefaultPivotTable> pair : childPivotTables.getEntryList()) {
				sortDefaultChildTableColumns(pair.getValue(), columnComparator);
			}
		} else {
			columnComparator.sortDefaultPivotTableColumns(pivotTable);
		}
	}
	
	private <K, E extends IdentifiedBy<K>> boolean needToSortColumn(List<DataSelectionItem<E, ?>> columnDimensions ) {
		if (!CollectionUtils.isEmpty(columnDimensions)) {
			for (DataSelectionItem dsi : columnDimensions) {
				if (dsi.getSortBy() != null) {
					return true;
				}
			}
		}
		return false;
	}

	private <K, E extends IdentifiedBy<K>> List<DataSelectionItem<E, ?>> getSortByAggregateMeasures(PivotQueryRequest<E> queryRequest) {
		List<DataSelectionItem<E, ?>> sortByAggregateMeasures = new ArrayList<>();
		
		for(DataSelectionItem<E, ?> aggregateMeasure : queryRequest.getAggregateMeasure().getSelectionItems())
			if(aggregateMeasure.getSortBy() != null) sortByAggregateMeasures.add(aggregateMeasure);
		
		return sortByAggregateMeasures;
	}
	
	private <K, E extends IdentifiedBy<K>> Map<DataSelectionItem<E, ?>, Aggregator> extractAggregators(PivotQueryRequest<E> pivotQueryRequest) {
		Map<DataSelectionItem<E, ?>, Aggregator> aggregators = new HashMap<>();
		List<DataSelectionItem<E, ?>> aggregateMeasures = pivotQueryRequest.getAggregateMeasure().getSelectionItems();
		for(DataSelectionItem<E, ?> dsi : aggregateMeasures) {
			DataPath underlyingPath = dsi.getUnderlyingPath();
			AggregateMeasure<?, ?> aggregateMeasure = dsi.getSelectedAggregateMeasure();
			if (aggregateMeasure != null) {
				AggregateInfo<?> aggregateInfo = aggregateMeasure.getAggregateInfo();
				Class<?> aggregateClass = aggregateInfo.getAggregateClass();
				if(Aggregator.class.isAssignableFrom(aggregateClass)){
					int size = (underlyingPath.getDDType() == DDType.ITEMLIST) ? ((ItemList) underlyingPath.getTerminatingItem()).getSize() : 0;
					Aggregator aggregator = (Aggregator<E, ?>) aggregateFactory.getAggregate(aggregateInfo, size);
					Aggregator<E, ?> aggregatorOnPath = new AggregateOnPath(dsi, aggregator);
					aggregators.put(dsi, aggregatorOnPath);
				} 
			}
		}
		
		return aggregators;
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<QueryResult<E>> submit(final QueryRequest<E> queryRequest) {
		queryRequest.setUserForPathSecurityCheck(ExecutionContexts.getCurrentExecutionContext().getUser());
		queryRequest.setSecurityRealm(ExecutionContexts.getCurrentExecutionContext().getSecurityRealm());
		return this.execService.submit(new QueryManagedExecution(queryRequest));
	}

	private class QueryManagedExecution<K, E extends IdentifiedBy<K>> implements ManagedExecution,
			Callable<QueryResult<E>> {

		private QueryRequest<E> request;
		private transient int searchResultSize = -1;
		private transient int groupSize = -1;;

		public QueryManagedExecution(QueryRequest<E> request) {
			this.request = request;
		}

		@Override
		public QueryResult<E> call() throws Exception {
			QueryResult<E> result = execute(this.request);
			searchResultSize = result.getSearchResult() == null ? -1 : result.getSearchResult()
					.size();
			groupSize = result.getAggregedResult() == null ? -1 : result.getAggregedResult().size();
			return result;
		}

		@Override
		public TaskType getType() {
			return TaskType.Query;
		}

		@Override
		public String getExecutionName() {
			return request.getDomain().getName() + " Query";
		}

		@Override
		public String getExecutionParameters() {
			return request.getDataSelection() + "\n" + request.getCriteria().toString() + "\n"
					+ "search result size: " + this.searchResultSize + "\n" + "group size: "
					+ this.groupSize;
		}

		@Override
		public boolean isNewThread() {
			return true;
		}
	}

	private String convertStringToPathString(DataSelectionItem item) {
		if (item == null) {
			return null;
		}

		StringBuilder headerName = new StringBuilder();
		List<DataRelationship> allRelationship = item.getUnderlyingPath().getRelationships();

		for (DataRelationship relationship : allRelationship) {
			headerName.append(relationship.getName() + HEADER_NAME_SEPERATOR);
		}

		if (item.getUnderlyingPath().isTerminatedWithAnItem()) {
			headerName.append(item.getUnderlyingPath().getTerminatingItem().getName());
		}

		return headerName.toString();
	}

}
