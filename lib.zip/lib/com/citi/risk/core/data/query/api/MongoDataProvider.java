package com.citi.risk.core.data.query.api;

import java.util.Collection;

import javax.persistence.Tuple;

import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.mongodb.DBCollection;

public interface MongoDataProvider {
	
	DBCollection getDbCollection(DataDomain domain);
	
	<E extends IdentifiedBy<?>> Collection<Tuple> find(QueryRequest<E> queryRequest);
}
