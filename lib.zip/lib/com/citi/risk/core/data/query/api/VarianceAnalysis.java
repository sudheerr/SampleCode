package com.citi.risk.core.data.query.api;

import java.util.concurrent.Future;

import com.citi.risk.core.dictionary.api.VarianceAnalysisRequest;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

/**
 * A representation of VarianceAnalysis. Provides method to do VarianceAnalysis.
 * <p> Caller can pass in the VarianceAnalysis request via a
 * {@link com.citi.risk.core.dictionary.api.VarianceAnalysisRequest VarianceAnalysisRequest} and get the
 * Future of  {@link com.citi.risk.core.data.query.api.VarianceAnalysisResult VarianceAnalysisResult} 
 * </p>
 *
 * @author ww78389
 * 
 * @param <K> key type to lookup by
 * @param <E> value type in cache, extends IdentifiedBy of type K
 * 
 * @see com.citi.risk.core.data.query.api.VarianceAnalysisResult
 * @see com.citi.risk.core.dictionary.api.VarianceAnalysisRequest
 */
public interface VarianceAnalysis{
	/**
	 * Takes a {@link com.citi.risk.core.dictionary.api.VarianceAnalysisRequest VarianceAnalysisRequest} and returns the analysis result as
	 * a Future of {@link com.citi.risk.core.data.query.api.VarianceAnalysisResult VarianceAnalysisResult}.
	 * 
	 */
	<K, E extends IdentifiedBy<K>> Future<VarianceAnalysisResult<E>> analyze(VarianceAnalysisRequest<E> varAnalysisRequest);

	/**
	 * A VarianceAnalysis needs to use a Query to get query results to analyze. 
	 */
	void setQuery(Query query);

}
