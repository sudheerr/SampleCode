package com.citi.risk.core.data.query.api;

import com.citi.risk.core.lang.compare.CompareMeasure;

/**
 * A representation of comparison result for a specific measure in a Difference Table of
 * {@link com.citi.risk.core.data.query.api.VarianceAnalysisResult VarianceAnalysisResult} . It contains two values(controlValue and
 * nonControlValue) and the comparison result(equal/not equal)
 * 
 * @author ww78389
 * 
 * @param <V>
 *            the type of the controlValue and nonControlValue
 * @see com.citi.risk.core.data.query.api.VarianceAnalysis
 * @see com.citi.risk.core.data.query.api.VarianceAnalysisResult
 */

public interface CompareResult<V> {
	
	@CompareMeasure
	V getControlValue();

	@CompareMeasure
	V getNonControlValue();

	Boolean isEqual();

	/**
	 * Return the difference between controlValue and nonControlValue as a Double value
	 */
	@CompareMeasure
	Double getDifferenceValue();

	/**
	 * Return a percentage number that indicates the proportion of difference based on controlValue
	 */
	@CompareMeasure
	Double getDifferencePercentage();
	
	CompareResult<V> getComplexResult();
	
	/**
	 * Return the absolute value between controlValue and nonControlValue as a Double value
	 */
	@CompareMeasure
	Double getAbsoluteDiffValue();
	
}
