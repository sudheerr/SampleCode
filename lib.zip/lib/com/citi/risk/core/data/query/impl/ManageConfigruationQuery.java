package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.query.api.SearchProvider;

public class ManageConfigruationQuery extends AbstractQuery {

	@Override
	public final SearchProvider getSearchProvider() {
		return configuration;
	}

	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.configuration = (Configuration)searchProvider;
	}
}