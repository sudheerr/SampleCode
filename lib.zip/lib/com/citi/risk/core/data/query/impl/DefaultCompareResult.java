package com.citi.risk.core.data.query.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.citi.risk.core.data.query.api.CompareResult;

/**
 * Default implementation of {@link com.citi.risk.core.data.query.api.CompareResult CompareResult}.
 * 
 * @author ww78389
 * 
 * @param <V>
 *            the type of the values compared.
 */
public class DefaultCompareResult<V> implements CompareResult<V> {

	private V controlValue;
	private V nonControlValue;
	private Boolean isEqual;
	private Double differenceValue = Double.valueOf(0);
	private Double differencePercentage = Double.valueOf(0);
	private Double absoluteDiffValue = Double.valueOf(0);

	public DefaultCompareResult(V controlValue, V nonControlValue, Boolean isEqual) {
		super();
		this.controlValue = controlValue;
		this.nonControlValue = nonControlValue;
		this.isEqual = isEqual;
		if (!isEqual) calculateDifference();
	}

	/**
	 * Calculate and set the values of property: differenceValue, differencePercentage.
	 */
	private void calculateDifference() {
		if (this.controlValue instanceof Number || this.nonControlValue instanceof Number) calculateNumberDifference();
		else if (this.controlValue instanceof Date || this.nonControlValue instanceof Date) calculateDateDifferenceAsHour();
		else {
			this.differenceValue = Double.valueOf(0);
			this.differencePercentage = Double.valueOf(0);
		}
		this.absoluteDiffValue = Math.abs(this.differenceValue);

	}

	@Override
	public V getControlValue() {
		return this.controlValue;
	}

	@Override
	public V getNonControlValue() {
		return this.nonControlValue;
	}

	@Override
	public Boolean isEqual() {
		return this.isEqual;
	}

	@Override
	public Double getDifferenceValue() {
		return this.differenceValue;
	}

	@Override
	public Double getDifferencePercentage() {
		return differencePercentage;
	}

	@Override
	public Double getAbsoluteDiffValue() {
		return absoluteDiffValue;
	}

	/**
	 * calculate date difference and return it as hour counts
	 */
	private void calculateDateDifferenceAsHour() {
		if (this.controlValue == null || this.nonControlValue == null) return;
		Double diffValue;
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime((Date) this.controlValue);
		long controlTime = calendar.getTimeInMillis();
		calendar.setTime((Date) this.nonControlValue);
		long nonControlTime = calendar.getTimeInMillis();
		Double variance = Double.valueOf((controlTime >= nonControlTime) ? (controlTime - nonControlTime)
				: (nonControlTime - controlTime));
		// convert milliseconds to hours
		diffValue = BigDecimal.valueOf(variance / 3600000D).setScale(2, RoundingMode.HALF_UP).doubleValue();
		this.differenceValue = diffValue;
	}

	private void calculateNumberDifference() {
		Double controlDoubleValue, nonControlDoubleValue;
		if (this.controlValue == null) {
			controlDoubleValue = Double.valueOf(0);
		} else {
			controlDoubleValue = doubleValue(this.controlValue);
		}
		if (this.nonControlValue == null) {
			nonControlDoubleValue = Double.valueOf(0);
		} else {
			nonControlDoubleValue = doubleValue(this.nonControlValue);
		}
		Double diffPercentage;
		Double diffValue = controlDoubleValue - nonControlDoubleValue;
		if (nonControlDoubleValue == 0) {
			// return positive or negative infinity
			diffPercentage = diffValue / nonControlDoubleValue;
		} else {
			diffPercentage = BigDecimal.valueOf(diffValue / nonControlDoubleValue).setScale(4, RoundingMode.HALF_UP)
					.doubleValue();
		}
		this.differenceValue = diffValue;
		if (diffPercentage.isInfinite()) {
			if (Double.compare(diffPercentage, Double.POSITIVE_INFINITY) == 0) {
				diffPercentage = Double.valueOf(1);
			} else {
				diffPercentage = Double.valueOf(-1);
			}
		} else if (diffPercentage.isNaN()) {
			diffPercentage = Double.valueOf(0);
		}
		this.differencePercentage = diffPercentage * 100.0;

	}

	private double doubleValue(Object obj) {
		return ((Number) obj).doubleValue();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((controlValue == null) ? 0 : controlValue.hashCode());
		result = prime * result + ((differencePercentage == null) ? 0 : differencePercentage.hashCode());
		result = prime * result + ((differenceValue == null) ? 0 : differenceValue.hashCode());
		result = prime * result + ((isEqual == null) ? 0 : isEqual.hashCode());
		result = prime * result + ((nonControlValue == null) ? 0 : nonControlValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		DefaultCompareResult other = (DefaultCompareResult) obj;
		if (controlValue == null) {
			if (other.controlValue != null) return false;
		} else if (!controlValue.equals(other.controlValue)) return false;
		if (differencePercentage == null) {
			if (other.differencePercentage != null) return false;
		} else if (!differencePercentage.equals(other.differencePercentage)) return false;
		if (differenceValue == null) {
			if (other.differenceValue != null) return false;
		} else if (!differenceValue.equals(other.differenceValue)) return false;
		if (isEqual == null) {
			if (other.isEqual != null) return false;
		} else if (!isEqual.equals(other.isEqual)) return false;
		if (nonControlValue == null) {
			if (other.nonControlValue != null) return false;
		} else if (!nonControlValue.equals(other.nonControlValue)) return false;
		return true;
	}

	@Override
	public String toString() {
		return "CR [cv=" + controlValue + ", ncv=" + nonControlValue + ", " + isEqual + ", dv=" + differenceValue
				+ ", dp=" + differencePercentage + "]";
	}

	@Override
	public CompareResult<V> getComplexResult() {
		return this;
	}

}
