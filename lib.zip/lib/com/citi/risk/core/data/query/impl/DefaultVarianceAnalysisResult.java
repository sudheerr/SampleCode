package com.citi.risk.core.data.query.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.VarianceAnalysisResult;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.table.SimpleTable;

/**
 * A default implementation of a {@link com.citi.risk.core.data.query.api.VarianceAnalysisResult VarianceAnalysisResult}.
 * 
 * @author ww78389
 * 
 * @param <E>
 *            type of the element queried for
 * 
 * @see com.citi.risk.core.data.query.api.VarianceAnalysisResult
 * @see com.citi.risk.core.data.query.api.QueryResult
 */
public class DefaultVarianceAnalysisResult<E> implements VarianceAnalysisResult<E> {

	private QueryResult<E> controlQueryResult;
	private QueryResult<E> nonControlQueryResult;
	private SimpleTable difference;
	// TODO refactor, should not have the same field in both queryResult and VAResult
	private Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult = new HashMap<>();
	private List<Element<List<?>, E>> nonControlOnlyAggreagtedResult = new ArrayList<>();
	private List<E> nonControlOnlySearchResult = new ArrayList<>();
	private String timeMarkKeyString="";
	
	private Map<List<?>, Element<List<?>, E>> nonControlGroupMap;

	@Override
	public QueryResult<E> getControlQueryResult() {
		return this.controlQueryResult;
	}

	@Override
	public QueryResult<E> getNonControlQueryResult() {
		return this.nonControlQueryResult;
	}

	@Override
	public SimpleTable getDifference() {
		return this.difference;
	}

	@Override
	public void setControlQueryResult(QueryResult controlQueryResult) {
		this.controlQueryResult = controlQueryResult;
	}

	@Override
	public void setNonControlQueryResult(QueryResult nonControlQueryResult) {
		this.nonControlQueryResult = nonControlQueryResult;
	}

	@Override
	public void setDifference(SimpleTable difference) {
		this.difference = difference;
	}

	@Override
	public Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> getComparedResult() {
		return comparedResult;
	}

	@Override
	public void setComparedResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult) {
		this.comparedResult = comparedResult;
	}

	@Override
	public Collection<Element<List<?>, E>> getNonControlOnlyAggregatedResult() {
		return nonControlOnlyAggreagtedResult;
	}

	@Override
	public void setNonControlOnlyAggregatedResult(List<Element<List<?>, E>> aggregatedResult) {
		this.nonControlOnlyAggreagtedResult = aggregatedResult;
	}

	@Override
	public List<E> getNonControlOnlySearchResult() {
		return this.nonControlOnlySearchResult;
	}

	@Override
	public void setNonControlOnlySearchResult(List<E> searchResult) {
		this.nonControlOnlySearchResult = searchResult;
	}

	@Override
	public String getTargetTimeMarkKeyString() {
		return this.timeMarkKeyString;
	}

	@Override
	public void setTargetTimeMarkKeyString(String timeMarkKeyString) {
		this.timeMarkKeyString = timeMarkKeyString;
	}

	@Override
	public void setNonControlGroupMap(Map<List<?>, Element<List<?>, E>> nonControlGroupMap) {
		this.nonControlGroupMap = nonControlGroupMap;
	}

	@Override
	public Map<List<?>, Element<List<?>, E>> getNonControlGroupMap() {
		return this.nonControlGroupMap;
	}

}
