package com.citi.risk.core.data.query.impl;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.dictionary.api.AggregateInfo;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.dictionary.impl.AggregeInfoDecorator;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.group.Group.Element;
import com.google.common.base.Function;
import com.google.common.collect.Ordering;

@SuppressWarnings("rawtypes")
class AggregatedResultComparator<E, V> implements Comparator<Group.Element> {

	DataSelectionItem dataSelectionItem = null;
	private QueryResult<E> queryResult;
	SortBy sortBy = null;
	private Collection<List<String>> nonControlOnlyGroupKeys;

	public AggregatedResultComparator(QueryResult<E> queryResult, DataSelectionItem dataSelectionItem,
			Collection<List<String>> nonControlOnlyGroupKeys) {
		this.dataSelectionItem = dataSelectionItem;
		this.sortBy = dataSelectionItem.getSortBy();
		this.queryResult = queryResult;
		this.nonControlOnlyGroupKeys = nonControlOnlyGroupKeys;
	}

	@Override
	@SuppressWarnings("unchecked")
	public int compare(Element left, Element right) {
		AggregateMeasure<?, ?> selectedAggregateMeasure = dataSelectionItem.getSelectedAggregateMeasure();
		DataPath path = dataSelectionItem.getUnderlyingPath();

		V leftValue;
		V rightValue;

		List<?> leftGroup = (List<?>) left.getGroup();
		List<?> rightGroup = (List<?>) right.getGroup();

		if (dataSelectionItem.getCompareMeasure() != null) {
			Function compareResultTransform = dataSelectionItem.getCompareMeasure().getResultTransform();
			leftValue = getValue(left, compareResultTransform);
			rightValue = getValue(right, compareResultTransform);
		} else {
			if (selectedAggregateMeasure != null) {
				Function fromAggrResultToValue = selectedAggregateMeasure.getResultTransform();
				leftValue = getAggregatedValue(left, leftGroup, fromAggrResultToValue);
				rightValue = getAggregatedValue(right, rightGroup, fromAggrResultToValue);

			} else {
				leftValue = getGroupValue(path, leftGroup);
				rightValue = getGroupValue(path, rightGroup);
			}
		}

		return comparedWith(leftValue, rightValue);
	}

	private int comparedWith(V leftValue, V rightValue) {
		if (leftValue == rightValue) {
			return 0;
		}
		if (leftValue == null) {
			return -1;
		}
		if (rightValue == null) {
			return 1;
		}
		if (Comparable.class.isAssignableFrom(leftValue.getClass())) {
			return Ordering.natural().compare((Comparable<V>) leftValue, (Comparable<V>) rightValue);
		} else {
			return Ordering.natural().compare((String) leftValue, (String) rightValue);
		}
	}

	private V getValue(Element left, Function compareResultTransform) {
		V leftValue;
		Object leftE = left.getMembers().iterator().next();
		Map<DataSelectionItem<E, ?>, CompareResult> leftMap = this.queryResult.getComparedResult().get(leftE);
		if (leftMap.get(dataSelectionItem) != null) {
			leftValue = (V) compareResultTransform.apply(leftMap.get(dataSelectionItem));
		} else {
			leftValue = null;
		}
		return leftValue;
	}

	private V getGroupValue(DataPath path, List<?> group) {
		V value;
		List<String> groupWithStringValue = (List<String>) group;
		if (nonControlOnlyGroupKeys.contains(groupWithStringValue)) {
			value = this.queryResult.getPathToGroupIndiceForNonControlOnlyElement().containsKey(path) ? (V) group
					.get(this.queryResult.getPathToGroupIndiceForNonControlOnlyElement().get(path)) : null;
		} else {
			value = (V) ((group).get(this.queryResult.getPathToGroupIndice()[dataSelectionItem.getSequenceNumber()]));
			if (path.toPathString().contains("TimeMark Key")) {
				value = (V) DefaultTimeMark.getTimeMarkfromKey(String.valueOf(value));
			}
		}
		return value;
	}

	private V getAggregatedValue(Element left, List<?> group, Function fromAggrResultToValue
			) {
		V value;
		List<String> groupWithStringValue = (List<String>) group;
		if (nonControlOnlyGroupKeys.contains(groupWithStringValue)) {
			value = null;
		} else {
			value = (V) fromAggrResultToValue.apply(left.getAggregationResult(dataSelectionItem));
		}
		return value;
	}
}
