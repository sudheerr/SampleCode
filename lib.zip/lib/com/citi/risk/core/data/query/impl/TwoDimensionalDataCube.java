package com.citi.risk.core.data.query.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.google.common.base.Function;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class TwoDimensionalDataCube {

	private Collection baseDataSet;
	
	private DataSelectionItem rowDsi;
	
	private DataSelectionItem columnDsi;
	
	private DataSelectionItem valueDsi;
	
	private ArrayList[][] dataCube;

	private TreeSet rowLabels = new TreeSet();
	private TreeSet columnLabels = new TreeSet();
	private Map<Object, Integer> rowLabelIndexMap = new HashMap<>();
	private Map<Object, Integer> columnLabelIndexMap = new HashMap<>();
	

	public TwoDimensionalDataCube(Collection baseDataSet,
			DataSelectionItem rowDsi, DataSelectionItem columnDsi,
			DataSelectionItem valueDsi) {
		super();
		this.baseDataSet = baseDataSet;
		this.rowDsi = rowDsi;
		this.columnDsi = columnDsi;
		this.valueDsi = valueDsi;
		
		init();
	}

	
	private void init() {
		generateUniqueRowColumnLabels();
		generateLabelIndexMap(rowLabels, rowLabelIndexMap);
		generateLabelIndexMap(columnLabels, columnLabelIndexMap);
		
		generateDataCube();
	}

	private void generateUniqueRowColumnLabels() {
		Function xTransform = rowDsi.getUnderlyingPath().getTranform();
		Function yTransform = columnDsi.getUnderlyingPath().getTranform();

		for(Object nextObject : baseDataSet) {
			rowLabels.add(xTransform.apply(nextObject));
			columnLabels.add(yTransform.apply(nextObject));
		}
	}

	private void generateLabelIndexMap(TreeSet labels, Map<Object, Integer> labelIndexMap) {
		int i = 0;
		for(Object xCoordinate : labels) 
			labelIndexMap.put(xCoordinate, i++);
	}

	private void generateDataCube() {
		initiateDataCube();
		populateDataCube();
	}
	
	private void initiateDataCube() {
		int numberOfRowLabels    = rowLabels.size();
		int numberOfColumnLabels = columnLabels.size();
		dataCube = new ArrayList[numberOfRowLabels][numberOfColumnLabels];
		
		dataCube = new ArrayList[numberOfRowLabels][numberOfColumnLabels];
		for(int i=0; i < numberOfRowLabels; i++)
			for(int j=0; j < numberOfColumnLabels; j++)
				dataCube[i][j] = new ArrayList();
	}
	
	private void populateDataCube() {
		Function rowTransform 	 = rowDsi.getUnderlyingPath().getTranform();
		Function columnTransform = columnDsi.getUnderlyingPath().getTranform();
		Function valueTransform  = valueDsi.getUnderlyingPath().getTranform();
		int rowIndex, columnIndex;
		for(Object nextObject : baseDataSet) {
			Object rowLabel = rowTransform.apply(nextObject);
			Object columnLabel = columnTransform.apply(nextObject);
			Object resultValue = valueTransform.apply(nextObject);
			rowIndex = rowLabelIndexMap.get(rowLabel);
			columnIndex = columnLabelIndexMap.get(columnLabel);
			dataCube[rowIndex][columnIndex].add(resultValue);
		}
	}

	public Collection getBaseDataSet() {
		return baseDataSet;
	}

	public void setBaseDataSet(Collection baseDataSet) {
		this.baseDataSet = baseDataSet;
	}

	public DataSelectionItem getRowDsi() {
		return rowDsi;
	}

	public void setRowDsi(DataSelectionItem rowDsi) {
		this.rowDsi = rowDsi;
	}

	public DataSelectionItem getColumnDsi() {
		return columnDsi;
	}

	public void setColumnDsi(DataSelectionItem columnDsi) {
		this.columnDsi = columnDsi;
	}

	public DataSelectionItem getValueDsi() {
		return valueDsi;
	}

	public void setValueDsi(DataSelectionItem valueDsi) {
		this.valueDsi = valueDsi;
	}

	public ArrayList[][] getDataCube() {
		return dataCube;
	}

	public SortedSet getRowLabels() {
		return rowLabels;
	}


	public SortedSet getColumnLabels() {
		return columnLabels;
	}

	public Map<Object, Integer> getRowLabelIndexMap() {
		return rowLabelIndexMap;
	}


	public Map<Object, Integer> getColumnLabelIndexMap() {
		return columnLabelIndexMap;
	}

}
