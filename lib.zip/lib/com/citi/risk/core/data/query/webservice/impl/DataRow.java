package com.citi.risk.core.data.query.webservice.impl;

import java.util.ArrayList;
import java.util.List;

public class DataRow {
	List<String> columns = new ArrayList<>();

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}
	
	
}
