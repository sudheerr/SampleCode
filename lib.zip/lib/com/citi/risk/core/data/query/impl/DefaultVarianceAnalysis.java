package com.citi.risk.core.data.query.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.Query;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.api.VarianceAnalysis;
import com.citi.risk.core.data.query.api.VarianceAnalysisResult;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.MeasureComparator;
import com.citi.risk.core.dictionary.api.PathBasedGroup;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.api.VarianceAnalysisRequest;
import com.citi.risk.core.dictionary.impl.DefaultPathBasedGroup;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.AbstractGroup.DefaultElement;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.table.DefaultSimpleTable;
import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.inject.Inject;

/**
 * A Default implementation for {@link com.citi.risk.core.dictionary.api.VarianceAnalysisRequest VarianceAnalysisRequest}
 * 
 * @author ww78389
 * 
 */
public class DefaultVarianceAnalysis implements VarianceAnalysis {

	private Query query;

	@Inject
	private ExecutorService managedExucutor;

	@Inject
	private Logger logger;

	@Override
	public <K, E extends IdentifiedBy<K>> Future<VarianceAnalysisResult<E>> analyze(VarianceAnalysisRequest<E> vaRequest) {
		if (query == null) throw new RuntimeException("DefaultVairanceAnalysis needs a query to do analyzing!");
		return this.managedExucutor.submit(new AnalysisManagedExecution(vaRequest));
	}

	private <K, E extends IdentifiedBy<K>> VarianceAnalysisResult<E> execute(VarianceAnalysisRequest<E> vaRequest) {
		VarianceAnalysisResult<E> vaResult = new DefaultVarianceAnalysisResult<>();
		populateQueryResult(vaRequest, vaResult);
		populateDifference(vaRequest, vaResult);
		return vaResult;
	}

	@SuppressWarnings("unchecked")
	private <K, E extends IdentifiedBy<K>> void populateQueryResult(final VarianceAnalysisRequest<E> vaRequest,
			final VarianceAnalysisResult<E> vaResult) {
		final QueryResult<E> controlResult = new DefaultQueryResult<>();
		final QueryResult<E> nonControlResult = new DefaultQueryResult<>();

		ControlResultQuery<K, E> controlResultQuery = new ControlResultQuery<>(controlResult, vaRequest);
		NonControlResultQuery<K, E> nonControlResultQuery = new NonControlResultQuery<>(nonControlResult, vaRequest);
		
		Future controlQuery = managedExucutor.submit(controlResultQuery);
		Future nonControlQuery = managedExucutor.submit(nonControlResultQuery);
		
		try {
			controlQuery.get();
			nonControlQuery.get();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		} catch (ExecutionException e) {
			throw new RuntimeException(e.getCause());
		}
		
		
		vaResult.setControlQueryResult(controlResult);
		vaResult.setNonControlQueryResult(nonControlResult);
	}
	
	private class ControlResultQuery<K, E extends IdentifiedBy<K>> implements ManagedExecution,	Runnable {
		private QueryResult<E> controlResult;
		private VarianceAnalysisRequest<E> vaRequest;
		
		public ControlResultQuery(QueryResult<E> controlResult, VarianceAnalysisRequest<E> vaRequest) {
			super();
			this.controlResult = controlResult;
			this.vaRequest = vaRequest;
		}

		@Override
		public void run() {
			populateControlQueryResult(vaRequest, controlResult);
		}

		@Override
		public TaskType getType() {
			return TaskType.VarianceAnalysis;
		}

		@Override
		public String getExecutionName() {
			return "Control Result Query";
		}

		@Override
		public String getExecutionParameters() {
			return StringUtils.EMPTY;
		}

		@Override
		public boolean isNewThread() {
			return true;
		}
		
	}
	
	private class NonControlResultQuery<K, E extends IdentifiedBy<K>> implements ManagedExecution,	Runnable {
		private QueryResult<E> nonControlResult;
		private VarianceAnalysisRequest<E> vaRequest;
		
		public NonControlResultQuery(QueryResult<E> nonControlResult, VarianceAnalysisRequest<E> vaRequest) {
			super();
			this.nonControlResult = nonControlResult;
			this.vaRequest = vaRequest;
		}

		@Override
		public void run() {
			populateNonControlQueryResult(vaRequest, nonControlResult);
		}

		@Override
		public TaskType getType() {
			return TaskType.VarianceAnalysis;
		}

		@Override
		public String getExecutionName() {
			return "NonControl Result Query";
		}

		@Override
		public String getExecutionParameters() {
			return StringUtils.EMPTY;
		}

		@Override
		public boolean isNewThread() {
			return true;
		}
		
	}

	private <K, E extends IdentifiedBy<K>> void populateControlQueryResult(final VarianceAnalysisRequest<E> vaRequest,
			final QueryResult<E> controlResult) {
		try {
			if (vaRequest.getControlResult() != null) {
				copySearchResultAndAggregatedResult(vaRequest.getControlResult(), controlResult);
			} else if (vaRequest.getControlResultFile() != null) {
				QueryResult<E> result = new DefaultQueryResult<E>()
						.readResultFromFile(vaRequest.getControlResultFile());
				copySearchResultAndAggregatedResult(result, controlResult);
			} else {
				querySearchResultAndAggregatedResult(vaRequest.getControlRequest(), controlResult);
				if (!compareAllRequired(vaRequest.getControlRequest()) && vaRequest.isOnlyShowControlResult()) {
					// paginate controlResult to minimize data to be compared
					AbstractQuery q = (AbstractQuery) this.query;
					q.populateSortedAndPaginatedResult(vaRequest.getControlRequest(), controlResult);
				}
			}
		} catch (IOException e) {
			throw new RuntimeException("Caught IOExeption while trying to read queryResult from file. ", e);
		}
	}

	private <K, E extends IdentifiedBy<K>> void populateNonControlQueryResult(
			final VarianceAnalysisRequest<E> vaRequest, final QueryResult<E> nonControlResult) {
		try {
			if (vaRequest.getNonControlResult() != null) {
				copySearchResultAndAggregatedResult(vaRequest.getNonControlResult(), nonControlResult);
			} else if (vaRequest.getNonControlResultFile() != null) {
				QueryResult<E> result = new DefaultQueryResult<E>()
						.readResultFromFile(vaRequest.getControlResultFile());
				copySearchResultAndAggregatedResult(result, nonControlResult);
			} else {
				querySearchResultAndAggregatedResult(vaRequest.getNonControlRequest(), nonControlResult);
			}
		} catch (IOException e) {
			throw new RuntimeException("Caught IOExeption while trying to read queryResult from file. ", e);
		}
	}

	private <E> void copySearchResultAndAggregatedResult(final QueryResult<E> fromResult, final QueryResult<E> toResult) {
		toResult.setSearchResult(fromResult.getSearchResult());
		toResult.setAggregatedResult(fromResult.getAggregedResult());
	}

	private <K, E extends IdentifiedBy<K>> boolean compareAllRequired(QueryRequest<E> queryRequest) {
		boolean filterRequired = false;
		Criteria furtherCriteria = queryRequest.getFurtherCriteria();
		if (furtherCriteria != null && !furtherCriteria.getAllCriterion().isEmpty()) {
			filterRequired = true;
		}
		boolean sortByRequired = false;
		for (DataSelectionItem<E, ?> dsi : queryRequest.getDataSelection().getSelectionItems()) {
			if (dsi.getSortBy() != null) sortByRequired = true;
		}
		return sortByRequired || filterRequired;
	}

	private <K, E extends IdentifiedBy<K>> void querySearchResultAndAggregatedResult(QueryRequest<E> request,
			QueryResult<E> result) {
		AbstractQuery q = (AbstractQuery) this.query;
		q.filterSecureDataPaths(request);
		q.populateSearchResult(request, result);
		q.populateAggregatedResult(request, result);
	}

	private <K, E extends IdentifiedBy<K>> void populateDifference(final VarianceAnalysisRequest<E> vaRequest,
			final VarianceAnalysisResult<E> vaResult) {
		VarianceAnalysisInfo<E> vaInfo = new VarianceAnalysisInfo<>(vaRequest, vaResult);
		String targetTimeMarkKeyString;

		Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap = new HashMap<>();
		populateComparedResultMapBasedOnControlResult(vaInfo, comparedResultMap);

		if (!vaRequest.isOnlyShowControlResult()) {
			populateComparedResultMapBasedOnNonControlResult(vaInfo, comparedResultMap);
			List<Element<List<?>, E>> nonControlOnlyAggregatedResult = vaInfo.populateNonControlOnlyAggregatedResult();
			List<E> nonControlOnlySearchResult = vaInfo.populateNonControlOnlySearchResult();
			targetTimeMarkKeyString = vaInfo.getTargetTimeMarkKeyString();
			vaResult.setNonControlOnlyAggregatedResult(nonControlOnlyAggregatedResult);
			vaResult.setNonControlOnlySearchResult(nonControlOnlySearchResult);
			vaResult.setTargetTimeMarkKeyString(targetTimeMarkKeyString);
		}
		// vaResult.set
		vaResult.setNonControlGroupMap(vaInfo.nonControlGroupMap);
		vaResult.setComparedResult(comparedResultMap);
		vaResult.setDifference(extractDifferenceTableFromComparedMap(vaInfo, comparedResultMap));
	}

	private <E> DefaultSimpleTable extractDifferenceTableFromComparedMap(final VarianceAnalysisInfo<E> vaInfo,
			final Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap) {
		if (!vaInfo.vaRequest.isWithDifferenceTable()) return null;
		DefaultSimpleTable diffTable = DefaultSimpleTable.create();
		// add difference based on control result
		for (Entry<List<?>, Element<List<?>, E>> entry : vaInfo.controlGroupMap.entrySet()) {
			List<?> keyValues = entry.getKey();
			Element<List<?>, E> controlElement = entry.getValue();
			E e = controlElement.getMembers().iterator().next();
			// populate keyValues into diffTable
			int diffTableRowNum = populateKeyValuesToNewRow(diffTable, keyValues, vaInfo);
			// populate compare results into diffTable
			for (DataSelectionItem<E, ?> dsi : vaInfo.measureItemList) {
				diffTable.put(diffTableRowNum, dsi, comparedResultMap.get(e).get(dsi));
			}
		}

		if (vaInfo.vaRequest.isOnlyShowControlResult()) {
			return diffTable;
		}

		for (Entry<List<?>, Element<List<?>, E>> entry : vaInfo.nonControlGroupMap.entrySet()) {
			List<?> keyValues = entry.getKey();
			if (vaInfo.controlGroupMap.containsKey(keyValues)) continue;
			Element<List<?>, E> nonControlElement = entry.getValue();
			E e = nonControlElement.getMembers().iterator().next();
			// populate keyValues into diffTable
			int diffTableRowNum = populateKeyValuesToNewRow(diffTable, keyValues, vaInfo);
			// populate compare results into diffTable
			for (DataSelectionItem<E, ?> dsi : vaInfo.measureItemList) {
				diffTable.put(diffTableRowNum, dsi, comparedResultMap.get(e).get(dsi));
			}
		}
		return diffTable;
	}

	private <E> int populateKeyValuesToNewRow(DefaultSimpleTable diffTable, List<?> keyValues,
			VarianceAnalysisInfo<E> vaInfo) {
		int diffTableRowNum = diffTable.rowMap().size();
		for (DataSelectionItem<E, ?> dsi : vaInfo.keyItemList) {
			Object keyValue = keyValues.get(vaInfo.pathToGroupIndice.get(dsi.getUnderlyingPath()));
			diffTable.put(diffTableRowNum, dsi, keyValue);
		}
		return diffTableRowNum;
	}

	private <E> void populateComparedResultMapBasedOnControlResult(final VarianceAnalysisInfo<E> vaInfo,
			final Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap) {
		Object controlValue;
		Object nonControlValue;
		// add difference based on control result
		for (Entry<List<?>, Element<List<?>, E>> entry : vaInfo.controlGroupMap.entrySet()) {
			List<?> keyValues = entry.getKey();
			Element<List<?>, E> controlElement = entry.getValue();
			Element<List<?>, E> nonControlElement = vaInfo.nonControlGroupMap.get(keyValues);
			populateElementMembersToComparedResult(comparedResultMap, controlElement.getMembers());
			// populate compare results into diffTable
			for (DataSelectionItem<E, ?> dsi : vaInfo.measureItemList) {
				MeasureComparator measureComparator = vaInfo.vaRequest.getMeasureComparators().get(dsi);
				if (dsi.getSelectedAggregateMeasure() == null) {
					controlValue = extractNotAggregatedValue(controlElement, dsi);
					nonControlValue = extractNotAggregatedValue(nonControlElement, dsi);
				} else {
					controlValue = extractAggregatedValue(controlElement, dsi);
					nonControlValue = extractAggregatedValue(nonControlElement, dsi);
				}
				CompareResult<?> compareResult = getCompareResult(controlValue, nonControlValue, measureComparator);
				populateComparedResult(comparedResultMap, controlElement.getMembers(), dsi, compareResult);
			}
		}
	}

	private <E> void populateComparedResultMapBasedOnNonControlResult(final VarianceAnalysisInfo<E> vaInfo,
			final Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap) {
		Object nonControlValue;
		// add difference based on nonControl result
		for (Entry<List<?>, Element<List<?>, E>> entry : vaInfo.nonControlGroupMap.entrySet()) {
			List<?> keyValues = entry.getKey();
			if (vaInfo.controlGroupMap.containsKey(keyValues)) continue;
			Element<List<?>, E> nonControlElement = entry.getValue();
			populateElementMembersToComparedResult(comparedResultMap, nonControlElement.getMembers());
			for (DataSelectionItem<E, ?> dsi : vaInfo.measureItemList) {
				MeasureComparator measureComparator = vaInfo.vaRequest.getMeasureComparators().get(dsi);
				if (dsi.getSelectedAggregateMeasure() == null) {
					nonControlValue = extractNotAggregatedValue(nonControlElement, dsi);
				} else {
					nonControlValue = extractAggregatedValue(nonControlElement, dsi);
				}
				CompareResult<?> compareResult = getCompareResult(null, nonControlValue, measureComparator);
				populateComparedResult(comparedResultMap, nonControlElement.getMembers(), dsi, compareResult);
			}
		}
	}

	private <E> void populateElementMembersToComparedResult(
			Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap, Collection<E> members) {
		for (Iterator iterator = members.iterator(); iterator.hasNext();) {
			E e = (E) iterator.next();
			comparedResultMap.put(e, new HashMap<DataSelectionItem<E, ?>, CompareResult>());
		}
	}

	private <E> void populateComparedResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResultMap,
			Collection<E> members, DataSelectionItem<E, ?> dsi, CompareResult compareResult) {
		for (Iterator iterator = members.iterator(); iterator.hasNext();) {
			E e = (E) iterator.next();
			comparedResultMap.get(e).put(dsi, compareResult);
		}
	}

	private <E> Object extractNotAggregatedValue(Element<List<?>, E> element, DataSelectionItem<E, ?> dsi) {
		if (element == null || dsi == null) return null;
		Function<Object, Object> pathTransform = dsi.getUnderlyingPath().getTranform();
		return pathTransform.apply(new ArrayList<>(element.getMembers()).get(0));
	}

	private <E> Object extractAggregatedValue(Element<List<?>, E> element, DataSelectionItem<E, ?> dsi) {
		if (element == null || dsi == null) return null;
		Function aggregateResultTransform = dsi.getSelectedAggregateMeasure().getResultTransform();
		return aggregateResultTransform.apply(element.getAggregationResult(dsi));

	}

	private <E> PathBasedGroup<E> createGroupWithKeyItems(List<DataSelectionItem<E, ?>> keyItemList) {
		PathBasedGroup<E> group = new DefaultPathBasedGroup();
		for (DataSelectionItem<E, ?> dsi : keyItemList) {
			group.add(dsi.getUnderlyingPath());
		}
		return group;
	}

	private <E> Map<DataPath, Integer> createPathToGroupIndice(List<DataSelectionItem<E, ?>> keyItemList) {
		Map<DataPath, Integer> result = new HashMap<>();
		int i = 0;
		for (DataSelectionItem<E, ?> dsi : keyItemList) {
			result.put(dsi.getUnderlyingPath(), i++);
		}
		return result;
	}

	/**
	 * If the given comparator is null, call equals() method to compare the two given value, otherwise uses the given measureComparator.<br>
	 * Returns a DefaultCompareResult that contains controlValue, nonControlValue and compare result(equal or not)
	 */
	private CompareResult<?> getCompareResult(Object controlValue, Object nonControlValue,
			MeasureComparator measureComparator) {
		Boolean isEqual;
		if (measureComparator == null) {
			if (controlValue == null || nonControlValue == null) {
				isEqual = false;
			} else if (controlValue.equals(nonControlValue)) {
				isEqual = true;
			} else {
				isEqual = false;
			}
		} else {
			isEqual = measureComparator.measureEqual(controlValue, nonControlValue);
		}
		return new DefaultCompareResult(controlValue, nonControlValue, isEqual);
	}

	/**
	 * Contains parameters and information needed to do VarianceAnalysis
	 */
	class VarianceAnalysisInfo<E> {

		private static final String TIME_MARK_KEY = "TimeMark Key";
		final VarianceAnalysisRequest<E> vaRequest;
		final VarianceAnalysisResult<E> vaResult;
		final List<DataSelectionItem<E, ?>> keyItemList;
		final List<DataSelectionItem<E, ?>> measureItemList;
		final Map<DataPath, Integer> pathToGroupIndice;
		final LinkedHashMap<List<?>, Element<List<?>, E>> controlGroupMap;
		final LinkedHashMap<List<?>, Element<List<?>, E>> nonControlGroupMap;
		final PathBasedGroup<E> group;

		private VarianceAnalysisInfo(VarianceAnalysisRequest<E> vaRequest, VarianceAnalysisResult<E> vaResult) {
			super();
			this.vaRequest = vaRequest;
			this.vaResult = vaResult;
			this.keyItemList = vaRequest.getKeyItems();
			this.measureItemList = vaRequest.getMeasureItems();
			this.group = createGroupWithKeyItems(this.keyItemList);
			this.pathToGroupIndice = createPathToGroupIndice(this.keyItemList);
			this.controlGroupMap = extractGroupMapByGroup(vaResult.getControlQueryResult(), this.group);
			this.nonControlGroupMap = extractGroupMapByGroup(vaResult.getNonControlQueryResult(), this.group);
		}

		private List<Element<List<?>, E>> populateNonControlOnlyAggregatedResult() {
			List<Element<List<?>, E>> nonControlOnlyAggregatedResult = Lists.newArrayList();
			QueryResult<E> nonControlQueryResult = this.vaResult.getNonControlQueryResult();
			Collection<Element<List<?>, E>> aggregatedResult = nonControlQueryResult.getAggregedResult();
			if (aggregatedResult != null) {
				for (Element<List<?>, E> element : aggregatedResult) {
					List<?> aggregateResultGroup = element.getGroup();
					if (!this.controlGroupMap.containsKey(aggregateResultGroup)) {
						nonControlOnlyAggregatedResult.add(element);
					}
				}
			}
			return nonControlOnlyAggregatedResult;
		}

		private String getTargetTimeMarkKeyString() {
			Collection<Criterion<E>> allCriterion = this.vaRequest.getNonControlRequest().getCriteria()
					.getAllCriterion();
			for (Criterion criterion : allCriterion) {
				String pathString = criterion.getDataSelectionItem().getUnderlyingPath().toPathString();
				if (pathString.contains(TIME_MARK_KEY)) {
					Object operand = criterion.getOperand(0);
					if (operand != null) return String.valueOf(operand);
				}
			}
			return null;
		}

		private List<E> populateNonControlOnlySearchResult() {
			List<E> nonControlOnlySearchResult = Lists.newArrayList();
			Set<Entry<List<?>, Element<List<?>, E>>> entrySet = this.nonControlGroupMap.entrySet();
			Set<List<?>> controlGroupMapkeySet = this.controlGroupMap.keySet();
			for (Entry<List<?>, Element<List<?>, E>> entry : entrySet) {
				if (!controlGroupMapkeySet.contains(entry.getKey())) {
					nonControlOnlySearchResult.addAll(entry.getValue().getMembers());
				}
			}
			return nonControlOnlySearchResult;
		}

		private <E> LinkedHashMap<List<?>, Element<List<?>, E>> extractGroupMapByGroup(QueryResult<E> queryResult,
				PathBasedGroup<E> group) {
			if (queryResult.getAggregedResult() != null) {
				return createGroupMapWithAggregatedResult(queryResult, group);
			} else {
				return createGroupMapWithSearchResult(queryResult, group);
			}
		}

		private <E> LinkedHashMap<List<?>, Element<List<?>, E>> createGroupMapWithAggregatedResult(
				QueryResult<E> queryResult, PathBasedGroup<E> group) {
			LinkedHashMap<List<?>, Element<List<?>, E>> groupMap = new LinkedHashMap<>();
			Collection<Element<List<?>, E>> elements = queryResult.getAggregedResult();
			for (Element<List<?>, E> e : elements) {
				E object = e.getMembers().iterator().next();
				List<?> groupOfElement = group.groupOf(object);
				groupMap.put(groupOfElement, e);
			}
			return groupMap;
		}

		private <E> LinkedHashMap<List<?>, Element<List<?>, E>> createGroupMapWithSearchResult(
				QueryResult<E> queryResult, PathBasedGroup<E> group) {
			LinkedHashMap<List<?>, Element<List<?>, E>> groupMap = new LinkedHashMap<>();
			for (E e : queryResult.getSearchResult()) {
				Element<List<?>, E> tmpElement = (Element<List<?>, E>)(Element)new DefaultElement<>(group.groupOf(e), Arrays.asList(e), (AbstractGroup<?, ?>) group);
				groupMap.put(tmpElement.getGroup(), tmpElement);
			}
			return groupMap;
		}
	}

	private class AnalysisManagedExecution<K, E extends IdentifiedBy<K>> implements ManagedExecution,
			Callable<VarianceAnalysisResult<E>> {

		private VarianceAnalysisRequest<E> request;

		public AnalysisManagedExecution(VarianceAnalysisRequest<E> request) {
			this.request = request;
		}

		@Override
		public VarianceAnalysisResult<E> call() throws Exception {
			return execute(this.request);
		}

		@Override
		public TaskType getType() {
			return TaskType.VarianceAnalysis;
		}

		@Override
		public String getExecutionName() {
			return "VarianceAnalysis";
		}

		@Override
		public String getExecutionParameters() {
			return "";
		}

        @Override
        public boolean isNewThread() {
            return true;
        }
    }

	@Override
	public void setQuery(Query query) {
		this.query = query;
	}
}
