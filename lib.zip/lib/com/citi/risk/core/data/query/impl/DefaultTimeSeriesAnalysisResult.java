package com.citi.risk.core.data.query.impl;

import java.util.List;

import com.citi.risk.core.data.query.api.TimeSeriesAnalysisResult;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.SimpleTable;

public class DefaultTimeSeriesAnalysisResult implements TimeSeriesAnalysisResult {

	private SimpleTable table;
	private List<TimeMark> timeMarkList;

	@Override
	public SimpleTable getTable() {
		return table;
	}

	@Override
	public SimpleTable setTable(SimpleTable table) {
		this.table = table;
		return this.table;
	}

	@Override
	public List<TimeMark> getTimeMarks() {
		return timeMarkList;
	}

	@Override
	public void setTimeMarks(List<TimeMark> timeMarks) {
		this.timeMarkList = timeMarks;
	}

}
