package com.citi.risk.core.data.query.impl;

import java.util.Collection;
import java.util.List;

import com.citi.risk.core.data.query.api.TimeSeriesAnalysisRequest;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.common.collect.Lists;

public class DefaultTimeSeriesAnalysisRequest<E> implements TimeSeriesAnalysisRequest<E> {

	private List<TimeMark> timeMarkList;
	private QueryRequest<E> queryRequest;
	private static final String TIMEMARK_STRING = "TimeMark";

	public DefaultTimeSeriesAnalysisRequest(QueryRequest<E> request, List<TimeMark> timeMarkList) {
		this.timeMarkList = timeMarkList;
		this.queryRequest = removeTimeMarkFromRequestCriteria(request);
	}

	private QueryRequest<E> removeTimeMarkFromRequestCriteria(QueryRequest<E> queryRequest) {
		QueryRequest<E> newQueryRequest = queryRequest;
		Criteria originalCriteria = newQueryRequest.getCriteria();

		List<Criterion> criterionsWithoutTimeMark = getCriterionsWithoutTimeMark(originalCriteria);
		newQueryRequest = buildQueryRequestWithCriterion(newQueryRequest, criterionsWithoutTimeMark);
		return newQueryRequest;

	}

	private QueryRequest<E> buildQueryRequestWithCriterion(QueryRequest<E> queryRequest, List<Criterion> criterionsWithoutTimeMark) {
		QueryRequest<E> newQueryRequest = queryRequest;
		DataSelection originalDataSelection = newQueryRequest.getDataSelection();
		if(originalDataSelection!=null){
			newQueryRequest = originalDataSelection.asQueryRequest();
		}
		Criteria criteria = null;
		for (Criterion criterion : criterionsWithoutTimeMark) {
			if (criteria == null) {
				criteria = criterion.criteria();
			} else {
				criteria = criteria.and(criterion.criteria());
			}
		}
		if (criteria != null) {
			newQueryRequest.addCriteria(criteria);
		}
		return newQueryRequest;
	}

	private List<Criterion> getCriterionsWithoutTimeMark(Criteria originalCriteria) {
		// get all the criterions without timeMark
		List<Criterion> criterionsWithoutTimeMark = Lists.newArrayList();
		Collection<Criterion<?>> allCriterion;
		if (originalCriteria != null) {
			allCriterion = originalCriteria.getAllCriterion();
			for (Criterion criterion : allCriterion) {
				if (!criterion.getDataSelectionItem().getUnderlyingPath().toPathString().contains(TIMEMARK_STRING)) criterionsWithoutTimeMark.add(criterion);
			}
		}
		return criterionsWithoutTimeMark;
	}

	@Override
	public QueryRequest<E> getQueryRequest() {
		return queryRequest;
	}

	@Override
	public List<TimeMark> getTimeMarks() {
		return timeMarkList;
	}
}
