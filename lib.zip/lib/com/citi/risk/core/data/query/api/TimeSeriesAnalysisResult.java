package com.citi.risk.core.data.query.api;

import java.util.List;

import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.table.SimpleTable;

public interface TimeSeriesAnalysisResult {

	SimpleTable getTable();

	SimpleTable setTable(SimpleTable table);

	List<TimeMark> getTimeMarks();

	void setTimeMarks(List<TimeMark> timeMarks);

}
