package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.google.inject.Inject;

public class ManageCachesQuery extends AbstractQuery {

	@Inject
	private CacheManager cacheManager;

	@Override
	public final SearchProvider getSearchProvider() {
		return cacheManager;
	}


	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.cacheManager = (CacheManager)searchProvider;
		
	}
}
