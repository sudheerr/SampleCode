package com.citi.risk.core.data.query.webservice.api;

public interface Criteria {

	String getPath();

	void setPath(String path);

	Object getValue();

	void setValue(Object value);

	Operation getOperation();

	void setOperation(Operation operation);

}
