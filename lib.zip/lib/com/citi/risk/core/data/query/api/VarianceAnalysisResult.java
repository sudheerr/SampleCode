package com.citi.risk.core.data.query.api;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.table.SimpleTable;

/**
 * A representation of a {@link com.citi.risk.core.data.query.api.VarianceAnalysis VarianceAnalysis} result. It contains two query results and a Difference Table to present the difference between the two query results.
 * 
 * @author ww78389
 * 
 * @param <E>
 *            type of the element queried for
 * 
 * @see com.citi.risk.core.data.query.api.VarianceAnalysis
 * @see com.citi.risk.core.dictionary.api.VarianceAnalysisRequest
 */
public interface VarianceAnalysisResult<E> {

	QueryResult<E> getControlQueryResult();

	QueryResult<E> getNonControlQueryResult();

	/**
	 * Return the Difference of ControlQueryResult and NonControlResult in a SimpleTable. The types in the table are < Integer, DataSelectionItem, CompareResult >
	 */
	SimpleTable getDifference();

	Collection<Group.Element<List<?>, E>> getNonControlOnlyAggregatedResult();

	List<E> getNonControlOnlySearchResult();
	
	String getTargetTimeMarkKeyString();

	void setDifference(SimpleTable difference);

	void setNonControlQueryResult(QueryResult nonControlQueryResult);

	void setControlQueryResult(QueryResult controlQueryResult);

	void setNonControlOnlyAggregatedResult(List<Group.Element<List<?>, E>> aggregatedResult);

	void setNonControlOnlySearchResult(List<E> searchResult);
	
	void setTargetTimeMarkKeyString(String timeMarkKeyString);

	void setNonControlGroupMap(Map<List<?>, Element<List<?>, E>> groupMap);
	
	Map<List<?>, Element<List<?>, E>> getNonControlGroupMap();

	public void setComparedResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult);

	public Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> getComparedResult();
}
