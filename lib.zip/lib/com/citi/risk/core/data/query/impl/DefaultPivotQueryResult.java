package com.citi.risk.core.data.query.impl;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.pivot.api.PivotTable;
import com.citi.risk.core.data.query.api.PivotQueryResult;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class DefaultPivotQueryResult<E> extends DefaultQueryResult<E> implements PivotQueryResult<E> {

	private PivotTable<E, ?, ?> pivotTable;

	private DataSelection<E> rowDimension;
	
	private DataSelection<E> columnDimension;

	private DataSelection<E> aggregateMeasure;


	public DefaultPivotQueryResult(DataSelection<E> rowDimension, DataSelection<E> columnDimension, DataSelection<E> aggregateMeasure) {
		this.rowDimension = rowDimension;
		this.columnDimension = columnDimension;
		this.aggregateMeasure = aggregateMeasure;
	}

	public void setPivotTable(PivotTable<E, ?, ?> pivotTable) {
		this.pivotTable = pivotTable;
	}

	@Override
	public <R, C> PivotTable<E, R, C> getPivotTable() {
		return (PivotTable<E, R, C>) this.pivotTable;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public <R, C> PivotTable<E, R, C> getPivotTable(DataSelectionItem<E, R> topLevelRowDsi, DataSelectionItem<E, C> topLevelColumnDsi) {
		boolean rowDimensionMatch = false;
		boolean columnDimensionMatch = false;
		
		if(CollectionUtils.isEmpty(rowDimension.getSelectionItems())) {
			if(topLevelRowDsi == null) rowDimensionMatch = true;
		} else if(topLevelRowDsi != null && rowDimension.getSelectionItems().get(0).equals(topLevelRowDsi)) { 
			rowDimensionMatch = true;
		}
		
		if(CollectionUtils.isEmpty(columnDimension.getSelectionItems())) { 
			if(topLevelColumnDsi == null) columnDimensionMatch = true;
		} else if(topLevelColumnDsi != null && (columnDimension.getSelectionItems().get(0).equals(topLevelColumnDsi))) { 
			columnDimensionMatch = true;
		}

		if(rowDimensionMatch && columnDimensionMatch) 
			return (PivotTable<E, R, C>) pivotTable;
		
		return null;
	}

	@Override
	public DataSelection<E> getRowDimension() {
		return rowDimension;
	}

	@Override
	public DataSelection<E> getColumnDimension() {
		return columnDimension;
	}

	@Override
	public DataSelection<E> getAggregateMeasure() {
		return aggregateMeasure;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((aggregateMeasure == null) ? 0 : aggregateMeasure.hashCode());
		result = prime * result
				+ ((columnDimension == null) ? 0 : columnDimension.hashCode());
		result = prime * result
				+ ((pivotTable == null) ? 0 : pivotTable.hashCode());
		result = prime * result
				+ ((rowDimension == null) ? 0 : rowDimension.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultPivotQueryResult other = (DefaultPivotQueryResult) obj;
		if (aggregateMeasure == null) {
			if (other.aggregateMeasure != null)
				return false;
		} else if (!aggregateMeasure.equals(other.aggregateMeasure))
			return false;
		if (columnDimension == null) {
			if (other.columnDimension != null)
				return false;
		} else if (!columnDimension.equals(other.columnDimension))
			return false;
		if (pivotTable == null) {
			if (other.pivotTable != null)
				return false;
		} else if (!pivotTable.equals(other.pivotTable))
			return false;
		if (rowDimension == null) {
			if (other.rowDimension != null)
				return false;
		} else if (!rowDimension.equals(other.rowDimension))
			return false;
		return true;
	}
	

}
