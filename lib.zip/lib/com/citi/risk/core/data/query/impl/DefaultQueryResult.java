package com.citi.risk.core.data.query.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.persistence.Tuple;

import com.citi.risk.core.ioc.impl.guice.CoreModule;
import org.apache.commons.collections.comparators.ComparatorChain;
import org.apache.commons.lang3.ArrayUtils;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.query.webservice.impl.DataRow;
import com.citi.risk.core.data.query.webservice.impl.DataTable;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.GroupBy;
import com.citi.risk.core.dictionary.api.PathBasedGroup;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.execution.impl.DefaultManagedExecutorService;
import com.citi.risk.core.ioc.impl.guice.ExecutorServiceModule.ManagedExecutorServiceProvider;
import com.citi.risk.core.lang.algo.AggrSortMergeHybridTask;
import com.citi.risk.core.lang.algo.SortMergeHybridTask;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.AbstractGroup.DefaultElement;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.group.Group.Element;
import com.citi.risk.core.lang.table.ColumnarTable;
import com.citi.risk.core.lang.table.DefaultSimpleTable;
import com.citi.risk.core.lang.table.RowMapper;
import com.citi.risk.core.lang.table.SimpleResultSet;
import com.citi.risk.core.lang.table.SimpleTable;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

class DefaultQueryResult<E> implements QueryResult<E> {

	private static final String TIME_MARK_KEY = "TimeMark Key";
	private static final String TIME_MARK_DOMAIN_NAME = "TimeMark";
	private Collection<E> searchResult;
	private Collection<Group.Element<List<?>, E>> aggregatedResult;
	private Collection<Group.Element<List<?>, E>> groupByResult;
	private Collection<Group.Element<List<?>, E>> rollupResult;
	private Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult = new HashMap<>();
	private Collection<List<String>> nonControlOnlyGroupKey = new ArrayList<>();
    private Collection<E> nonControlOnlySearchResult = new ArrayList<>();
	private transient int[] pathToGroupIndice = new int[64];
	private Map<DataPath, Integer> pathToGroupIndiceForNonControlOnlyElement = new HashMap<>();
	private SimpleTable table;
	private Integer totalRowCount;
	private Integer totalPageCount;
	private OutputStream excelOutputStream;
	private List<DataTable> dataTables;
	private ColumnarTable columnarTable;
	private Collection<Tuple> tupleResult;
	private Map<List<?>, Element<List<?>, E>> nonControlGroupMap;
	private SimpleResultSet simpleResultSet;
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.risk.core.data.query.impl.QueryResult#getSearchResult()
	 */
	@Override
	public Collection<E> getSearchResult() {
		return searchResult;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.risk.core.data.query.impl.QueryResult#setSearchResult(java.util .Collection)
	 */
	@Override
	public void setSearchResult(Collection<E> searchResult) {
		this.searchResult = searchResult;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.risk.core.data.query.impl.QueryResult#getAggregedResult()
	 */
	@Override
	public Collection<Group.Element<List<?>, E>> getAggregedResult() {
		return aggregatedResult;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.risk.core.data.query.impl.QueryResult#setAggregatedResult(java .util.Collection)
	 */
	@Override
	public void setAggregatedResult(Collection<Group.Element<List<?>, E>> aggregatedResult) {
		this.aggregatedResult = aggregatedResult;
	}

	@Override
	public Collection<Group.Element<List<?>, E>> getGroupByResult() {
		return groupByResult;
	}

	@Override
	public void setGroupByResult(Collection<Group.Element<List<?>, E>> groupByResult) {
		this.groupByResult = groupByResult;
	}

	@Override
	public Collection<Group.Element<List<?>, E>> getRollupResult() {
		return rollupResult;
	}

	@Override
	public void setRollupResult(Collection<Group.Element<List<?>, E>> rollupResult) {
		this.rollupResult = rollupResult;
	}

	private int[] addIntoIntArray(int[] array, int index, int value){
		int[] newArray = array;
		if(newArray == null || newArray.length == 0){
			newArray = new int[64];
		}
		
		if(index >= newArray.length){
			int extendSize = Math.max(index-newArray.length+1, newArray.length >> 2);
			newArray = Arrays.copyOf(newArray, newArray.length + extendSize);
		}
		newArray[index] = value;
		
		return newArray;
	}
	
	@Override
	public void addPathToGroupIndex(DataSelectionItem<?, ?> dsi, int index){
		int[] arrayCopy = addIntoIntArray(pathToGroupIndice, dsi.getSequenceNumber(), index);
		if(pathToGroupIndice != arrayCopy){
			pathToGroupIndice = arrayCopy;
		}
		
		DataPath<?, ?> path = dsi.getUnderlyingPath();
		if (!path.toPathString().contains(TIME_MARK_DOMAIN_NAME)) {
			int size = pathToGroupIndiceForNonControlOnlyElement.size();
			pathToGroupIndiceForNonControlOnlyElement.put(path, size);
		}
	}

	@Override
	public SimpleTable getTable() {
		return table;
	}

	@Override
	public void setTable(SimpleTable table) {
		this.table = table;
	}

	@Override
	public Integer getResultPageCount() {
		return totalPageCount;
	}

	@Override
	public void setResultPageCount(int count) {
		this.totalPageCount = count;
	}

	@Override
	public Integer getResultRowCount() {
		return totalRowCount;
	}

	@Override
	public void setResultRowCount(int count) {
		this.totalRowCount = count;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.risk.core.data.query.impl.QueryResult#toValues(com.citi.risk .core.dictionary.api.DataSelectionItem)
	 */
	@Override
	public <V> List<V> toValues(DataSelectionItem<E, V> dataSelectionItem) {
		if (tupleResult != null) {
			return toValuesFromTuples(dataSelectionItem);
		} else if (aggregatedResult == null) {
			return toValuesFromSearchResult(dataSelectionItem);
		}
		return toValueFromGroupingResult(dataSelectionItem);
	}

	private <V> List<V> toValueFromGroupingResult(DataSelectionItem<E, V> dataSelectionItem) {
		List<V> values = new ArrayList<>(this.aggregatedResult.size());

		AggregateMeasure<?, ?> selectedAggregateMeasure = dataSelectionItem.getSelectedAggregateMeasure();
		DataPath path = dataSelectionItem.getUnderlyingPath();

		if (dataSelectionItem.getCompareMeasure() != null) {
			Function compareResultTransform = dataSelectionItem.getCompareMeasure().getResultTransform();
			for (Element<List<?>, E> element : this.getAggregedResult()) {
				E object = element.getMembers().iterator().next();
				CompareResult compareResult = this.comparedResult.get(object).get(dataSelectionItem);
				if (compareResult == null) {
					values.add(null);
				} else {
					V _comparedResult = (V) compareResultTransform.apply(compareResult);
					values.add(_comparedResult);
				}
			}
			return values;
		}

		if (selectedAggregateMeasure != null) {
			Function fromAggrResultToValue = selectedAggregateMeasure.getResultTransform();
			for (Element<? extends List<?>, E> groupElement : this.aggregatedResult) {
				Object aggregateResult = groupElement.getAggregationResult(dataSelectionItem);
				List<String> group = (List<String>) groupElement.getGroup();
				if (!nonControlOnlyGroupKey.isEmpty() && nonControlOnlyGroupKey.contains(group)) {
					values.add(null);
				} else {
					values.add((V) fromAggrResultToValue.apply(aggregateResult));
				}
			}
			return values;
		}

		for (Element<? extends List<?>, E> groupElement : this.aggregatedResult) {
			List<String> group = (List<String>) groupElement.getGroup();
			if (!nonControlOnlyGroupKey.isEmpty() && nonControlOnlyGroupKey.contains(group)) {
				if (path.toPathString().contains(TIME_MARK_KEY)) {
					String string = group.get(group.size() - 1);
					values.add((V) string);
				} else {
					boolean containsKey = this.pathToGroupIndiceForNonControlOnlyElement.containsKey(path);
					Integer index = this.pathToGroupIndiceForNonControlOnlyElement.get(path);
					V v = (V) group.get(index);
					values.add(containsKey ? v : null);
				}
			} else {
				Integer index = this.pathToGroupIndice[dataSelectionItem.getSequenceNumber()];
				V e = (V) group.get(index);
				values.add(e);
			}

		}
		return values;
	}

	@Override
	public DataRow toDataRowFromRollUpResult(DataSelection<E> dataSelection, Group.Element<List<?>, E> element) {
		List<DataSelectionItem<E, ?>> dataSelectionItems = dataSelection.getSelectionItems();

		DataRow dataRow = new DataRow();
		List<String> columns = Lists.newArrayList();
		List<?> group = element.getGroup();

		for (DataSelectionItem<E, ?> dsi : dataSelectionItems) {
			AggregateMeasure<?, ?> selectedAggregateMeasure = dsi.getSelectedAggregateMeasure();

			if (selectedAggregateMeasure != null) {
				Function fromAggrResultToValue = selectedAggregateMeasure.getResultTransform();
				Object aggregateResult = element.getAggregationResult(dsi);
				Object o = fromAggrResultToValue.apply(aggregateResult);
				String s = o == null ? null : o.toString();
				columns.add(s);
			} else {
				Integer index = this.pathToGroupIndice[dsi.getSequenceNumber()];
				Object o;
				if (index != null && index < group.size()) {
					o = group.get(index);
				} else {
					continue;
				}
				String s = o == null ? null : o.toString();
				columns.add(s);
			}
		}
		dataRow.setColumns(columns);

		return dataRow;
	}

	protected <V> V toValueFromGroupingResult(DataSelectionItem<E, V> dataSelectionItem,
			Element<? extends List<?>, E> element) {
		if (element == null) return null;

		AggregateMeasure<?, ?> selectedAggregateMeasure = dataSelectionItem.getSelectedAggregateMeasure();
		V value;

		if (selectedAggregateMeasure != null) {
			Function fromAggrResultToValue = selectedAggregateMeasure.getResultTransform();
			value = (V) fromAggrResultToValue.apply(element.getAggregationResult(dataSelectionItem));
		} else {
			value = (V) element.getGroup().get(pathToGroupIndice[dataSelectionItem.getSequenceNumber()]);
		}

		return value;
	}

	private <V> List<V> toValuesFromSearchResult(DataSelectionItem<E, V> dataSelectionItem) {
		if (dataSelectionItem.getCompareMeasure() == null) {
			return toValuesWithoutCompareMeasure(dataSelectionItem);
		} else {
			return toValuesWithCompareMeasure(dataSelectionItem);
		}
	}

	private <V> List<V> toValuesWithCompareMeasure(DataSelectionItem<E, V> dataSelectionItem) {
		Function compareResultTransform = dataSelectionItem.getCompareMeasure().getResultTransform();
		List<V> values = new ArrayList<>(this.searchResult.size());
		for (E object : this.searchResult) {
			V _comparedResult;
			Map<DataSelectionItem<E, ?>, CompareResult> comparedResultMap = this.comparedResult.get(object);
			if (comparedResultMap == null) {
				_comparedResult = null;
			} else {
				CompareResult compareResult = comparedResultMap.get(dataSelectionItem);
				_comparedResult = compareResult == null ? null : (V) compareResultTransform.apply(compareResult);
			}
			values.add(_comparedResult);
		}
		return values;
	}

	private <V> List<V> toValuesWithoutCompareMeasure(DataSelectionItem<E, V> dataSelectionItem) {
		Function<E, V> fromObjectToValue = (Function<E, V>) dataSelectionItem.getUnderlyingPath().getTranform();
		List<V> values = new ArrayList<>(this.searchResult.size());
		for (E object : this.searchResult) {
			if (!nonControlOnlySearchResult.isEmpty() && nonControlOnlySearchResult.contains(object)) {
				if (dataSelectionItem.getUnderlyingPath().getTerminatingItem().isDimension()) {
					values.add(fromObjectToValue.apply(object));
				} else {
					values.add(null);
				}
			} else {
				values.add(fromObjectToValue.apply(object));
			}
		}
		return values;
	}

	private <V> List<V> toValuesFromTuples(DataSelectionItem<E, V> dataSelectionItem) {
		List<V> values = Lists.newArrayListWithExpectedSize(this.tupleResult.size());
		for (Tuple tuple : tupleResult) {
			values.add((V) tuple.get(dataSelectionItem.toString(), dataSelectionItem.getUnderlyingPath()
					.getTerminatingItem().getJavaSimpleType()));
		}

		return values;
	}

	@Override
	public void orderByWithPagination(DataSelectionItem[] dsis, int pageSize, int pageIndex, int maxRowCount) {
		if (aggregatedResult == null) {
			orderingAndPagingSearchResult(dsis, pageSize, pageIndex, maxRowCount);
		} else {
			orderingAndPagingAggregationResult(dsis, pageSize, pageIndex, maxRowCount);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void orderingAndPagingAggregationResult(DataSelectionItem[] dsis, int pageSize, int pageIndex, int maxRowCount) {
		int leastSearchRows;
		int currentPageSize;
		int totalPages = 1;
		int totalRows;
		boolean reverseSearchForOptimization = false;
		final List<Group.Element<List<?>, E>> aggregateResultList = Lists
				.<Group.Element<List<?>, E>> newArrayList(this.aggregatedResult);
		int partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(aggregateResultList.size());
		
		List<Group.Element<List<?>, E>> sortedAndPagedAggregateResultList = Lists.newArrayList();

		totalRows = aggregateResultList.size();
		if ((maxRowCount < Integer.MAX_VALUE) && (maxRowCount < totalRows)) {
			totalRows = maxRowCount;
		}

		if (pageSize < Integer.MAX_VALUE) {
			totalPages = getTotalPages(pageSize, totalRows);
			if (pageIndex < totalPages - 1) {
				currentPageSize = pageSize;
				leastSearchRows = (pageSize * pageIndex) + pageSize;
				if ((leastSearchRows > partitionSize / 2) && (pageIndex > totalPages / 2)) {
					reverseSearchForOptimization = true;
					leastSearchRows = (totalPages - pageIndex) * pageSize;
				}
			} else {
				leastSearchRows = totalRows;
				currentPageSize = totalRows % pageSize == 0 ? pageSize : totalRows % pageSize;
				if ((leastSearchRows > partitionSize / 2) && (pageIndex > totalPages / 2)) {
					reverseSearchForOptimization = true;
					leastSearchRows = currentPageSize;
				}
			}
		} else {
			leastSearchRows = totalRows;
			currentPageSize = aggregateResultList.size();
		}

		if (ArrayUtils.isEmpty(dsis)) {
			sortedAndPagedAggregateResultList = aggregateResultList.subList(0, leastSearchRows);
		} else {
			ComparatorChain comparator = new ComparatorChain();
			Comparator<Group.Element<List<?>, E>> singleComparator; 
			SortBy sortBy;
			for (DataSelectionItem dsi : dsis) {
				sortBy = reverseSearchForOptimization ? dsis[0].getReverseSortBy() : dsis[0].getSortBy();
				singleComparator = new AggregatedResultComparator(this, dsi,nonControlOnlyGroupKey);
				comparator.addComparator(singleComparator, sortBy == SortBy.DESC);
			}
			ForkJoinTask<Collection<Element<List<?>, E>>> taskFuture = ManagedExecutorServiceProvider.getInstance().submit(
					new AggrSortMergeHybridTask<E>(aggregateResultList, comparator, null, partitionSize, leastSearchRows,
							CoreModule.getConfiguration().getInteger("query.task.timeout", 60)));
			try {
				sortedAndPagedAggregateResultList.addAll(taskFuture.get(CoreModule.getConfiguration().getInteger("query.task.timeout", 60), TimeUnit.SECONDS));
			} catch (InterruptedException | TimeoutException e) {
				taskFuture.cancel(true);
				throw new TaskTimeoutCancelationException("sort canceled since timeout", e);
			} catch (ExecutionException e) {
				taskFuture.cancel(true);
				throw new RuntimeException(e.getCause());
			}
		}
		int startRow = sortedAndPagedAggregateResultList.size() - currentPageSize > 0 ? sortedAndPagedAggregateResultList
				.size() - currentPageSize
				: 0;
		sortedAndPagedAggregateResultList = sortedAndPagedAggregateResultList.subList(startRow,
				sortedAndPagedAggregateResultList.size());
		this.setAggregatedResult(sortedAndPagedAggregateResultList);
		this.setResultRowCount(totalRows);
		this.setResultPageCount(totalPages);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void orderingAndPagingSearchResult(DataSelectionItem[] dsis, int pageSize, int pageIndex, int maxRowCount) {
		int leastSearchRows;
		int currentPageSize;
		int totalPages = 1;
		int totalRows;
		boolean reverseSearchForOptimization = false;
		final List<E> searchResultList = Lists.newArrayList(this.searchResult);
		int partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(searchResultList.size());
		List<E> sortedAndPagedSearchResultList = Lists.newArrayList();

		totalRows = searchResultList.size();
		if ((maxRowCount < Integer.MAX_VALUE) && (maxRowCount < totalRows)) {
			totalRows = maxRowCount;
		}

		if (pageSize < Integer.MAX_VALUE) {
			totalPages = getTotalPages(pageSize, totalRows);
			if (pageIndex < totalPages - 1) {
				currentPageSize = pageSize;
				leastSearchRows = (pageSize * pageIndex) + pageSize;
				if ((leastSearchRows > partitionSize / 2) && (pageIndex > totalPages / 2)) {
					reverseSearchForOptimization = true;
					leastSearchRows = (totalPages - pageIndex) * pageSize;
				}
			} else {
				leastSearchRows = totalRows;
				currentPageSize = totalRows % pageSize == 0 ? pageSize : totalRows % pageSize;
				if ((leastSearchRows > partitionSize / 2) && (pageIndex > totalPages / 2)) {
					reverseSearchForOptimization = true;
					leastSearchRows = currentPageSize;
				}
			}
		} else {
			leastSearchRows = totalRows;
			currentPageSize = searchResultList.size();
		}
		if (ArrayUtils.isEmpty(dsis)) {
			sortedAndPagedSearchResultList = searchResultList.subList(0, leastSearchRows);
		} else {
			ComparatorChain comparator = new ComparatorChain();
			Comparator<E> singleComparator; 
			SortBy sortBy;
			for (DataSelectionItem dsi : dsis) {
				sortBy = reverseSearchForOptimization ? dsi.getReverseSortBy() : dsi.getSortBy();
				singleComparator = new SearchResultComparator(this, dsi);
				comparator.addComparator(singleComparator, sortBy == SortBy.DESC);
			}
			SortMergeHybridTask<E> task = new SortMergeHybridTask<>(searchResultList, comparator, null, partitionSize, leastSearchRows, CoreModule.getConfiguration().getInteger("query.task.timeout", 60));
			ForkJoinTask<Collection<E>> taskFuture = ManagedExecutorServiceProvider.getInstance().submit(task);
			try {
				sortedAndPagedSearchResultList.addAll(taskFuture.get(CoreModule.getConfiguration().getInteger("query.task.timeout", 60), TimeUnit.SECONDS));
			} catch (InterruptedException | TimeoutException e) {
				taskFuture.cancel(true);
				throw new TaskTimeoutCancelationException("sort canceled since timeout", e);
			} catch (ExecutionException e) {
				taskFuture.cancel(true);
				throw new RuntimeException(e.getCause());
			}
		}
		int startRow = sortedAndPagedSearchResultList.size() - currentPageSize > 0 ? sortedAndPagedSearchResultList
				.size() - currentPageSize : 0;
		sortedAndPagedSearchResultList = sortedAndPagedSearchResultList.subList(startRow,
				sortedAndPagedSearchResultList.size());
		this.setSearchResult(sortedAndPagedSearchResultList);
		this.setResultRowCount(totalRows);
		this.setResultPageCount(totalPages);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void groupBySearchResult(GroupBy<E> groupBy, List<DataSelectionItem<E, ?>> dsiToSortList) {

		List<DataSelectionItem<E, ?>> dataSelectionItems = groupBy.getGroupByDataSelectionItems();
		PathBasedGroup<E> group = null;

		List<SortBy> sortBys = new ArrayList<>();
		for (DataSelectionItem<E, ?> dsi : dataSelectionItems) {
			DataPath path = dsi.getUnderlyingPath();
			if (group == null) group = path.getGroup();
			else group.add(path);
			sortBys.add(dsi.getSortBy());
		}
		
		if (group == null) return;

		Map<?, Collection<E>> unSortedMap = group.groupIntoMap(this.searchResult);

		List retElements = new ArrayList();

		for (Object key : unSortedMap.keySet()) {
			Collection<E> sortMembers = orderingSortItems(dsiToSortList, unSortedMap, key);
			Element e = new DefaultElement(key, sortMembers, (AbstractGroup) group);
			retElements.add(e);
		}

		this.groupByResult = retElements;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Collection<E> orderingSortItems(List<DataSelectionItem<E, ?>> dsiToSortList,
			Map<?, Collection<E>> unSortedMap, Object key) {

		Collection<E> sortMembers = unSortedMap.get(key);
		int partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(sortMembers.size());

		for (DataSelectionItem<E, ?> dsi : dsiToSortList) {
			SortBy sortBy = dsi.getSortBy();
			SortMergeHybridTask<E> task = new SortMergeHybridTask<>(sortMembers, new MultiColumnsComparator(dsi,
					dsiToSortList), sortBy, partitionSize, sortMembers.size(), CoreModule.getConfiguration().getInteger("query.task.timeout", 60));
			Collection<E> sortedCollection;
			ForkJoinTask<Collection<E>> sortMergeHybridTask = ManagedExecutorServiceProvider.getInstance().submit(task);
			try {
				sortedCollection = sortMergeHybridTask.get(CoreModule.getConfiguration().getInteger("query.task.timeout", 60), TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				sortMergeHybridTask.cancel(true);
				throw new RuntimeException(e);
			} catch (ExecutionException e) {
				sortMergeHybridTask.cancel(true);
				throw new RuntimeException(e.getCause());
			} catch (TimeoutException e) {
				sortMergeHybridTask.cancel(true);
				throw new TaskTimeoutCancelationException("SortMergeHybridTask timeout", e);
			}
			sortMembers.clear();
			sortMembers.addAll(sortedCollection);
		}
		return sortMembers;
	}

	@Override
	public void writeResultToFile(File targetFile) throws IOException {
		ObjectOutputStream objectOutputStream = null;
		try {
			if (!targetFile.createNewFile()) throw new RuntimeException("File already exists");
			objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(targetFile)));
			objectOutputStream.writeObject((DefaultSimpleTable)this.table);
			objectOutputStream.flush();
			objectOutputStream.close();
		} catch (IOException e) {
			throw new RuntimeException("Write result to File Failed!", e);
		} finally {
			if (objectOutputStream != null) {
				objectOutputStream.close();
			}
		}
	}

	@Override
	public QueryResult<E> readResultFromFile(File file) throws IOException {
		ObjectInputStream objectInputStream = null;
		try {
			objectInputStream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
			SimpleTable tableFromFile = (SimpleTable) objectInputStream.readObject();
			this.setTable(tableFromFile);
		} catch (IOException | ClassNotFoundException e) {
			throw new RuntimeException("Read result from File Failed!", e);
		} finally {
			if (objectInputStream != null) {
				objectInputStream.close();
			}
		}
		return this;
	}

	/**
	 * Populate the specified columns of query result or aggregated result into a <code>Table</code>.
	 * 
	 * @param columns
	 */
	@SuppressWarnings({ "unchecked" })
	protected <K, E extends IdentifiedBy<K>> void populateTable(List<DataSelectionItem<E, ?>> columns) {
		SimpleTable _table = DefaultSimpleTable.create();
		for (DataSelectionItem columnIndex : columns) {
			// TODO eliminate the if/else clauses in toValues
			List<?> columnValues = this.toValues(columnIndex);
			_table.addColumn(columnIndex, columnValues);
		}
		this.setTable(_table);
	}

	private int getTotalPages(int pageSize, int resultSize) {
		int totalPages = resultSize / pageSize;

		if (resultSize % pageSize > 0) {
			++totalPages;
		}
		return totalPages;
	}

	@Override
	public OutputStream getExcelOutputStream() {
		return excelOutputStream;
	}

	@Override
	public void setExcelOutputStream(OutputStream excelOutputStream) {
		this.excelOutputStream = excelOutputStream;
	}

	@Override
	public Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> getComparedResult() {
		return comparedResult;
	}

	@Override
	public void setComparedResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult) {
		this.comparedResult = comparedResult;
	}

	@Override
	public void setDataTables(List<DataTable> dataTables) {
		this.dataTables = dataTables;

	}

	@Override
	public List<DataTable> getDataTables() {
		return dataTables;
	}

	@Override
	public void setColumnarTable(ColumnarTable columnarTable) {
		this.columnarTable = columnarTable;
	}

	@Override
	public ColumnarTable getColumnarTable() {
		return columnarTable;
	}

	@Override
	public int[] getPathToGroupIndice() {
		return this.pathToGroupIndice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aggregatedResult == null) ? 0 : aggregatedResult.hashCode());
		result = prime * result + ((rollupResult == null) ? 0 : rollupResult.hashCode());
		result = prime * result + ((pathToGroupIndice == null) ? 0 : Arrays.hashCode(pathToGroupIndice));
		result = prime * result + ((searchResult == null) ? 0 : searchResult.hashCode());
		result = prime * result + ((table == null) ? 0 : table.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof DefaultQueryResult)) return false;
		DefaultQueryResult<?> other = (DefaultQueryResult<?>) obj;
		if (aggregatedResult == null) {
			if (other.aggregatedResult != null) return false;
		} else if (!aggregatedResult.equals(other.aggregatedResult)) return false;
		if (rollupResult == null) {
			if (other.rollupResult != null) return false;
		} else if (!rollupResult.equals(other.rollupResult)) return false;
		if (pathToGroupIndice == null) {
			if (other.pathToGroupIndice != null) return false;
		}
		else if (!ArrayUtils.isEquals(pathToGroupIndice, other.pathToGroupIndice)) return false;
		if (searchResult == null) {
			if (other.searchResult != null) return false;
		} else if (!searchResult.equals(other.searchResult)) return false;
		if (table == null) {
			if (other.table != null) return false;
		} else if (!table.equals(other.table)) return false;
		if (totalPageCount == null) {
			if (other.totalPageCount != null) return false;
		} else if (!totalPageCount.equals(other.totalPageCount)) return false;
		if (totalRowCount == null) {
			if (other.totalRowCount != null) return false;
		} else if (!totalRowCount.equals(other.totalRowCount)) return false;
		return true;
	}

	@Override
	public void setResultTuples(Collection<Tuple> tuples) {
		this.tupleResult = tuples;
	}

	@Override
	public void setNonControlOnlyGroupKeys(Collection<List<String>> groupKeys) {
		this.nonControlOnlyGroupKey = groupKeys;
	}

	@Override
	public void setNonControlOnlySearchResult(Collection<E> nonControlOnlySearchResult) {
		this.nonControlOnlySearchResult = nonControlOnlySearchResult;
	}
	
	public Collection<E> getNonControlOnlySearchResult() {
		return this.nonControlOnlySearchResult;
	}

	@Override
	public Map<DataPath, Integer> getPathToGroupIndiceForNonControlOnlyElement() {
		return this.pathToGroupIndiceForNonControlOnlyElement;
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getQueryResults(RowMapper<T> mapper) {
		if (this.simpleResultSet == null) {
			return Collections.emptyList();
		}
		
		
		List<T> results = new ArrayList<>(simpleResultSet.getRowSize());
		while (simpleResultSet.next()) {
			results.add(mapper.mapRow(simpleResultSet, simpleResultSet.getCurRowIndex()));
		}

		return results;
	}

	public void populateSimpleResultSet(List<DataSelectionItem<E, ?>> columns) {
		Map<String, Integer> aliasMap = new HashMap<>();
		int columnIndex = 0;
		for (DataSelectionItem<E, ?> dsi : columns) {
			aliasMap.put(dsi.getAlias(), columnIndex++);
		}

		columnIndex = 0;
		for (DataSelectionItem<E, ?> dsi : columns) {
			List<?> columnValues = (List<?>) toValues(dsi);
			if (simpleResultSet == null) {
				simpleResultSet = SimpleResultSet.createWithAliasMap(columnValues.size(),
						columns.size(), aliasMap);
			}

			simpleResultSet.addColumnDimension(columnValues, columnIndex++);
		}
	}

	public void setNonControlGroupMap(Map<List<?>, Element<List<?>, E>> nonControlGroupMap) {
		this.nonControlGroupMap = nonControlGroupMap;
	}

	public Map<List<?>, Element<List<?>, E>> getNonControlGroupMap() {
		return this.nonControlGroupMap;
	}

}
