package com.citi.risk.core.data.query.impl;

import java.util.Collection;
import java.util.Collections;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.impl.DataKeyPredicate;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;

public class DefaultSearchProvider implements SearchProvider {

	Collection<? extends IdentifiedBy<?>> items;

	@Override
	@SuppressWarnings("unchecked")
	public Collection<? extends IdentifiedBy<?>> getAll(DataDomain domain) {

		if (getItems() != null) {
			return getItems();
		} else {
			return Collections.emptyList();
		}
	}

	public <E extends IdentifiedBy> Collection<E> getItems() {
		return (Collection<E>) items;
	}

	public void setItems(Collection<? extends IdentifiedBy<?>> items) {
		this.items = items;
	}

	@Override
	@SuppressWarnings("unchecked")
	public <E extends IdentifiedBy<?>> Collection<E> search(DataDomain domain, Select<E> select) {
		Collection<E> allitems = (Collection<E>) getAll(domain);
		Collection<E> result = select.select(allitems);
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Collection<? extends IdentifiedBy<?>> getAll(DataKey dataKey) {
		return getAll(dataKey.getDomain());
	}

	@Override
	public <E extends IdentifiedBy<?>> Collection<E> search(DataKey dataKey,
			Select<E> select) {
		return search(dataKey.getDomain(), select);
	}
	
	
	@Override
	public <T extends IdentifiedBy<?>> Collection<T> select(Criteria<T> criteria, Select<T> specialSelect){
		DataDomain<T> domain = criteria.getDomain();
        Select<T> select = criteria.getSelect();
        Collection<T> results = search(domain, select);
		return specialSelect.select(results);
	}

}
