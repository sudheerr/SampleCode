package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.gui.event.api.GUIEventService;
import com.google.inject.Inject;

public class GUIEventQuery extends AbstractQuery {

	@Inject
	GUIEventService guiEventService;
	
	@Override
	public SearchProvider getSearchProvider() {
		return guiEventService;
	}

	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.guiEventService = (GUIEventService)searchProvider;
	}
}
