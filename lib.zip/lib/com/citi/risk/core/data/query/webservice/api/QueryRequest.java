package com.citi.risk.core.data.query.webservice.api;

import java.io.Serializable;

public interface QueryRequest extends Serializable {

	public String getDomainName();

	public void setDomainName(String domainName);

	int getPageSize();

	void setPageSize(int size);

	int getPageIndex();

	void setPageIndex(int index);

	int getDefaultPageSize();

	int getMaxRowCount();

	void setMaxRowCount(int maxRowCount);
	
	boolean isGenerateColumnarResults();

	void setGenerateColumnarResults(boolean generateColumnarResults);
}
