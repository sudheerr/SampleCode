package com.citi.risk.core.data.query.impl;

import java.util.Comparator;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.common.base.Function;
import com.google.common.collect.Ordering;

class SearchResultComparator<E, V> implements Comparator<E> {

	private final DataSelectionItem<E, V> dataSelectionItem;
	private QueryResult<E> queryResult;

	public SearchResultComparator(QueryResult<E> queryResult, DataSelectionItem<E, V> dataSelectionItem) {
		this.dataSelectionItem = dataSelectionItem;
		this.queryResult = queryResult;
	}

	@Override
	@SuppressWarnings("unchecked")
	public int compare(E left, E right) {
		V leftValue;
		V rightValue;
		if (dataSelectionItem.getCompareMeasure() != null) {
			Function compareResultTransform = dataSelectionItem.getCompareMeasure().getResultTransform();
			leftValue = getComparedValue(left, compareResultTransform);
			rightValue = getComparedValue(right, compareResultTransform);
		} else {
			Function<E, V> fromObjectToValue = (Function<E, V>) dataSelectionItem.getUnderlyingPath().getTranform();
			leftValue = fromObjectToValue.apply(left);
			rightValue = fromObjectToValue.apply(right);
		}

		return compareWith(leftValue, rightValue);
	}

	private int compareWith(V leftValue, V rightValue) {
		if (leftValue == rightValue) {
			return 0;
		}
		if (leftValue == null) {
			return -1;
		}
		if (rightValue == null) {
			return 1;
		}
		if (Comparable.class.isAssignableFrom(leftValue.getClass())) {
			return leftValueComparable(leftValue, rightValue);
		} else {
			return Ordering.natural().compare(ObjectUtils.toString(leftValue), ObjectUtils.toString(rightValue));
		}
	}

	private int leftValueComparable(V leftValue, V rightValue) {
		if (dataSelectionItem.getUnderlyingPath().toPathString().contains("TimeMark Key")) {
			TimeMark leftTimeMark = DefaultTimeMark.getTimeMarkfromKey(leftValue.toString());
			TimeMark rightTimeMark = DefaultTimeMark.getTimeMarkfromKey(rightValue.toString());
			return Ordering.natural().compare(leftTimeMark, rightTimeMark);
		}
		return Ordering.natural().compare((Comparable<V>) leftValue, (Comparable<V>) rightValue);
	}

	private V getComparedValue(E left, Function compareResultTransform) {
		Map<DataSelectionItem<E, ?>, CompareResult> comparedResultMap = this.queryResult.getComparedResult().get(left);
		if (comparedResultMap == null) return null;
		CompareResult compareResult = comparedResultMap.get(dataSelectionItem);
		return compareResult == null ? null : (V) compareResultTransform.apply(compareResult);
	}
}
