package com.citi.risk.core.data.query.impl;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.service.impl.DefaultDataAccessService;
import com.google.inject.Inject;
import com.google.inject.Injector;

/**
 * Created by lw84456 on 5/20/2016.
 */
public class CustomDataQuery extends AbstractQuery{
    @Inject
    Injector injector;

    private SearchProvider dataAccessor = injector.getInstance(DefaultDataAccessService.class);

    @Override
    public SearchProvider getSearchProvider() {
        return dataAccessor;
    }

    @Override
    public void setSearchProvider(SearchProvider searchProvider) {
        dataAccessor = searchProvider;
    }
}
