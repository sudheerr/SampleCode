package com.citi.risk.core.data.query.webservice.api;

import java.util.concurrent.Future;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface Query {

	<K, E extends IdentifiedBy<K>> Future<QueryResult> submit(QueryRequest queryRequest);
}
