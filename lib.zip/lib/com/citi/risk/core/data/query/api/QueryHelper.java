package com.citi.risk.core.data.query.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.lang.table.SimpleTable;

/**
 * Helps query data through {@link com.citi.risk.core.data.query.api.Query
 * Query}. This interface only exposes the very basic functionalities of Query
 * interface, use Query for the full functionalities.
 * 
 * @see com.citi.risk.core.data.query.api.DataAccessQuery
 * @see com.citi.risk.core.dictionary.api.DataPath
 * @see com.citi.risk.core.dictionary.api.SortBy
 *
 */
public interface QueryHelper {

	OngoingQueryStatment selectFrom(Class domainImplClass);

	@SuppressWarnings("unchecked")
	<D> OngoingQueryStatment<D> select(DataPath<D, ?>... paths);
	
	@SuppressWarnings("unchecked")
	<D> OngoingQueryStatment<D> select(DataSelection<D>... dataSelections);

	interface OngoingQueryStatment<D> {
		OngoingQueryStatment<D> from(Class<? extends D> domainImplClass);

		OngoingQueryStatment<D> where(Criteria<D> criteria);

		OngoingQueryStatment<D> top(int topCount);

		OngoingQueryStatment<D> orderBy(DataPath<D, ?> path, SortBy sorby);

		QueryRequest<D> toQueryRequest();

		Collection<D> queryDomains();

		Collection<D> queryDomainsForUpdate();

		SimpleTable queryTable();
	}
}