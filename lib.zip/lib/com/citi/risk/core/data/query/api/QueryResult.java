package com.citi.risk.core.data.query.api;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.Tuple;

import com.citi.risk.core.data.query.webservice.impl.DataRow;
import com.citi.risk.core.data.query.webservice.impl.DataTable;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.GroupBy;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.table.ColumnarTable;
import com.citi.risk.core.lang.table.RowMapper;
import com.citi.risk.core.lang.table.SimpleTable;

/**
 * A representation of query result. Contains both a collection of simple search elements and grouped elements
 * 
 * @param <E>
 *            type of the element queried for
 * @see com.citi.risk.core.lang.group.Group
 * @see com.citi.risk.core.lang.table.Table
 * @see com.citi.risk.core.dictionary.api.DataSelectionItem
 */
public interface QueryResult<E> {

	/**
	 * Returns the search result in the form of a collection of type E
	 * 
	 * @return
	 */
	public Collection<E> getSearchResult();

	/**
	 * Sets the search result to this object
	 * 
	 * @param searchResult
	 *            Collection of type E
	 */
	public void setSearchResult(Collection<E> searchResult);

	/**
	 * Returns the Aggregated Result for the Query
	 * 
	 * @return
	 */
	public Collection<Group.Element<List<?>, E>> getAggregedResult();

	Collection<Group.Element<List<?>, E>> getGroupByResult();

	void setGroupByResult(Collection<Group.Element<List<?>, E>> groupByResult);

	Collection<Group.Element<List<?>, E>> getRollupResult();

	void setRollupResult(Collection<Group.Element<List<?>, E>> rollupResult);

	/**
	 * Sets the aggregated result with the Collection passed in as argument
	 * 
	 * @param aggregatedResult
	 */
	public void setAggregatedResult(Collection<Group.Element<List<?>, E>> aggregatedResult);

	public void setComparedResult(Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> comparedResult);

	public Map<E, Map<DataSelectionItem<E, ?>, CompareResult>> getComparedResult();

	public Integer getResultPageCount();

	public void setResultPageCount(int count);

	public Integer getResultRowCount();

	public void setResultRowCount(int count);

	/**
	 * Sets the <code>SimpleTable</code> with the table argument passed
	 * 
	 * @param table
	 */
	public void setTable(SimpleTable table);

	/**
	 * Returns the <code>Table</code>
	 * 
	 * @return <code>Table</code>
	 */
	public SimpleTable getTable();

	void setExcelOutputStream(OutputStream excelOutputStream);

	OutputStream getExcelOutputStream();

	/**
	 * Serialize the current QueryResult to a target File
	 */
	public void writeResultToFile(File file) throws IOException;

	/**
	 * Deserialize the current QueryResult from a target File
	 */
	public QueryResult<E> readResultFromFile(File file) throws IOException;

	public void addPathToGroupIndex(DataSelectionItem<?, ?> dsi, int index);

	/**
	 * Converts the passed in <code>DataSelectionItem</code> and returns a {@code List} of values of type V
	 * 
	 * @param dataSelectionItem
	 * @return
	 */
	public <V> List<V> toValues(DataSelectionItem<E, V> dataSelectionItem);

	DataRow toDataRowFromRollUpResult(DataSelection<E> dataSelection, Group.Element<List<?>, E> element);

	void orderByWithPagination(DataSelectionItem[] dsi, int pageSize, int pageIndex, int maxRowCount);

	void setDataTables(List<DataTable> dataTables);

	List<DataTable> getDataTables();

	void setColumnarTable(ColumnarTable columnarTable);

	public ColumnarTable getColumnarTable();

	public abstract int[] getPathToGroupIndice();

	void groupBySearchResult(GroupBy<E> groupBy, List<DataSelectionItem<E, ?>> dsiToSortList);

	void setResultTuples(Collection<Tuple> tuples);

	/**
	 * add nonControlOnlyGropuKeys field to implement outer join function. This collection of keys will be used for populating table, sort and pagination
	 * 
	 * @param groupKeys
	 */
	public void setNonControlOnlyGroupKeys(Collection<List<String>> groupKeys);

	public void setNonControlOnlySearchResult(Collection<E> nonControlOnlySearchResult);

	public Map<DataPath, Integer> getPathToGroupIndiceForNonControlOnlyElement();

	<T> List<T> getQueryResults(RowMapper<T> mapper);
}
