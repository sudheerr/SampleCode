package com.citi.risk.core.data.query.api;

import java.util.List;
import java.util.Set;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;


/**
 * A representation of Query. The implementation class will have a ExecutorService
 * that handles the query submit call. 
 * 
 * <p> Caller can pass in the query request via a
 * {@link com.citi.risk.core.dictionary.api.QueryRequest QueryRequest} and get the
 * Future of  {@link com.citi.risk.core.data.query.api.QueryResult QueryResult} 
 * </p>
 *
 * @param <K> key type to lookup by
 * @param <E> value type in cache, extends IdentifiedBy of type K
 * 
 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
 * @see com.citi.risk.core.dictionary.api.QueryRequest
 * @see com.citi.risk.core.data.query.api.QueryResult
 * @see com.citi.risk.core.dictionary.api.DataDomain
 */
public interface DataAccessQuery extends Query
{
	/**
	 * Returns a Element value for the given Domain and Key parameters 
	 * @param domain 
	 * @param key
	 * @return
	 */
	<K, E extends IdentifiedBy<K>> E get(DataDomain domain, K key);
	
	/**
	 * Returns a list of element values for the given Domain and the List of Keys
	 * 
	 * @param domain
	 * @param keys
	 * @return
	 */
	<K, E extends IdentifiedBy<K>> List<E> get(DataDomain domain, List<K> keys);

	Set<DataKey> searchDataAvailabilities();
	
	Set<DataKey> searchDataAvailabilities(TimeMark timeMark);
}
