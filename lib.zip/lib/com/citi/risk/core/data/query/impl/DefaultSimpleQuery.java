package com.citi.risk.core.data.query.impl;

import java.util.Collection;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.query.api.SimpleQuery;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public class DefaultSimpleQuery extends AbstractQuery implements SimpleQuery{
	private SearchProvider searchProvider = new DefaultSearchProvider();

	@Override
	public SimpleQuery withItemsToSearch(Collection<? extends IdentifiedBy<?>> items) {
		((DefaultSearchProvider) this.searchProvider).setItems(items);
		return this;
	}

	@Override
	public final SearchProvider getSearchProvider() {
		return searchProvider;
	}

	@Override
	public void setSearchProvider(SearchProvider searchProvider) {
		this.searchProvider = searchProvider;
	}

}
