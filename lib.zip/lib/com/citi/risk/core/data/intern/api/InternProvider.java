package com.citi.risk.core.data.intern.api;

import java.util.Collection;

public interface InternProvider {

	<T> T get(T t);
	
	Collection<Class> getInternClasses();
	
	int getInternCount(Class klass);

	String getInternHitRate(Class klass);
	
	void clearIntern(Class klass);

}
