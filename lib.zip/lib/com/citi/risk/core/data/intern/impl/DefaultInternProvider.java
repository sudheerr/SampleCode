package com.citi.risk.core.data.intern.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.hibernate.annotations.Immutable;

import com.citi.risk.core.data.intern.api.InternProvider;
import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.collect.Interner;
import com.google.common.collect.Interners;
import com.google.common.collect.Maps;
import com.google.common.primitives.Primitives;
import com.google.inject.Singleton;

@Singleton
public class DefaultInternProvider implements InternProvider {

	private DecimalFormat df = new DecimalFormat("#.00"); 
	
	@SuppressWarnings("rawtypes")
	private ConcurrentMap<Class, Pair<Interner, AtomicLong>> 
				internersByClass = Maps.<Class, Pair<Interner, AtomicLong>>newConcurrentMap();

	@Override
	@SuppressWarnings("unchecked")
	public <T> T get(T value) {
		if(value == null) return value;
		final Class<T> klazz = (Class<T>)value.getClass();
		if(!isInternable(klazz)) 
			return value;
		if (value instanceof ValueHolder) {
			ValueHolder<T> valueHolder = (ValueHolder<T>) value;
			T tValue = valueHolder.get();
			if (tValue != null && 
					!NullTerminator.isNullTerminatorClass(tValue.getClass()) 
					&& isImmutableDomain(tValue.getClass())) {
				valueHolder.set(getInterned(tValue));
			}
			return (T) valueHolder;
		} else {
			return getInterned(value);
		}
	}
	
	@SuppressWarnings("unchecked")
	private <T> T getInterned(T value) {
		final Class<T> klazz = (Class<T>)value.getClass();

		Pair<Interner, AtomicLong> pair = 
					(Pair<Interner, AtomicLong>)internersByClass.get(klazz);
	
		if (pair == null) {
			Interner<T> interner = Interners.<T>newStrongInterner();
			pair = new Pair(interner, new AtomicLong(0L));
			internersByClass.putIfAbsent(klazz, pair);
		}
		
		Interner<T> interner = (Interner<T>)pair.getFirst();
		pair.getSecond().incrementAndGet();
		return (T)interner.intern(value);
	}
	
	@SuppressWarnings("rawtypes")
	private boolean isInternable(Class klazz) {
		return klazz.isPrimitive()
				|| (Primitives.isWrapperType(klazz))
				|| (klazz == Date.class)
				|| (klazz == String.class)
				|| (klazz == Timestamp.class)
				|| (klazz == BigDecimal.class)
				|| (klazz == BigInteger.class)
				|| (klazz == java.sql.Date.class)
				|| (ValueHolder.class.isAssignableFrom(klazz))
				|| isImmutableDomain(klazz);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private boolean isImmutableDomain(Class klass) {
		return klass.isAnnotationPresent(Immutable.class);
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public Collection<Class> getInternClasses() {
		return internersByClass.keySet();
	}

	@SuppressWarnings("rawtypes")
	@Override
	public int getInternCount(Class klass) {
		Pair<Interner, AtomicLong> pair = internersByClass.get(klass);
		if (pair != null) {
			Map map = getInternMapFromInterner(pair.getFirst());
			return map == null ? 0 : map.size();
		}
		return 0;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void clearIntern(Class klass) {
		Pair<Interner, AtomicLong> pair = internersByClass.get(klass);
		if (pair != null) {
			Map map = getInternMapFromInterner(pair.getFirst());
			if(map != null) {
				map.clear();
			}
			pair.getSecond().set(0L);
		}
	}
	
	@SuppressWarnings("rawtypes")
	private Map getInternMapFromInterner(Interner intern) {
		Map map = null;
		if (intern != null) {
			try {
				map = (Map) FieldUtils.readDeclaredField(intern, "val$map", true);
			} catch (Exception e) {
				throw new RuntimeException("can not find Val$map field", e);
			}
		}
		return map;
	}

	@Override
	public String getInternHitRate(Class klass) {
		Pair<Interner, AtomicLong> pair = internersByClass.get(klass);
		if (pair != null) {
			Map map = getInternMapFromInterner(pair.getFirst());
			if (map != null && map.size() != 0) {
				double rate = (double)(pair.getSecond().get()) / map.size();
				return df.format(rate);
			}
		}
		return "0.00";
	}
}
