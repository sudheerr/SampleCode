/**
 * 
 */
package com.citi.risk.core.data.json;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataSelection;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.ItemList;
import com.citi.risk.core.dictionary.api.QueryRequest;
import com.citi.risk.core.dictionary.impl.DefaultQueryRequest;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

/**
 * @author kb59097
 *
 */
public class QueryRequestJsonSerializer implements JsonSerializer, JsonDeserializer {
	private static final Logger LOGGER = LoggerFactory.getLogger(QueryRequestJsonSerializer.class);
	private Injector injector = Guice.createInjector(CoreModule.getInstance());
	
	@Inject
	private DictionaryParser parser;
	
	private Map<String,Integer> jsonObjectCache;
	private Map<String,Object> deserializedObjectCache;
	
	public static final String REF_PREFEX="REFERENCE";
	
	public QueryRequestJsonSerializer(){
		jsonObjectCache=new HashMap();
		deserializedObjectCache=new HashMap();
		injector.injectMembers(this);
	}
	
	@Override
	public JsonElement serialize(Object obj, Type arg1,
			JsonSerializationContext context) {
		JsonObject jsonObj = new JsonObject();
		if(obj==null){
			return jsonObj;
		}
		if(DataDomain.class.isAssignableFrom(obj.getClass())){
			return createDomainJsonObject((DataDomain)obj,context);
		}else if(DataSelection.class.isAssignableFrom(obj.getClass())){
			return createDataSelectionJsonObject((DataSelection)obj,context);
		}
		return jsonObj;
	}

	@Override
	public Object deserialize(JsonElement element, Type type,
			JsonDeserializationContext context) throws JsonParseException{
		Class clazz=(Class)type;
		JsonObject obj=element.getAsJsonObject();
		Object request= null;
		if(StringUtils.equals(QueryRequest.class.getName(), clazz.getName())){
			request = deserializeQueryRequest(obj,context);
		}else if(StringUtils.equals(DataDomain.class.getName(), clazz.getName())){
			return deserializeDomain(obj,context);
		}
		return request;
	}
	
	private void deserializeDataSelectionItemAndBuild(QueryRequest request,JsonObject obj,JsonDeserializationContext context){
		JsonArray jarray=obj.get("dataSelectionItems").getAsJsonArray();
		int i = 0;
		JsonElement itemElement;
		while(i<jarray.size()){
			itemElement=jarray.get(i).getAsJsonObject().get("path");
			DataPath path=deserializePath(itemElement.getAsJsonObject(),context);
			request.getDataSelection().and(path);
			i++;
		}
	}
	
	public DataPath deserializePath(JsonObject obj,JsonDeserializationContext context){
		JsonObject terminatingItem=obj.get("terminatingItem").getAsJsonObject();
		DataDomain domain=deserializeDomain(terminatingItem.get("domain").getAsJsonObject(),context);
		if(terminatingItem.get("isItemList")==null){
			return domain.getItem(terminatingItem.get("name").getAsString()).path();
		}else{
			ItemList itemList=domain.getItemLists(terminatingItem.get("name").getAsString());
			return itemList.elementPath(obj.get("index").getAsInt());
		}
		
	}
	
	private QueryRequest deserializeQueryRequest(JsonObject obj,JsonDeserializationContext context){
		JsonElement domainElement=obj.get("domain");
		DataDomain domain=context.deserialize(domainElement,DataDomain.class);
		QueryRequest request=new DefaultQueryRequest(domain);
		request.setFromWebService(obj.get("fromWebService").getAsBoolean());
		request.setMaxRowCount(obj.get("maxRowCount").getAsInt());
		request.setPageIndex(obj.get("pageIndex").getAsInt());
		request.setPageSize(obj.get("pageSize").getAsInt());
		request.setIncludeItems(obj.get("includeItems").getAsBoolean());
		deserializeDataSelectionItemAndBuild(request,obj.get("dataSelection").getAsJsonObject(),context);
		// deserialize Criteria item
		return request;
	}
	
	private DataDomain deserializeDomain(JsonObject obj,JsonDeserializationContext contenxt){
		String reference=obj.get(REF_PREFEX).getAsString();
		if(!deserializedObjectCache.containsKey(reference)){
			String domainClass=obj.get("domainClass").getAsString();
			try {
				Class newClass=Class.forName(domainClass);
				DataDomain domain= parser.parseDomain(newClass);
				deserializedObjectCache.put(reference, domain);
				return domain;
			} catch (ClassNotFoundException e) {
				LOGGER.error("Can't find class" + domainClass + " context: " + contenxt.toString(), e);
			}
		}
		return (DataDomain)deserializedObjectCache.get(reference);
	}
	
	private JsonObject createDomainJsonObject(DataDomain domain,JsonSerializationContext context){
		JsonObject jsonObj = new JsonObject();
		String domainClassName=domain.getDomainClass().getName();
		if(!jsonObjectCache.containsKey(domainClassName)){
			List<String> domainImplClasses=new ArrayList();
			Class[] implClasses=domain.getDomainImplClasses();
			if(implClasses!=null){
				for(Class clazz: implClasses){
					domainImplClasses.add(clazz.getName());
				}
			}
			int reference=domainClassName.hashCode();
			jsonObj.add("domainName", context.serialize(domain.getName()));
			jsonObj.add("domainClass", context.serialize(domain.getDomainClass().getName()));
			jsonObj.add("domainImplClasses", context.serialize(domainImplClasses));
			jsonObj.add(REF_PREFEX, context.serialize(reference));
			jsonObjectCache.put(domainClassName, reference);
		}else{
			jsonObj.addProperty(REF_PREFEX,jsonObjectCache.get(domainClassName));
		}
		return jsonObj;
	}
	
	
	private JsonObject createDataSelectionJsonObject(DataSelection dataSelection,JsonSerializationContext context){
		JsonObject jsonObj = new JsonObject();
		DataDomain domain=dataSelection.getDomain();
		jsonObj.add("domain",createDomainJsonObject(domain,context));
		jsonObj.add("dataSelectionItems", context.serialize(dataSelection.getSelectionItems()));
		return jsonObj;
	}
	
}
