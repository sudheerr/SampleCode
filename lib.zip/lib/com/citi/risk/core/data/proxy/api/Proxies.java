package com.citi.risk.core.data.proxy.api;

public interface Proxies {
	public <T> T create(T value);

	public Object create(Class<?> klass);
}
