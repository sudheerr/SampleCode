package com.citi.risk.core.data.proxy.impl;

import java.util.List;

import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang3.ClassUtils;

import com.citi.risk.core.data.intern.api.InternProvider;
import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.citi.risk.core.data.service.transaction.api.MethodInvocationExecutor;
import com.citi.risk.core.data.service.transaction.impl.TrxMethodInvocationExecutor;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.gui.api.Handler;
import com.citi.risk.core.lang.annotation.Service;
import com.citi.risk.core.security.api.InvocationComplianceService;
import com.citi.risk.core.security.impl.InvocationComplianceType;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;

@Singleton
public class InvocationInterceptor implements MethodInterceptor {
	@Inject
	private InternProvider internees;

	@Inject
	private ClassInterfacesMethodsCache classInterfacesMethodsCache;
	@Inject
	private ManagedExecutorService managedExecutorService;
	@Inject
	private ValidatorFactory factory;
	
	@Inject
	private InvocationComplianceService invocationComplianceService;
	
	@Inject
	private Injector injector;

	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		Object value = methodInvocation.getThis();		

		Object[] args = methodInvocation.getArguments();

		if (value instanceof Handler) {
			return callGuiHandler(methodInvocation);
		}

		if(ExecutionContexts.getCurrentExecutionContext().isInDataAccessServiceOrCacheManagerContext()){
			intern(args);
			return methodInvocation.proceed();
		}
		
		if (isService(value.getClass())) {
			return callMethodCallable(methodInvocation);
		}
		
		return methodInvocation.proceed();
	}
	
	private boolean isService(Class<?> klass) {
			
		List<Class<?>> list = ClassUtils.getAllInterfaces(klass);
		for(Class<?> klass1 : list){
			if (klass1.getAnnotation(Service.class) != null) {
				return true;
			}
		}
		if (klass.getAnnotation(Service.class) != null) {
			return true;
		}

		return false;
	}

	private Object callGuiHandler(MethodInvocation methodInvocation) throws Throwable {
		return methodInvocation.proceed();
	}

	private Object callMethodCallable(MethodInvocation methodInvocation) throws Throwable {
		InvocationComplianceType previousType = ExecutionContexts.getCurrentExecutionContext().getComplianceType();
		try{
			InvocationComplianceType currentType = invocationComplianceService.check(previousType, InvocationComplianceType.SERVICE);
			ExecutionContexts.getCurrentExecutionContext().setComplianceType(currentType);
			
			MethodInvocationExecutor executor = injector.getInstance(TrxMethodInvocationExecutor.class);
			executor.setMethodInvocation(methodInvocation);
			
			return executor.execute();
		}catch(Throwable e){
			throw e;
		}finally{
			ExecutionContexts.getCurrentExecutionContext().setComplianceType(previousType);
		}
	}

	private void intern(Object[] args) {
		if (args != null) {
			for (int i = 0; i < args.length; i++) {
				Object o = args[i];
				if (o instanceof ValueHolder<?>) {
					ValueHolder valueHolder = (ValueHolder) o;
					Object innerValue = ((ValueHolder<?>) o).get();
					Object temp = internees.get(innerValue);
					valueHolder.set(temp);
				} else {
					args[i] = internees.get(o);
				}
			}
		}
	}

	public Validator getValidator() {
		return factory.getValidator();

	}
}
