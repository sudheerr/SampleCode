package com.citi.risk.core.data.proxy.impl;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.data.proxy.api.ValueHolder;

public class DynamicProxy<T>  implements InvocationHandler, ValueHolder<T>, Serializable {

	private static Method VALUE_HOLD_GET_METHOD;
	private static Method VALUE_HOLD_SET_METHOD;
	private static Method VALUE_HOLD_IS_DELETE_METHOD;
	private static Method VALUE_HOLD_SET_DELETE_METHOD;
	private static Method VALUE_HOLD_GET_IMPLCLASS_METHOD;
	private static Method VALUE_HOLD_TO_STRING_METHOD;
	private static Method VALUE_HOLD_EQUALS_METHOD;
	private static Method VALUE_HOLD_HASHCODE_METHOD;
	private static Method VALUE_HOLD_ISVALID_METHOD;
	private static Method VALUE_HOLD_SETVALID_METHOD;
	
	static {
		try {
			VALUE_HOLD_GET_METHOD 			= ValueHolder.class.getMethod("get");
			VALUE_HOLD_SET_METHOD 			= ValueHolder.class.getMethod("set", Object.class);
			VALUE_HOLD_IS_DELETE_METHOD 	= ValueHolder.class.getMethod("isDeleted");
			VALUE_HOLD_SET_DELETE_METHOD 	= ValueHolder.class.getMethod("setDeleted", boolean.class);
			VALUE_HOLD_GET_IMPLCLASS_METHOD = ValueHolder.class.getMethod("getImplClass");
			VALUE_HOLD_TO_STRING_METHOD 	= Object.class.getMethod("toString");
			VALUE_HOLD_EQUALS_METHOD 		= Object.class.getMethod("equals", Object.class);
			VALUE_HOLD_HASHCODE_METHOD 		= Object.class.getMethod("hashCode");
			VALUE_HOLD_ISVALID_METHOD 		= ValueHolder.class.getMethod("isValidInCache");
			VALUE_HOLD_SETVALID_METHOD 		= ValueHolder.class.getMethod("setValidInCache", boolean.class);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	private static final long serialVersionUID = -4885542976839835603L;

	private T value;
	
	private boolean isDeleted;
	
	private boolean isValidInCache = true;
	
	@Override
	public boolean isDeleted() {
		return isDeleted;
	}

	@Override
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public DynamicProxy(T value) {
		this.value = value;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (method.getDeclaringClass() == ValueHolder.class || method.getDeclaringClass() == Object.class) {
			if (VALUE_HOLD_GET_METHOD.getName() == method.getName()) {
				return get();
			} else if (VALUE_HOLD_SET_METHOD.getName() == method.getName()) {
				set((T) args[0]);
				return null;
			} else if (VALUE_HOLD_IS_DELETE_METHOD.getName() == method.getName()) {
				return isDeleted();
			} else if (VALUE_HOLD_SET_DELETE_METHOD.getName() == method.getName()) {
				setDeleted((boolean)args[0]);
				return null;
			} else if (VALUE_HOLD_GET_IMPLCLASS_METHOD.getName() == method.getName()) {
				return getImplClass();
			} else if (VALUE_HOLD_TO_STRING_METHOD.getName() == method.getName()) {
				return value == null ? StringUtils.EMPTY : value.toString();
			} else if (VALUE_HOLD_EQUALS_METHOD.getName() == method.getName()) {
				return isEqualsWithProxy(args[0]);
			} else if (VALUE_HOLD_HASHCODE_METHOD.getName() == method.getName()) {
				return value == null ? 0: value.hashCode();
			} else if (VALUE_HOLD_ISVALID_METHOD.getName() == method.getName()) {
				return isValidInCache();
			} else if (VALUE_HOLD_SETVALID_METHOD.getName() == method.getName()) {
				setValidInCache((boolean)args[0]);
				return null;
			}
		}
		return method.invoke(value, args);
	}

	@Override
	public T get() {
		return value;
	}

	@Override
	public void set(T e) {
		this.value = e;
	}

	@Override
	public Class<?> getImplClass() {
		return value == null ? null : value.getClass();
	}

	private boolean isEqualsWithProxy(Object other) {
		Object rawValue = other;
		if (other != null && (other instanceof ValueHolder) ) {
			rawValue = ((DynamicProxy)Proxy.getInvocationHandler(other)).value;
		}
		return ObjectUtils.equals(value, rawValue);
	}

	@Override
	public boolean isValidInCache() {
		return this.isValidInCache;
	}

	@Override
	public void setValidInCache(boolean isValid) {
		this.isValidInCache = isValid;
	}

}
