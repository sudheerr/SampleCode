package com.citi.risk.core.data.proxy.impl;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;

import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.google.common.base.Throwables;

public class ManagedInvocationCallable implements Callable<Object>, ManagedExecution {
	private MethodInvocation methodInvocation;
	private TaskType type = TaskType.InfraInvocation;

	public ManagedInvocationCallable(MethodInvocation methodInvocation) {
		this.methodInvocation = methodInvocation;
	}

	@Override
	public Object call() throws Exception {
		try {
			return methodInvocation.proceed();
		} catch (Throwable t) {
			if (t instanceof Exception) {
				throw (Exception) t;
			}
			throw new RuntimeException(t);
		}
	}

	@Override
	public TaskType getType() {
		return type;
	}
	
	public void setType(TaskType type) {
		this.type = type;
	}

	@Override
	public String getExecutionName() {
		Method method = methodInvocation.getMethod();
		InfraInvocation invocationTypeAnno = method.getAnnotation(InfraInvocation.class);
		if (invocationTypeAnno == null) {
			return method.getDeclaringClass().getSimpleName() + "." + method.getName();
		} else {
			return method.getDeclaringClass().getSimpleName() + "." + method.getName() + " , Invocation Type: " + invocationTypeAnno.type();
		}
	}

	@Override
	public String getExecutionParameters() {
		
		InfraInvocation infraInvocation = methodInvocation.getMethod().getAnnotation(InfraInvocation.class);
		if (infraInvocation != null) {
			boolean showParametersValue = infraInvocation.showParametersValue();
			if (showParametersValue) {
				return getParameterValueString();
			}
		}
		
		Method method = methodInvocation.getMethod();
		Class<?>[] methodParams = method.getParameterTypes();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < methodParams.length; i++) {
			if (i != 0) {
				sb.append(", ");
			}
			sb.append("Param-").append(i).append(":").append(methodParams[i].getSimpleName());
		}
		return sb.toString();
	}

	private String getParameterValueString() {
		Object[] parameters = methodInvocation.getArguments();
		Class<?>[] methodParams = methodInvocation.getMethod().getParameterTypes();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < parameters.length; i++) {
			if (i != 0) {
				sb.append(",\n");
			}
			try {
				String parameterString = parameters[i] == null ? "NULL" : parameters[i].toString();
				sb.append("Param-").append(i).append(" ").append(methodParams[i].getSimpleName()).append(":").append(parameterString);
			} catch (Exception e) {
				sb.append("Param-").append(i).append(" ").append(methodParams[i].getSimpleName()).append(":").append("exeception happens when make parameter to string, exception is:" + Throwables.getStackTraceAsString(e));
			}
		}
		return sb.toString();
	}

	@Override
	public boolean isNewThread() {
		return false;
	}
}