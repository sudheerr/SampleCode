package com.citi.risk.core.data.proxy.impl;

import java.lang.reflect.Method;
import java.util.concurrent.Callable;

import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.dictionary.gui.domain.GuiDomain;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;

public final class GuiDomainInvocationCallable implements Callable<Object>, ManagedExecution {
	
	private MethodInvocation methodInvocation;

	public GuiDomainInvocationCallable(MethodInvocation methodInvocation) {
		this.methodInvocation = methodInvocation;
	}

	@Override
	public Object call() throws Exception {
		try {
			return methodInvocation.proceed();
		} catch (Throwable t) {
			if (t instanceof Exception) {
				throw (Exception) t;
			}
			throw new RuntimeException(t);
		}
	}

	@Override
	public TaskType getType() {
		return TaskType.InfraInvocation;
	}

	@Override
	public String getExecutionName() {
		Method method = methodInvocation.getMethod();
		InfraInvocation invocationTypeAnno = method.getAnnotation(InfraInvocation.class);
		if (invocationTypeAnno == null) {
			return method.getDeclaringClass().getSimpleName() + "." + method.getName();
		} else {
			return method.getDeclaringClass().getSimpleName() + "." + method.getName() + " , Invocation Type: " + invocationTypeAnno.type();
		}
	}

	@Override
	public String getExecutionParameters() {
		Object[] args = methodInvocation.getArguments();
		if (args[0] == null) {
			return "null";
		}
		GuiDomain<?> guiDomain = (GuiDomain<?>) args[0];
		return guiDomain.getName();
	}

	@Override
	public boolean isNewThread() {
		return false;
	}
}
