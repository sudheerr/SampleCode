package com.citi.risk.core.data.proxy.api;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ValidationException;
import javax.validation.metadata.BeanDescriptor;

public interface ProxyValidator<E> {

	Set<ConstraintViolation<E>> validate() throws ValidationException;

	Set<ConstraintViolation<E>> validateProperty(String propertyName, Class<?>... groups);

	Set<ConstraintViolation<E>> validateValue(String propertyName, Object value, Class<?>... groups);

	BeanDescriptor getConstraintsForClass();

}
