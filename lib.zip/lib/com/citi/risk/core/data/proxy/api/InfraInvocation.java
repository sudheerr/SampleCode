package com.citi.risk.core.data.proxy.api;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.Callable;

import com.citi.risk.core.data.proxy.impl.ManagedInvocationCallable;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface InfraInvocation {
	InvocationType type() default InvocationType.Service;
	Class<? extends Callable<Object>> callable() default ManagedInvocationCallable.class;
	boolean showParametersValue() default false;
}
