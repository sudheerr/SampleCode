package com.citi.risk.core.data.proxy.impl;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.ClassUtils;

import com.citi.risk.core.data.proxy.api.Proxies;
import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Singleton
public final class DefaultProxies implements Proxies {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultProxies.class);

	
	@Inject
	Injector injector;
	private Map<Class, Constructor> proxyClassMap = new ConcurrentHashMap();

	@Override
	public final <T> T create(T value) {
		if (value == null || Proxy.isProxyClass(value.getClass())) {
			return value;
		}
		Constructor<?> cons = getConstructor(value.getClass());
		if (cons != null) {
			try {
				return (T)cons.newInstance(new DynamicProxy<T>(value));
			} catch (Exception e) {
				LOGGER.debug(e.getMessage(), e);
			}
		}
		return value;
	}
	
	private Constructor getConstructor(Class clazz) {
		Constructor cons = proxyClassMap.get(clazz);
		if (cons == null) {
			List<Class<?>> list = ClassUtils.getAllInterfaces(clazz);
			list.add(ValueHolder.class);
			Class[] interfaces = list.toArray(new Class[list.size()]);
			Class vhClazz = Proxy.getProxyClass(clazz.getClassLoader(), interfaces);
			try {
				cons = vhClazz.getConstructor(InvocationHandler.class);
				proxyClassMap.put(clazz, cons);
			} catch (Exception e) {
				LOGGER.debug(e.getMessage(), e);
			}
		}
		return cons;
	}

	@Override
	public final Object create(Class<?> klass) {
		try {
			Object o = klass.newInstance();
			injector.injectMembers(o);
			return create(o);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
