package com.citi.risk.core.data.proxy.api;

public enum InvocationType {
	Service,
	Load,
	Query,
	StartUp,
	GUI,
	GUI_Serialize,
	UserPreference,
	GUI_Deserialize,
	Security,
	Document
}
