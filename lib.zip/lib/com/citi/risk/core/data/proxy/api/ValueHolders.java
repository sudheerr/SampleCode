package com.citi.risk.core.data.proxy.api;


public class ValueHolders {
	
	private ValueHolders() {
	}
	
	public static boolean isValid(Object object) {
		if (object instanceof ValueHolder) {
			return ((ValueHolder)object).isValidInCache();
		}
		return true;
	}
	
	public static void setValid(Object object, boolean isValid) {
		if (object instanceof ValueHolder) {
			((ValueHolder)object).setValidInCache(isValid);
		}
	}

}
