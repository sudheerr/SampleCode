package com.citi.risk.core.data.proxy.impl;

import java.util.Collection;
import java.util.Collections;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.service.impl.DataAccessType;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Lists;

public abstract class RecordDataInvocationCallable extends ManagedInvocationCallable {

	public RecordDataInvocationCallable(MethodInvocation methodInvocation) {
		super(methodInvocation);
	}

	@Override
	public Object call() throws Exception {
		Object result = super.call();
		if (result == null) {
			return result;
		}

		Collection items = recordData(result);
		if (CollectionUtils.isNotEmpty(items)) {
			addDataToTask(getDataAccessType(), items);
		}
		return result;
	}

	protected Collection recordData(Object result) {
		if (result instanceof Collection) {
			return (Collection) result;
		} else if (result instanceof IdentifiedBy) {
			return Lists.newArrayList(result);
		} else {
			return Collections.emptyList();
		}

	}

	protected void addDataToTask(DataAccessType type, Collection items) {
		if (ExecutionContexts.getCurrentExecutionContext() != null
				&& ExecutionContexts.getCurrentExecutionContext().getCurrentTask() != null) {
			ExecutionContexts.getCurrentExecutionContext().getCurrentTask().addDataAccessItem(type, items);
		}
	}

	protected abstract DataAccessType getDataAccessType();

}
