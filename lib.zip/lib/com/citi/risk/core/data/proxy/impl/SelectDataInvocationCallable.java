package com.citi.risk.core.data.proxy.impl;

import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.service.impl.DataAccessType;

public class SelectDataInvocationCallable extends RecordDataInvocationCallable {

	public SelectDataInvocationCallable(MethodInvocation methodInvocation) {
		super(methodInvocation);
	}

	@Override
	protected DataAccessType getDataAccessType() {
		return DataAccessType.SELECT;
	}

}
