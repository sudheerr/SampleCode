package com.citi.risk.core.data.proxy.api;


public interface ValueHolder<E>  {
	E get();

	void set(E e);

	Class<?> getImplClass();
	
	boolean isDeleted();

	void setDeleted(boolean isDeleted);
	
	boolean isValidInCache();
	
	void setValidInCache(boolean isValid);
}
