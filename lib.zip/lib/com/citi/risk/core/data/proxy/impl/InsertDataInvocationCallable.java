package com.citi.risk.core.data.proxy.impl;

import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.service.impl.DataAccessType;

public class InsertDataInvocationCallable extends RecordDataInvocationCallable {

	public InsertDataInvocationCallable(MethodInvocation methodInvocation) {
		super(methodInvocation);
	}

	@Override
	protected DataAccessType getDataAccessType() {
		return DataAccessType.INSERT;
	}

}
