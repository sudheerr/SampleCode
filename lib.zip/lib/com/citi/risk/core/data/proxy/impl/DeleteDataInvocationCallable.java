package com.citi.risk.core.data.proxy.impl;

import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.service.impl.DataAccessType;

public class DeleteDataInvocationCallable extends RecordDataInvocationCallable {

	public DeleteDataInvocationCallable(MethodInvocation methodInvocation) {
		super(methodInvocation);
	}

	@Override
	protected DataAccessType getDataAccessType() {
		return DataAccessType.DELETE;
	}

}
