package com.citi.risk.core.data.proxy.impl;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class DynamicProxyJsonSerializer extends JsonSerializer<DynamicProxy>{

	@Override
	public void serialize(DynamicProxy value, JsonGenerator jgen,
			SerializerProvider provider) throws IOException,
			JsonProcessingException {
		provider.defaultSerializeValue(value.get(), jgen);
	}

}
