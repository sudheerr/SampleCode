package com.citi.risk.core.data.proxy.impl;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.util.ExceptionHandler;
import com.google.inject.Inject;

public final class ManagedInvocationInterceptor implements MethodInterceptor {
	
	private ManagedExecutorService managedExecutorService;

	@Inject
	public ManagedInvocationInterceptor(ManagedExecutorService managedExecutorService) {
		this.managedExecutorService = managedExecutorService;
	}

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		InfraInvocation infraInvocation = invocation.getMethod().getAnnotation(InfraInvocation.class);
		Future<Object> future;
		if (infraInvocation != null) {
			Class<? extends Callable<Object>> callable = infraInvocation.callable();
			future = this.managedExecutorService.submit(callable.getConstructor(MethodInvocation.class).newInstance(
					invocation));
		} else {
			ManagedInvocationCallable callable = new ManagedInvocationCallable(invocation);
			callable.setType(TaskType.MiscInvocation);
			future = this.managedExecutorService.submit(callable);
		}
		try {
			return future.get();
		} catch (InterruptedException e) {
			throw e;
		} catch (ExecutionException e) {
			ExceptionHandler.debug(this.getClass(), e);
			throw e.getCause();
		}
	}

}
