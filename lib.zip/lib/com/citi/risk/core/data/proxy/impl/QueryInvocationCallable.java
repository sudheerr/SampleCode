package com.citi.risk.core.data.proxy.impl;

import java.util.Collection;
import java.util.Collections;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.query.api.QueryResult;
import com.citi.risk.core.data.service.impl.DataAccessType;

public class QueryInvocationCallable extends RecordDataInvocationCallable {

	public QueryInvocationCallable(MethodInvocation methodInvocation) {
		super(methodInvocation);
	}

	@Override
	public Object call() throws Exception {
		Object result = super.call();
		if (result == null) {
			return result;
		}

		Collection searchResult = getSearchResult(result);
		if (CollectionUtils.isNotEmpty(searchResult)) {
			addDataToTask(DataAccessType.SELECT, searchResult);
		}

		Collection aggregateResult = getAggregateResult(result);
		if (CollectionUtils.isNotEmpty(aggregateResult)) {
			addDataToTask(DataAccessType.AGGREGATE, aggregateResult);
		}

		return result;
	}

	@Override
	protected DataAccessType getDataAccessType() {
		return DataAccessType.SELECT;
	}

	private Collection getSearchResult(Object result) {
		if (result instanceof QueryResult) {
			return ((QueryResult) result).getSearchResult();
		}

		return Collections.emptyList();
	}

	private Collection getAggregateResult(Object result) {
		if (result instanceof QueryResult) {
			return ((QueryResult) result).getAggregedResult();
		}

		return Collections.emptyList();
	}

}
