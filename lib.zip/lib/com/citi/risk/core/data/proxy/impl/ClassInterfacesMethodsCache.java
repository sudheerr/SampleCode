package com.citi.risk.core.data.proxy.impl;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.lang3.ClassUtils;

import com.google.common.collect.Maps;
import com.google.inject.Singleton;

@Singleton
public class ClassInterfacesMethodsCache {
	private static final ConcurrentMap<Class<?>, ConcurrentMap<MethodInfoBean, Method>> methodsCache = Maps.newConcurrentMap();

	private void put(Class<?> implClass) {
		if (methodsCache.containsKey(implClass)) {
			return;
		}
		List<Class<?>> interfaceList = ClassUtils.getAllInterfaces(implClass);
		ConcurrentMap<MethodInfoBean, Method> methodInfoMap = Maps.newConcurrentMap();
		for (Class<?> interfaceClass : interfaceList) {
			Method[] methodArray = interfaceClass.getMethods();
			for (Method method : methodArray) {
				MethodInfoBean methodInfoBean = new MethodInfoBean();
				methodInfoBean.setMethodName(method.getName());
				methodInfoBean.setMethodParms(method.getParameterTypes());
				methodInfoMap.putIfAbsent(methodInfoBean, method);
			}
		}
		methodsCache.putIfAbsent(implClass, methodInfoMap);
	}

	public Method get(Class<?> implClass, Method method) {
		put(implClass);
		ConcurrentMap<MethodInfoBean, Method> map = methodsCache.get(implClass);
		if (map != null) {
			MethodInfoBean methodInfoBean = new MethodInfoBean();
			methodInfoBean.setMethodName(method.getName());
			methodInfoBean.setMethodParms(method.getParameterTypes());
			Method tMethod =  map.get(methodInfoBean);
			if(tMethod != null){
				return tMethod;
			}
			return method;
		}
		return null;
	}
}

class MethodInfoBean {
	private String methodName;
	private Class[] methodParms;

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public void setMethodParms(Class[] methodParms) {
		this.methodParms = methodParms;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((methodName == null) ? 0 : methodName.hashCode());
		result = prime * result + Arrays.hashCode(methodParms);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MethodInfoBean other = (MethodInfoBean) obj;
		if (methodName == null) {
			if (other.methodName != null)
				return false;
		} else if (!methodName.equals(other.methodName))
			return false;
		if (!Arrays.equals(methodParms, other.methodParms))
			return false;
		return true;
	}

}