package com.citi.risk.core.data.proxy.impl;

import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.*;

import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.ioc.impl.guice.CoreModule;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.ObjectUtils;

import com.citi.risk.core.data.proxy.api.Proxies;
import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.execution.impl.DefaultManagedExecutorService;
import com.citi.risk.core.ioc.impl.guice.ExecutorServiceModule.ManagedExecutorServiceProvider;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ProxyHelper
{
    public static final String GUICE_PROXY_FLAG = "$EnhancerByGuice$";
    
    public static Class getRawClass(Object value) {
		if (null == value) {
			return null;
		}

        if(value instanceof ValueHolder) {
            return getRawClassFromGuiceProxy(((ValueHolder) value).getImplClass());
        }
        
        boolean isGuiceProxy = value.getClass().getName().contains(GUICE_PROXY_FLAG);
        if(isGuiceProxy) {
            return getRawClassFromGuiceProxy(value.getClass().getSuperclass());
        }
        
        return value.getClass();
    }
    
    public static Class getRawClassFromGuiceProxy(Class clazz) {
        boolean isGuiceProxy = clazz.getName().contains(GUICE_PROXY_FLAG);
        if(isGuiceProxy) {
            return getRawClassFromGuiceProxy(clazz.getSuperclass());
        }
        return clazz;
    }
    
    public static boolean isInstanceof(Class clazz, Object value) {
    	if (value == null || clazz == null) {
    		return false;
    	}
    	Object rawValue = value;
        if(value instanceof ValueHolder) {
        	rawValue = ((ValueHolder) value).get();
        }
        return clazz.isInstance(rawValue);
    }
    
    public static <V> V getHoldingValue(V holderValue) {
    	if (holderValue != null && holderValue instanceof ValueHolder<?>) {
			return ((DynamicProxy<V>) Proxy.getInvocationHandler(holderValue)).get();
    	}
    	return holderValue;
    }

	/**
	 * @deprecated use getHoldingValue() instead
	 */
    @Deprecated
    public static Object getHolderValue(Object value) {
        if(value instanceof ValueHolder<?>)
        {
            return ((ValueHolder) value).get();
        }
        return value;
    }

	public static Collection getValues(Collection domainObjects) {
		Collection results = Lists.newArrayList();
		for (Object o : domainObjects) {
			results.add((o instanceof ValueHolder) ? ((ValueHolder) o).get() : o);
		}
		return results;
	}
	
	public static boolean isDeleted(Object value) {
		if (value instanceof ValueHolder<?>) {
			return ((ValueHolder) value).isDeleted();
		}
		return false;
	}
	
	public static <V> Collection<V> getValuesParallel(Collection<V> domainObjects) {
		if (domainObjects.size()<=DefaultManagedExecutorService.getForkJoinPartitionSize(domainObjects.size())) {
			return getValues(domainObjects); 
		} else {
			ForkJoinTask<Collection<V>> unWrapValueHolderTask = ManagedExecutorServiceProvider.getInstance().submit(new UnWrapValueHolderTask<>(domainObjects, CoreModule.getConfiguration().getInteger("query.task.timeout", 60)));
			try {
				return unWrapValueHolderTask.get(CoreModule.getConfiguration().getInteger("query.task.timeout", 60), TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				unWrapValueHolderTask.cancel(true);
				throw new RuntimeException(e);
			} catch (ExecutionException e) {
				unWrapValueHolderTask.cancel(true);
				throw new RuntimeException(e.getCause());
			} catch (TimeoutException e) {
				unWrapValueHolderTask.cancel(true);
				throw new TaskTimeoutCancelationException("UnWrapValueHolderTask timeout", e);
			}
		}
	}

	public static <K, E extends IdentifiedBy<K>> Collection<E> addProxies(final Collection<E> items, Proxies proxies) {
		Collection<E> proxyItems = Lists.newArrayList();
		for (E e : items) {
			if (e instanceof ValueHolder) {
				proxyItems.add(e);
			} else {
				proxyItems.add(proxies.create(e));
			}
		}
		return proxyItems;
	}

	public static <BK, E extends ManagedVersion<BK>> Collection<E> addProxiesWithManagedVersion(final Collection<E> items, Proxies proxies)
	{
		Collection<E> proxyItems = Lists.newArrayList();
		Map<BK, E> latestVhMap = Maps.newHashMap();
		E latestVh;
		E rawValue;

		for (E e : items) {
			if (e instanceof ValueHolder) {
				proxyItems.add(e);
			} else {
				proxyItems.add(proxies.create(e));
			}

			rawValue = ProxyHelper.getHoldingValue(e);
			latestVh = latestVhMap.get(rawValue.getBusinessKey());
			if (latestVh == null) {
				latestVh = proxies.create(rawValue);
				latestVhMap.put(rawValue.getBusinessKey(), latestVh);
			}
			rawValue.setLatest(latestVh);

			if (BooleanUtils.isFalse(rawValue.getExpired()) || ObjectUtils.compare(rawValue.getVersion(), latestVh.getVersion()) > 0) {
				((ValueHolder<E>) latestVh).set(rawValue);
			}
		}

		latestVhMap.clear();
		return proxyItems;
	}
	
	static class UnWrapValueHolderTask<V> extends RecursiveTask<Collection<V>> implements ManagedExecution {
		
		private Collection<V> domainObjects;
		
		private int partitionSize;

		private final int timeout;

		private final Stack<UnWrapValueHolderTask<V>> tasks = new Stack<>();
		
		public UnWrapValueHolderTask(Collection<V> domainObjects, final int timeout) {
			super();
			this.domainObjects = domainObjects;
			partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(domainObjects.size());
			this.timeout = timeout;
		}
		
		@Override
		public boolean cancel(boolean mayInterruptIfRunning) {
			while (!tasks.isEmpty()) {
				tasks.pop().cancel(true);
			}
			return super.cancel(mayInterruptIfRunning);
		}

		@Override
		protected Collection<V> compute() {
			if (domainObjects.size()<=partitionSize) {
				return directUnWrapValueHolder(domainObjects);
			}
			Iterable<List<V>> subCollections = Iterables.partition(domainObjects, partitionSize);
			Collection<UnWrapValueHolderTask<V>> subTasks = Lists.newArrayList();
			
			for (List<V> subCollection : subCollections) {
				UnWrapValueHolderTask<V> unWrapValueHolderTask = (UnWrapValueHolderTask<V>) new UnWrapValueHolderTask<>(subCollection, this.timeout).fork();
				subTasks.add(unWrapValueHolderTask);
				tasks.push(unWrapValueHolderTask);
			}
			Collection<V> returnCollection = Lists.newArrayList();
			for (UnWrapValueHolderTask<V> task : subTasks ) {
				try {
					returnCollection.addAll(task.get(2 * this.timeout, TimeUnit.SECONDS));
				} catch (InterruptedException | TimeoutException e) {
					cancel(true);
					throw new TaskTimeoutCancelationException("UnWrapValueHolderTask timeout", e);
				} catch (ExecutionException e) {
					cancel(true);
					throw new RuntimeException(e.getCause());
				}
			}
			return returnCollection;
		}

		private Collection<V> directUnWrapValueHolder(Collection<V> values) {
			Collection<V> results = Lists.newArrayList();
			for (V value : values) {
				if (value != null && (value instanceof ValueHolder)) {
					V rawValue = (V) ((DynamicProxy)Proxy.getInvocationHandler(value)).get();
					results.add(rawValue);
				} else {
					results.add(value);
				}
			}
			return results;
		}
		
		@Override
		public TaskType getType() {
			return TaskType.CoreParallel;
		}

		@Override
		public String getExecutionName() {
			return "UnWrapValueHolder Task";
		}

		@Override
		public String getExecutionParameters() {
			return null;
		}

		@Override
		public boolean isNewThread() {
			return true;
		}
	}
}
