package com.citi.risk.core.data.lang;

public class PackageUtil
{
	private PackageUtil() {
	}
	
    public static String getSchemaName(Class<?> targetClass) {
        String[] splittedPackageNameArray = targetClass.getPackage().getName().split("\\.");
        int index = splittedPackageNameArray.length - 2;
        if (index < 0) {
            throw new RuntimeException("Invalid package name : " + targetClass.getPackage());
        }
        return splittedPackageNameArray[index];
    }
}
