package com.citi.risk.core.data.lang;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.google.common.collect.Lists;

public class ReflectionUtil {
	
	private static Logger logger = LoggerFactory.getLogger(ReflectionUtil.class);

	private ReflectionUtil() {
	}
	
	/**
	 * detect generic type list which defined in super class<br>
	 * 
	 * e.g. 
	 * Given class SomeWidget extends DefaulWidget < Type1, Type2 >, then a List containing [Type1, Type2] will be returned.
	 * 
	 * @param klazz
	 * @return type list
	 */
	public static List<String> findTypeArgumentNames(Class klazz) {
		List<String> typeArgumentNames = Lists.newArrayList();
		Class rawClass = ProxyHelper.getRawClassFromGuiceProxy(klazz);
		ParameterizedType parameterizedType = (ParameterizedType) rawClass.getGenericSuperclass();
		Type[] genericTypeArguments = parameterizedType.getActualTypeArguments();
		
		for (Type type : genericTypeArguments) {
			int whiteSpacePosition = type.toString().indexOf(" ") + 1;
			String className = type.toString().substring(whiteSpacePosition);
			typeArgumentNames.add(className);
		}
		return typeArgumentNames;
	}

	public static Object readAnnotationAttribute(Annotation annotation, String attributeName) {
		if (annotation == null)
			return null;
		try {
			Method method = annotation.getClass().getMethod(attributeName);
			Object result = (Object) method.invoke(annotation);
			return result;
		} catch (Exception e) {
			logger.warn("Failed to get value from annotation: " + annotation + " from attribute: " + attributeName, e);
			return null;
		}
	}
	
}
