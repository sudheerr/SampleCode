package com.citi.risk.core.data.db.provider.api;

import java.sql.SQLException;

public interface StatisticalDataSource {

	StringBuilder outputConnectionStatistics(StringBuilder sb) throws SQLException;
	
	void info(String info);
	
}
