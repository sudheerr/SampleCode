package com.citi.risk.core.data.db.provider.impl;

import com.citi.risk.core.configuration.api.LifeCycles;
import com.citi.risk.core.data.db.provider.api.DataSourceDictionary;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.inject.Inject;
import com.google.inject.Provider;

public class DataSourceDictionaryProvider implements Provider<DataSourceDictionary> {

	private static DataSourceDictionary dataSourceDictionary = null;
	
	@Inject
	private DBCPDataSourceDictionary dbcpDataSourceDictionary;
	
	@Inject
	private C3P0DataSourceDictionary c3p0DataSourceDictionary;

	@Override
	public DataSourceDictionary get() {
		if (dataSourceDictionary == null) {
			if (LifeCycles.LOCAL.equals(CoreModule.getEnvironment().getLifeCycle())) {
				dataSourceDictionary = dbcpDataSourceDictionary;
			} else {
				dataSourceDictionary = c3p0DataSourceDictionary;
			}
		}
		return dataSourceDictionary;
	}

}
