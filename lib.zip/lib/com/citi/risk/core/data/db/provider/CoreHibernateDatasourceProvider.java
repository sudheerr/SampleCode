package com.citi.risk.core.data.db.provider;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.hibernate.service.UnknownUnwrapTypeException;
import org.hibernate.service.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.Configurable;

import com.citi.risk.core.data.db.provider.api.DataSourceDictionary;
import com.citi.risk.core.data.service.persistenceunit.impl.HibernatePersistenceUnit;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class CoreHibernateDatasourceProvider implements ConnectionProvider, Configurable {
	
	private String datasourceName = null;
	private Injector injector;
	
	@Inject
	private DataSourceDictionary dataSourceDictionary = null;

	@Override
	public boolean isUnwrappableAs(Class unwrapType) {
		return ConnectionProvider.class.equals( unwrapType ) ||
				CoreHibernateDatasourceProvider.class.isAssignableFrom( unwrapType ) ||
				DataSource.class.isAssignableFrom( unwrapType );
	}

	@Override
	@SuppressWarnings( {"unchecked"})
	public <T> T unwrap(Class<T> unwrapType) {
		if ( ConnectionProvider.class.equals( unwrapType ) ||
				CoreHibernateDatasourceProvider.class.isAssignableFrom( unwrapType ) ) {
			return (T) this;
		}
		else if ( DataSource.class.isAssignableFrom( unwrapType ) ) {
			return (T) null;
		}
		else {
			throw new UnknownUnwrapTypeException( unwrapType );
		}
	}

	@Override
	public void configure(Map configurationValues) {
		datasourceName = (String)configurationValues.get(HibernatePersistenceUnit.SHARED_DATA_SOURCE_NAME);
		injector = (Injector)configurationValues.get("INJECTOR");
	}

	@Override
	public Connection getConnection() throws SQLException {
		return getDataSource().getConnection();
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
		conn.close();
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}
	
	private DataSource getDataSource() {
		DataSourceDictionary dsd = this.getDataSourceDictionary();
		if (dsd == null) {
			throw new RuntimeException("Can not get DataSourceDictionary instance from Injector");
		}
		DataSource datasource = dataSourceDictionary.getDataSource(this.datasourceName);
		if (datasource == null) {
			throw new RuntimeException("Can not find data source for " +  datasourceName);
		}
		return datasource;
	}
	
	private DataSourceDictionary getDataSourceDictionary() {
		if (dataSourceDictionary == null) {
			injector.injectMembers(this);
		}
		return dataSourceDictionary;
	}

}
