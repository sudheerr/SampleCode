package com.citi.risk.core.data.db.provider.impl;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.h2.tools.RunScript;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.support.JdbcUtils;

import com.citi.risk.core.data.db.provider.api.StatisticalDataSource;
import com.citi.risk.core.data.db.provider.api.TimeLoggedDataSource;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.proxy.api.InvocationType;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class LazyDataSource implements TimeLoggedDataSource, StatisticalDataSource {
	
	protected static org.slf4j.Logger logger = LoggerFactory.getLogger(LazyDataSource.class);
	
	private String name;
	private DataSource delegateDataSource = null;
	private String installScriptsFromURL;
	private String installScript;
	private boolean installed = false;
	private boolean Statistics = false;
	private ConcurrentHashMap<Connection, Long> timeMap = new ConcurrentHashMap<>();
	private ConcurrentHashMap<Connection, String> stackTraceMap = new ConcurrentHashMap<>();
	private long startTime;
	
	protected LazyDataSource(String name, DataSource delegateDataSource, boolean Statistics) {
		this.name = name;
		this.delegateDataSource = delegateDataSource;
		this.Statistics = Statistics;
		installed = false;
		startTime = System.currentTimeMillis();
	}
	
	protected LazyDataSource(String name, DataSource delegateDataSource, boolean Statistics, boolean installed) {
		this.name = name;
		this.delegateDataSource = delegateDataSource;
		this.Statistics = Statistics;
		this.installed = installed;
		startTime = System.currentTimeMillis();
	}
		
	protected LazyDataSource(String name, DataSource delegateDataSource, String installScriptsFromURL, String installScript, boolean Statistics) {
		this.name = name;
		this.delegateDataSource = delegateDataSource;
		this.installScriptsFromURL = StringUtils.trim(installScriptsFromURL);
		this.installScript = StringUtils.trim(installScript);
		this.Statistics = Statistics;
		installed = false;
		startTime = System.currentTimeMillis();
	}
	
	public DataSource getDelegateDataSourceForOps() {
		return delegateDataSource;
	}

	@Override
	public PrintWriter getLogWriter() throws SQLException {
		return getDelegateDataSource().getLogWriter();
	}

	@Override
	public void setLogWriter(PrintWriter out) throws SQLException {
		getDelegateDataSource().setLogWriter(out);
	}

	@Override
	public void setLoginTimeout(int seconds) throws SQLException {
		getDelegateDataSource().setLoginTimeout(seconds);
	}

	@Override
	public int getLoginTimeout() throws SQLException {
		return getDelegateDataSource().getLoginTimeout();
	}

	@Override
	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		try {
			return getDelegateDataSource().getParentLogger();
		} catch (Exception e) {
			throw new SQLFeatureNotSupportedException(e);
		}
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		return getDelegateDataSource().unwrap(iface);
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return getDelegateDataSource().isWrapperFor(iface);
	}

	@Override
	public Connection getConnection() throws SQLException {
		Connection connection;
		if (Statistics) {
			StringBuilder sb = new StringBuilder("CONNECTION-STATIS[" + name + "]OPEN, Before [");
			outputConnectionStatistics(sb).append("], After [");
			connection = new StatisticalConnection(this.name, getDelegateDataSource().getConnection(), this);
			info(outputConnectionStatistics(sb).append("]").toString());
		} else {
			connection = this.getDelegateDataSource().getConnection();
		}
		makeMaxNumActive();
		
		timeMap.put(connection, System.currentTimeMillis());
		stackTraceMap.put(connection, getCurrentStrackTrace());
		return new CoreConnection(connection, timeMap, stackTraceMap);
	}
	
	private String getCurrentStrackTrace() {
		StringBuilder sb = new StringBuilder();
		StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
		if (ArrayUtils.isNotEmpty(stackTraceElements)) {
			for (StackTraceElement stackTraceElement : stackTraceElements) {
				sb.append(stackTraceElement).append("\n");
			}
		}
		
		return sb.toString();
	}

	@InfraInvocation(type = InvocationType.StartUp)
	@Override
	public Connection getConnection(String username, String password) throws SQLException {
		Connection connection;
		if (Statistics) {
			StringBuilder sb = new StringBuilder("CONNECTION-STATIS[" + name + "]OPEN, Before [");
			outputConnectionStatistics(sb).append("], After [");
			connection = new StatisticalConnection(this.name, getDelegateDataSource().getConnection(username, password), this);
			info(outputConnectionStatistics(sb).append("]").toString());
		} else {
			connection = this.getDelegateDataSource().getConnection(username, password);
		}
		makeMaxNumActive();
		
		timeMap.put(connection, System.currentTimeMillis());
		stackTraceMap.put(connection, getCurrentStrackTrace());
		return new CoreConnection(connection, timeMap, stackTraceMap);
	}
	
	private int maxNumActive = 0;
	
	public int getMaxNumActive() {
		return maxNumActive;
	}

	private void makeMaxNumActive() throws SQLException {
		int _maxNumActive = 0;
		if (getDelegateDataSource() instanceof ComboPooledDataSource) {
			_maxNumActive = ((ComboPooledDataSource) getDelegateDataSource()).getNumBusyConnectionsAllUsers();
		} else if (getDelegateDataSource() instanceof BasicDataSource) {
			_maxNumActive = ((BasicDataSource) getDelegateDataSource()).getNumActive();
		}
		if (_maxNumActive > this.maxNumActive) {
			this.maxNumActive = _maxNumActive;
		}
	}
	
	@Override
	public StringBuilder outputConnectionStatistics(StringBuilder sb) throws SQLException {
		if (getDelegateDataSource() instanceof ComboPooledDataSource) {
			sb.append("Total:").append(((ComboPooledDataSource)getDelegateDataSource()).getNumConnectionsAllUsers())
				.append(" , Idle:").append(((ComboPooledDataSource)getDelegateDataSource()).getNumIdleConnectionsAllUsers())
				.append(" , Busy:").append(((ComboPooledDataSource)getDelegateDataSource()).getNumBusyConnectionsAllUsers())
				.append(" , Unclosed:").append(((ComboPooledDataSource)getDelegateDataSource()).getNumUnclosedOrphanedConnectionsAllUsers());
		} else if (getDelegateDataSource() instanceof BasicDataSource) {
			sb.append("Active:").append(((BasicDataSource)getDelegateDataSource()).getNumActive())
					.append(" , Idle:").append(((BasicDataSource)getDelegateDataSource()).getNumIdle())
					.append(" , Max Active:").append(((BasicDataSource)getDelegateDataSource()).getMaxActive())
					.append(" , Max Idle:").append(((BasicDataSource)getDelegateDataSource()).getMaxIdle());
		}
		return sb;
	}
	

	@Override
	public void info(String info) {
		logger.info(info);
	}
	
	private synchronized DataSource getDelegateDataSource() throws SQLException  {
		if (!this.installed) {
			installScript();
			this.installed = true;
		}
		return this.delegateDataSource;
	}

	private void installScript() throws SQLException  {
		if (installScript == null && installScriptsFromURL == null) {
			return;
		}
		String[] scripts = null;
		if (installScript != null) {
			scripts = StringUtils.split(installScript, ";");
		}
		
		if (scripts == null && installScriptsFromURL == null) {
			info("[Install datasource " + this.name + "] without scripts");
		} else {
			runScript(scripts);
		}
	}

	private void runScript(String[] scripts) {
		Connection connection = null;
		try { 
			connection = delegateDataSource.getConnection();
			if (installScriptsFromURL != null) {
				info("[Install datasource " + this.name + "] with scripts from url : " + installScriptsFromURL);
				ResultSet rs = RunScript.execute(connection, new StringReader(installScriptsFromURL));
				JdbcUtils.closeResultSet(rs);
			}
			if (scripts != null) {
				closeScripts(scripts, connection);
			}
		} catch (Exception e) {
			logger.info("Can not install scripts of " +  installScript, e);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e){
					logger.debug("Failed to close connection", e);
				}
			}
		}
	}

	private void closeScripts(String[] scripts, Connection connection) throws IOException, SQLException {
		info("[Install datasource " + this.name + "] with scripts from install scripts : " + installScript);
		for (String script : scripts) {
			InputStreamReader is = new InputStreamReader(new ClassPathResource(script).getInputStream());
			ResultSet rs2 = RunScript.execute(connection, is);
			JdbcUtils.closeResultSet(rs2);
		}
	}

	@Override
	public Map<Connection, Long> getConnectionCheckOutTime() {
		return timeMap;
	}

	@Override
	public Map<Connection, String> getConnectionCheckOutStackTrace() {
		return stackTraceMap;
	}

	public long getStartTime() {
		return startTime;
	}

	@Override
	public String toString() {
		return name;
	}
	
}
