package com.citi.risk.core.data.db.provider.impl;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.collection.map.Maps;
import com.citi.risk.core.lang.encrypt.impl.DefaultEncrypter;
import com.mchange.v2.c3p0.ComboPooledDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;

public class C3P0DataSourceDictionary extends AbstractDataSourceDictionary {

	private Logger logger = LoggerFactory.getLogger(C3P0DataSourceDictionary.class);

	private Configuration configuration = CoreModule.getConfiguration();

	@Override
	protected void closeDataSource(DataSourceTransactionManager dstm) {
		DataSource dataSource = dstm.getDataSource();
		if(dataSource !=null){
			try {
				((ComboPooledDataSource)((LazyDataSource)dataSource).getDelegateDataSourceForOps()).softResetAllUsers();
			} catch (SQLException e) {
				throw new RuntimeException("throw exception when close the dataSource"+e);
			}
		}
	}

	@Override
	protected DataSource buildDataSource(String dataSourceName, Integer initilalSize, Integer maxIdle, Integer maxActive, boolean restart) {

		Properties properties = configuration.getPrefixProperties(dataSourceName);

		logger.info("Create Data source [" + dataSourceName + "] with properties :" +  properties);

		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		
		Properties jdbcProperties = new Properties();

		// process URL
		String strValue = getPropertyValue(properties, false, org.hibernate.ejb.AvailableSettings.JDBC_DRIVER, org.hibernate.cfg.AvailableSettings.DRIVER, "JDBC.driver");
		try {
			dataSource.setDriverClass(strValue);
			jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_DRIVER, strValue);
		} catch (PropertyVetoException e) {
			throw new RuntimeException("Impossible to initialize C3P0 Data Source with driver class '" + strValue + "', see nested exceptions", e);
		}

		strValue = getPropertyValue(properties, false, org.hibernate.ejb.AvailableSettings.JDBC_URL, org.hibernate.cfg.AvailableSettings.URL, "JDBC.url");
		dataSource.setJdbcUrl(fetchURL(strValue));
		jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_URL, strValue);
		this.fetchURLInstallScripts(strValue);

		strValue = getPropertyValue(properties, true, org.hibernate.ejb.AvailableSettings.JDBC_USER, org.hibernate.cfg.AvailableSettings.USER, "JDBC.username", DefaultEncrypter.PWP_ACCOUNT_NAME);
		if (strValue != null) {
			dataSource.setUser(strValue);
			jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_USER, strValue);
		}

		strValue = getDecryptedPropertyValue(dataSourceName, properties, org.hibernate.ejb.AvailableSettings.JDBC_PASSWORD, org.hibernate.cfg.AvailableSettings.PASS, "JDBC.password");
		if (strValue != null) {
			dataSource.setPassword(strValue);
			jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_PASSWORD, strValue);
		}

		Boolean bValue = getPropertyValueAsBoolean(properties, "JDBC.autoCommit");
		if (bValue != null) {
			dataSource.setAutoCommitOnClose(bValue);
			jdbcProperties.put("JDBC.autoCommit", bValue);
		}

		Properties driverProperties = getPropertyAsProperty(dataSourceName, properties, "JDBC.driverProperties");
		if (driverProperties != null) {
			dataSource.setProperties(driverProperties);
			jdbcProperties.put("JDBC.driverProperties", driverProperties);
		}
		
		setProperties(dataSourceName, jdbcProperties);

		//===================================== c3p0 configure =====================================//
		Integer iValue = getPropertyValueAsInteger(properties, 1, org.hibernate.cfg.AvailableSettings.C3P0_ACQUIRE_INCREMENT, "c3p0.acquireIncrement");
		if (iValue != null) {
			dataSource.setAcquireIncrement(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, 10, "c3p0.acquireRetryAttempts");
		if (iValue != null) {
			dataSource.setAcquireRetryAttempts(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.acquireRetryDelay");
		if (iValue != null) {
			dataSource.setAcquireRetryDelay(iValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.automaticTestTable");
		if (strValue != null) {
			dataSource.setAutomaticTestTable(strValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "c3p0.breakAfterAcquireFailure");
		if (bValue != null) {
			dataSource.setBreakAfterAcquireFailure(bValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.checkoutTimeout");
		if (iValue != null) {
			dataSource.setCheckoutTimeout(iValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.connectionCustomizerClassName");
		if (strValue != null) {
			dataSource.setConnectionCustomizerClassName(strValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.connectionTesterClassName");
		if (strValue != null) {
			try {
				dataSource.setConnectionTesterClassName(strValue);
			} catch (PropertyVetoException e) {
				logger.debug("Failed to setConnectionTesterClassName " + strValue + " for dataSource", e);
			}
		}
		iValue = getPropertyValueAsInteger(properties, 600, org.hibernate.cfg.AvailableSettings.C3P0_IDLE_TEST_PERIOD, "c3p0.idleConnectionTestPeriod");
		if (iValue != null) {
			dataSource.setIdleConnectionTestPeriod(iValue);
		}
		iValue = (initilalSize !=null && initilalSize > 0)? initilalSize :getPropertyValueAsInteger(properties, 0, "c3p0.initialPoolSize");
		if (iValue != null) {
			dataSource.setInitialPoolSize(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.maxAdministrativeTaskTime");
		if (iValue != null) {
			dataSource.setMaxAdministrativeTaskTime(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.maxConnectionAge");
		if (iValue != null) {
			dataSource.setMaxConnectionAge(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, 300, org.hibernate.cfg.AvailableSettings.C3P0_TIMEOUT, "c3p0.maxIdleTime");
		if (iValue != null) {
			dataSource.setMaxIdleTime(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.maxIdleTimeExcessConnections");
		if (iValue != null) {
			dataSource.setMaxIdleTimeExcessConnections(iValue);
		}
		iValue = (maxActive !=null && maxActive >=0)?maxActive:getPropertyValueAsInteger(properties, 5, org.hibernate.cfg.AvailableSettings.C3P0_MAX_SIZE, "c3p0.maxPoolSize");
		if (iValue != null) {
			dataSource.setMaxPoolSize(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, org.hibernate.cfg.AvailableSettings.C3P0_MAX_STATEMENTS, "c3p0.maxStatements");
		if (iValue != null) {
			dataSource.setMaxStatements(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.maxStatementsPerConnection");
		if (iValue != null) {
			dataSource.setMaxStatementsPerConnection(iValue);
		}
		iValue = (maxIdle !=null && maxIdle >=0)?maxIdle: getPropertyValueAsInteger(properties, 0, org.hibernate.cfg.AvailableSettings.C3P0_MIN_SIZE, "c3p0.minPoolSize");
		if (iValue != null) {
			dataSource.setMinPoolSize(iValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.preferredTestQuery");
		if (strValue != null) {
			dataSource.setPreferredTestQuery(strValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.propertyCycle");
		if (iValue != null) {
			dataSource.setPropertyCycle(iValue);
		}
		bValue = getPropertyValueAsBoolean(properties, Boolean.TRUE, "c3p0.testConnectionOnCheckin");
		if (bValue != null) {
			dataSource.setTestConnectionOnCheckin(bValue);
		}
		bValue = getPropertyValueAsBoolean(properties, Boolean.TRUE, "c3p0.testConnectionOnCheckout");
		if (bValue != null) {
			dataSource.setTestConnectionOnCheckout(bValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.unreturnedConnectionTimeout");
		if (iValue == null) {
			// see if common c3p0 setup exists if specific not exist
			iValue = configuration.getInteger("c3p0.unreturnedConnectionTimeout", null);
		}
		if (iValue != null) {
			dataSource.setUnreturnedConnectionTimeout(iValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "c3p0.usesTraditionalReflectiveProxies");
		if (bValue != null) {
			dataSource.setUsesTraditionalReflectiveProxies(bValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "c3p0.debugUnreturnedConnectionStackTraces");
		if (bValue == null) {
			// see if common c3p0 setup exists if specific not exist
			bValue = configuration.getBoolean("c3p0.debugUnreturnedConnectionStackTraces", null);
		}
		if (bValue != null) {
			dataSource.setDebugUnreturnedConnectionStackTraces(bValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.factoryClassLocation");
		if (strValue != null) {
			dataSource.setFactoryClassLocation(strValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "c3p0.forceIgnoreUnresolvedTransactions");
		if (bValue != null) {
			dataSource.setForceIgnoreUnresolvedTransactions(bValue);
		}
		iValue = getPropertyValueAsInteger(properties, "c3p0.numHelperThreads");
		if (iValue != null) {
			dataSource.setNumHelperThreads(iValue);
		}
		strValue = getPropertyValue(properties, true, "c3p0.overrideDefaultUser");
		if (strValue != null) {
			dataSource.setOverrideDefaultUser(strValue);
		}

		strValue = getDecryptedPropertyValue(dataSourceName, properties, "c3p0.overrideDefaultPassword");
		if (strValue != null) {
			dataSource.setOverrideDefaultPassword(strValue);
		}

		return new LazyDataSource(dataSourceName, dataSource, false, true);
	}

	@Override
	public Map<String, Integer> getActiveDataSources() {
		Map<String, Integer> activeDataSources = Maps.newHashMap();
		for (Map.Entry<String, DataSourceTransactionManager> entry : getAllDataSource().entrySet()) {
			int activeCount = 0;
			DataSource dataSource = entry.getValue().getDataSource();
			ComboPooledDataSource delegateDataSource = (ComboPooledDataSource) (((LazyDataSource) dataSource).getDelegateDataSourceForOps());
			try {
				activeCount = delegateDataSource.getNumBusyConnectionsAllUsers();
			} catch (SQLException e) {
				logger.debug("Failed to get busy connections count for dataSource: " + entry.getKey(), e);
			}
			if (activeCount > 0) {
				activeDataSources.put(entry.getKey(), activeCount);
			}
		}
		return activeDataSources;
	}

}
