package com.citi.risk.core.data.db.provider;

import javax.inject.Named;
import javax.inject.Provider;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.db.provider.api.DataSourceDictionary;
import com.citi.risk.core.data.service.persistenceunit.api.PersistenceUnitDictionary;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class CoreMybatisDataSourceProvider implements Provider<DataSource> {
	
	protected Configuration configuration = CoreModule.getConfiguration();
	
	@Inject
	private PersistenceUnitDictionary persistenceUnitDictionary;
	
	@Inject
	private DataSourceDictionary dataSourceDictionary;
	
	private String dataSourceName = null;
	
	@Inject
	public CoreMybatisDataSourceProvider(Injector injector, @Named("Core.Mybatis.Prefix") final String mybatisPrefix) {
		injector.injectMembers(this);
		String temp = persistenceUnitDictionary.getPersistenceUnitName(mybatisPrefix);
		dataSourceName = StringUtils.isBlank(temp) ? mybatisPrefix : temp;
	}
	
	@Override
	public DataSource get() {
		return dataSourceDictionary.getDataSource(dataSourceName);
	}
	
}
