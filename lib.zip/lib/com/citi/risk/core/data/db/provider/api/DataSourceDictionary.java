package com.citi.risk.core.data.db.provider.api;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.Map;
import java.util.Properties;

public interface DataSourceDictionary {
	
	DataSource getDataSource(String dataSourceName);
	
	PlatformTransactionManager getTransactionManager(String dataSourceName);

	DataSourceTransactionManager restartDataSource(String dataSourceName, Integer initilalSize, Integer maxIdle, Integer maxActive, long orignalStartTime);

	Map<String, Integer> getActiveDataSources();

	Properties getProperties(String dataSourceName);
}
