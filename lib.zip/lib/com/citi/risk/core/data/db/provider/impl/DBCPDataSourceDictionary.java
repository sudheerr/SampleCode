package com.citi.risk.core.data.db.provider.impl;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.util.CollectionUtils;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.collection.map.Maps;
import com.citi.risk.core.lang.encrypt.impl.DefaultEncrypter;
import com.google.common.collect.Lists;


public class DBCPDataSourceDictionary extends AbstractDataSourceDictionary { 

	private Logger logger = LoggerFactory.getLogger(DBCPDataSourceDictionary.class);
	
	private Configuration configuration = CoreModule.getConfiguration();

	@Override
	protected void closeDataSource(DataSourceTransactionManager dstm){
		DataSource dataSource = dstm.getDataSource();
		if(dataSource !=null){
			try {
				((BasicDataSource)((LazyDataSource)dataSource).getDelegateDataSourceForOps()).close();
			} catch (SQLException e) {
				throw new RuntimeException("throw exception when close the dataSource"+e);
			}
		}
	}

	@Override
	protected DataSource buildDataSource(String dataSourceName, Integer initilalSize, Integer maxIdle, Integer maxActive, boolean restart) {
		
		Properties properties = configuration.getPrefixProperties(dataSourceName);
		
		logger.info("Create Data source [" + dataSourceName + "] with properties :" +  properties);
		
		BasicDataSource dataSource = new BasicDataSource();

		Properties jdbcProperties = new Properties();
		
		String urlIS;
		String jdbcDriver;
		// process URL
		String strValue = getPropertyValue(properties, false, org.hibernate.ejb.AvailableSettings.JDBC_DRIVER, org.hibernate.cfg.AvailableSettings.DRIVER, "JDBC.driver");
        dataSource.setDriverClassName(strValue);
        jdbcDriver = strValue;
		jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_DRIVER, strValue);

		strValue = getPropertyValue(properties, true, org.hibernate.ejb.AvailableSettings.JDBC_URL, org.hibernate.cfg.AvailableSettings.URL, "JDBC.url");
		dataSource.setUrl(fetchURL(strValue));
		urlIS = this.fetchURLInstallScripts(strValue);
		jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_URL, strValue);
		
		strValue = getPropertyValue(properties, true, org.hibernate.ejb.AvailableSettings.JDBC_USER, org.hibernate.cfg.AvailableSettings.USER, "JDBC.username", DefaultEncrypter.PWP_ACCOUNT_NAME);
		if (strValue != null) {
			dataSource.setUsername(strValue);
			jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_USER, strValue);
		}
		
		strValue = getDecryptedPropertyValue(dataSourceName, properties, org.hibernate.ejb.AvailableSettings.JDBC_PASSWORD, org.hibernate.cfg.AvailableSettings.PASS, "JDBC.password");
		if (strValue != null) {
			dataSource.setPassword(strValue);
			jdbcProperties.put(com.citi.risk.core.data.store.spark.sql.AvailableSettings.JDBC_PASSWORD, strValue);
		}
		
		Boolean bValue = getPropertyValueAsBoolean(properties, "JDBC.autoCommit");
		if (bValue != null) {
			dataSource.setDefaultAutoCommit(bValue);
			jdbcProperties.put("JDBC.autoCommit", bValue);
		}
		
		Integer iValue = getPropertyValueAsInteger(properties, "JDBC.loginTimeout");
		if (iValue != null) {
	        try {
	            dataSource.setLoginTimeout(iValue);
	            jdbcProperties.put("JDBC.loginTimeout", iValue);
	        } catch (Exception e) {
	            throw new RuntimeException("Impossible to set DBCP login timeout '" + iValue + "', see nested exceptions", e);
	        }
		}
		
		Properties driverProperties = getPropertyAsProperty(dataSourceName, properties, "JDBC.driverProperties");
		if (driverProperties != null) {
	        for (Entry<Object, Object> property : driverProperties.entrySet()) {
	            String name = property.getKey().toString();
	            String value = property.getValue().toString();
	            dataSource.addConnectionProperty(name, value);
	        }
			jdbcProperties.put("JDBC.driverProperties", driverProperties);
		}
		
		setProperties(dataSourceName, jdbcProperties);
		
		//===================================== DBCP configure =====================================//
		bValue = getPropertyValueAsBoolean(properties, "DBCP.accessToUnderlyingConnectionAllowed");
		if (bValue != null) {
			dataSource.setAccessToUnderlyingConnectionAllowed(bValue);
		}
		strValue = getPropertyValue(properties, true, "DBCP.defaultCatalog");
		if (strValue != null) {
			dataSource.setDefaultCatalog(strValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "DBCP.defaultReadOnly");
		if (bValue != null) {
			dataSource.setDefaultReadOnly(bValue);
		}
		iValue = getPropertyValueAsInteger(properties, "DBCP.defaultTransactionIsolation");
		if (iValue != null) {
			dataSource.setDefaultTransactionIsolation(iValue);
		}
		iValue = (initilalSize !=null && initilalSize >0)?initilalSize:getPropertyValueAsInteger(properties, "DBCP.initialSize");
		if (iValue != null) {
			dataSource.setInitialSize(iValue);
		}
		iValue = (maxIdle !=null && maxIdle >0)?maxIdle:getPropertyValueAsInteger(properties, "DBCP.maxIdle");
		if (iValue != null) {
			dataSource.setMaxIdle(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "DBCP.maxOpenPreparedStatements");
		if (iValue != null) {
			dataSource.setMaxOpenPreparedStatements(iValue);
		}
		Long lValue = getPropertyValueAsLong(properties, "DBCP.maxWait");
		if (lValue != null) {
			dataSource.setMaxWait(lValue);
		}
		lValue = getPropertyValueAsLong(properties, "DBCP.minEvictableIdleTimeMillis");
		if (lValue != null) {
			dataSource.setMinEvictableIdleTimeMillis(lValue);
		}
		iValue = getPropertyValueAsInteger(properties, "DBCP.minIdle");
		if (iValue != null) {
			dataSource.setMinIdle(iValue);
		}
		iValue = getPropertyValueAsInteger(properties, "DBCP.numTestsPerEvictionRun");
		if (iValue != null) {
			dataSource.setNumTestsPerEvictionRun(iValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "DBCP.poolPreparedStatements");
		if (bValue != null) {
			dataSource.setPoolPreparedStatements(bValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "DBCP.testOnBorrow");
		if (bValue != null) {
			dataSource.setTestOnBorrow(bValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "DBCP.testOnReturn");
		if (bValue != null) {
			dataSource.setTestOnReturn(bValue);
		}
		bValue = getPropertyValueAsBoolean(properties, "DBCP.testWhileIdle");
		if (bValue != null) {
			dataSource.setTestWhileIdle(bValue);
		}
		strValue = getPropertyValue(properties, true, "DBCP.validationQuery");
		if (strValue != null) {
			dataSource.setValidationQuery(strValue);
		}
        Integer numberConnections = (maxActive !=null && maxActive >0)?maxActive:getPropertyValueAsInteger(properties, "DBCP.maxTotal");
        if (numberConnections != null){
            dataSource.setMaxActive(numberConnections);
        }

        lValue = getPropertyValueAsLong(properties, "DBCP.timeBetweenEvictionRunsMillis");		
		if (lValue != null) {
			dataSource.setTimeBetweenEvictionRunsMillis(lValue);
		}
		
		bValue = getPropertyValueAsBoolean(properties, "DBCP.removeAbandoned");		
		if (bValue != null) {
			dataSource.setRemoveAbandoned(bValue);
		}
		
		iValue = getPropertyValueAsInteger(properties, "DBCP.removeAbandonedTimeout");		
		if (iValue != null) {
			dataSource.setRemoveAbandonedTimeout(iValue);
		}
		
		bValue = getPropertyValueAsBoolean(properties, "DBCP.logAbandoned");		
		if (bValue != null) {
			dataSource.setLogAbandoned(bValue);
		}

		if(restart) {
			return new LazyDataSource(dataSourceName, (DataSource)dataSource, false,true);
		}else {
			if (StringUtils.equals("org.h2.Driver", jdbcDriver)) {
				String[] splitInstallScripts = StringUtils.split((String)properties.get(CONNECTION_INSTALL_SCRIPT), ";");
				String h2InstallScripts = getInstallScripts(splitInstallScripts);
				return new LazyDataSource(dataSourceName, (DataSource)dataSource, urlIS, h2InstallScripts, false);
			} else {
				return new LazyDataSource(dataSourceName, (DataSource)dataSource, false);
			}
		}
	}
	
	protected String getInstallScripts(String[] installScripts) {
		if(installScripts == null) {
			return null;
		}
		StringBuilder scriptBuilder = new StringBuilder("");
		getH2InstallScripts(Lists.newArrayList(installScripts), scriptBuilder, "");
		return scriptBuilder.toString();
	}
	
	protected void getH2InstallScripts(List<String> installScripts, StringBuilder scriptBuilder, String filePath) {
		List<String> folderList = Lists.newArrayList();
		
		for(String script : installScripts) {
			if(script.endsWith(".class")) {
				continue;
			}
			if(script.toLowerCase().contains(".sql") || script.toLowerCase().contains(".scripts")) {
				scriptBuilder.append(script.contains("/") ? script : filePath + "/" + script);
				scriptBuilder.append(";");
			} else {
				folderList.add(script);
			}
		}
		if(CollectionUtils.isEmpty(folderList)) {
			return;
		}
		for(String folder : folderList) {
			String currentFilePath = filePath + "/" + folder;
			if(this.getClass().getResource(currentFilePath) == null) {
				logger.error("could not locate " + currentFilePath + ".");
			}
			String testPath = this.getClass().getResource(currentFilePath).getPath();
			String mainPath = testPath.replace("test-classes", "classes");
			File testJarFile = new java.io.File(testPath);
			File mainJarFile = new java.io.File(mainPath);
			
			getFilesUnderFolder(testJarFile, scriptBuilder, currentFilePath);
			getFilesUnderFolder(mainJarFile, scriptBuilder, currentFilePath);
		}
	}
	
	protected void getFilesUnderFolder(File file, StringBuilder scriptBuilder, String currentFilePath) {
		if(file.exists() && file.isDirectory()) {
			String[] fileArray = file.list();
			ArrayList<String> fileList = Lists.newArrayList(fileArray);
			Collections.sort(fileList, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					int o1Value = o1.toLowerCase().contains(".dml") ? 1 : -1;
					int o2Value = o2.toLowerCase().contains(".dml") ? 1 : -1;
					return o1Value - o2Value;
				}
				
			});
			getH2InstallScripts(fileList, scriptBuilder, currentFilePath);
		}
	}

	@Override
	public Map<String, Integer> getActiveDataSources() {
		Map<String, Integer> activeDataSources = Maps.newHashMap();
		for (Map.Entry<String, DataSourceTransactionManager> entry : getAllDataSource().entrySet()) {
			DataSource dataSource = entry.getValue().getDataSource();
			BasicDataSource delegateSource = (BasicDataSource) (((LazyDataSource) dataSource).getDelegateDataSourceForOps());
			if (delegateSource.getNumActive() > 0) {
				activeDataSources.put(entry.getKey(), delegateSource.getNumActive());
			}
		}
		return activeDataSources;
	}

}
