package com.citi.risk.core.data.db.provider.api;

import java.sql.Connection;
import java.util.Map;

import javax.sql.DataSource;

public interface TimeLoggedDataSource extends DataSource {
	Map<Connection, Long> getConnectionCheckOutTime();
	
	Map<Connection, String> getConnectionCheckOutStackTrace();
}
