package com.citi.risk.core.data.db.provider.impl;

import java.io.IOException;
import java.io.StringReader;
import java.util.Properties;
import java.util.concurrent.ConcurrentMap;

import javax.sql.DataSource;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.db.provider.api.DataSourceDictionary;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.encrypt.api.Encrypter;
import com.citi.risk.core.lang.encrypt.impl.DefaultEncrypter;
import com.google.common.collect.Maps;

public abstract class AbstractDataSourceDictionary implements DataSourceDictionary {
	private static final Logger LOGGER = LoggerFactory.getLogger(DBCPDataSourceDictionary.class);

	private ConcurrentMap<String, DataSourceTransactionManager> dictionary = Maps.newConcurrentMap();
	private ConcurrentMap<String, Properties> dataSourceProperties = Maps.newConcurrentMap();

	public static final String CONNECTION_INSTALL_SCRIPT 				= "install.scripts";

	private Encrypter encrypter = DefaultEncrypter.getInstance();

	@Override
	final public DataSource getDataSource(String dataSourceName) {
		return ((DataSourceTransactionManager)getTransactionManager(dataSourceName)).getDataSource();
	}
	
	@Override
	@InfraInvocation
	public synchronized DataSourceTransactionManager restartDataSource(String dataSourceName, Integer initilalSize, Integer maxIdle, Integer maxActive, long orignalStartTime) {
		DataSourceTransactionManager orginalDstm = dictionary.get(dataSourceName);
		if(orginalDstm.getDataSource() instanceof LazyDataSource && ((LazyDataSource)(orginalDstm.getDataSource())).getStartTime() == orignalStartTime){
			if(dictionary.containsKey(dataSourceName)) {
				DataSourceTransactionManager dstm =  new DataSourceTransactionManager(
						buildDataSource(dataSourceName, initilalSize, maxIdle, maxActive, true));
				orginalDstm =  dictionary.replace(dataSourceName, dstm);
				closeDataSource(orginalDstm);
				return orginalDstm;
			}
			return null;
		}else {
			throw new RuntimeException(" the current datasource connection is not the latest, please refresh the page");
		}
	}

	@Override
	@InfraInvocation
	public PlatformTransactionManager getTransactionManager(String dataSourceName) {
		DataSourceTransactionManager dstm = dictionary.get(dataSourceName);
		if (dstm == null) {
			try {
				dstm = new DataSourceTransactionManager(
						buildDataSource(dataSourceName, null, null, null, false));
			} catch (Exception e) {
				throw new RuntimeException("Error whild building datasource: " + dataSourceName, e);
			}
			DataSourceTransactionManager before = dictionary.putIfAbsent(dataSourceName, dstm);
			if (before != dstm && before != null) {
				//Close DS
				dstm = before;
			}
		}
		return dstm;
	}
	
	abstract protected DataSource buildDataSource(String dataSourceName, Integer initilalSize, Integer maxIdle, Integer maxActive, boolean restart);
	
	abstract protected void closeDataSource(DataSourceTransactionManager dataSource);
	
	protected String getPropertyValue(Properties properties, boolean optional, String... keys) {
		String value;
		for (String key : keys) {
			value = properties.getProperty(key);
			if(value != null) {
				return value;
			}
		}

		if (!optional) {
			throw new DataSourcePropertiesException("Can not find [" + ArrayUtils.toString(keys) + " for datasource");
		}
		return null;
	}

	protected String getDecryptedPropertyValue(String prefixPropertyName, Properties properties, String... keys) {
		String value = getPropertyValue(properties, true, keys);
		String result = encrypter.getDecryptedValue(prefixPropertyName, value);
		return result;
	}

	protected Properties getPropertyAsProperty(String dataSourceName, Properties properties, String... keys) {
		String value;
		for (String key : keys) {
			value = properties.getProperty(key);
			if (value != null) {
				Properties driverProperties = new Properties();
				try {
					driverProperties.load(new StringReader(value.replaceAll(";", "\n")));

					String encPassword = getPropertyValue(driverProperties, true, "password");
					String decPassword = encrypter.getDecryptedValue(dataSourceName, encPassword);
					setPassword(driverProperties, decPassword);
					
					return driverProperties;
				} catch (IOException ex) {
					throw new RuntimeException("Failed to initialize data source Properties: " + value, ex);
				}
			}
		}
		return null;
	}

	private void setPassword(Properties driverProperties, String decPassword) {
		if(decPassword != null) {
			driverProperties.setProperty("password", decPassword);
		}
	}

	protected Integer getPropertyValueAsInteger(Properties properties, String... keys) {
		return getPropertyValueAsInteger(properties, null, keys);
	}
	protected Integer getPropertyValueAsInteger(Properties properties, Integer defaultValue, String... keys) {
		String value;
		for (String key : keys) {
			value = properties.getProperty(key);
			if (StringUtils.isNotBlank(value)) {
				try {
					return Integer.valueOf(value);
				} catch (NumberFormatException nex) {
					LOGGER.info("Invalid value as Integer for property : " + key);
				}
			}
		}
		return defaultValue;
	}

	protected Long getPropertyValueAsLong(Properties properties, String... keys) {
		return getPropertyValueAsLong(properties, null, keys);
	}
	protected Long getPropertyValueAsLong(Properties properties, Long defaultValue, String... keys) {
		String value;
		for (String key : keys) {
			value = properties.getProperty(key);
			if (StringUtils.isNotBlank(value)) {
				try {
					return Long.valueOf(value);
				} catch (NumberFormatException nex) {
					LOGGER.info("Invalid value as Long for property : " + key);
				}
			}
		}
		return defaultValue;
	}
	protected Boolean getPropertyValueAsBoolean(Properties properties, String... keys) {
		return getPropertyValueAsBoolean(properties, null, keys);
	}

	protected Boolean getPropertyValueAsBoolean(Properties properties, Boolean defaultValue, String... keys) {
		String value;
		for (String key : keys) {
			value = properties.getProperty(key);
			if (StringUtils.isNotBlank(value)) {
				try {
					return Boolean.valueOf(value);
				} catch (NumberFormatException nex) {
					LOGGER.info("Invalid value as Boolean for property : " + key);
				}
			}
		}
		return defaultValue;
	}

	protected String fetchURL(String ourl) {
		if (StringUtils.isBlank(ourl)) {
			return null;
		}
		String[] urls = StringUtils.splitByWholeSeparator(ourl, "init=");
		if (urls == null || urls.length < 2) {
			return ourl;
		} else {
			return StringUtils.trimToNull(urls[0]);
		}
	}

	protected String fetchURLInstallScripts(String ourl) {
		if (StringUtils.isBlank(ourl)) {
			return null;
		}
		String[] urls = StringUtils.splitByWholeSeparator(ourl, "init=");
		if (urls == null || urls.length < 2) {
			return null;
		} else {
			return StringUtils.trimToNull(StringUtils.replaceChars(urls[1], '\\', ' '));
		}
	}

	public ConcurrentMap<String, DataSourceTransactionManager> getAllDataSource()
	{
		return dictionary;
	}

	@Override
	public Properties getProperties(String dataSourceName) {
		Properties dsProperties = this.dataSourceProperties.get(dataSourceName);
		if (dsProperties == null) {
			getTransactionManager(dataSourceName);
			dsProperties = this.dataSourceProperties.get(dataSourceName);
		}

		return dsProperties;
	}
	
	protected void setProperties(String dataSourceName, Properties properties) {
		this.dataSourceProperties.put(dataSourceName, properties);
	}
}
