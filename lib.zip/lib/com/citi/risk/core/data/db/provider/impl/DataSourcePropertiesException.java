package com.citi.risk.core.data.db.provider.impl;

public class DataSourcePropertiesException extends RuntimeException {

	private static final long serialVersionUID = -755500773295964180L;

	public DataSourcePropertiesException() {
		//intentionally-blank override
	}
	
	public DataSourcePropertiesException(String message) {
		super(message);
	}
	
	public DataSourcePropertiesException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public DataSourcePropertiesException(Throwable cause) {
		super(cause);
	}
	
}
