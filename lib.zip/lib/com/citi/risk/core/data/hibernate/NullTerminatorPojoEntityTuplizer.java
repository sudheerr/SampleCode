package com.citi.risk.core.data.hibernate;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.metamodel.binding.AttributeBinding;
import org.hibernate.metamodel.binding.EntityBinding;
import org.hibernate.property.Getter;
import org.hibernate.property.Setter;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.hibernate.tuple.entity.PojoEntityTuplizer;

import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.citi.risk.core.lang.businessobject.NullTerminator;

public class NullTerminatorPojoEntityTuplizer extends PojoEntityTuplizer {

	public NullTerminatorPojoEntityTuplizer(EntityMetamodel entityMetamodel, EntityBinding mappedEntity) {
		super(entityMetamodel, mappedEntity);
	}

	public NullTerminatorPojoEntityTuplizer(EntityMetamodel entityMetamodel, PersistentClass mappedEntity) {
		super(entityMetamodel, mappedEntity);
	}

	@Override
	protected Getter buildPropertyGetter(Property mappedProperty, PersistentClass mappedEntity) {
		return new ProxyGetter(super.buildPropertyGetter(mappedProperty, mappedEntity));
	}

	@Override
	protected Getter buildPropertyGetter(AttributeBinding mappedProperty) {
		return new ProxyGetter(super.buildPropertyGetter(mappedProperty));
	}

	static class ProxySetter implements Setter {
		Setter proxySetter = null;

		public ProxySetter(Setter proxySetter) {
			this.proxySetter = proxySetter;
		}

		@Override
		public void set(Object target, Object value, SessionFactoryImplementor factory) throws HibernateException {
			if (target != null && target instanceof ValueHolder) {
				proxySetter.set(((ValueHolder<?>) target).get(), value, factory);
			} else {
				proxySetter.set(target, value, factory);
			}
		}

		@Override
		public String getMethodName() {
			return proxySetter.getMethodName();
		}

		@Override
		public Method getMethod() {
			return proxySetter.getMethod();
		}

	}

	static class ProxyGetter implements Getter {
		Getter proxyGetter = null;

		public ProxyGetter(Getter proxyGetter) {
			this.proxyGetter = proxyGetter;
		}

		@Override
		public Object get(Object owner) throws HibernateException {
			Object ret;
			if (owner != null && owner instanceof ValueHolder) {
				ret = proxyGetter.get(((ValueHolder<?>) owner).get());
			} else {
				ret = proxyGetter.get(owner);
			}
			return ret == null || NullTerminator.isCreatedByNullTerminator(ret) ? null : ret;
		}

		@Override
		public Object getForInsert(Object owner, Map mergeMap, SessionImplementor session) throws HibernateException {
			Object ret;
			if (owner != null && owner instanceof ValueHolder) {
				ret = proxyGetter.getForInsert(((ValueHolder<?>) owner).get(), mergeMap, session);
			} else {
				ret = proxyGetter.getForInsert(owner, mergeMap, session);
			}
			return ret == null || NullTerminator.isCreatedByNullTerminator(ret) ? null : ret;
		}

		@Override
		public Member getMember() {
			return proxyGetter.getMember();
		}

		@Override
		public Class getReturnType() {
			return proxyGetter.getReturnType();
		}

		@Override
		public String getMethodName() {
			return proxyGetter.getMethodName();
		}

		@Override
		public Method getMethod() {
			return proxyGetter.getMethod();
		}
	}
}
