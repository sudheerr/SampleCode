package com.citi.risk.core.data.hibernate;

import java.io.Serializable;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.metamodel.binding.AttributeBinding;
import org.hibernate.metamodel.binding.EntityBinding;
import org.hibernate.property.Getter;
import org.hibernate.property.Setter;
import org.hibernate.tuple.Instantiator;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.hibernate.tuple.entity.PojoEntityTuplizer;

import com.citi.risk.core.data.proxy.api.ValueHolder;

public class ProxyPojoEntityTuplizer extends PojoEntityTuplizer {

	public ProxyPojoEntityTuplizer(EntityMetamodel entityMetamodel, EntityBinding mappedEntity) {
		super(entityMetamodel, mappedEntity);
	}

	public ProxyPojoEntityTuplizer(EntityMetamodel entityMetamodel,	PersistentClass mappedEntity) {
		super(entityMetamodel, mappedEntity);
	}

	@Override
	protected Getter buildPropertyGetter(Property mappedProperty, PersistentClass mappedEntity) {
		return new ProxyGetter(super.buildPropertyGetter(mappedProperty, mappedEntity));
	}

	@Override
	protected Setter buildPropertySetter(Property mappedProperty, PersistentClass mappedEntity) {
		return new ProxySetter(super.buildPropertySetter(mappedProperty, mappedEntity));
		
	}

	@Override
	protected Getter buildPropertyGetter(AttributeBinding mappedProperty) {
		return new ProxyGetter(super.buildPropertyGetter(mappedProperty));
	}

	@Override
	protected Setter buildPropertySetter(AttributeBinding mappedProperty) {
		return new ProxySetter(super.buildPropertySetter(mappedProperty));
	}
	
	@Override
    protected Instantiator buildInstantiator(PersistentClass persistentClass) {
		return new ProxyPojoInstantiator(super.buildInstantiator(persistentClass));
	}

	@Override
	protected Instantiator buildInstantiator(EntityBinding entityBinding) {
		return new ProxyPojoInstantiator(super.buildInstantiator(entityBinding));
	}

	static class ProxySetter implements Setter {
		Setter proxySetter = null;

		public ProxySetter(Setter proxySetter) {
			this.proxySetter = proxySetter;
		}

		@Override
		public void set(Object target, Object value, SessionFactoryImplementor factory) throws HibernateException {
			if (target != null && target instanceof ValueHolder) {
				proxySetter.set( ((ValueHolder<?>)target).get(), value, factory);
			} else {
				proxySetter.set(target, value, factory);
			}
		}

		@Override
		public String getMethodName() {
			return proxySetter.getMethodName();
		}

		@Override
		public Method getMethod() {
			return proxySetter.getMethod();
		}
		
	}

	static class ProxyGetter implements Getter {
		 Getter proxyGetter = null;
		 
		public ProxyGetter(Getter proxyGetter) {
			this.proxyGetter = proxyGetter;
		}

		@Override
		public Object get(Object owner) throws HibernateException {
			if (owner != null && owner instanceof ValueHolder) {
				return proxyGetter.get( ((ValueHolder<?>)owner).get());
			} else {
				return proxyGetter.get(owner);
			}
		}

		@Override
		public Object getForInsert(Object owner, Map mergeMap, SessionImplementor session) throws HibernateException {
			if (owner != null && owner instanceof ValueHolder) {
				return proxyGetter.getForInsert( ((ValueHolder<?>)owner).get(), mergeMap, session);
			} else {
				return proxyGetter.getForInsert(owner, mergeMap, session);
			}
		}

		@Override
		public Member getMember() {
			return proxyGetter.getMember();
		}

		@Override
		public Class getReturnType() {
			return proxyGetter.getReturnType();
		}

		@Override
		public String getMethodName() {
			return proxyGetter.getMethodName();
		}

		@Override
		public Method getMethod() {
			return proxyGetter.getMethod();
		}

	}
	
	static class ProxyPojoInstantiator implements Instantiator, Serializable {
		
		private Instantiator instantiator = null;

		public ProxyPojoInstantiator(Instantiator proxyPojoInstantiator) {
			this.instantiator = proxyPojoInstantiator;
		}

		@Override
		public Object instantiate(Serializable id) {
			return instantiator.instantiate(id);
		}

		@Override
		public Object instantiate() {
			return instantiator.instantiate();
		}

		@Override
		public boolean isInstance(Object object) {
			if (object != null && object instanceof ValueHolder) {
				return instantiator.isInstance( ((ValueHolder<?>)object).get());
			} else {
				return instantiator.isInstance(object);
			}
		}
		
	}

}
