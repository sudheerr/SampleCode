package com.citi.risk.core.data.hibernate;

import com.citi.risk.core.data.proxy.api.ValueHolder;
import com.citi.risk.core.lang.create.api.Create;
import com.google.inject.Inject;
import org.hibernate.EmptyInterceptor;
import org.hibernate.EntityMode;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.persister.entity.EntityPersister;

import java.io.Serializable;

public class HibernateProxyInterceptor extends EmptyInterceptor {

	private static final long serialVersionUID = -6673466152016695716L;

	@Inject
	private Create create;
	
	private SessionFactoryImplementor sessionFactory;
	public void setSessionFactory(SessionFactoryImplementor sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Object instantiate(String entityName, EntityMode entityMode,	Serializable id) {
		try {
			Class<?> klass = Class.forName(entityName);
			Object instance = create.getInstance(klass);
			
			EntityPersister entityPersister = sessionFactory.getEntityPersister(entityName);
			if (id != null) {
				entityPersister.setIdentifier(instance, id, null);
			}

			return instance;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public String getEntityName(Object object) {
		if (object instanceof ValueHolder && ((ValueHolder)object).get() != null) {
			return getRawClass(((ValueHolder)object).get().getClass()).getName();
		}
		return getRawClass(object.getClass()).getName();
	}
	
	private Class getRawClass(Class clazz) {
        boolean isGuiceProxy = clazz.getName().indexOf("EnhancerByGuice") >= 0;
        if(isGuiceProxy) {
            return getRawClass(clazz.getSuperclass());
        }
        return clazz;
    }

}
