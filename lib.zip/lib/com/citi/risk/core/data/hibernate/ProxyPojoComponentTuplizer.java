package com.citi.risk.core.data.hibernate;

import org.hibernate.InstantiationException;
import org.hibernate.cfg.Environment;
import org.hibernate.internal.util.ReflectHelper;
import org.hibernate.mapping.Component;
import org.hibernate.tuple.Instantiator;
import org.hibernate.tuple.PojoInstantiator;
import org.hibernate.tuple.component.PojoComponentTuplizer;

import com.citi.risk.core.lang.create.api.Create;
import com.google.inject.Inject;

public class ProxyPojoComponentTuplizer extends PojoComponentTuplizer {

	@Inject
	private static Create create;

	public ProxyPojoComponentTuplizer(Component component) {
		super(component);
	}

	@Override
	protected Instantiator buildInstantiator(Component component) {
		if (hasCustomAccessors || !Environment.useReflectionOptimizer()) {
			return new ProxyPojoInstantiator(component);
		}
		return super.buildInstantiator(component);
	}

	static public class ProxyPojoInstantiator extends PojoInstantiator {
		private final Class mappedClass;
		private final boolean isAbstract;

		public ProxyPojoInstantiator(Component component) {
			super(component, null);
			this.mappedClass = component.getComponentClass();
			this.isAbstract = ReflectHelper.isAbstractClass(mappedClass);
		}

		@Override
		public Object instantiate() {
			if (isAbstract) {
				throw new InstantiationException("Cannot instantiate abstract class or interface: ", mappedClass);
			}
			return create.getInstance(mappedClass);
		}
	}

}
