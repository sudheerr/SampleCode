package com.citi.risk.core.data.io;

import org.apache.ibatis.reflection.factory.DefaultObjectFactory;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class IbatisObjectFactory extends DefaultObjectFactory {

    private static final long serialVersionUID = 1938101966531256774L;
    
    @Inject
    Injector injector;
    
    @Override
    public <T> T create(Class<T> type) {
        if(IdentifiedBy.class.isAssignableFrom(type)){
            return injector.getInstance(type);
        }
        return create(type, null, null);
      }
    
}
