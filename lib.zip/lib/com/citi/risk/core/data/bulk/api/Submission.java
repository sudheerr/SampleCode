package com.citi.risk.core.data.bulk.api;

import java.util.Map;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface Submission<K, E extends IdentifiedBy<K>> {

	BulkProcessingEnabled<K, E> getBulkProcessingEnabled();

	BulkOperation getOperation();

	Map<String, String> getOptions();
}
