package com.citi.risk.core.data.bulk.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.exceptions.ExceptionFactory;
import org.apache.ibatis.executor.BatchExecutorException;
import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.executor.ErrorContext;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionManager;
import org.apache.ibatis.session.defaults.DefaultSqlSession;
import org.apache.ibatis.transaction.Transaction;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.managed.ManagedTransactionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.bulk.api.BulkProcessingException;
import com.citi.risk.core.data.bulk.api.EntryAdditionalInfoPair;
import com.citi.risk.core.data.mybatis.BulkExecutor;
import com.citi.risk.core.data.mybatis.ManagedMapperProvider;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.collection.list.Lists;
import com.google.common.collect.Iterables;
import com.google.inject.Inject;
import com.google.inject.Injector;

@SuppressWarnings({"unchecked", "rawtypes"})
public class MybatisBatchExcecuter<K, E extends IdentifiedBy<K>> {
	private static final Logger LOGGER = LoggerFactory.getLogger(MybatisBatchExcecuter.class);
	
	private Class mapperClass = null;
	private Method method = null;
	private List<EntryAdditionalInfoPair<K, E>> executePair = null;
	private int bulkSize = 10000;
	@Inject
	private Injector injector = null;
	
	private ManagedMapperProvider getManagedMapperProvider() {
		Object mapperInstance = injector.getInstance(mapperClass);
		if (mapperInstance == null) {
			return null;
		}
		Object invocationHandlerObject =  Proxy.getInvocationHandler(mapperInstance);
		if (invocationHandlerObject == null) {
			throw new RuntimeException();
		}
		return (ManagedMapperProvider)invocationHandlerObject;
	}
	
	private Object getMapper(SqlSession sqlSession) {
		return sqlSession.getMapper(mapperClass);
	}
	
	private TransactionFactory getTransactionFactoryFromEnvironment(Environment environment) {
		if (environment == null || environment.getTransactionFactory() == null) {
			return new ManagedTransactionFactory();
		}
		return environment.getTransactionFactory();
	}
	  
	private SqlSession getBulkSession() {
		SqlSessionManager sqlSessionManager = getManagedMapperProvider().getSqlSessionManager();
		Transaction tx = null;
		try {
			Environment environment = sqlSessionManager.getConfiguration().getEnvironment();
			final TransactionFactory transactionFactory = getTransactionFactoryFromEnvironment(environment);
			tx = transactionFactory.newTransaction(environment.getDataSource(), null, true);
			final Executor executor = new BulkExecutor(sqlSessionManager.getConfiguration(), tx);
			return new DefaultSqlSession(sqlSessionManager.getConfiguration(), executor);
		} catch (Exception e) {
			throw ExceptionFactory.wrapException("Error opening session.  Cause: " + e, e);
		} finally {
			if (tx != null) {
				try {
					tx.close();
				} catch (SQLException ignore) {
					LOGGER.debug("Failed to close tx", ignore);
				}
			}
			ErrorContext.instance().reset();
		}
	}

	public List<EntryAdditionalInfoPair<K, E>> execute() throws BulkProcessingException {
		SqlSession sqlSession = getBulkSession();
		Object batchMapper = this.getMapper(sqlSession);
		Iterable<List<EntryAdditionalInfoPair<K, E>>> partitioned = Iterables.partition(executePair, this.bulkSize);
		BulkProcessingException exception = new BulkProcessingException();
		List<EntryAdditionalInfoPair<K, E>> executed = Lists.newArrayList();
		
		// add to batch
		for (List<EntryAdditionalInfoPair<K, E>> partition : partitioned) {
			try{
				executeMapper(batchMapper, method, partition);
				executed.addAll(partition);
			} catch (Exception ex) {
				exception.registerFailures(partition, ex);
			}
		}
		
		//flush
		List<EntryAdditionalInfoPair<K, E>> successed = Lists.newArrayList();
		try{
			sqlSession.flushStatements();
		} catch (org.apache.ibatis.exceptions.PersistenceException ex) {
			LOGGER.debug("Failed to flush statement.", ex);
			BatchExecutorException batchEx = (BatchExecutorException)ex.getCause();
			List<BatchResult> batchResults = batchEx.getSuccessfulBatchResults();
			for (BatchResult batchResult : batchResults) {
				HashMap _rfailed = (HashMap)batchResult.getParameterObjects().get(0);
				List<EntryAdditionalInfoPair<K, E>> sValue = (List<EntryAdditionalInfoPair<K, E>>)(Object)_rfailed.get("values");
				successed.addAll(sValue);
				executed.removeAll(sValue);
			}
			exception.registerFailures(executed, batchEx);
		}
		
		//close
		try {
			sqlSession.commit();
			sqlSession.close();
		} catch (Exception e) {
			LOGGER.debug("Failed to commit or close session.", e);
		};
		
		//has Exception ?
		if (exception.hasAnyFailure()) {
			exception.addCompletedOnes(successed);
			throw exception;
		}
		
		return successed;
	}
	
	private void executeMapper(Object mapper, Method method, List<EntryAdditionalInfoPair<K, E>> entites) {
		try {
			method.invoke(mapper, entites);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			LOGGER.debug("Failed to invoke method", e);
		}
	}
	
	public MybatisBatchExcecuter<K, E> setBulkSize(int bulkSize) {
		this.bulkSize = bulkSize;
		return this;
	}

	public MybatisBatchExcecuter<K, E> setInvke(Class _mapperClass) {
		this.method = this.getExcecuteMethod(_mapperClass, "invokeAll");
		if (method == null) {
			throw new RuntimeException();
		}
		this.mapperClass = _mapperClass;
		return this;
	}
	
	private Method getExcecuteMethod(Class _mapperClass, String methodName) {
		Method[] methods = _mapperClass.getDeclaredMethods();
		for(Method _method : methods) {
			if (StringUtils.equals(methodName, _method.getName())) {
				return _method;
			}
		}
		this.mapperClass = _mapperClass;
		return null;
	}

	public MybatisBatchExcecuter<K, E> setExecutePair(List<EntryAdditionalInfoPair<K, E>> executePair) {
		this.executePair = executePair;
		return this;
	}

}
