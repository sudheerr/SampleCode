package com.citi.risk.core.data.bulk.api;

public enum BulkOperation {
	
	UPDATE;

}
