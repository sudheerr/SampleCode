package com.citi.risk.core.data.bulk.api;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface EntryAdditionalInfoPair<K, E extends IdentifiedBy<K>> {
	
	E getEntry();

	void setEntry(E entry);

	String getAdditionalInfo();

	void setAdditionalInfo(String additionalInfo);
}
