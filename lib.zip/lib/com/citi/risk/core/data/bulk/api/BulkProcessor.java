package com.citi.risk.core.data.bulk.api;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface BulkProcessor {
	
	<K, E extends IdentifiedBy<K>> List<EntryAdditionalInfoPair<K, E>> newEntryAdditionalnfoPair(List<E> entries);

	@InfraInvocation
	<K, E extends IdentifiedBy<K>> Future<List<EntryAdditionalInfoPair<K, E>>> submit(
				BulkProcessingEnabled<K, E> bpe, 
				BulkOperation operation, 
				List<EntryAdditionalInfoPair<K, E>> entries, 
				Map<String, String> options);
}
