package com.citi.risk.core.data.bulk.api;

import java.util.Collection;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.collect.Lists;

@SuppressWarnings({"serial", "rawtypes", "unchecked"})
public final class BulkProcessingException extends RuntimeException {

	private List<Pair<List<EntryAdditionalInfoPair>, Exception>> failedPair = Lists.newArrayList();
	private List<EntryAdditionalInfoPair> completededOnes = Lists.newArrayList();
	
	public <K, E extends IdentifiedBy<K>> List<EntryAdditionalInfoPair<K, E>> getFailedOnes() {
		List<EntryAdditionalInfoPair<K, E>> fails = Lists.newArrayList(); 
		for (Pair<List<EntryAdditionalInfoPair>, Exception> pair : this.failedPair) {
			if (pair != null && CollectionUtils.isNotEmpty(pair.getFirst())) {
				fails.addAll((List<EntryAdditionalInfoPair<K, E>>)(Object)pair.getFirst());
			}
		}
		return fails;
	}

	public <K, E extends IdentifiedBy<K>> List<EntryAdditionalInfoPair<K, E>> getCompletedOnes() {
		return (List<EntryAdditionalInfoPair<K, E>>)(Object)completededOnes;
	}

	public <K, E extends IdentifiedBy<K>> void registerFailures(List<EntryAdditionalInfoPair<K, E>> failedOnes, Exception cause) {
		if (CollectionUtils.isEmpty(failedOnes) && cause == null) {
			return;
		}
		Pair<List<EntryAdditionalInfoPair>, Exception> pair = 
				new Pair((List<EntryAdditionalInfoPair>)(Object)failedOnes, cause);
		this.failedPair.add(pair);
	}

	public <K, E extends IdentifiedBy<K>> void addCompletedOnes(List<EntryAdditionalInfoPair<K, E>> completededOnes) {
		if (CollectionUtils.isEmpty(completededOnes)) {
			return;
		}
		this.completededOnes.addAll(completededOnes);
	}

	public boolean hasAnyFailure() {
		return !this.failedPair.isEmpty();
	}

	public Collection<Exception> getCauseExceptions() {
		Collection<Exception> exceptions = Lists.newArrayList(); 
		for (Pair<List<EntryAdditionalInfoPair>, Exception> pair : this.failedPair) {
			if (pair != null && pair.getSecond() != null) {
				exceptions.add(pair.getSecond());
			}
		}
		return exceptions;
	}
	
	public List<Pair<List<EntryAdditionalInfoPair>, Exception>> getFailedPair() {
		return this.failedPair;
	}
}
