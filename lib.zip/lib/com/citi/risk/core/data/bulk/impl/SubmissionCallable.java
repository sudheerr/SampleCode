package com.citi.risk.core.data.bulk.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.data.bulk.api.BulkOperation;
import com.citi.risk.core.data.bulk.api.BulkProcessingEnabled;
import com.citi.risk.core.data.bulk.api.BulkProcessingException;
import com.citi.risk.core.data.bulk.api.EntryAdditionalInfoPair;
import com.citi.risk.core.data.bulk.api.Submission;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.collection.list.Lists;
import com.google.inject.Inject;

public class SubmissionCallable<K, E extends IdentifiedBy<K>> implements ManagedExecution, 
																  		 Callable<List<EntryAdditionalInfoPair<K, E>>>, 
																  		 Submission<K, E> {
	private BulkOperation operation;
	private BulkProcessingEnabled<K, E> bulkprocessing;
	private Map<String, String> options;
	
	private List<EntryAdditionalInfoPair<K, E>> unsubmittedEntries;
	
	@Inject
	private ManagedExecutorService batchExecutionService;
	
	private String executionParameters = StringUtils.EMPTY; 

	private int getBatchSize() {
		return CoreModule.getConfiguration().getInteger("bulk.processing.batch.size", 100);
	}
	
	public SubmissionCallable(BulkProcessingEnabled<K, E> bulkprocessing, 
							  BulkOperation operation,
							  List<EntryAdditionalInfoPair<K, E>> entries,
							  Map<String, String> options) {
		this.bulkprocessing = bulkprocessing;
		this.operation = operation;
		this.options = options;
		executionParameters = "BulkProcessing=" + bulkprocessing.getClass().getName() + ",operation=" + operation.name();
		if (entries == null) {
			this.unsubmittedEntries = new ArrayList();
		} else {
			this.unsubmittedEntries = new ArrayList(entries);
		}
		executionParameters = executionParameters + ",Total Entities=" + unsubmittedEntries.size();
	}

	@Override
	public List<EntryAdditionalInfoPair<K, E>> call() {
		Boolean originalValue = ExecutionContexts.getCurrentExecutionContext().isInContextOfBulkProcess();
		try {
			ExecutionContexts.getCurrentExecutionContext().setIsInContextOfBulkProcess(true);
			return doCall();
		} finally {
			ExecutionContexts.getCurrentExecutionContext().setIsInContextOfBulkProcess(originalValue);
		}
	}

	private List<EntryAdditionalInfoPair<K, E>> doCall() {
		List<EntryAdditionalInfoPair<K, E>> completedOnes = new ArrayList();
		BulkProcessingException submissionException = new BulkProcessingException();
		int batchSize = getBatchSize();
		List<Future<List<EntryAdditionalInfoPair<K, E>>>> futures = Lists.newArrayList();
		while(isThereUnprocessedEntries()) {
			List<EntryAdditionalInfoPair<K, E>> readyToBeProcessedEntries = takeReadyToBeProcessedEntries();
			futures.clear();
			for (int i = 0; i < readyToBeProcessedEntries.size(); i = i	+ batchSize) {
				int endIndex = i + batchSize;
				if (endIndex >= readyToBeProcessedEntries.size()) {
					endIndex = readyToBeProcessedEntries.size();
				}
				List<EntryAdditionalInfoPair<K, E>> batch = readyToBeProcessedEntries.subList(i, endIndex);
				BulkBatchCallable<K, E> batchCallable = new BulkBatchCallable(this, batch);
				Future<List<EntryAdditionalInfoPair<K, E>>> future = batchExecutionService.submit(batchCallable);
				if (future != null) {
					futures.add(future);
				}
			}
			
			// process futures.
			for (Future<List<EntryAdditionalInfoPair<K, E>>> future : futures) {
				try{
					List<EntryAdditionalInfoPair<K, E>> result = future.get();
					if (result != null) {
						completedOnes.addAll(result);
					}
				} catch (InterruptedException | ExecutionException e) {
					BulkProcessingException bpe = null;
					if (e instanceof BulkProcessingException) {
						bpe = (BulkProcessingException)e;
					} else if (e instanceof ExecutionException && (e.getCause() instanceof BulkProcessingException)) {
						bpe = (BulkProcessingException)e.getCause();
					}
					
					if (bpe != null) {
						if (CollectionUtils.isNotEmpty(bpe.getCompletedOnes())) {
							completedOnes.addAll((List<EntryAdditionalInfoPair<K, E>>)(Object)bpe.getCompletedOnes());
						}
						if (CollectionUtils.isNotEmpty(bpe.getFailedOnes())) {
							submissionException.registerFailures((List<EntryAdditionalInfoPair<K, E>>)(Object)bpe.getFailedOnes(), bpe);
						}
					} else {
						submissionException.registerFailures(readyToBeProcessedEntries, e);
					}
				}
			}
		}
		executionParameters = executionParameters + 
				", completed=" + completedOnes.size() + ", failed=" + submissionException.getFailedOnes().size();
		if(!submissionException.hasAnyFailure()) {
			return completedOnes;
		}

		submissionException.addCompletedOnes(completedOnes);
		throw submissionException;
	}

	
	private List<EntryAdditionalInfoPair<K, E>> takeReadyToBeProcessedEntries() {
		List<EntryAdditionalInfoPair<K, E>> readyList = new ArrayList();
		Set keys = new HashSet();
		Iterator<EntryAdditionalInfoPair<K, E>> unsubmittedEntriesIterator = unsubmittedEntries.iterator();
		EntryAdditionalInfoPair<K, E> entryAdditionInfoPair;
		while (unsubmittedEntriesIterator.hasNext()) {
			entryAdditionInfoPair = unsubmittedEntriesIterator.next();
			if (entryAdditionInfoPair.getEntry() instanceof ManagedVersion) {
				Object bizKey = ((ManagedVersion) entryAdditionInfoPair.getEntry()).getBusinessKey();
				if (keys.contains(bizKey)) {
					return readyList;
				} else {
					keys.add(bizKey);
				}
			} else {
				K key = entryAdditionInfoPair.getEntry().key();
				if (keys.contains(key))
					return readyList;
				else
					keys.add(key);
			}
			readyList.add(entryAdditionInfoPair);
			unsubmittedEntriesIterator.remove();
		}
		return readyList;
	}
	
	private Boolean isThereUnprocessedEntries() {
		return !unsubmittedEntries.isEmpty();
	}	
	
	@Override
	public TaskType getType() {
		return TaskType.BulkSubmission;
	}

	@Override
	public String getExecutionName() {
		return TaskType.BulkSubmission.name();
	}

	@Override
	public String getExecutionParameters() {
		return executionParameters + ", UnSubmitted=" + unsubmittedEntries.size();
	}

	@Override
	public boolean isNewThread() {
		return true;
	}

	@Override
	public BulkProcessingEnabled<K, E> getBulkProcessingEnabled() {
		return this.bulkprocessing;
	}

	@Override
	public BulkOperation getOperation() {
		return this.operation;
	}

	@Override
	public Map<String, String> getOptions() {
		return this.options;
	}
	
}
