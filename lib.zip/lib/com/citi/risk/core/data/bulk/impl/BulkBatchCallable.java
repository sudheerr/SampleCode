package com.citi.risk.core.data.bulk.impl;

import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.lang.StringUtils;

import com.citi.risk.core.data.bulk.api.BulkOperation;
import com.citi.risk.core.data.bulk.api.BulkProcessingEnabled;
import com.citi.risk.core.data.bulk.api.EntryAdditionalInfoPair;
import com.citi.risk.core.data.bulk.api.Submission;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public class BulkBatchCallable<K, E extends IdentifiedBy<K>> implements ManagedExecution, Callable<List<EntryAdditionalInfoPair<K, E>>> {

	private Submission<K, E> submission;
	private List<EntryAdditionalInfoPair<K, E>> entryAddInfoPairs;
	private String executionParameters = StringUtils.EMPTY;
	
	public BulkBatchCallable(Submission<K, E> submission, List<EntryAdditionalInfoPair<K, E>> entryAddInfoPairs) {
		this.submission = submission;
		this.entryAddInfoPairs = entryAddInfoPairs;
		executionParameters = StringUtils.join(entryAddInfoPairs, ",");
	}
	
	@Override
	public List<EntryAdditionalInfoPair<K, E>> call() throws Exception {
		BulkProcessingEnabled<K, E> bulkProcessing = submission.getBulkProcessingEnabled();
		BulkOperation operation = submission.getOperation();
		List<EntryAdditionalInfoPair<K, E>> result;
		switch (operation) {
			case UPDATE:
				result = bulkProcessing.update(entryAddInfoPairs, submission.getOptions());
				break;
			default:
				result = entryAddInfoPairs;
				break;
		}
		return result;
	}
	
	@Override
	public String getExecutionName() {
		return TaskType.BulkProcessing.name();
	}
	
	@Override
	public String getExecutionParameters() {
		return executionParameters;
	}
	
	@Override
	public TaskType getType() {
		return TaskType.BulkProcessing;
	}
	
	@Override
	public boolean isNewThread() {
		return true;
	}
}