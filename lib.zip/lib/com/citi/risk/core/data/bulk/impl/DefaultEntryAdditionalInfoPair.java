package com.citi.risk.core.data.bulk.impl;

import com.citi.risk.core.data.bulk.api.EntryAdditionalInfoPair;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;

public final class DefaultEntryAdditionalInfoPair<K, E extends IdentifiedBy<K>> implements EntryAdditionalInfoPair<K, E> {
	
	private E entry;
	private String additionalInfo;

	public DefaultEntryAdditionalInfoPair() {
		this(null);
	}

	public DefaultEntryAdditionalInfoPair(E entry) {
		this.entry = entry;
	}

	@Override
	public E getEntry() {
		return entry;
	}

	@Override
	public void setEntry(E entry) {
		this.entry = entry;
	}

	@Override
	public String getAdditionalInfo() {
		return this.additionalInfo;
	}

	@Override
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	@Override
	public String toString() {
		if (!NullTerminator.objectIsNull(entry)) {
			String toString = "[AI=" + this.additionalInfo + ",ID=" + entry.key();
			if (entry instanceof ManagedVersion) {
				toString = toString + ",BK=" + ((ManagedVersion)entry).getBusinessKey()	+ ",VER=" + ((ManagedVersion)entry).getVersion();
			}
			return toString +"]";
		} else {
			return "[EMPTY]";
		}
	}

}
