package com.citi.risk.core.data.bulk.api;

import java.util.List;
import java.util.Map;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface BulkProcessingEnabled<K, E extends IdentifiedBy<K>> {
	
	List<EntryAdditionalInfoPair<K, E>> 
			update(List<EntryAdditionalInfoPair<K, E>> entries, Map<String, String> options) throws BulkProcessingException;

}
