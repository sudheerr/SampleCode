package com.citi.risk.core.data.bulk.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.citi.risk.core.data.bulk.api.BulkOperation;
import com.citi.risk.core.data.bulk.api.BulkProcessingEnabled;
import com.citi.risk.core.data.bulk.api.BulkProcessor;
import com.citi.risk.core.data.bulk.api.EntryAdditionalInfoPair;
import com.citi.risk.core.execution.api.ManagedExecutorService;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;

@Singleton
public class DefaultBulkProcessorImpl implements BulkProcessor {
	
	@Inject
	private ManagedExecutorService submissionManagedExecutor;

	@Inject
	private Injector injector;

	@Override
	public <K, E extends IdentifiedBy<K>> List<EntryAdditionalInfoPair<K, E>> newEntryAdditionalnfoPair(List<E> entries) {
		List<EntryAdditionalInfoPair<K, E>> returnList = Lists.newArrayListWithCapacity(entries.size());
		for (E entry : entries) {
			if (!NullTerminator.objectIsNull(entry) && entry.key() != null) {
				returnList.add(new DefaultEntryAdditionalInfoPair<K, E>(entry));
			}
		}
		return returnList;
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<List<EntryAdditionalInfoPair<K, E>>> submit(
									BulkProcessingEnabled<K, E> bpe, 
									BulkOperation operation,
									List<EntryAdditionalInfoPair<K, E>> entries,
									Map<String, String> options) {
		SubmissionCallable<K, E> submissionCallable = new SubmissionCallable(bpe, operation, entries, options);
		injector.injectMembers(submissionCallable);
		return submissionManagedExecutor.submit(submissionCallable);
	}
}
