package com.citi.risk.core.data.pivot.impl;

import java.util.concurrent.ConcurrentHashMap;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.dictionary.api.DataPath;

public class DimensionPathObjectMap {

	@SuppressWarnings("rawtypes")
	private static ConcurrentHashMap<String, PivotDimension> pathDimensionObjMap = new ConcurrentHashMap<>();
	
	private DimensionPathObjectMap() {
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T, DT> PivotDimension<T, DT> getPivotDimension(T dimension, DataPath<DT, T> dataPath) {
		String dimensionString = dimension.toString();
		PivotDimension pivotDimension = pathDimensionObjMap.get(dimensionString);
		if(pivotDimension == null) {
			pivotDimension = new DefaultPivotDimension(dimension, dataPath);
			pathDimensionObjMap.putIfAbsent(dimensionString, pivotDimension);
		}
		return pivotDimension;
	}
	
}
