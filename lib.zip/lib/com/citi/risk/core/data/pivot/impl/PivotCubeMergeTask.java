package com.citi.risk.core.data.pivot.impl;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.*;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

public class PivotCubeMergeTask<E> extends RecursiveTask<Map<PivotDimensionGroup<E>, Collection<E>>> implements ManagedExecution {

	private static final long serialVersionUID = 4812020777260081167L;

	private final ConcurrentMap<PivotDimensionGroup<E>, Collection<E>> pivotResult;
	
	private final List<Map<PivotDimensionGroup<E>, Collection<E>>> dimensionGroupMapList;

	private final int partitionSize;

	private final int timeout;

	private final Stack<PivotCubeMergeTask<E>> tasks = new Stack<>();

	
	public PivotCubeMergeTask(
			ConcurrentMap<PivotDimensionGroup<E>, Collection<E>> result,
			List<Map<PivotDimensionGroup<E>, Collection<E>>> dimensionGroupMapList,
			int partitionSize, final int timeout) {
		this.pivotResult = result;
		this.dimensionGroupMapList = dimensionGroupMapList;
		this.partitionSize = partitionSize;
		this.timeout = timeout;
	}

	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		while (!tasks.isEmpty()) {
			tasks.pop().cancel(true);
		}
		return super.cancel(mayInterruptIfRunning);
	}

	@Override
	protected Map<PivotDimensionGroup<E>, Collection<E>> compute() {
		if(dimensionGroupMapList == null || dimensionGroupMapList.isEmpty()) return Collections.emptyMap();
		if(dimensionGroupMapList.size() <= partitionSize) return merge(dimensionGroupMapList);
		
		Iterable<List<Map<PivotDimensionGroup<E>, Collection<E>>>> partitionedGroups = Iterables.partition(dimensionGroupMapList, partitionSize);
		final Collection<PivotCubeMergeTask<E>> partitionedTasks = new ArrayList<>(dimensionGroupMapList.size()/partitionSize);
		for (final List<Map<PivotDimensionGroup<E>, Collection<E>>> partitionedGroup : partitionedGroups) {
			PivotCubeMergeTask<E> pivotCubeMergeTask = (PivotCubeMergeTask<E>) new PivotCubeMergeTask<>(pivotResult, partitionedGroup, partitionSize, this.timeout).fork();
			partitionedTasks.add(pivotCubeMergeTask);
			tasks.push(pivotCubeMergeTask);
		}
		for (final PivotCubeMergeTask<E> partitionedTask : partitionedTasks) {
			try {
				partitionedTask.get(2 * this.timeout, TimeUnit.SECONDS);
			} catch (InterruptedException | TimeoutException e) {
				cancel(true);
				throw new TaskTimeoutCancelationException("PivotCubeMergeTask timeout", e);
			} catch (ExecutionException e) {
				cancel(true);
				throw new RuntimeException(e.getCause());
			}
		}

		return pivotResult;
	}


	private Map<PivotDimensionGroup<E>, Collection<E>> merge(List<Map<PivotDimensionGroup<E>, Collection<E>>> dimensionGroupMapList) {
		for(Map<PivotDimensionGroup<E>, Collection<E>> groupMap : dimensionGroupMapList) {
			for(Entry<PivotDimensionGroup<E>, Collection<E>> entry : groupMap.entrySet()) {
				PivotDimensionGroup<E> group = entry.getKey();
				Collection<E> value = entry.getValue();
				if(value==null || value.isEmpty()) continue;

				getGroupKeyMembersAndAdd(group, value);
			}
		}
		return pivotResult;
	}

	private void getGroupKeyMembersAndAdd(PivotDimensionGroup<E> key, Collection<E> sourceColl) {
		Collection<E> existColl = pivotResult.get(key);
		if (existColl == null) {
			existColl = pivotResult.putIfAbsent(key, Lists.<E>newArrayList(sourceColl));
		}
		if (existColl != null) {
			synchronized (existColl) {
				existColl.addAll(sourceColl);
			}
		}
	}
	
	@Override
	public TaskType getType() {
		return TaskType.CoreParallel;
	}

	@Override
	public String getExecutionName() {
		return "PivotCubeMerge Task";
	}

	@Override
	public String getExecutionParameters() {
		return null;
	}

	@Override
	public boolean isNewThread() {
		return true;
	}
}
