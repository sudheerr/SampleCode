package com.citi.risk.core.data.pivot.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.citi.risk.core.ioc.impl.guice.CoreModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.pivot.api.PivotDataCube;
import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.dictionary.api.AggregateInfo;
import com.citi.risk.core.dictionary.api.AggregateMeasure;
import com.citi.risk.core.dictionary.api.DDType;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.ItemList;
import com.citi.risk.core.dictionary.api.PivotQueryRequest;
import com.citi.risk.core.dictionary.impl.AggregateOnPath;
import com.citi.risk.core.execution.impl.DefaultManagedExecutorService;
import com.citi.risk.core.ioc.impl.guice.ExecutorServiceModule.ManagedExecutorServiceProvider;
import com.citi.risk.core.lang.aggregate.AggregateFactory;
import com.citi.risk.core.lang.aggregate.Aggregator;

@SuppressWarnings({"unchecked", "rawtypes"})
public class DefaultPivotDataCube<E, R, C, T> implements PivotDataCube<E, R, C, T> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultPivotDataCube.class);


    private AggregateFactory aggregateFactory;

    private PivotQueryRequest<E> pivotQueryRequest; 
	
	private Collection<E> initialDataSet;
	
	private Map<PivotDimensionGroup<E>, Collection<E>> dimensionGroupMap;
	
	private int groupMaxNum;
	
	private HashMap<PivotDataCubeKey, PivotTableCell> dataTableMap = null;

	private final int timeout;
	
	public DefaultPivotDataCube(AggregateFactory aggregateFactory, PivotQueryRequest<E> pivotQueryRequest, Collection<E> initialDataSet, int groupMaxNum, final int timeout) {
		this.aggregateFactory = aggregateFactory;
		this.pivotQueryRequest = pivotQueryRequest;
		this.initialDataSet = initialDataSet;
		this.groupMaxNum = groupMaxNum;
		this.timeout = timeout;
	}
	
	public void populateDataCube() {
		Map<DataSelectionItem<E, ?>, Aggregator<E, ?>> aggregators = new HashMap<>();
		extractAggregateClasses(pivotQueryRequest, aggregators);

		buildDimensionGroupMap();
		aggregateValuesInEachDimensionGroup(aggregators);
	}
	
	private void buildDimensionGroupMap() {
		List<DataSelectionItem<E, ?>> rowDimensions = pivotQueryRequest.getRowDimension().getSelectionItems();
		List<DataSelectionItem<E, ?>> columnDimensions = pivotQueryRequest.getColumnDimension().getSelectionItems();

		DataSelectionItem<E, ?>[] rowDataSelectionItems = (DataSelectionItem<E, ?>[]) rowDimensions.toArray(new DataSelectionItem[rowDimensions.size()]);
		DataSelectionItem<E, ?>[] colDataSelectionItems = (DataSelectionItem<E, ?>[]) columnDimensions.toArray(new DataSelectionItem[columnDimensions.size()]);

		int partitionNum = initialDataSet == null ? 50000:
			DefaultManagedExecutorService.getForkJoinPartitionSize(initialDataSet.size());
		
		ForkJoinTask<Map<PivotDimensionGroup<E>, Collection<E>>> buildMapFuture = ManagedExecutorServiceProvider.getInstance().submit(new PivotCubeTask<E>(rowDataSelectionItems, colDataSelectionItems, initialDataSet, partitionNum, groupMaxNum, this.timeout));
		try {
			dimensionGroupMap = buildMapFuture.get(this.timeout, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			buildMapFuture.cancel(true);
			throw new TaskTimeoutCancelationException("query timeout", e);
		} catch (ExecutionException e) {
			buildMapFuture.cancel(true);
			throw new RuntimeException(e.getCause());
		} catch (TimeoutException e) {
			buildMapFuture.cancel(true);
			throw new TaskTimeoutCancelationException("PivotCubeTask canceled since timeout", e);
		}
	}

	private void aggregateValuesInEachDimensionGroup(Map<DataSelectionItem<E, ?>, Aggregator<E, ?>> aggregators) {
		if(aggregators.isEmpty())
			return;
		
		int partitionNum = DefaultManagedExecutorService.getForkJoinPartitionSize(dimensionGroupMap.keySet().size());

		ForkJoinTask<Map<PivotDimensionGroup<E>, Collection<E>>> aggregateFuture = ManagedExecutorServiceProvider.getInstance().submit(new PivotCubeAggregationTask<>(dimensionGroupMap, aggregators, dimensionGroupMap.keySet(), partitionNum, this.timeout));
		try {
			aggregateFuture.get(this.timeout, TimeUnit.SECONDS);
		} catch (InterruptedException | TimeoutException e) {
			aggregateFuture.cancel(true);
			throw new TaskTimeoutCancelationException("PivotCubeAggregationTask timeout", e);
		} catch (ExecutionException e) {
			throw new RuntimeException(e.getCause());
		}
	}
	
	@Override
	public Map<PivotDimensionGroup<E>, Collection<E>> getDimensionGroupMap() {
		return dimensionGroupMap;
	}
	
	@Override
	public Map<PivotDataCubeKey, PivotTableCell> getDataTableMap() {
		if(dataTableMap == null) {
			dataTableMap = new HashMap<>(dimensionGroupMap.size());
			for(PivotDimensionGroup pivotDimensionGroup : dimensionGroupMap.keySet()) {
				dataTableMap.put(pivotDimensionGroup.getPivotDataCubeKey(pivotQueryRequest.getRowDimension().getSelectionItems(), pivotQueryRequest.getColumnDimension().getSelectionItems()),
						pivotDimensionGroup.getPivotTableCell());
			}
		}
		return dataTableMap;
	}

	@Override
	public void setIncludeSummary(boolean includeSummary) {
		throw new RuntimeException("Operation not supported yet.");
	}

	@Override
	public boolean getIncludeSummary() {
		throw new RuntimeException("Operation not supported yet.");
	}

	private void extractAggregateClasses(PivotQueryRequest pivotQueryRequest,
			Map<DataSelectionItem<E, ?>, Aggregator<E, ?>> aggregators) {
		List<DataSelectionItem<E, ?>> aggregateMeasures = pivotQueryRequest.getAggregateMeasure().getSelectionItems();
		for(DataSelectionItem<E, ?> dsi : aggregateMeasures) {
			AggregateMeasure<?, ?> aggregateMeasure = dsi.getSelectedAggregateMeasure();
			if(aggregateMeasure == null) continue;
			
			AggregateInfo<?> aggregateInfo = aggregateMeasure.getAggregateInfo();
			Class<?> aggregateClass = aggregateInfo.getAggregateClass();
			if(Aggregator.class.isAssignableFrom(aggregateClass)){
				aggregators.put(dsi, getAggregatorOnPath(dsi, aggregateInfo));
			}
		}
	}

	private Aggregator<E, ?> getAggregatorOnPath(DataSelectionItem<E, ?> dsi, AggregateInfo<?> aggregateInfo) {
		int size = 0;
		if (dsi.getUnderlyingPath().getDDType() == DDType.ITEMLIST) {
			size = ((ItemList) dsi.getUnderlyingPath().getTerminatingItem()).getSize();
		}
		Aggregator aggregator = (Aggregator<E, ?>) aggregateFactory.getAggregate(aggregateInfo, size);
		Aggregator<E, ?> aggregatorOnPath = new AggregateOnPath(dsi, aggregator);
		return aggregatorOnPath;
	}

}
