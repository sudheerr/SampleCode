package com.citi.risk.core.data.pivot.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.citi.risk.core.data.pivot.api.PivotTableCellValue;
import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class DefaultPivotTableCellValue<E, V> implements PivotTableCellValue<E, V> {

	private Map<DataSelectionItem<E, V>, V> cellValues;  
	
	private Map<DataSelectionItem<E, V>, CompareResult<V>> compareResult;
	
	private Collection<E> members = new ArrayList<>();
	
	private Collection<E> nonControlMembers = new ArrayList<>();

	public DefaultPivotTableCellValue(Map<DataSelectionItem<E, V>, V> cellValues) {
		this.cellValues = cellValues;
	}
	
	@SuppressWarnings("unchecked")
	public DefaultPivotTableCellValue(PivotTableCell<E> pivotTableCell) {
		this.cellValues = (Map<DataSelectionItem<E, V>, V>)(Map<?,?>)pivotTableCell.getValueMap();
		this.compareResult = (Map<DataSelectionItem<E, V>, CompareResult<V>>)(Map<?,?>) pivotTableCell.getCompareResult();
		this.members = pivotTableCell.getMembers();
		this.nonControlMembers = pivotTableCell.getNonControlMembers();
	}
	
	@Override
	public V getValue(DataSelectionItem<E, V> aggregateMeasureDsi) {
		return cellValues.get(aggregateMeasureDsi);
	}

	@Override
	public boolean isEmpty() {
		if(cellValues == null || cellValues.isEmpty()) return true;

		return false;
	}

	@Override
	public Boolean hasCompareResult() {
		return this.compareResult != null;
	}

	@Override
	public CompareResult<V> getVarianceResult(DataSelectionItem<E, V> aggregateMeasureDsi) {
		if (this.compareResult == null) {
			return null;
		}
		return this.compareResult.get(aggregateMeasureDsi);
	}
	
	@Override
	public Collection<E> getMembers() {
		return this.members;
	}
	
	@Override
	public Collection<E> getNonControlMembers() {
		return this.nonControlMembers;
	}

}
