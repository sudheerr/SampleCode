package com.citi.risk.core.data.pivot.api;

import com.citi.risk.core.dictionary.api.DataPath;

import java.util.List;

public interface PivotDimensions<E, T> {

	PivotDimension<E, T> getTopLevelPivotDimension();
	
	List<PivotDimension<E, ?>> getPivotDimensions();
	
	String getPivotDimensionsString();
	
	List<?> getPivotDimensionValues();

	DataPath<E, ?> getTerminatingPath();
	
}
