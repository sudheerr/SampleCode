package com.citi.risk.core.data.pivot.api;

import java.util.Set;

import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.google.common.collect.Table;

public interface PivotTable<E, R, C> extends Table<PivotDimensions<E, R>, PivotDimensions<E, C>, PivotTableCellValue> {

	<CR, CC> PivotTable<E, CR, CC> getChildTable(PivotDimensions<E, CR> rowDimensions, PivotDimensions<E, CC> columnDimensions);

	Boolean hasChildTables();
	
	Set<R> getRowHeaders(); 
	
	Set<C> getColumnHeaders(); 
	
	PivotTableCellValue getRowSummary(C columnHeader);
	
	PivotTableCellValue getColumnSummary(R rowHeader);
	
	PivotTableCellValue getGrandSummary();

	Set<PivotDimensions<E, R>> rowKeySetWithSubtotalKey();

	DataSelectionItem<E, R> getTopLevelRowDsi();

	DataSelectionItem<E, C> getTopLevelColumnDsi();
	
	Set<DataSelectionItem<E, ?>> getAggregateMeasureDSIs();
	
	void paginate(int pageSize, int pageIndex);
}
