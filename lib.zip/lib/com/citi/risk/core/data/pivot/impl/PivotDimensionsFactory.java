package com.citi.risk.core.data.pivot.impl;

import java.util.List;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class PivotDimensionsFactory {
	
	private PivotDimensionsFactory() {
	}

	public static <E, T> PivotDimensions<E, T> createPivotDimensions(DataDomain<E> domain, T... values) {
		if(values == null || values.length == 0)
			return null;
		PivotDimension<E, ?>[] pivotDimensions = new PivotDimension[values.length];
		int i = 0;
		for(T value : values) {
			pivotDimensions[i] = new DefaultPivotDimension<>(domain, value);
			i++;
		}
		
		return new DefaultPivotDimensions<>(pivotDimensions);
	}
	
	public static <E, T> PivotDimensions<E, T> createPivotDimensions(DataDomain<E> domain, List<T> values) {
		if(values == null || values.isEmpty())
			return null;
		PivotDimension<E, ?>[] pivotDimensions = new PivotDimension[values.size()];
		int i = 0;
		for(T value : values) {
			pivotDimensions[i] = new DefaultPivotDimension<>(domain, value);
			i++;
		}
		
		return new DefaultPivotDimensions<>(pivotDimensions);
	}

	public static <E, T> PivotDimensions<E, T> createPivotDimensions(List<T> values, List<DataSelectionItem<E, ?>> dataSelectionItems) {
		if(values == null || values.isEmpty())
			return null;
		if(values.size() != dataSelectionItems.size())
			throw new RuntimeException("mismatch between size of dimension values and data selection items.");
		
		PivotDimension<T, ?>[] pivotDimensions = new PivotDimension[values.size()];
		int i = 0;
		for(T value : values) {
			pivotDimensions[i] = new DefaultPivotDimension(value, dataSelectionItems.get(i).getUnderlyingPath());
			i++;
		}
		
		return new DefaultPivotDimensions(pivotDimensions);
	}

	public static <E, T> PivotDimensions<E, T> getPivotDimensions(PivotDimension<E, T>... values) {
		if(values == null || values.length == 0)
			return null;
		PivotDimension<E, T>[] pivotDimensions = new PivotDimension[values.length];
		int i = 0;
		for(PivotDimension<E, T> value : values) {
			pivotDimensions[i] = value;
		}
		
		return new DefaultPivotDimensions<>(pivotDimensions);
	}
	
	public static <E, T> PivotDimensions<E, T> getPivotDimensions(List<PivotDimension<E, T>> values) {
		if(values == null || values.isEmpty())
			return null;
		PivotDimension<E, T>[] pivotDimensions = new PivotDimension[values.size()];
		int i = 0;
		for(PivotDimension<E, T> value : values) {
			pivotDimensions[i] = value;
		}
		
		return new DefaultPivotDimensions<>(pivotDimensions);
	}
}
