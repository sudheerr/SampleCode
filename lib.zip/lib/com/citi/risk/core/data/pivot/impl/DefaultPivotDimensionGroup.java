package com.citi.risk.core.data.pivot.impl;

import java.util.List;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class DefaultPivotDimensionGroup<E> implements PivotDimensionGroup<E> {

	private final List<Object> rowDimensionValues;

	private final List<Object> colDimensionValues;

	private PivotTableCell pivotTableCell;

	private final int hashCode;

	public DefaultPivotDimensionGroup(List<Object> rowDimensionValues,
			List<Object> colDimensionValues) {
		this.rowDimensionValues = rowDimensionValues;
		this.colDimensionValues = colDimensionValues;
		this.hashCode = ((rowDimensionValues==null) ? 0 : rowDimensionValues.hashCode()) * 31 + ((colDimensionValues==null) ? 0 : colDimensionValues.hashCode());
	}

	@Override
	public PivotDataCubeKey getPivotDataCubeKey(List<DataSelectionItem<E, ?>> rowDataSelectionItems, List<DataSelectionItem<E, ?>> colDataSelectionItems) {
		return new PivotDataCubeKey(
				PivotDimensionsFactory.createPivotDimensions(rowDimensionValues, rowDataSelectionItems),
				PivotDimensionsFactory.createPivotDimensions(colDimensionValues, colDataSelectionItems));
	}

	@Override
	public List<Object> getRowDimensionValues() {
		return rowDimensionValues;
	}

	@Override
	public List<Object> getColumnDimensionValues() {
		return colDimensionValues;
	}

	@Override
	public boolean equals(Object other){
		if(other==null) return false;
		if(!(other instanceof DefaultPivotDimensionGroup)){
			return false;
		}
		
		DefaultPivotDimensionGroup that = (DefaultPivotDimensionGroup)other;
		if(this.rowDimensionValues == that.rowDimensionValues && this.colDimensionValues == that.colDimensionValues) return true;
		if(this.hashCode() != that.hashCode) return false;

		boolean rowDimsEqual  = false;
		if(this.rowDimensionValues != null && that.rowDimensionValues != null)
			rowDimsEqual = this.rowDimensionValues.equals(that.rowDimensionValues);
		else if(this.rowDimensionValues == null && that.rowDimensionValues == null) rowDimsEqual = true;
		
		boolean colDimsEqual  = false;
		if(this.colDimensionValues != null && that.colDimensionValues != null)
			colDimsEqual = this.colDimensionValues.equals(that.colDimensionValues);
		else if(this.colDimensionValues == null && that.colDimensionValues == null) colDimsEqual = true;
		
		if(rowDimsEqual && colDimsEqual) return true;

		return false;
	}

	@Override
	public int hashCode(){
		return hashCode;
	}

	@Override
	public void setPivotTableCell(PivotTableCell pivotTableCell) {
		this.pivotTableCell = pivotTableCell;
	}

	@Override
	public PivotTableCell getPivotTableCell() {
		return pivotTableCell;
	}

}
