package com.citi.risk.core.data.pivot.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class PivotTableChildTree<K, V> extends TreeMap<K, V> {

	private static final long serialVersionUID = 1L;
	
	private static final Comparator<Comparable> HASHCODE_COMPARATOR;
	
    /**
     * The head of the doubly linked list.
     */
    private transient List<Entry<K,V>> entryList;
    
    static {
		HASHCODE_COMPARATOR = new Comparator() {
			@Override
			public int compare(Object o1, Object o2) {
				if(o1 != null && o2 != null)
					return Integer.compare(o1.hashCode(), o2.hashCode());
				else if(o1 == null && o2 == null) return 0;
				else if(o1 != null) return 1;
				else return -1;
			}
		};
	}

	public PivotTableChildTree() {
		super((Comparator<? super K>) HASHCODE_COMPARATOR);
		entryList = new LinkedList();
	}
	

	@Override
	public V put(K key, V value) {
		V storedVal = super.put(key, value);
		if(storedVal == null) 
			entryList.add(new Entry<>(key, value));
		
		return storedVal;
	}
	
	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	public Iterator<Entry<K, V>> getEntryListIterator() {
		return entryList.iterator();
	}
	
	public void setEntryList(List<Entry<K,V>> entryList) {
		this.entryList = entryList;
	}
	
	public List<Entry<K, V>> getEntryList() {
		return entryList;
	}
	
	@Override
	public Set<K> keySet() {
		LinkedHashSet navigatableKeySet = new LinkedHashSet();
		for (Entry<K,V> entry : entryList) {
			navigatableKeySet.add(entry.getKey());
		}
		return navigatableKeySet;
	}

	
	public void sortAndPaginate(Comparator comparator, int startIndex, int endIndex) {
		Collections.sort(entryList, comparator);
		entryList = entryList.subList(startIndex, endIndex);
	}
	
	public void sort(Comparator comparator) {
		Collections.sort(entryList, comparator);
	}
	
	public void paginate(int startIndex, int endIndex) {
		entryList = entryList.subList(startIndex, endIndex);
	}

	static final class Entry<K,V> implements Map.Entry<K,V> {
        K key;
        V value;

        /**
         * Make a new cell with given key, value, and parent, and with
         * {@code null} child links, and BLACK color.
         */
        Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        /**
         * Returns the key.
         *
         * @return the key
         */
        @Override
        public K getKey() {
            return key;
        }

        /**
         * Returns the value associated with the key.
         *
         * @return the value associated with the key
         */
        @Override
        public V getValue() {
            return value;
        }

        /**
         * Replaces the value currently associated with the key with the given
         * value.
         *
         * @return the value associated with the key before this method was
         *         called
         */
        @Override
        public V setValue(V value) {
            V oldValue = this.value;
            this.value = value;
            return oldValue;
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Map.Entry))
                return false;
            Map.Entry<?,?> e = (Map.Entry<?,?>)o;

            return valEquals(key,e.getKey()) && valEquals(value,e.getValue());
        }

        @Override
        public int hashCode() {
            int keyHash = key==null ? 0 : key.hashCode();
            int valueHash = value==null ? 0 : value.hashCode();
            return keyHash ^ valueHash;
        }

        @Override
        public String toString() {
            return key + "=" + value;
        }
    }

    /**
     * Test two values for equality.  Differs from o1.equals(o2) only in
     * that it copes with {@code null} o1 properly.
     */
    static final boolean valEquals(Object o1, Object o2) {
        return o1==null ? o2==null : o1.equals(o2);
    }

}
