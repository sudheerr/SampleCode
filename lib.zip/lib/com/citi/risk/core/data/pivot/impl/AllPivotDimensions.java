package com.citi.risk.core.data.pivot.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;

public class AllPivotDimensions<E> implements PivotDimensions<E, String> {

	private static final AtomicReference<AllPivotDimensions> instance = new AtomicReference<>();

	public static AllPivotDimensions getInstance() {
		AllPivotDimensions allPivotDimensions = instance.get();

		if (allPivotDimensions == null) {
			instance.compareAndSet(null, new AllPivotDimensions());
			allPivotDimensions = instance.get();
		}

		return allPivotDimensions;
	}

	private PivotDimension<E, ?>[] pivotDimensions = new PivotDimension[0];

	protected AllPivotDimensions() {}
	
	@Override
	public List<PivotDimension<E, ?>> getPivotDimensions() {
		return Arrays.asList(pivotDimensions);
	}

	@Override
	public String getPivotDimensionsString() {
		return "*";
	}

	@Override
	public List<String> getPivotDimensionValues() {
		return Collections.emptyList();
	}

	@Override
	public PivotDimension<E, String> getTopLevelPivotDimension() {
		return null;
	}

	@Override public DataPath<E, ?> getTerminatingPath() {
		return null;
	}

}
