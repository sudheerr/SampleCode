package com.citi.risk.core.data.pivot.impl;

import java.util.*;
import java.util.concurrent.*;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.data.query.api.TaskExecutionRuntimeException;
import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.execution.impl.DefaultManagedExecutorService;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.ioc.impl.guice.ExecutorServiceModule.ManagedExecutorServiceProvider;
import com.google.common.collect.Iterables;

@SuppressWarnings({"rawtypes", "unchecked" })
public class PivotCubeTask<E> extends RecursiveTask<Map<PivotDimensionGroup<E>, Collection<E>>> implements ManagedExecution{
	private static final long serialVersionUID = -7200824136686993964L;
	
	private final DataSelectionItem<E, ?>[] rowDataSelectionItems;
	private final DataSelectionItem<E, ?>[] colDataSelectionItems;
	private final Collection<E> dataSet;
	private final int groupMaxNum;

	private final int partitionSize;

	private final int timeout;

	private final Stack<PivotCubeTask<E>> tasks = new Stack<>();
	
	public PivotCubeTask(DataSelectionItem<E, ?>[] rowDataSelectionItems,
			DataSelectionItem<E, ?>[] colDataSelectionItems,
			Collection<E> dataSet, final int partitionSize, int groupMaxNum, final int timeout) {
		this.rowDataSelectionItems = rowDataSelectionItems;
		this.colDataSelectionItems = colDataSelectionItems;
		this.dataSet = dataSet;
		this.partitionSize = partitionSize;
		this.groupMaxNum = groupMaxNum;
		this.timeout = timeout;
	}
	
	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		while (!tasks.isEmpty()) {
			tasks.pop().cancel(true);
		}
		return super.cancel(mayInterruptIfRunning);
	}

	@Override
	protected Map<PivotDimensionGroup<E>, Collection<E>> compute() {
		if (dataSet == null || dataSet.isEmpty()) return Collections.emptyMap();
		if (dataSet.size() <= partitionSize) return buildCubeKeys(dataSet);

		Iterable<List<E>> partitionedDataSets = Iterables.partition(dataSet, partitionSize);
		final Collection<PivotCubeTask<E>> partitionedPivotCubeTasks = new ArrayList(dataSet.size()/partitionSize);
		for (final List<E> partitionedDataSet : partitionedDataSets) {
			PivotCubeTask<E> pivotCubeTask = (PivotCubeTask<E>) new PivotCubeTask<>(rowDataSelectionItems, colDataSelectionItems, partitionedDataSet, partitionSize, groupMaxNum, this.timeout).fork();
			partitionedPivotCubeTasks.add(pivotCubeTask);
			tasks.push(pivotCubeTask);
		}
		List<Map<PivotDimensionGroup<E>, Collection<E>>> result = new ArrayList<>(partitionedPivotCubeTasks.size());
		for (final PivotCubeTask<E> partitionedPivotCubeTask : partitionedPivotCubeTasks) {
			try {
				result.add(partitionedPivotCubeTask.get(2 * this.timeout, TimeUnit.SECONDS));
			} catch (InterruptedException | TimeoutException e) {
				cancel(true);
				throw new TaskTimeoutCancelationException("PivotCubeTask canceled since timeout", e);
			} catch (ExecutionException e) {
				cancel(true);
				throw new TaskExecutionRuntimeException(e.getCause());
			}
		}
		return parallelMerge(result);
	}
	
	private Map<PivotDimensionGroup<E>, Collection<E>> parallelMerge(List<Map<PivotDimensionGroup<E>, Collection<E>>> resultList) {
		ConcurrentHashMap<PivotDimensionGroup<E>, Collection<E>> result = new ConcurrentHashMap<>(32);
		int _partitionSize = DefaultManagedExecutorService.getForkJoinPartitionSize(resultList.size());
		ForkJoinTask<Map<PivotDimensionGroup<E>, Collection<E>>> pivotCubeMergeTask = ManagedExecutorServiceProvider.getInstance().submit(new PivotCubeMergeTask<>(result, resultList, _partitionSize, this.timeout));
		try {
			pivotCubeMergeTask.get(this.timeout, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			pivotCubeMergeTask.cancel(true);
			throw new RuntimeException(e);
		} catch (ExecutionException e) {
			pivotCubeMergeTask.cancel(true);
			throw new RuntimeException(e.getCause());
		} catch (TimeoutException e) {
			pivotCubeMergeTask.cancel(true);
			throw new TaskTimeoutCancelationException("PivotCubeMergeTask timeout", e);
		}
		return result;
	}

	public Map<PivotDimensionGroup<E>, Collection<E>> buildCubeKeys(Collection<E> dataSet) {
		Map<PivotDimensionGroup<E>, Collection<E>> dataCubeMap = new HashMap<>(dataSet.size()/10);
		for(E object : dataSet) {
			PivotDimensionGroup key = getPivotDimensionGroup(object);

			Collection<E> keyCollection = dataCubeMap.get(key);
			if(keyCollection == null) {
				keyCollection = new LinkedList<>();
				dataCubeMap.put(key, keyCollection);
			}
			keyCollection.add(object);
		}
		
		if (dataCubeMap.size()>groupMaxNum) {
			throw new RuntimeException("The number of groups are more than " + groupMaxNum + ".");
		}
		
		return dataCubeMap;
	}

	private PivotDimensionGroup<E> getPivotDimensionGroup(E object) {
		List rowPivotDimensions = new ArrayList(rowDataSelectionItems.length);
		List colPivotDimensions = new ArrayList(colDataSelectionItems.length);
		
		for(DataSelectionItem dsi : rowDataSelectionItems)
			rowPivotDimensions.add(dsi.getUnderlyingPath().getTranform().apply(object));
		for(DataSelectionItem dsi : colDataSelectionItems)
			colPivotDimensions.add(dsi.getUnderlyingPath().getTranform().apply(object));
		
		if(rowDataSelectionItems.length > 0 && colDataSelectionItems.length > 0)
			return new DefaultPivotDimensionGroup<>(rowPivotDimensions, colPivotDimensions);
		if(rowDataSelectionItems.length > 0)
			return new RowOnlyPivotDimensionGroup<>(rowPivotDimensions);
		if(colDataSelectionItems.length > 0)
			return new ColumnOnlyPivotDimensionGroup<>(colPivotDimensions);

		return NullPivotDimensionGroup.getInstance();
	}

	@Override
	public TaskType getType() {
		return TaskType.CoreParallel;
	}

	@Override
	public String getExecutionName() {
		return "PivotCube Task";
	}

	@Override
	public String getExecutionParameters() {
		return null;
	}

	@Override
	public boolean isNewThread() {
		return true;
	}

}
