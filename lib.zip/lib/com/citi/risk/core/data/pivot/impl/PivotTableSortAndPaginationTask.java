package com.citi.risk.core.data.pivot.impl;

import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.aggregate.Aggregator;
import com.google.common.collect.Iterables;

import org.apache.commons.collections.comparators.ComparatorChain;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@SuppressWarnings({"rawtypes", "unchecked"})
public class PivotTableSortAndPaginationTask<E> extends RecursiveTask<List<PivotTableSortGroup>> implements ManagedExecution{
	private static final long serialVersionUID = 4057857615526913355L;

	private List<PivotTableSortGroup> pivotTableSortGroups;
	private List<DataSelectionItem<E, ?>> sortByAggregateMeasures;
	private Map<DataSelectionItem<E, ?>, Aggregator> aggregators;
	private int NumberOfPartitions;
	private final int timeout;
	private final Stack<PivotTableSortAndPaginationTask<E>> tasks = new Stack<>();
	
	public PivotTableSortAndPaginationTask(List<PivotTableSortGroup> pivotTableSortGroups,
			List<DataSelectionItem<E, ?>> sortByAggregateMeasures,
			Map<DataSelectionItem<E, ?>, Aggregator> aggregators,
			int NumberOfPartitions, final int timeout) {
		super();
		this.pivotTableSortGroups = pivotTableSortGroups;
		this.sortByAggregateMeasures = sortByAggregateMeasures;
		this.aggregators = aggregators;
		this.NumberOfPartitions = NumberOfPartitions;
		this.timeout = timeout;
	}
	
	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		while (!tasks.isEmpty()) {
			tasks.pop().cancel(true);
		}
		return super.cancel(mayInterruptIfRunning);
	}
	
	@Override
	protected List<PivotTableSortGroup> compute() {
		for(PivotTableSortGroup pivotTableSortGroup : pivotTableSortGroups) {
			sortPivotTable(pivotTableSortGroup.getPivotTable(), pivotTableSortGroup.getStartIndex(), pivotTableSortGroup.getEndIndex());
		}

		return pivotTableSortGroups;
	}
	
	private void sortPivotTable(DefaultPivotTable pivotTable, int startIndex, int endIndex) {
		if(pivotTable.getChildPivotTables() != null) 
			sortChildTables(pivotTable, startIndex, endIndex);
		else if(pivotTable.getDataTable() != null) 
			sortDataTable(pivotTable, startIndex, endIndex);
	}

	private void sortChildTables(DefaultPivotTable pivotTable, int startIndex, int endIndex) {
		ComparatorChain comparatorChain = new ComparatorChain();
		DefaultPivotTableRowComparator rowLabelComparator = new DefaultPivotTableRowComparator(pivotTable.getRowDataSelectionItem(), sortByAggregateMeasures);
		comparatorChain.addComparator(rowLabelComparator);
		for(DataSelectionItem<E, ?> sortByAggrMeasure : sortByAggregateMeasures) {
			DefaultPivotTableSubtotalComparator subTotalComparator = new DefaultPivotTableSubtotalComparator(sortByAggrMeasure);
			comparatorChain.addComparator(subTotalComparator);
		}

		PivotTableChildTree<?, DefaultPivotTable> childPivotTables = pivotTable.getChildPivotTables();
		childPivotTables.sort(comparatorChain);
		
		int sublistStart = 0, sublistEnd = 0;
		int runningCountForStart = 0, runningCountForEnd = 0;
		boolean sublistStartFound = false, sublistEndFound = false;
		
		int i = -1;
		for(Entry<?, DefaultPivotTable> pair : childPivotTables.getEntryList()) {
			i++;
			if(sublistStartFound && sublistEndFound) break;

			if(!sublistStartFound) {
				if(startIndex >= runningCountForStart && startIndex < (runningCountForStart + pair.getValue().getTotalDataRowsCount())) { 
					sublistStart = i;
					sublistStartFound = true;
				} else {
					runningCountForStart = runningCountForStart + pair.getValue().getTotalDataRowsCount();
				}
			}
			
			if(!sublistEndFound) {
				if((endIndex+1) > runningCountForEnd && (endIndex+1) <= (runningCountForEnd + pair.getValue().getTotalDataRowsCount())) {
					sublistEnd = i;
					sublistEndFound = true;
				} else { 
					runningCountForEnd = runningCountForEnd + pair.getValue().getTotalDataRowsCount();
				}
			}
		}
		if(!sublistStartFound) sublistStart = 0;
		if(!sublistEndFound) sublistEnd = childPivotTables.size()-1;
		
		childPivotTables.paginate(sublistStart, sublistEnd+1);
		pivotTable.setChildPivotTables(childPivotTables);
		
		int newStart = sublistStart == 0 ? startIndex : startIndex - runningCountForStart;
		int newEnd   = sublistStart == 0 ? endIndex   : endIndex - runningCountForStart;

		processChildTablesInParallel(pivotTable.getChildPivotTables(), newStart, newEnd);
	}

	private void processChildTablesInParallel(PivotTableChildTree<?, DefaultPivotTable> childPivotTables, int newStart, int newEnd) {
		int runningCount = 0;
		Collection<PivotTableSortAndPaginationTask<E>> childTasks = new ArrayList();
		List<PivotTableSortGroup> pivotTableSortGrps = new ArrayList<>();
		
		for(Entry<?, DefaultPivotTable> pair : childPivotTables.getEntryList()) {
			int totalDataRowsCount = pair.getValue().getTotalDataRowsCount();
			int start = newStart + 1 > runningCount ? newStart : 0;
			int end = runningCount + totalDataRowsCount <= (newEnd+1) ? totalDataRowsCount - 1 : newEnd-runningCount;
			
			if(NumberOfPartitions <= 1) {
				sortPivotTable(pair.getValue(), start, end);
			} else {
				pivotTableSortGrps.add(new PivotTableSortGroup(pair.getValue(), start, end));
			}
			runningCount += totalDataRowsCount;
		}
		
		if(!pivotTableSortGrps.isEmpty()) {
			Iterable<List<PivotTableSortGroup>> partitionedSortGrps = Iterables.partition(pivotTableSortGrps, (int)Math.ceil((double)pivotTableSortGrps.size()/NumberOfPartitions));
			int partitionedSortGrpSize = Iterables.size(partitionedSortGrps);
			for(List<PivotTableSortGroup> partitionedSortGrp : partitionedSortGrps) {
				PivotTableSortAndPaginationTask pivotTableSortAndPaginationTask = (PivotTableSortAndPaginationTask) new PivotTableSortAndPaginationTask(partitionedSortGrp, sortByAggregateMeasures, aggregators, (int) Math.ceil((double) NumberOfPartitions / partitionedSortGrpSize), this.timeout).fork();
				childTasks.add(pivotTableSortAndPaginationTask);
				tasks.push(pivotTableSortAndPaginationTask);
			}
			for(PivotTableSortAndPaginationTask task : childTasks)
				try {
					task.get(2 * this.timeout, TimeUnit.SECONDS);
				} catch (InterruptedException | TimeoutException e) {
					cancel(true);
					throw new TaskTimeoutCancelationException("PivotTableSortAndPaginationTask timeout", e);
				} catch (ExecutionException e) {
					cancel(true);
					throw new RuntimeException(e.getCause());
				}
		}
	}

	private void sortDataTable(DefaultPivotTable pivotTable, int startIndex, int endIndex) {
		ComparatorChain comparatorChain = new ComparatorChain();
		DefaultPivotTableDataRowComparator rowLabelComparator = new DefaultPivotTableDataRowComparator(pivotTable.getRowDataSelectionItem(), sortByAggregateMeasures);
		comparatorChain.addComparator(rowLabelComparator);
		for(DataSelectionItem<E, ?> sortByAggrMeasure : sortByAggregateMeasures) {
			DefaultPivotTableDataRowSubtotalComparator subTotalComparator = new DefaultPivotTableDataRowSubtotalComparator(sortByAggrMeasure, aggregators);
			comparatorChain.addComparator(subTotalComparator);
		}

		PivotTableChildTree<?, PivotTableChildTree<PivotDimensions, PivotTableCell>> dataTable = pivotTable.getDataTable();
		dataTable.sortAndPaginate(comparatorChain, startIndex, endIndex+1);
		pivotTable.setDataTable(dataTable);
	}

	@Override
	public TaskType getType() {
		return TaskType.CoreParallel;
	}

	@Override
	public String getExecutionName() {
		return "PivotTable Sort and Pagination Task";
	}

	@Override
	public String getExecutionParameters() {
		return null;
	}

	@Override
	public boolean isNewThread() {
		return true;
	}

}
