package com.citi.risk.core.data.pivot.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.data.pivot.api.PivotTable;
import com.citi.risk.core.data.pivot.api.PivotTableCellValue;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.data.query.impl.DefaultCompareResult;
import com.citi.risk.core.data.query.impl.PivotTableSizeExceedException;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.impl.AggregateOnPath;
import com.citi.risk.core.lang.aggregate.Aggregator;
import com.citi.risk.core.lang.aggregate.Evaluator;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Table;
import com.google.common.collect.Tables;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class DefaultPivotTable<E, R, C> implements PivotTable<E, R, C> {

	private PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> childPivotTables;
	
	private PivotTableChildTree<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> dataTable;

	private Map<DataSelectionItem<E, ?>, Aggregator> aggregators;
	
	private int totalDataRows = 0;
	
	private DefaultPivotTable parentPivotTable;
	
	private DataSelectionItem<E, R> rowDataSelectionItem;
	
	private Map<PivotDimensions<E, C>, PivotTableCell> subTotal;
	
	private Collection<E> nonControlOnlyMembers;
	
	private int maxPivotRowSize;
	
	private DefaultPivotTableDataColumnComparator<E> columnComparator;
	
	public DefaultPivotTable(Map<DataSelectionItem<E, ?>, Aggregator> aggregators, DefaultPivotTable parentPivotTable, DataSelectionItem<E, R> rowDataSelectionItem, int maxRowSize) {
		this.aggregators = aggregators;
		this.parentPivotTable = parentPivotTable;
		this.rowDataSelectionItem = rowDataSelectionItem;
		maxPivotRowSize = maxRowSize;
	}

	public DefaultPivotTable(Map<DataSelectionItem<E, ?>, Aggregator> aggregators, DefaultPivotTable parentPivotTable, DataSelectionItem<E, R> rowDataSelectionItem, int totalDataRows, int maxRowSize) {
		this.aggregators = aggregators;
		this.parentPivotTable = parentPivotTable;
		this.rowDataSelectionItem = rowDataSelectionItem;
		this.totalDataRows = totalDataRows;
		maxPivotRowSize = maxRowSize;
	}
	
	@Override
	public <CR, CC> PivotTable<E, CR, CC> getChildTable(PivotDimensions<E, CR> rowDimensions, PivotDimensions<E, CC> columnDimensions) {

		PivotTable pivotTable = this;
		for(PivotDimension rowDimension : rowDimensions.getPivotDimensions()) {
			if(pivotTable != null)
				pivotTable = ((DefaultPivotTable)pivotTable).getChildTable(rowDimension);
			else
				return null;
		}
		
		return getChildTableForColumnDims(pivotTable, columnDimensions);
	}
	
	private <CR, CC> PivotTable<E, CR, CC> getChildTableForColumnDims(PivotTable pivotTable, PivotDimensions<E, CC> columnDimensions) {
		if(pivotTable == null) return null;
		if(AllPivotDimensions.getInstance().equals(columnDimensions)) return pivotTable;
		
		DefaultPivotTable childTable = new DefaultPivotTable(
				((DefaultPivotTable) pivotTable).getAggregators(),
				((DefaultPivotTable) pivotTable).getParentPivotTable(),
				((DefaultPivotTable) pivotTable).getRowDataSelectionItem(),
				((DefaultPivotTable) pivotTable).getTotalDataRows(),
				this.maxPivotRowSize);

		if(pivotTable.hasChildTables()) {
			Collection<Entry<?, DefaultPivotTable<E, ?, ?>>> _childPivotTables = ((DefaultPivotTable)pivotTable).getChildPivotTables().getEntryList();
			for(Entry<?, DefaultPivotTable<E, ?, ?>> pair : _childPivotTables) {
				childTable.addChildTable(pair.getKey(), getChildTableForColumnDims(pair.getValue(), columnDimensions));
			}
		} else if(((DefaultPivotTable) pivotTable).getDataTable() != null) {
			PivotTableChildTree<?, PivotTableChildTree<PivotDimensions<E, ?>, PivotTableCell>> _dataTable = ((DefaultPivotTable) pivotTable).getDataTable();
			PivotTableChildTree dataTableCopy = new PivotTableChildTree();
			for(Entry<?, PivotTableChildTree<PivotDimensions<E, ?>, PivotTableCell>> pair : _dataTable.getEntryList()) {
				Map<PivotDimensions<E, ?>, PivotTableCell> tableCellCopy = getTableCellCopy(columnDimensions, pair);
				
				dataTableCopy.put(pair.getKey(), tableCellCopy);
			}
			childTable.setDataTable(dataTableCopy);
		}
		
		return childTable;
	}

	private <CC> Map<PivotDimensions<E, ?>, PivotTableCell> getTableCellCopy(PivotDimensions<E, CC> columnDimensions,
			Entry<?, PivotTableChildTree<PivotDimensions<E, ?>, PivotTableCell>> pair) {
		Map<PivotDimensions<E, ?>, PivotTableCell> tableCellCopy = new PivotTableChildTree<>();
		for(Entry<PivotDimensions<E, ?>, PivotTableCell> entry : pair.getValue().getEntryList()) {
			if(isChildDimension(entry.getKey(), columnDimensions)) {
				PivotDimensions<E, ?> childColDimensions ;
				if (Objects.equal(columnDimensions, entry.getKey()))
					childColDimensions = entry.getKey();
				else {
					List<PivotDimension<E, ?>> dimensionValues = entry.getKey().getPivotDimensions().subList(columnDimensions.getPivotDimensions().size(), entry.getKey().getPivotDimensions().size());				
					childColDimensions = (PivotDimensions<E, ?>)(PivotDimensions)PivotDimensionsFactory.getPivotDimensions((List)dimensionValues);
				}
					//TODO: Check if need to fix the start/end index above
				
				tableCellCopy.put(childColDimensions, entry.getValue());
			}
		}
		return tableCellCopy;
	}

	public PivotTable getChildTable(PivotDimension<?, ?> rowDimension) {
		if(dataTable != null) {
			if (dataTable.containsKey(rowDimension.getDimensionValue())) {
				R rowValue = (R) rowDimension.getDimensionValue();
				DefaultPivotTable returnChildTable = new DefaultPivotTable<>(aggregators, getParentPivotTable(), rowDataSelectionItem, this.maxPivotRowSize);
				PivotTableChildTree<R, Map<PivotDimensions<E, C>, PivotTableCell>> childDataPairs = new PivotTableChildTree();
				childDataPairs.put(rowValue, dataTable.get(rowValue));
				returnChildTable.setDataTable(childDataPairs);
				return returnChildTable;
			}
		} else if(childPivotTables != null && childPivotTables.containsKey(rowDimension.getDimensionValue())) {
			R rowValue = (R) rowDimension.getDimensionValue();
			return childPivotTables.get(rowValue);
		}

		return null;
	}
	
	@Override
	public Boolean hasChildTables() {
		return childPivotTables != null ? true : false;
	}
	
	public <CR,CC> DefaultPivotTable<E, CR, CC> addChildPivotTable(R rowValue, DataSelectionItem<E, R> childRowDsi) {
		if(childPivotTables == null) childPivotTables = new PivotTableChildTree();

		
		DefaultPivotTable<E,CR,CC> childTable = (DefaultPivotTable<E, CR, CC>) childPivotTables.get(rowValue);
		if(childTable != null)
			return childTable;
		
		DefaultPivotTable<E, ?, ?> childPivotTable = new DefaultPivotTable<>(aggregators, this, childRowDsi, this.maxPivotRowSize);
		childPivotTables.put(rowValue, childPivotTable);
		
		return (DefaultPivotTable<E, CR, CC>) childPivotTable;
	}
	
	
	
	public void addDataRow(R rowHeader, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell> cellMap) {
		if(dataTable == null) dataTable = new PivotTableChildTree();
		dataTable.put(rowHeader, cellMap);
		incrementDataRowsCount();
	}

	public void addDataRow(R rowHeader, PivotDimensions<E, C> columnDimensions, PivotTableCell cell) {
		if(dataTable == null) dataTable = new PivotTableChildTree();
		
		Map<PivotDimensions<E, C>, PivotTableCell> existingColDimMap = dataTable.get(rowHeader);
		if(existingColDimMap != null) {
			existingColDimMap.put(columnDimensions, cell);
			return;
		}
		
		PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell> colDimMap = new PivotTableChildTree<>();
		colDimMap.put(columnDimensions, cell);
		dataTable.put(rowHeader, colDimMap);
		incrementDataRowsCount();
	}

	public void incrementDataRowsCount() {
		totalDataRows++;
		if(totalDataRows > maxPivotRowSize)
			throw new PivotTableSizeExceedException("Number of rows exceed the specified limit of ", maxPivotRowSize, totalDataRows, "row");
		
		if(parentPivotTable != null) 
			parentPivotTable.incrementDataRowsCount();
	}
	
	public int getTotalDataRowsCount() {
		return totalDataRows;
	}
	
	@Override
	public Set<R> getRowHeaders() {
		Set<R> rowHeaders = new LinkedHashSet<>();
		if(childPivotTables != null) {
			rowHeaders.addAll(childPivotTables.keySet());
		} else if(dataTable != null) {
			rowHeaders.addAll(dataTable.keySet());
		}
		return rowHeaders;
	}

	@Override
	public Set<C> getColumnHeaders() {
		Set<C> colHeaders = new LinkedHashSet<>();
		if(childPivotTables != null) {
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : childPivotTables.getEntryList()) {
				Set<?> childColumnHeaders = pair.getValue().getColumnHeaders();
				for(Object childColHeader : childColumnHeaders) 
					colHeaders.add((C) childColHeader);
			}
		} else if(dataTable != null) {
			addColumnHeaders(colHeaders);
		}
		return colHeaders;
	}

	private void addColumnHeaders(Set<C> colHeaders) {
		for(Entry<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> pair : dataTable.getEntryList()){
			for(Entry<PivotDimensions<E, C>, PivotTableCell> pd : pair.getValue().getEntryList()) {
				if (pd.getKey() != null) {
					colHeaders.add((C)pd.getKey().getPivotDimensions().get(0).getDimensionValue());
				}
			}
		}
	}

	@Override
	public PivotTableCellValue getRowSummary(C columnHeader) {
		if (columnHeader != null && columnHeader.equals(AllPivotDimensions.getInstance().getPivotDimensionsString())) {
			return getGrandSummary();
		}
		List<PivotTableCell> cells = new ArrayList<>();
		for(Entry<PivotDimensions<E, C>, PivotTableCell> entry : getSubTotal().entrySet()) {
			boolean include = false;
			if(columnHeader instanceof PivotDimensions) {
				if(isChildDimension(entry.getKey(), (PivotDimensions)columnHeader))
					include = true;
			} else {
				if(Objects.equal(entry.getKey().getPivotDimensionValues().get(0), columnHeader))
					include = true;
			}
			if(include) cells.add(entry.getValue());
		}
		
		PivotTableCell pivotTableCell = mergePivotCells(cells);
		aggregatePivotCell(pivotTableCell);
		Map<DataSelectionItem<?, ?>, Object> rowSummary = (Map<DataSelectionItem<?, ?>, Object>)(Map<?,?>)pivotTableCell.getValueMap();
		
		return new DefaultPivotTableCellValue(pivotTableCell);
	}

	@Override
	public PivotTableCellValue getColumnSummary(R rowHeader) {
		if(dataTable != null) {
			if (dataTable.containsKey(rowHeader)) {
				List<PivotTableCell> cells = new ArrayList<>();
				cells.addAll(dataTable.get(rowHeader).values());
				PivotTableCell pivotTableCell = mergePivotCells(cells);
				aggregatePivotCell(pivotTableCell);
				return new DefaultPivotTableCellValue(pivotTableCell);
			}
		} else if (childPivotTables != null && childPivotTables.containsKey(rowHeader)) {
			return childPivotTables.get(rowHeader).getGrandSummary();
		}
		return new DefaultPivotTableCellValue(Collections.<DataSelectionItem<?, ?>, Object>emptyMap());
	}
	
	private PivotTableCell mergePivotCells(List<PivotTableCell> cells) {
		PivotTableCell pivotTableCell = new PivotTableCell(aggregators.size());
		for (PivotTableCell cell : cells) {
			pivotTableCell.addMembers(cell.getMembers());
			pivotTableCell.addNonControlMembers(cell.getNonControlMembers());
		}
		return pivotTableCell;
	}
	
	private void aggregatePivotCell(PivotTableCell pivotTableCell) {
		Map<DataSelectionItem, Object> valueMap = new HashMap<>();
		Map<DataSelectionItem<E, ?>, CompareResult> compareResult = new HashMap<>();
		for(Entry<DataSelectionItem<E, ?>, Aggregator> entry : aggregators.entrySet()) {
			DataSelectionItem<E,?> dsi = entry.getKey();
			Aggregator aggregator = entry.getValue();
			Object aggregateValue = aggregator.aggregate(pivotTableCell.getMembers());
			
			valueMap.put(dsi, aggregateValue);
			if (dsi.getCompareMeasure() != null && pivotTableCell.getNonControlMembers() != null) {
				Object controlAggregateValue = aggregateValue;
				Object nonControlAggregateValue = aggregator.aggregate(pivotTableCell.getNonControlMembers());
				if (aggregator instanceof AggregateOnPath) {
					Evaluator resultTransform = ((AggregateOnPath)aggregator).getDsi().getSelectedAggregateMeasure().getResultTransform();
					controlAggregateValue = resultTransform.apply(controlAggregateValue);
					nonControlAggregateValue = resultTransform.apply(nonControlAggregateValue);
				}
				
				CompareResult variance = new DefaultCompareResult(controlAggregateValue, nonControlAggregateValue, false);
				compareResult.put(dsi, variance);
			}
		}
		pivotTableCell.setValueMap(valueMap);
		pivotTableCell.setCompareResult(compareResult);
	}
	
	
	@Override
	public PivotTableCellValue getGrandSummary() {
		List<PivotTableCell> allCells = new ArrayList<>();
		Map<DataSelectionItem<?, ?>, Object> grandSummary = new HashMap<>();
		Collection<PivotTableCell> values = getSubTotal().values();
		if(values.isEmpty())
			return new DefaultPivotTableCellValue(grandSummary);
		allCells.addAll(values);

		PivotTableCell pivotTableCell = mergePivotCells(allCells);
		if (this.getNonControlOnlyMembers() != null)
			pivotTableCell.addNonControlMembers(this.getNonControlOnlyMembers());
		aggregatePivotCell(pivotTableCell);
		grandSummary = (Map<DataSelectionItem<?, ?>, Object>)(Map<?,?>)pivotTableCell.getValueMap();
		return new DefaultPivotTableCellValue(pivotTableCell);
	}
	
	@Override
	public void paginate(int pageSize, int pageIndex) {
		int startIndex;
		int endIndex;
		
		if(pageSize < Integer.MAX_VALUE) {
			startIndex = pageIndex * pageSize;
			if(startIndex >= this.getTotalDataRowsCount()) startIndex = this.getTotalDataRowsCount() - pageSize;
			if(startIndex < 0) startIndex = 0;
			
			endIndex = startIndex + pageSize - 1;
			if(endIndex > this.getTotalDataRowsCount()) endIndex = this.getTotalDataRowsCount() - 1;
		} else {
			startIndex = 0;
			endIndex = this.getTotalDataRowsCount() - 1;
		}
		
		doPaginate(startIndex, endIndex);
		this.subTotal = null;
	}

	//paginate [startIndex, endIndex] (inclusive) data in the cellSet().
	private void doPaginate(int startIndex, int endIndex) {
		if (this.hasChildTables()) {
			doPaginateChildTables(this.getChildPivotTables(), startIndex, endIndex);
		} else if (this.getDataTable() != null){
			int size  = this.getTotalDataRowsCount();
			startIndex = validateIndex(startIndex, size);
			endIndex = validateIndex(endIndex, size);
			this.getDataTable().paginate(startIndex, endIndex+1);
		}
	}

	private int validateIndex(int index, int size) {
		if (index < 0) {
			index = 0;
		} else if (index > size -1 ) {
			index = size - 1;
		}
		return index;
	}
	
	private void doPaginateChildTables(PivotTableChildTree<R, DefaultPivotTable<E, Object, Object>> pivotTableChildTree, int startIndex, int endIndex) {
		int sublistStart = 0, sublistEnd = 0;
		int runningCountForStart = 0, runningCountForEnd = 0;
		boolean sublistStartFound = false, sublistEndFound = false;
		
		int i = -1;
		for(PivotTableChildTree.Entry<R, DefaultPivotTable<E, Object, Object>> pair : pivotTableChildTree.getEntryList()) {
			i++;
			if(sublistStartFound && sublistEndFound) break;

			if(!sublistStartFound) {
				if(startIndex >= runningCountForStart && startIndex < (runningCountForStart + pair.getValue().getTotalDataRowsCount())) { 
					sublistStart = i;
					sublistStartFound = true;
				} else {
					runningCountForStart = runningCountForStart + pair.getValue().getTotalDataRowsCount();
				}
			}
			
			if(!sublistEndFound) {
				if((endIndex+1) > runningCountForEnd && (endIndex+1) <= (runningCountForEnd + pair.getValue().getTotalDataRowsCount())) {
					sublistEnd = i;
					sublistEndFound = true;
				} else { 
					runningCountForEnd = runningCountForEnd + pair.getValue().getTotalDataRowsCount();
				}
			}
		}
		if(!sublistStartFound) sublistStart = 0;
		if(!sublistEndFound) sublistEnd = pivotTableChildTree.size()-1;
		
		pivotTableChildTree.paginate(sublistStart, sublistEnd+1);
		
		int newStart = sublistStart == 0 ? startIndex : startIndex - runningCountForStart;
		int newEnd   = sublistStart == 0 ? endIndex   : endIndex - runningCountForStart;

		processChildTables(pivotTableChildTree, newStart, newEnd);
		
	}
	
	private void processChildTables(PivotTableChildTree<R, DefaultPivotTable<E, Object, Object>> pivotTableChildTree, int newStart, int newEnd) {
		int runningCount = 0;
		for(Entry<R, DefaultPivotTable<E, Object, Object>> pair : pivotTableChildTree.getEntryList()) {
			DefaultPivotTable childTable = pair.getValue();
			int totalDataRowsCount = childTable.getTotalDataRowsCount();
			int start = newStart + 1 > runningCount ? newStart : 0;
			int end = runningCount + totalDataRowsCount <= (newEnd+1) ? totalDataRowsCount - 1 : newEnd-runningCount;
			childTable.doPaginate(start, end);
			runningCount += totalDataRowsCount;
		}
		
	}

	@Override
	@InfraInvocation
	public Set<Cell<PivotDimensions<E, R>, PivotDimensions<E, C>, PivotTableCellValue>> cellSet() {
		return generateCellSet(this, null);
	}

	private Set<Cell<PivotDimensions<E, R>, PivotDimensions<E, C>, PivotTableCellValue>>  generateCellSet(DefaultPivotTable pivotTable, PivotDimensions<E, R> startingPivotDimensions) {
		Set<Cell<PivotDimensions<E, R>, PivotDimensions<E, C>, PivotTableCellValue>>  cellSet = new LinkedHashSet<>();
		if(pivotTable.getDataTable() != null) {
			PivotTableChildTree<?, PivotTableChildTree<PivotDimensions<E, ?>, PivotTableCell>> _dataTable = pivotTable.getDataTable();
			for(Entry<?, PivotTableChildTree<PivotDimensions<E, ?>, PivotTableCell>> pair : _dataTable.getEntryList()) {
				PivotDimensions<E, R> rowDimensions = appendPivotDimensions(startingPivotDimensions, (R) pair.getKey(), pivotTable.getRowDataSelectionItem());
				for(Entry<PivotDimensions<E, ?>, PivotTableCell> entry : pair.getValue().getEntryList()) {
					cellSet.add((Cell)Tables.immutableCell(rowDimensions, entry.getKey(), new DefaultPivotTableCellValue(entry.getValue())));
				}
			}
			return cellSet;
		} else if(pivotTable.getChildPivotTables() != null) {
			PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> childTables = pivotTable.getChildPivotTables();
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : childTables.getEntryList()) {
				cellSet.addAll(generateCellSet(pair.getValue(), appendPivotDimensions(startingPivotDimensions, pair.getKey(), pivotTable.getRowDataSelectionItem())));
			}
		}
		
		return cellSet;
	}
	
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<PivotDimensions<E, R>, PivotTableCellValue> column(PivotDimensions<E, C> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<PivotDimensions<E, C>> columnKeySet() {
		Set<PivotDimensions<E, C>> columnKeys = generateColumnKeySet(this);
		sortKeySet(columnKeys);
		return columnKeys;
	}
	
	private Set<PivotDimensions<E, C>> generateColumnKeySet(DefaultPivotTable pivotTable) {
		Set<PivotDimensions<E, C>> columnKeys = new LinkedHashSet<>();
		if(pivotTable.getDataTable() != null) {
			PivotTableChildTree<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> _dataTable = pivotTable.getDataTable();
			for(Entry<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> pair : _dataTable.getEntryList()) {
				for (Entry<PivotDimensions<E, C>, PivotTableCell> columns : pair.getValue().getEntryList()) {
					columnKeys.add(columns.getKey());
				}
			}
			return columnKeys;
		} else if(pivotTable.getChildPivotTables() != null) {
			PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> _childPivotTables = pivotTable.getChildPivotTables();
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : _childPivotTables.getEntryList()) {
				columnKeys.addAll(generateColumnKeySet(pair.getValue()));
			}
		}
		
		return columnKeys;
	}

	private void sortKeySet(Set<PivotDimensions<E, C>> columnKeys) {
		if (this.getColumnComparator() != null) {
			List<PivotDimensions<E, C>> keys = new ArrayList<>(columnKeys);
			Function<PivotDimensions, Entry<PivotDimensions, PivotTableCell>> keyToEntryFunction = new Function<PivotDimensions, Entry<PivotDimensions, PivotTableCell>>(){
				@Override
				public Entry<PivotDimensions, PivotTableCell> apply(
						PivotDimensions input) {
					return new com.citi.risk.core.data.pivot.impl.PivotTableChildTree.Entry(input, null);
				}
			};
			List<Entry<PivotDimensions, PivotTableCell>> columns = new ArrayList(Lists.transform(keys, keyToEntryFunction));
			Collections.sort(columns, this.getColumnComparator());
			columnKeys.clear();
			for (Entry<PivotDimensions, PivotTableCell> entry : columns) {
				columnKeys.add(entry.getKey());
			}
		}
	}

	@Override
	public Map<PivotDimensions<E, C>, Map<PivotDimensions<E, R>, PivotTableCellValue>> columnMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsColumn(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsRow(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsValue(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PivotTableCellValue get(Object rowDimensions, Object columnDimensions) {
		List<PivotDimension> rowPivotDimensions = ((PivotDimensions)rowDimensions).getPivotDimensions();
		if(dataTable != null) {
			return getCell(columnDimensions, rowPivotDimensions);
		} else if(childPivotTables != null) {
			PivotTable childTable = getChildTable(rowPivotDimensions.get(0));
			if(childTable == null) return null;
			
			PivotDimension[] childRowDimensions = new PivotDimension[rowPivotDimensions.size()-1];
			for(int i=0; i < rowPivotDimensions.size()-1; i++)
				childRowDimensions[i] = rowPivotDimensions.get(i+1);
			return ((DefaultPivotTable)childTable).get(new DefaultPivotDimensions<>(childRowDimensions), columnDimensions);
		}
		return null;
	}

	private PivotTableCellValue getCell(Object columnDimensions, List<PivotDimension> rowPivotDimensions) {
		if(rowPivotDimensions.size() > 1) return null;
		if (dataTable.containsKey(rowPivotDimensions.get(0).getDimensionValue())) {
			R rowValue = (R) rowPivotDimensions.get(0).getDimensionValue();
			if(!dataTable.get(rowValue).containsKey(columnDimensions)) return null;
			return new DefaultPivotTableCellValue(dataTable.get(rowValue).get(columnDimensions));
		}
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PivotTableCellValue put(PivotDimensions<E, R> arg0, PivotDimensions<E, C> arg1, PivotTableCellValue arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void putAll(
			Table<? extends PivotDimensions<E, R>, ? extends PivotDimensions<E, C>, ? extends PivotTableCellValue> table) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PivotTableCellValue remove(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<PivotDimensions<E, C>, PivotTableCellValue> row(PivotDimensions<E, R> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<PivotDimensions<E, R>> rowKeySet() {
		return generateRowKeySet(this, null, false);
	}

	@Override
	public Set<PivotDimensions<E, R>> rowKeySetWithSubtotalKey() {
		return generateRowKeySet(this, null, true);
	}
	
	private Set<PivotDimensions<E, R>> generateRowKeySet(DefaultPivotTable pivotTable, PivotDimensions<E, R> startingPivotDimensions, boolean genSubtotalKey) {
		if(pivotTable.getRowDataSelectionItem() == null) return Collections.emptySet();
		
		Set<PivotDimensions<E, R>> rowKeySet = new LinkedHashSet<>();
		if(pivotTable.getDataTable() != null) {
			PivotTableChildTree<?, Map<PivotDimensions<E, ?>, PivotTableCell>> _dataTable = pivotTable.getDataTable();
			for(Entry<?, Map<PivotDimensions<E, ?>, PivotTableCell>> pair : _dataTable.getEntryList()) 
				rowKeySet.add(appendPivotDimensions(startingPivotDimensions, (R) pair.getKey(), pivotTable.getRowDataSelectionItem()));
			return rowKeySet;
		} else if(pivotTable.getChildPivotTables() != null) {
			PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> childTables = pivotTable.getChildPivotTables();
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : childTables.getEntryList()) {
				PivotDimensions<E, R> childStartingPivotDimensions = appendPivotDimensions(startingPivotDimensions, pair.getKey(), pivotTable.getRowDataSelectionItem());
				if(genSubtotalKey) {
					rowKeySet.add(childStartingPivotDimensions);
				}
				rowKeySet.addAll(generateRowKeySet(pair.getValue(), childStartingPivotDimensions, genSubtotalKey));
			}
		}
		
		return rowKeySet;
	}
	
	

	@Override
	public Map<PivotDimensions<E, R>, Map<PivotDimensions<E, C>, PivotTableCellValue>> rowMap() {
		return getRowMap(this, null);
	}

	private Map<PivotDimensions<E, R>, Map<PivotDimensions<E, C>, PivotTableCellValue>> getRowMap(DefaultPivotTable pivotTable, PivotDimensions<E, R> startingRowDimensions) {
		Map<PivotDimensions<E, R>, Map<PivotDimensions<E, C>, PivotTableCellValue>> map = new LinkedHashMap<>();
		if(pivotTable.getDataTable() != null) {
			PivotTableChildTree<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> dataList = pivotTable.getDataTable();
			for(Entry<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> pair : dataList.getEntryList()) {
				PivotTableChildTree<PivotDimensions<E, C>, PivotTableCellValue> colMap = new PivotTableChildTree<>();
				for(Entry<PivotDimensions<E, C>, PivotTableCell> entry : pair.getValue().getEntryList()) 
					colMap.put(entry.getKey(), new DefaultPivotTableCellValue(entry.getValue()));
				
				map.put(appendPivotDimensions(startingRowDimensions, pair.getKey(), pivotTable.getRowDataSelectionItem()), colMap);
			}
		} else if(pivotTable.getChildPivotTables() != null) {
			PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> childTables = pivotTable.getChildPivotTables();
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : childTables.getEntryList()) {
				map.putAll(getRowMap(pair.getValue(), appendPivotDimensions(startingRowDimensions, pair.getKey(), pivotTable.getRowDataSelectionItem())));
			}
		}
		
		return map;
	}

 	private PivotDimensions<E, R> appendPivotDimensions(PivotDimensions<E, R> startingDim, R childDim, DataSelectionItem<E, R> rowDsi) {
		List<PivotDimension<E, ?>> dimensions = new ArrayList<>();
		if(startingDim != null) {
			dimensions.addAll(startingDim.getPivotDimensions());
		}
 		DefaultPivotDimension newDim = new DefaultPivotDimension(childDim, rowDsi.getUnderlyingPath());
 		dimensions.add(newDim);

 		return new DefaultPivotDimensions(dimensions.toArray(new PivotDimension[dimensions.size()]));
 	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Collection<PivotTableCellValue> values() {
		// TODO Auto-generated method stub
		return Collections.emptyList();
	}

	public <CR, CC>PivotTableChildTree<R, DefaultPivotTable<E, CR, CC>> getChildPivotTables() {
		return (PivotTableChildTree<R, DefaultPivotTable<E, CR, CC>>)(PivotTableChildTree)childPivotTables;
	}

	public void setChildPivotTables(PivotTableChildTree<R, DefaultPivotTable<E, ?, ?>> childPivotTables) {
		this.childPivotTables = childPivotTables;
	}

	public PivotTableChildTree<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> getDataTable() {
		return dataTable;
	}

	public void setDataTable(PivotTableChildTree<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> dataTable) {
		this.dataTable = dataTable;
	}

	public <V> Map<DataSelectionItem<E, V>, Aggregator> getAggregators() {
		return (Map<DataSelectionItem<E, V>, Aggregator>)(Map)aggregators;
	}

	public int getTotalDataRows() {
		return totalDataRows;
	}

	public DefaultPivotTable getParentPivotTable() {
		return parentPivotTable;
	}

	public void setParentPivotTable(DefaultPivotTable parentPivotTable) {
		this.parentPivotTable = parentPivotTable;
	}

	public DataSelectionItem<E, R> getRowDataSelectionItem() {
		return rowDataSelectionItem;
	}

	public void setRowDataSelectionItem(DataSelectionItem<E, R> rowDataSelectionItem) {
		this.rowDataSelectionItem = rowDataSelectionItem;
	}

	public <CR, CC> PivotTable<E, CR, CC> addChildTable(R row, PivotTable<E, ?, ?> childTable) {
		if(childPivotTables == null) childPivotTables = new PivotTableChildTree();
		
		if (childPivotTables.containsKey(row)) {
			return (PivotTable<E, CR, CC>) childPivotTables.get(row);
		}
		
		childPivotTables.put(row, (DefaultPivotTable<E, ?, ?>) childTable);
		
		return (PivotTable<E, CR, CC>) childTable;
	}

	private boolean isChildDimension(PivotDimensions<E, ?> parentDimensions, PivotDimensions<E, ?> childDimensions) {
		if(childDimensions == AllPivotDimensions.getInstance()) return true;
		if(!parentDimensions.getPivotDimensions().isEmpty()
				&& !childDimensions.getPivotDimensions().isEmpty()
				&& parentDimensions.getPivotDimensions().size() >= childDimensions.getPivotDimensions().size()) {
			for(int i = 0; i < childDimensions.getPivotDimensions().size(); i++) 
				if(!Objects.equal(parentDimensions.getPivotDimensions().get(i).toString(), childDimensions.getPivotDimensions().get(i).toString()))
					return false;
			return true;
		}
		
		return false;
	}
	
	public Map<PivotDimensions<E, C>, PivotTableCell> getSubTotal() {
		if(subTotal != null) return subTotal;
		
		subTotal = new HashMap<>();
		
		if(dataTable != null) {
			return getSubTotalForDataTable();
		} else if(childPivotTables != null) {
			Map<PivotDimensions<E, C>, List<PivotTableCell>> subTotalColl = new HashMap<>();
			for(Entry<R, DefaultPivotTable<E, ?, ?>> pair : childPivotTables.getEntryList()) {
				Map<PivotDimensions, PivotTableCell> pairSubTotal = (Map)pair.getValue().getSubTotal();
				for(Entry<PivotDimensions, PivotTableCell> entry : pairSubTotal.entrySet()) {
					addCellToSubTotalColl(subTotalColl, entry);
				}
			}
			for(Entry<PivotDimensions<E, C>, List<PivotTableCell>> entry : subTotalColl.entrySet()) {
				subTotal.put(entry.getKey(), mergePivotCells(entry.getValue()));
			}
		}
		
		
		return subTotal;
		
	}
	
	private void addCellToSubTotalColl(Map<PivotDimensions<E, C>, List<PivotTableCell>> subTotalColl,
			Entry<PivotDimensions, PivotTableCell> entry) {
		List<PivotTableCell> cells = subTotalColl.get(entry.getKey());
		if(cells == null) {
			cells = new ArrayList<>();
			subTotalColl.put(entry.getKey(), cells);
		}
		cells.add(entry.getValue());
	}

	private Map<PivotDimensions<E, C>, PivotTableCell> getSubTotalForDataTable() {
		Map<PivotDimensions<E, C>, List<PivotTableCell>> subTotalColl = new HashMap<>();
		for(Entry<R, PivotTableChildTree<PivotDimensions<E, C>, PivotTableCell>> pair : dataTable.getEntryList()) {
			for(Entry<PivotDimensions<E, C>, PivotTableCell> entry : pair.getValue().getEntryList()) {
				List<PivotTableCell> cells = subTotalColl.get(entry.getKey());
				if(cells == null) {
					cells = new ArrayList<>();
					subTotalColl.put(entry.getKey(), cells);
				}
				cells.add(entry.getValue());
			}
		}

		for(Entry<PivotDimensions<E, C>, List<PivotTableCell>> entry : subTotalColl.entrySet()) {
			subTotal.put(entry.getKey(), mergePivotCells(entry.getValue()));
		}
		
		return subTotal;
	}
	
	@Override
	public DataSelectionItem<E, R> getTopLevelRowDsi() {
		return rowDataSelectionItem;
	}

	@Override
	public DataSelectionItem<E, C> getTopLevelColumnDsi() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<DataSelectionItem<E, ?>> getAggregateMeasureDSIs() {
		return aggregators.keySet();
	}
	
	public Collection<E> getNonControlOnlyMembers() {
		return this.nonControlOnlyMembers;
	}
	
	public void setNonControlOnlyMembers(Collection<E> nonControlOnlyMembers) {
		this.nonControlOnlyMembers = nonControlOnlyMembers;
	}
	
	public void setColumnComparator(DefaultPivotTableDataColumnComparator<E> columnComparator) {
		this.columnComparator = columnComparator;
	}
	
	public DefaultPivotTableDataColumnComparator<E> getColumnComparator() {
		return this.columnComparator;
	}
}
