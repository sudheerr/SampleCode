package com.citi.risk.core.data.pivot.impl;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.data.query.api.TaskExecutionRuntimeException;
import com.citi.risk.core.data.query.impl.TaskTimeoutCancelationException;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.aggregate.Aggregator;
import com.google.common.collect.Iterables;

public class PivotCubeAggregationTask<E> extends RecursiveTask<Map<PivotDimensionGroup<E>, Collection<E>>> implements ManagedExecution  {

	private static final long serialVersionUID = 3598707457174112559L;

	private Map<PivotDimensionGroup<E>, Collection<E>> dimensionGroupMap;
	
	private Map<DataSelectionItem<E, ?>, Aggregator<E, ?>> aggregators;
	
	private Collection<PivotDimensionGroup<E>> dimensionGroups;
	
	private final int partitionSize;

	private final int timeout;

	private final Stack<PivotCubeAggregationTask<E>> tasks = new Stack<>();

	public PivotCubeAggregationTask(
			Map<PivotDimensionGroup<E>, Collection<E>> dimensionGroupMap,
			Map<DataSelectionItem<E, ?>, Aggregator<E, ?>> aggregators,
			Collection<PivotDimensionGroup<E>> dimensionGroups, int partitionSize, final int timeout) {
		this.dimensionGroupMap = dimensionGroupMap;
		this.aggregators = aggregators;
		this.dimensionGroups = dimensionGroups;
		this.partitionSize = partitionSize;
		this.timeout = timeout;
	}
	
	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		while (!tasks.isEmpty()) {
			tasks.pop().cancel(true);
		}
		return super.cancel(mayInterruptIfRunning);
	}

	@Override
	protected Map<PivotDimensionGroup<E>, Collection<E>> compute() {
		if (dimensionGroups == null || dimensionGroups.isEmpty() || aggregators == null || aggregators.isEmpty()) return new HashMap<>(1);
		if (dimensionGroups.size() <= partitionSize) return aggregate();

		Iterable<List<PivotDimensionGroup<E>>> partitionedDimensionGroups = Iterables.partition(dimensionGroups, partitionSize);
		final Collection<PivotCubeAggregationTask<E>> partitionedPivotCubeAggregationTasks = new ArrayList<>(dimensionGroups.size()/partitionSize);
		for (final List<PivotDimensionGroup<E>> partitionedDimensionGroup : partitionedDimensionGroups) {
			PivotCubeAggregationTask<E> pivotCubeAggregationTask = (PivotCubeAggregationTask<E>) new PivotCubeAggregationTask<>(dimensionGroupMap, aggregators, partitionedDimensionGroup, partitionSize, this.timeout).fork();
			partitionedPivotCubeAggregationTasks.add(pivotCubeAggregationTask);
			tasks.push(pivotCubeAggregationTask);
		}
		for (final PivotCubeAggregationTask<E> partitionedPivotAggregationTask : partitionedPivotCubeAggregationTasks) {
			try {
				partitionedPivotAggregationTask.get(2 * this.timeout, TimeUnit.SECONDS);
			} catch (InterruptedException | TimeoutException e) {
				cancel(true);
				throw new TaskTimeoutCancelationException("PivotCubeAggregationTask canceled since timeout", e);
			} catch (ExecutionException e) {
				cancel(true);
				throw new TaskExecutionRuntimeException(e.getCause());
			}
		}
		return dimensionGroupMap;
	}

	private Map<PivotDimensionGroup<E>, Collection<E>> aggregate() {
		for(PivotDimensionGroup<E> dimensionGroup : dimensionGroups) {
			PivotTableCell pivotTableCell = new PivotTableCell(aggregators.size()); 
			for(Entry<DataSelectionItem<E, ?>, Aggregator<E, ?>> entry : aggregators.entrySet()) {
				DataSelectionItem<E, ?> pathKey = entry.getKey();
				Object aggregateVal = entry.getValue().aggregate(dimensionGroupMap.get(dimensionGroup));
				if(aggregateVal != null)
					pivotTableCell.addValue(pathKey, aggregateVal);
			}
			dimensionGroup.setPivotTableCell(pivotTableCell);
		}
		return dimensionGroupMap;
	}

	@Override
	public TaskType getType() {
		return TaskType.CoreParallel;
	}

	@Override
	public String getExecutionName() {
		return "PivotCubeAggregation Task";
	}

	@Override
	public String getExecutionParameters() {
		return null;
	}

	@Override
	public boolean isNewThread() {
		return true;
	}
}
