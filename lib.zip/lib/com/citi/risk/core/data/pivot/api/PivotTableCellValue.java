package com.citi.risk.core.data.pivot.api;

import java.util.Collection;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public interface PivotTableCellValue<E, V> {

	V getValue(DataSelectionItem<E, V> aggregateMeasureDsi);

	Boolean hasCompareResult();
	CompareResult<V> getVarianceResult(DataSelectionItem<E, V> compareMeasureDsi);
	
	Collection<E> getMembers();
	
	Collection<E> getNonControlMembers();
	
	boolean isEmpty();
	
}
