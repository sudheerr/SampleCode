package com.citi.risk.core.data.pivot.impl;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class DefaultPivotDimension<E, T> implements PivotDimension<E, T> {

	private T dimension;

	private DataPath<E, T> dataPath;
	
	private DataDomain<E> domain;
	
	private String dimensionString;

	public DefaultPivotDimension(T dimension, DataPath<E, T> dataPath) {
		this.dimension = dimension;
		this.dataPath = dataPath;
		this.dimensionString = (dimension == null) ? "" : dimension.toString();
	}

	public DefaultPivotDimension(DataDomain<E> domain, T dimension) {
		this.domain = domain;
		this.dimension = dimension;
		this.dimensionString = (dimension == null) ? "" : dimension.toString();
	}

	@Override
	public T getDimensionValue() {
		return dimension;
	}

	@Override
	@JsonIgnore
	public DataPath<E, T> getDimensionPath() {
		return dataPath;
	}

	public void setDimension(T dimension) {
		this.dimension = dimension;
		this.dimensionString = (dimension == null) ? "" : dimension.toString();
	}

	public void setDataPath(DataPath<E, T> dataPath) {
		this.dataPath = dataPath;
	}

	@Override
	public String toString() {
		return dimensionString;
	}
	
	public DataDomain<E> getDomain() {
		return domain;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DefaultPivotDimension other = (DefaultPivotDimension) obj;
		if (dataPath == null) {
			if (other.dataPath != null)
				return false;
		} else if (!dataPath.equals(other.dataPath))
			return false;
		if (dimension == null) {
			if (other.dimension != null)
				return false;
		} else if (!dimension.equals(other.dimension))
			return false;
		if (dimensionString == null) {
			if (other.dimensionString != null)
				return false;
		} else if (!dimensionString.equals(other.dimensionString))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dataPath == null) ? 0 : dataPath.hashCode());
		result = prime * result
				+ ((dimension == null) ? 0 : dimension.hashCode());
		result = prime * result
				+ ((dimensionString == null) ? 0 : dimensionString.hashCode());
		return result;
	}
}
