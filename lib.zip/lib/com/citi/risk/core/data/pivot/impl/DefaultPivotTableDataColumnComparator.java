package com.citi.risk.core.data.pivot.impl;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.SortBy;
import com.google.common.collect.Ordering;

public class DefaultPivotTableDataColumnComparator<E> implements Comparator<Entry<PivotDimensions, PivotTableCell>> {

	List<DataSelectionItem<E,?>> columnDimensions = null; 
	
	public DefaultPivotTableDataColumnComparator(List<DataSelectionItem<E, ?>> columnDimensions) {
		this.columnDimensions = columnDimensions;
	}
	
	@Override
	public int compare(Entry<PivotDimensions, PivotTableCell> t1, Entry<PivotDimensions, PivotTableCell> t2) {
		int compareValue = 0;
		PivotDimensions o1 = t1.getKey();
		PivotDimensions o2 = t2.getKey();
		
		if (o1 != null && o2 != null) {
			for (int i=0; i<columnDimensions.size(); i++) {
				DataSelectionItem dsi = columnDimensions.get(i);
				if (dsi != null && dsi.getSortBy()!=null) {
					compareValue = compareBasedOnColumnDsi(o1.getPivotDimensionValues().get(i), o2.getPivotDimensionValues().get(i), dsi.getSortBy());
					if (compareValue != 0) {
						return compareValue;
					}
				}
			}
		} 
		
		return compareValue;
	}

	private int compareBasedOnColumnDsi(Object o1DimensionValue, Object o2DimensionValue, SortBy sortBy) {
		int compareValue;
		
		if(o1DimensionValue != null && o2DimensionValue != null) {
			if (Comparable.class.isAssignableFrom(o1DimensionValue.getClass())) {
				compareValue = Ordering.natural().compare((Comparable) o1DimensionValue, (Comparable) o2DimensionValue);
			} else {
				compareValue = Ordering.natural().compare((String)o1DimensionValue, (String)o2DimensionValue);
			}
		} else if(o1DimensionValue == null) {
			compareValue = -1;
		} else {
			compareValue = 1;
		}

		if(sortBy.equals(SortBy.DESC))
			compareValue = -1 * compareValue;
		
		return compareValue;
	}
	
	public void sortDefaultPivotTableColumns(DefaultPivotTable pivotTable) {
		if (pivotTable.getDataTable() != null) {
			sortEachRowsColumn(pivotTable.getDataTable());
		}
	}
	
	private void sortEachRowsColumn(PivotTableChildTree<?, PivotTableChildTree<PivotDimensions, PivotTableCell>> dataTable) {
		for ( Entry<?, PivotTableChildTree<PivotDimensions, PivotTableCell>> tube : dataTable.getEntryList() ) {
			PivotTableChildTree<PivotDimensions, PivotTableCell> tubeValue = tube.getValue();
			tubeValue.sortAndPaginate(this, 0, tubeValue.getEntryList().size());
		}
	}

}
