package com.citi.risk.core.data.pivot.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.citi.risk.core.data.query.api.CompareResult;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class PivotTableCell<E> {

	private Map<DataSelectionItem, Object> valueMap;
	
	private Collection<E> members = new ArrayList<>();
	
	private Collection<E> nonControlMembers = new ArrayList<>();
	
	private Map<DataSelectionItem<E, ?>, CompareResult> comparedResult = new HashMap<>();
	
	public PivotTableCell(int cellSize) {
		valueMap = new HashMap<>(cellSize);
	}

	public Map<DataSelectionItem, Object> getValueMap() {
		return valueMap;
	}
	
	public Map<DataSelectionItem<E, ?>, CompareResult> getCompareResult() {
		return this.comparedResult;
	}
	
	public void setCompareResult(Map<DataSelectionItem<E, ?>, CompareResult> comparedResult) {
		this.comparedResult = comparedResult;
	}

	public void setValueMap(Map<DataSelectionItem, Object> valueMap) {
		this.valueMap = valueMap;
	}
	
	public void addValue(DataSelectionItem key, Object value) {
		valueMap.put(key, value == null ? 0 : value);
	}
	
	public Collection<E> getMembers() {
		return this.members;
	}
	
	public void addMembers(Collection<E> members) {
		this.members.addAll(members);
	}
	
	public void addNonControlMembers(Collection<E> nonControlMembers) {
		this.nonControlMembers.addAll(nonControlMembers);
	}
	
	public Collection<E> getNonControlMembers() {
		return this.nonControlMembers;
	}
	
}
