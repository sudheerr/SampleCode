package com.citi.risk.core.data.pivot.impl;

@SuppressWarnings("rawtypes")
public final class PivotTableSortGroup {

    private DefaultPivotTable pivotTable;
    private int startIndex;
    private int endIndex;

	public PivotTableSortGroup(DefaultPivotTable pivotTable, int startIndex, int endIndex) {
		this.pivotTable = pivotTable;
		this.startIndex = startIndex;
		this.endIndex = endIndex;
	}

	public DefaultPivotTable getPivotTable() {
		return pivotTable;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

}
