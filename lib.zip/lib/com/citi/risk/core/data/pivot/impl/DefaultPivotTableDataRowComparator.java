package com.citi.risk.core.data.pivot.impl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.SortBy;
import com.google.common.collect.Ordering;

@SuppressWarnings({ "rawtypes" })
public class DefaultPivotTableDataRowComparator<E, R, C> implements Comparator<Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>>> {

	DataSelectionItem dataSelectionItem = null;
	
	List<DataSelectionItem<E, ?>> aggregateMeasures = null;
	
	boolean sortByRowHeader;
	boolean sortByDSCOrder;
	
	public DefaultPivotTableDataRowComparator(DataSelectionItem dataSelectionItem, List<DataSelectionItem<E, ?>> aggregateMeasures) {
		this.dataSelectionItem = dataSelectionItem;
		this.aggregateMeasures = aggregateMeasures;
		if (dataSelectionItem != null ) {
			sortByRowHeader = dataSelectionItem.getSortBy() != null || CollectionUtils.isEmpty(aggregateMeasures);
			sortByDSCOrder = dataSelectionItem.getSortBy() != null && dataSelectionItem.getSortBy().equals(SortBy.DESC);
		}
	}

	@Override
	public int compare(Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o1, Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o2) {
		if(sortByRowHeader)
			return compareBasedOnRowdsi(o1, o2);
		else
			return 0;
	}



	private int compareBasedOnRowdsi(Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o1, Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o2) {
		int compareValue = 0;
		if(o1.getKey() != null && o2.getKey() != null) {
			if (Comparable.class.isAssignableFrom(o1.getKey().getClass())) {
				compareValue = Ordering.natural().compare((Comparable) o1.getKey(), (Comparable) o2.getKey());
			} else {
				compareValue = Ordering.natural().compare((String) o1.getKey(), (String) o2.getKey());
			}
		} else if(o1.getKey() == null) {
			compareValue = -1;
		} else if(o2.getKey() == null) {
			compareValue = 1;
		}

		if(sortByDSCOrder)
			compareValue = -1 * compareValue;
		
		return compareValue;
	}

}
