package com.citi.risk.core.data.pivot.api;

import com.citi.risk.core.dictionary.api.DataPath;

public interface PivotDimension<E, T> {

	T getDimensionValue();
	
	DataPath<E, T> getDimensionPath();
	
}
