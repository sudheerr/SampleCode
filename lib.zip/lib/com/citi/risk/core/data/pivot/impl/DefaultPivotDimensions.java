package com.citi.risk.core.data.pivot.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.citi.risk.core.data.pivot.api.PivotDimension;
import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.collection.list.Lists;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DefaultPivotDimensions<E, T> implements PivotDimensions<E, T>, Comparable<DefaultPivotDimensions<E, T>> {

	private PivotDimension<E, ?>[] pivotDimensions;
	
	private String stringValue;
	
	private int hashcode;

	private static DateFormat dateFormat = new SimpleDateFormat("MMM dd yyyy");
	
	public DefaultPivotDimensions(PivotDimension<E, ?>[] pivotDimensions) {
		this.pivotDimensions = pivotDimensions;
		this.stringValue = "";
		for(int i = 0; i < pivotDimensions.length; i++) {
			if(i != 0)
				this.stringValue = this.stringValue.concat(",");
			this.stringValue = this.stringValue.concat(pivotDimensions[i].toString());
		}
		this.hashcode = stringValue.hashCode();
	}

	public DefaultPivotDimensions(List<PivotDimension<E, ?>> pivotDimensions) {
		this.pivotDimensions = pivotDimensions.toArray(new PivotDimension[pivotDimensions.size()]);
		this.stringValue = "";
		for(int i = 0; i < pivotDimensions.size(); i++) {
			if(i != 0)
				this.stringValue = this.stringValue.concat(",");
			this.stringValue = this.stringValue.concat(pivotDimensions.get(i).toString());
		}
		this.hashcode = stringValue.hashCode();
	}

	@Override
	@JsonIgnore
	public List<PivotDimension<E, ?>> getPivotDimensions() {
		return Arrays.asList(pivotDimensions);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof DefaultPivotDimensions)) return false;

		DefaultPivotDimensions<E, ?> that = (DefaultPivotDimensions<E, ?>) o;

		return stringValue.equals(that.stringValue);

	}

	@Override
	public int hashCode() {
		return hashcode;
	}

	@Override
	public String toString() {
		return stringValue;
	}

	@Override
	@JsonIgnore
	public String getPivotDimensionsString() {
		return stringValue;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	@JsonIgnore
	public List<?> getPivotDimensionValues() {
		List dimensionValueList = new ArrayList();
		for(PivotDimension<E, ?> pd : pivotDimensions)
			dimensionValueList.add(pd.getDimensionValue());
		return dimensionValueList;
	}

	@JsonProperty(value = "pivotDimensionValues")
	public List<String> getPivotDimensionValuesForJson() {
		List<String> dimensionValueList = Lists.newArrayList();
		for(PivotDimension<E, ?> pd : pivotDimensions) {
			Object dimensionValue = pd.getDimensionValue();
			if (dimensionValue instanceof Date) {
				// Date format like Navigator
				Date date = (Date)dimensionValue;
				dimensionValueList.add(dateFormat.format(date));
			} else if (dimensionValue != null) {
				dimensionValueList.add(dimensionValue.toString());
			} else {
				dimensionValueList.add(null);
			}
		}
		return dimensionValueList;
	}

	@Override
	@JsonIgnore
	public PivotDimension<E, T> getTopLevelPivotDimension() {
		if(pivotDimensions != null && pivotDimensions.length > 0)
			return (PivotDimension<E, T>) pivotDimensions[0];
		
		return null;
	}

	@Override
	@JsonIgnore
	public DataPath<E, ?> getTerminatingPath() {
		if (pivotDimensions != null) {
			return pivotDimensions[pivotDimensions.length - 1].getDimensionPath();
		}
		return null;
	}

	@Override
	public int compareTo(DefaultPivotDimensions<E, T> other) {
		return this.stringValue.compareTo(other.stringValue);
	}

}
