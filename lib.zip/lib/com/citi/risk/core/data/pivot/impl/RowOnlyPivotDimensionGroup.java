package com.citi.risk.core.data.pivot.impl;

import java.util.Collections;
import java.util.List;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class RowOnlyPivotDimensionGroup<E> implements PivotDimensionGroup<E> {

	private final List<Object> rowDimensionValues;

	private PivotTableCell pivotTableCell;

	private final int hashCode;

	public RowOnlyPivotDimensionGroup(final List<Object> rowDimensionValues) {
		this.rowDimensionValues = rowDimensionValues;
		hashCode = (rowDimensionValues==null) ? 0 : rowDimensionValues.hashCode();
	}

	@Override
	public List<Object> getRowDimensionValues() {
		return rowDimensionValues;
	}

	@Override
	public List<Object> getColumnDimensionValues() {
		return Collections.emptyList();
	}
	
	@Override
	public int hashCode(){
		return hashCode;
	}
	
	@Override
	public boolean equals(Object other){
		if(other==null) return false;
		if(!(other instanceof RowOnlyPivotDimensionGroup)){
			return false;
		}
		
		RowOnlyPivotDimensionGroup that = (RowOnlyPivotDimensionGroup)other;
		if(this.rowDimensionValues == that.rowDimensionValues) return true;
		if(this.hashCode() != that.hashCode) return false;

		if(this.rowDimensionValues != null && that.rowDimensionValues != null)
			return this.rowDimensionValues.equals(that.rowDimensionValues);
		
		return false;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public PivotDataCubeKey getPivotDataCubeKey(List<DataSelectionItem<E, ?>> rowDataSelectionItems, List<DataSelectionItem<E, ?>> colDataSelectionItems) {
		return new PivotDataCubeKey(
				PivotDimensionsFactory.createPivotDimensions(rowDimensionValues, rowDataSelectionItems),
				AllPivotDimensions.getInstance());
	}

	@Override
	public void setPivotTableCell(PivotTableCell pivotTableCell) {
		this.pivotTableCell = pivotTableCell;
	}

	@Override
	public PivotTableCell getPivotTableCell() {
		return pivotTableCell;
	}

}
