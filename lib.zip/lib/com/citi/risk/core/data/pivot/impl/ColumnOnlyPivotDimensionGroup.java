package com.citi.risk.core.data.pivot.impl;

import java.util.Collections;
import java.util.List;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class ColumnOnlyPivotDimensionGroup<E> implements PivotDimensionGroup<E> {

	private final List<Object> colDimensionValues;
	
	private PivotTableCell pivotTableCell;

	private final int hashCode;

	public ColumnOnlyPivotDimensionGroup(List<Object> rowDimensionValues) {
		this.colDimensionValues = rowDimensionValues;
		hashCode = (rowDimensionValues==null) ? 0 : rowDimensionValues.hashCode();
	}

	@Override
	public PivotDataCubeKey getPivotDataCubeKey(List<DataSelectionItem<E, ?>> rowDataSelectionItems, List<DataSelectionItem<E, ?>> colDataSelectionItems) {
		return new PivotDataCubeKey(
				AllPivotDimensions.getInstance(),
				PivotDimensionsFactory.createPivotDimensions(colDimensionValues, colDataSelectionItems));
	}

	@Override
	public List<Object> getRowDimensionValues() {
		return Collections.emptyList();
	}

	@Override
	public List<Object> getColumnDimensionValues() {
		return colDimensionValues;
	}

	@Override
	public boolean equals(Object other){
		if(other==null) return false;
		if(!(other instanceof ColumnOnlyPivotDimensionGroup)){
			return false;
		}
		
		ColumnOnlyPivotDimensionGroup that = (ColumnOnlyPivotDimensionGroup)other;
		if(this.colDimensionValues == that.colDimensionValues) return true;
		if(this.hashCode() != that.hashCode) return false;

		if(this.colDimensionValues != null && that.colDimensionValues != null)
			return this.colDimensionValues.equals(that.colDimensionValues);
		
		return false;
	}

	@Override
	public int hashCode(){
		return hashCode;
	}

	@Override
	public void setPivotTableCell(PivotTableCell pivotTableCell) {
		this.pivotTableCell = pivotTableCell;
	}

	@Override
	public PivotTableCell getPivotTableCell() {
		return pivotTableCell;
	}

}

