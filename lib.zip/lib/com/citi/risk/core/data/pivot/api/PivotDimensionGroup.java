package com.citi.risk.core.data.pivot.api;

import java.util.List;

import com.citi.risk.core.data.pivot.impl.PivotDataCubeKey;
import com.citi.risk.core.data.pivot.impl.PivotTableCell;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public interface PivotDimensionGroup<E> {

	public PivotDataCubeKey getPivotDataCubeKey(List<DataSelectionItem<E, ?>> rowDataSelectionItems, List<DataSelectionItem<E, ?>> colDataSelectionItems);

	public List<Object> getRowDimensionValues();

	public List<Object> getColumnDimensionValues();
	
	public void setPivotTableCell(PivotTableCell pivotTableCell);

	public PivotTableCell getPivotTableCell();
}
