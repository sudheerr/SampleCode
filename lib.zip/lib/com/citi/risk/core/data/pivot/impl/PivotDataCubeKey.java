package com.citi.risk.core.data.pivot.impl;

import com.citi.risk.core.data.pivot.api.PivotDimensions;

public class PivotDataCubeKey<E> {

	private final PivotDimensions<E, ?> rowDimensions;
	
	private final PivotDimensions<E, ?> columnDimensions;
	
	private int hashCode;
	
	public PivotDataCubeKey(PivotDimensions<E, ?> rowDimensions,
			PivotDimensions<E, ?> columnDimensions) {
		this.rowDimensions = rowDimensions;
		this.columnDimensions = columnDimensions;
		hashCode = rowDimensions.getPivotDimensionsString().hashCode() * 31 + columnDimensions.getPivotDimensionsString().hashCode();
	}

	@Override
	public int hashCode() {
		return hashCode;
	}

	@Override
	public boolean equals(Object other) {
		if(other == null) return false;
		if(!(other instanceof PivotDataCubeKey)) return false;
		
        if (this == other) {
            return true;
        }

        PivotDataCubeKey that = (PivotDataCubeKey) other;
        if(this.hashCode != that.hashCode)
        	return false;
        
        if(this.rowDimensions.getPivotDimensionsString().equals(that.rowDimensions.getPivotDimensionsString())
        		&& this.columnDimensions.getPivotDimensionsString().equals(that.columnDimensions.getPivotDimensionsString())) 
        	return true;
        	
		return false;
	}

	public <T> PivotDimensions<E, T> getRowDimensions() {
		return (PivotDimensions<E, T>) rowDimensions;
	}

	public <T> PivotDimensions<E, T> getColumnDimensions() {
		return (PivotDimensions<E, T>) columnDimensions;
	}
	
}
