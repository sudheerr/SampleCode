package com.citi.risk.core.data.pivot.impl;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import com.citi.risk.core.data.pivot.api.PivotDimensionGroup;
import com.citi.risk.core.dictionary.api.DataSelectionItem;

public class NullPivotDimensionGroup<E> implements PivotDimensionGroup<E> {

	private static final AtomicReference<NullPivotDimensionGroup> instance = new AtomicReference<>();

	private PivotTableCell pivotTableCell;

	public static NullPivotDimensionGroup getInstance() {
		NullPivotDimensionGroup nullPivotDimensionGroup = instance.get();

		if (nullPivotDimensionGroup == null) {
			instance.compareAndSet(null, new NullPivotDimensionGroup());
			nullPivotDimensionGroup = instance.get();
		}

		return nullPivotDimensionGroup;
	}

	@Override
	public PivotDataCubeKey getPivotDataCubeKey(List<DataSelectionItem<E, ?>> rowDataSelectionItems, List<DataSelectionItem<E, ?>> colDataSelectionItems) {
		return new PivotDataCubeKey(AllPivotDimensions.getInstance(), AllPivotDimensions.getInstance());
	}

	@Override
	public List<Object> getRowDimensionValues() {
		return Collections.emptyList();
	}

	@Override
	public List<Object> getColumnDimensionValues() {
		return Collections.emptyList();
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if(this == obj) return true;
		if(obj instanceof NullPivotDimensionGroup) return true;
		
		return false;
	}

	@Override
	public void setPivotTableCell(PivotTableCell pivotTableCell) {
		this.pivotTableCell = pivotTableCell;
	}

	@Override
	public PivotTableCell getPivotTableCell() {
		return pivotTableCell;
	}

}
