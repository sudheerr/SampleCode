package com.citi.risk.core.data.pivot.api;

import java.util.Collection;
import java.util.Map;

import com.citi.risk.core.data.pivot.impl.PivotDataCubeKey;
import com.citi.risk.core.data.pivot.impl.PivotTableCell;

public interface PivotDataCube<E, R, C, T> {

	void setIncludeSummary(boolean includeSummary);
	
	boolean getIncludeSummary();
	
	Map<PivotDataCubeKey, PivotTableCell> getDataTableMap();
	
	Map<PivotDimensionGroup<E>, Collection<E>> getDimensionGroupMap();
	
}
