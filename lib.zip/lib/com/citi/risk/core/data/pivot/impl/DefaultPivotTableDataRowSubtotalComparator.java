package com.citi.risk.core.data.pivot.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.citi.risk.core.data.pivot.api.PivotDimensions;
import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.lang.aggregate.Aggregator;
import com.citi.risk.core.lang.aggregate.Evaluator;
import com.google.common.collect.Ordering;

@SuppressWarnings({"unchecked", "rawtypes"})
public class DefaultPivotTableDataRowSubtotalComparator<E, R, C> implements Comparator<Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>>> {

	DataSelectionItem<E, ?> aggregateMeasure = null;
	
	Map<DataSelectionItem<E, ?>, Aggregator> aggregators = null;
	
	boolean sortBySubTotal;
	boolean sortByDSCOrder;

	public DefaultPivotTableDataRowSubtotalComparator(DataSelectionItem<E, ?> aggregateMeasure, Map<DataSelectionItem<E, ?>, Aggregator> aggregators) {
		this.aggregateMeasure = aggregateMeasure;
		this.aggregators = aggregators;
		sortBySubTotal = aggregateMeasure != null && aggregateMeasure.getSortBy() != null;
		sortByDSCOrder = sortBySubTotal && aggregateMeasure.getSortBy().equals(SortBy.DESC);
	}

	@Override
	public int compare(Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o1, Entry<R, Map<PivotDimensions<E, C>, PivotTableCell>> o2) {
		if(!sortBySubTotal) return 0;
		
		List<PivotTableCell> allCellsLeft = new ArrayList<>();
		Collection<PivotTableCell> valuesLeft = o1.getValue().values();
		allCellsLeft.addAll(valuesLeft);

		List<PivotTableCell> allCellsRight = new ArrayList<>();
		Collection<PivotTableCell> valuesRight = o2.getValue().values();
		allCellsRight.addAll(valuesRight);

		Object aggregatedValueLeft = null;
		Object aggregatedValueRight = null;
		for(Entry<DataSelectionItem<E, ?>, Aggregator> entry : aggregators.entrySet()) {
			if(entry.getKey().equals(aggregateMeasure)) {
				Evaluator resultTransform = aggregateMeasure.getSelectedAggregateMeasure().getResultTransform();
				aggregatedValueLeft = entry.getValue().aggregate(getCellMembers((List<PivotTableCell<E>>)(List)allCellsLeft));
				aggregatedValueRight = entry.getValue().aggregate(getCellMembers((List<PivotTableCell<E>>)(List)allCellsRight));
				if (resultTransform != null) {
					aggregatedValueLeft = resultTransform.apply(aggregatedValueLeft);
					aggregatedValueRight = resultTransform.apply(aggregatedValueRight);
				}
			}
		}

		int compareValue = getCompareValue(aggregatedValueLeft, aggregatedValueRight);
		if(sortByDSCOrder)
			compareValue = -1 * compareValue;
		
		return compareValue;
	}

	private int getCompareValue(Object aggregatedValueLeft, Object aggregatedValueRight) {
		int compareValue = 0;
		if(aggregatedValueLeft != null && aggregatedValueRight != null) {
			if (Comparable.class.isAssignableFrom(aggregatedValueLeft.getClass())) {
				compareValue = Ordering.natural().compare((Comparable) aggregatedValueLeft, (Comparable) aggregatedValueRight);
			} else {
				compareValue = Ordering.natural().compare(aggregatedValueLeft.toString(), aggregatedValueRight.toString());
			}
		} else if(aggregatedValueLeft != null ) {
			compareValue = 1;
		} else if(aggregatedValueRight != null ) {
			compareValue = -1;
		}
		return compareValue;
	}
	
	private <E> Collection<E> getCellMembers(List<PivotTableCell<E>> cells) {
		List<E> returnColl = new ArrayList();
		for(PivotTableCell<E> cell : cells)
			returnColl.addAll(cell.getMembers());
		
		return returnColl;
	}
	
}
