package com.citi.risk.core.data.pivot.impl;

import java.util.Comparator;
import java.util.Map.Entry;

import com.citi.risk.core.dictionary.api.DataSelectionItem;
import com.citi.risk.core.dictionary.api.SortBy;
import com.citi.risk.core.lang.aggregate.Evaluator;
import com.google.common.collect.Ordering;

@SuppressWarnings({ "rawtypes" })
public class DefaultPivotTableSubtotalComparator<E> implements Comparator<Entry<?, DefaultPivotTable<E, ?, ?>>>  {

	DataSelectionItem sortByAggregateMeasure;

	boolean sortByDSCOrder;
	
	public DefaultPivotTableSubtotalComparator(DataSelectionItem sortByAggregateMeasure) {
		this.sortByAggregateMeasure = sortByAggregateMeasure;
		sortByDSCOrder = sortByAggregateMeasure!=null && sortByAggregateMeasure.getSortBy()!=null && sortByAggregateMeasure.getSortBy().equals(SortBy.DESC);
	}
	
	@Override
	public int compare(Entry<?, DefaultPivotTable<E, ?, ?>> o1, Entry<?, DefaultPivotTable<E, ?, ?>> o2) {
		int compareValue = 0;

		Object leftSubtotal  = o1.getValue().getGrandSummary().getValue(sortByAggregateMeasure);
		Object rightSubtotal = o2.getValue().getGrandSummary().getValue(sortByAggregateMeasure);
		
		Evaluator resultTransform = sortByAggregateMeasure.getSelectedAggregateMeasure().getResultTransform();
		if (resultTransform != null) {
			leftSubtotal = resultTransform.apply(leftSubtotal);
			rightSubtotal = resultTransform.apply(rightSubtotal);
		}
		
		if(leftSubtotal != null && rightSubtotal != null) {
			if (Comparable.class.isAssignableFrom(leftSubtotal.getClass())) {
				compareValue = Ordering.natural().compare((Comparable) leftSubtotal, (Comparable) rightSubtotal);
			} else {
				compareValue = Ordering.natural().compare((String) leftSubtotal, (String) rightSubtotal);
			}
		} else if(leftSubtotal != null) {
			compareValue = 1;
		} else if(rightSubtotal != null) {
			compareValue = -1;
		}

		if(sortByDSCOrder)
			compareValue = -1 * compareValue;
		
		return compareValue;
	}

}
