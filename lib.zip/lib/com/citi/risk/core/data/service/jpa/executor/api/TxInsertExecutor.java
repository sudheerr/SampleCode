package com.citi.risk.core.data.service.jpa.executor.api;

import java.util.Collection;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface TxInsertExecutor<E extends IdentifiedBy<?>> extends TxExecutor<Collection<E>>  {

	TxInsertExecutor<E> insert(Collection<E> storeItems);
	
    TxInsertExecutor<E> useProxyHelper();
	
}
