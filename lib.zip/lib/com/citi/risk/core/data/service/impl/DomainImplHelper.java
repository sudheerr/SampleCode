package com.citi.risk.core.data.service.impl;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.api.Deleter;
import com.citi.risk.core.data.service.api.Updater;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.IOSpecification;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public class DomainImplHelper
{

    @Inject
    DictionaryParser parser;
    @Inject
    DomainImplParser domainImplParser;
    
    private IOSpecification getIOSpecification(Class<?> clazz) {
        DomainImplSpecification domainImplSpecification = domainImplParser.parse(clazz);
        if (null == domainImplSpecification) {
            throw new NullPointerException("IOSpec is missed with class: [" + clazz + "]");
        }
        IOSpecification iOSpecification = domainImplSpecification.getIOSpecification();
        return iOSpecification;
    }
    
    @SuppressWarnings({ "rawtypes" })
    public <T> DataDomain getDomain(T instance) {
        if (instance == null) {
        	return null;
        }
        return getDomainByImplClass(instance.getClass());
    }
    
    @SuppressWarnings({ "rawtypes" })
    public DataDomain getDomainByImplClass(Class implClass) {
        Class<?>[] doaminClasses = getDomainClasses(ProxyHelper.getRawClassFromGuiceProxy(implClass));
        DataDomain domain = null;
        if (doaminClasses != null && doaminClasses.length > 0) {
            domain = parser.parseDomain(doaminClasses[0]);
        }
        if (domain == null)
            throw new RuntimeException("Template " + implClass + " is not a valid domain.");
        return domain;
    }
    
    public Class<?>[] getDomainClasses(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.getDomainClasses();
    }
    
    public Class<? extends Storer> getActiveStorerClass(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.getActiveStorerClass();
    }
    
    public Class<? extends Loader> getActiveLoaderClass(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.getActiveLoaderClass();
    }
    
    public Class<? extends Deleter> getActiveDeleterClass(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.getActiveDeleterClass();
    }
    
    public Class<? extends Updater> getActiveUpdaterClass(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.getActiveUpdaterClass();
    }
    
    public boolean isInitialLoad(Class<?> clazz) {
        IOSpecification iOSpecification = getIOSpecification(clazz);
        return iOSpecification.isInitialLoad();
    }
    
}
