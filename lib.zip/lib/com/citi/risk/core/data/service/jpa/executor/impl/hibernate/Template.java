package com.citi.risk.core.data.service.jpa.executor.impl.hibernate;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.Attribute;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.SingularAttribute;

import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.Example;
import org.hibernate.ejb.EntityManagerImpl;
import org.hibernate.internal.SessionFactoryImpl;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.hibernate.tuple.entity.EntityTuplizer;
import org.springframework.util.CollectionUtils;

import com.citi.risk.core.data.service.impl.DomainImplHelper;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.DDR;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataMember;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.impl.Criterias;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.google.inject.Injector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Template<K, D, E extends D> {
	private static final Logger LOGGER = LoggerFactory.getLogger(Template.class);
	
	private static final int ORACEL_IN_LIMITATION = 10000;

	private DomainImplHelper domainImplHelper;

	private EntityManager entityManager;
	private Class<E> entityClass;

	private boolean hasOmitCriteria = false;
	private com.citi.risk.core.dictionary.api.Criteria<D> omitCriteria = null;
	private Collection<CriteriaQuery<E>> criteriaQuery = null;
	private Example hibernateCriterion = null;

	public Template(Class<E> entityClass, EntityManager entityManager, Injector injector) {
		this.entityManager = entityManager;
		this.entityClass = entityClass;
		this.domainImplHelper = injector.getInstance(DomainImplHelper.class);
	}

	public void templateFor(Collection<K> identifiers, boolean onlyUnExpired) {
		criteriaQuery = buildIdentifiersQuery(identifiers);
		if(ManagedVersion.class.isAssignableFrom(entityClass)) {
			if(onlyUnExpired) {
				hasOmitCriteria = true;
				omitCriteria = buildIsExpiredCriteria();
			}
		} else {
			hasOmitCriteria = false;
			omitCriteria = null;
		}
	}
	
	private com.citi.risk.core.dictionary.api.Criteria<D> buildIsExpiredCriteria() {
		if(ManagedVersion.class.isAssignableFrom(entityClass)) {
			DataDomain<D> domain = domainImplHelper.getDomainByImplClass(entityClass);
			return ((DataItem<D, Boolean>)domain.getItem("Is Expired")).eq(Boolean.FALSE);
		}
		return null;
	}

	public void templateFor(E templateValue) {
		if (templateValue != null) {
			Collection<Criterion<?>> processCriterions = Lists.newArrayList();
			buildCriterion(templateValue, (DataPath<E, E>)null, processCriterions);
			if (!processCriterions.isEmpty()) {
				hasOmitCriteria = true;
				omitCriteria = Criterias.buildCriteria(processCriterions);
				omitCriteria.setDomainImplClass((Class<? extends E>) templateValue.getClass());
			}
			hibernateCriterion = Example.create(templateValue);
			criteriaQuery = Collections.emptyList();
		}
	}

	public void templateFor(com.citi.risk.core.dictionary.api.Criteria<D> criteria) {
		Collection<Criterion<?>> processCriterions = Lists.newArrayList();
		Collection<Criterion<?>> omitCriterions = Lists.newArrayList();
		filterCriteriaForValueTypeRelns(criteria, processCriterions, omitCriterions);
		criteriaQuery = buildQuery(entityClass, criteria, processCriterions, omitCriterions);
		if(omitCriterions.isEmpty()) {
			hasOmitCriteria = false;
			omitCriteria = null;
		} else {
			hasOmitCriteria = true;
			omitCriteria = Criterias.createCriteria(omitCriterions);
			omitCriteria.setDomainImplClass(criteria.getDomainImplClass());
		}
	}

	public void modification(E updateTemplate, Collection<E> targetEntities) {
		if(updateTemplate == null || CollectionUtils.isEmpty(targetEntities)) {
			return;
		}
		for(E entity : targetEntities) {
			modification(updateTemplate, entity);
		}
	}

	private void modification(E updateTemplate, E targetEntity) {
		if (targetEntity == null || updateTemplate == null) {
			return;
		}
		if (targetEntity.getClass() != updateTemplate.getClass()) {
			throw new RuntimeException("targetEntity and updateTemplate must be of the same class! targetEntity "
					+ targetEntity.getClass() + " and updateTemplate " + updateTemplate.getClass());
		}
		EntityType entityType = getEntityType(entityManager.getEntityManagerFactory(), updateTemplate.getClass());
		if (entityType == null) {
			return;
		}
		AbstractEntityPersister entityPersister = getEntityPersister((EntityManagerImpl) entityManager,	updateTemplate.getClass());
		EntityTuplizer tuplizer = entityPersister.getEntityTuplizer();
		String[] propertyNames = entityPersister.getPropertyNames();

		for (String propertyName : propertyNames) {
			Attribute attribute = entityType.getAttribute(propertyName);
			E updateValue = (E) tuplizer.getPropertyValue(updateTemplate, propertyName);
			if (!isValueSet(updateValue)) {
				continue;
			}
			switch (attribute.getPersistentAttributeType()) {
			case BASIC:
			case MANY_TO_ONE:
				tuplizer.setPropertyValue(targetEntity, propertyName, updateValue);
				break;

			case EMBEDDED:
			case ONE_TO_ONE:
				E targetValue = (E) tuplizer.getPropertyValue(targetEntity, propertyName);

				if (targetValue == null) {
					tuplizer.setPropertyValue(targetEntity, propertyName, updateValue);
				} else {
					modification(updateValue, Arrays.asList(targetValue));
				}
				break;
			default:
				// case MANY_TO_MANY: case ONE_TO_MANY: case ELEMENT_COLLECTION:
				throw new UnsupportedOperationException("Operation '" + attribute.getPersistentAttributeType()
						+ "' is not supported!");
			} // end "switch"
		}
	}

	private AbstractEntityPersister getEntityPersister(EntityManagerImpl entityManager, Class entityClass) {
		SessionFactoryImpl factory = (SessionFactoryImpl) entityManager.getSession().getSessionFactory();
		return (AbstractEntityPersister) factory.getClassMetadata(entityClass);
	}

	private <T> boolean isValueSet(T value) {
		return (value != null)
				&& !((value instanceof Collection) && ((Collection) value).isEmpty())
				&& !((value instanceof Map) && ((Map) value).isEmpty())
				&& !((value instanceof Number) && Double.compare(((Number) value).doubleValue(), 0.0D) == 0)
				&& (!value.getClass().isPrimitive() || ((value.getClass() == long.class) && !value.equals(0L))
						|| ((value.getClass() == int.class) && !value.equals(0))
						|| ((value.getClass() == double.class) && !value.equals(0.0D))
						|| ((value.getClass() == float.class) && !value.equals(0.0F))
						|| ((value.getClass() == short.class) && !value.equals((short) 0)) || ((value.getClass() == char.class) && !value
						.equals('\u0000')));
	}


	public boolean isEntityVersioned(E entity) {
		LOGGER.info("entityClass: " + entity.getClass().getName());
		return ((AbstractEntityPersister) ((EntityManagerImpl)entityManager).getSession().getSessionFactory()
				.getClassMetadata(entityClass)).isVersioned();
	}

	public Object getIdentifierFromPersister(E entity) {
		return ((AbstractEntityPersister) ((EntityManagerImpl)entityManager).getSession().getSessionFactory()
				.getClassMetadata(entityClass)).getIdentifier(entity);
	}

	public boolean hasOmitCriteria() {
		return hasOmitCriteria;
	}

	public com.citi.risk.core.dictionary.api.Criteria<D> getOmitCriteria() {
		return omitCriteria;
	}

	public Collection<CriteriaQuery<E>> getCriteriaQuery() {
		return criteriaQuery;
	}

	public org.hibernate.criterion.Criterion getHibernateCriterion() {
		return hibernateCriterion;
	}

	private <R> void buildCriterion(Object template, DataPath<E, R> parentPath, Collection<Criterion<?>> criterions) {
		DataDomain domain = domainImplHelper.getDomain(template);
		for (Method method : domain.getDomainClass().getMethods()) {
			try {
				if (StringUtils.equals(method.getName(),"incrementVersion") || (StringUtils.equals(method.getName(),"getIdentifier")
						&& ManagedVersion.class.isAssignableFrom(template.getClass()))) {
					continue;
				}
				if (StringUtils.equals("void", method.getReturnType().getName())) {
					continue;
				}
				R value = (R)method.invoke(template);
				if (!isNullValue(value)) {
					continue;
				}
				buildCriterion(domain, method, value, parentPath, criterions);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				LOGGER.debug(e.getMessage(), e);
			}
		}
	}

	private <R> void buildCriterion(DataDomain<R> domain, Method method, R value, DataPath<E, R> parentPath, Collection<Criterion<?>> criterions) {
		if (method.isAnnotationPresent(DDI.class)) {
			criterions.add(Criterias.buildCriterion(
					appendPath(domain, method.getAnnotation(DDI.class).name(), parentPath, true),
					value,
					Criterion.Op.eq));
		} else if (method.isAnnotationPresent(DDR.class)) {
			DDR ddrAnn = method.getAnnotation(DDR.class);
			if (!ddrAnn.isDimension() || Collection.class.isAssignableFrom(value.getClass())) {
				throw new UnsupportedOperationException("Conversion of multi-dimensional items to criteria is not supported.");
			} else if (!ddrAnn.isValueType()) {
				throw new UnsupportedOperationException("Conversion of non-valueType item to criteria is not supported.");
			} else {
				buildCriterion(domain, ddrAnn.name(), value, parentPath, criterions);
			}
		}
	}

	private <R> void buildCriterion(DataDomain<R> domain, String name, R value, DataPath<E, R> parentPath, Collection<Criterion<?>> criterions) {
		if (!StringUtils.equals("Time mark", name) && !StringUtils.equals("Created by", name)) {
			buildCriterion(value, appendPath(domain, name, parentPath, false), criterions);
		}
	}

	private <R> DataPath<E, ?> appendPath(DataDomain<R> domain, String name, DataPath<E, R> parentPath, boolean isDDI) {
		if (parentPath != null) {
			DataPath path = isDDI ? domain.getItem(name).path() : domain.getRelationship(name).path();						
			return parentPath.append(path).path();
		} else {
			return (DataPath<E, ?>)(isDDI ? domain.getItem(name).path() : domain.getRelationship(name).path());
		}
	}

	private boolean isNullValue(Object value) {
		if(value == null) {
			return false;
		}
		if (Collection.class.isAssignableFrom(value.getClass())) {
			return !((Collection<?>) value).isEmpty();
		}
		return !NullTerminator.isCreatedByNullTerminator(value);
	}

	private Collection<CriteriaQuery<E>> buildQuery(Class<E> entityClass,
													Criteria<D> criteria,
													Collection<Criterion<?>> processCriterions,
													Collection<Criterion<?>> omitCriterions) {

		// Check Hibernate Entity from Criteria impl class.
		Collection<EntityType<E>> entityTypes = Lists.newArrayList();
		if (criteria.getDomainImplClass() != null) {
			EntityType<E> entityType = getEntityType(entityManager.getEntityManagerFactory(), criteria.getDomainImplClass());
			if (entityType != null) {
				entityTypes.add(entityType);
			}
		}
		//Check Hiberante entity from Criteria domain, all implement form hibernate entity manager by domain class.
		if (criteria.isQueryAllDomainImpls() && entityTypes.isEmpty()) {
			entityTypes = this.resolveEntityTypes(entityManager.getEntityManagerFactory(), criteria.getDomain().getDomainClass());
		}

		if (!criteria.isQueryAllDomainImpls() && entityTypes.isEmpty()) {
			EntityType<E> entityType = getEntityType(entityManager.getEntityManagerFactory(), entityClass);
			if (entityType != null) {
				entityTypes.add(entityType);
			}
		}

		Collection<CriteriaQuery<E>> criteriaQueries = Lists.newArrayList();
		for (EntityType<E> entityType : entityTypes) {

			if (entityType == null) {
				return Collections.emptyList();
			}
			CriteriaQuery<E> _criteriaQuery = entityManager.getCriteriaBuilder().createQuery(entityType.getJavaType());
			Root<E> root = _criteriaQuery.from(entityType);

			// Begin Build Where statements.
			Predicate where = null;
			for (Criterion<?> criterion : processCriterions) {
				if (criterion.getDataSelectionItem().getUnderlyingPath().hasRelationships()) {
					List<DataRelationship<?,?>> relationships = criterion.getDataSelectionItem().getUnderlyingPath().getRelationships();
					DataItem<?, ?> terminatingItem = criterion.getDataSelectionItem().getUnderlyingPath().getTerminatingItem();
					if (!validateRelationships(entityClass, entityManager, relationships, terminatingItem)) {
						omitCriterions.add(criterion);
						continue;
					}
					Join join = null;
					SingularAttribute attribute;
					EntityType baseType = entityType;
					for (DataRelationship<?, ?> relationship : relationships) {
						attribute = this.getAttribute(baseType, relationship.getDomain(), relationship);
						if (join == null) {
							join = root.join(attribute.getName());
							baseType = getEntityType(entityManager.getEntityManagerFactory(), attribute.getType().getJavaType());
						} else {
							join = join.join(attribute.getName());
						}
					}
					attribute = this.getAttribute(baseType, terminatingItem.getDomain(), terminatingItem);
					Predicate expression = buildPredicate(entityManager.getCriteriaBuilder(), join, attribute, criterion);
					if (expression != null) {
						where = where == null ? expression : entityManager.getCriteriaBuilder().and(where, expression);
					} else {
						omitCriterions.add(criterion);
					}
				} else if (criterion.getDataSelectionItem().getUnderlyingPath().isTerminatedWithAnItem()) {
					DataDomain<?> domain = criterion.getDataSelectionItem().getUnderlyingPath().getStartingDomain();
					DataItem<?, ?> item = criterion.getDataSelectionItem().getUnderlyingPath().getTerminatingItem();
					SingularAttribute attribute = this.getAttribute(entityType, domain, item);
					if (attribute == null) {
						omitCriterions.add(criterion);
						continue;
					}
					Predicate expression = buildPredicate(entityManager.getCriteriaBuilder(), root, attribute, criterion);
					if (expression != null) {
						where = where == null ? expression : entityManager.getCriteriaBuilder().and(where, expression);
					} else {
						omitCriterions.add(criterion);
					}
				}
			}
			if (where != null) {
				_criteriaQuery.where(where);
			}
			criteriaQueries.add(_criteriaQuery);
		}
		return criteriaQueries;
	}

	@SuppressWarnings("rawtypes")
	private Predicate buildPredicate(CriteriaBuilder criteriaBuilder, Path<E> entity, Attribute attribute, Criterion criterion) {
		Expression expression = entity.get(attribute.getName());
		Predicate predicate = null;
		switch (criterion.getOP()) {
		case eq:
			predicate = criteriaBuilder.equal(expression, criterion.getOperand(0));
			break;
		case ne:
			predicate = criteriaBuilder.notEqual(expression, criterion.getOperand(0));
			break;
		case lt:
			predicate = criteriaBuilder.lessThan(expression, (Comparable)criterion.getOperand(0));
			break;
		case le:
			predicate = criteriaBuilder.lessThanOrEqualTo(expression, (Comparable)criterion.getOperand(0));
			break;
		case gt:
			predicate = criteriaBuilder.greaterThan(expression, (Comparable)criterion.getOperand(0));
			break;
		case ge:
			predicate = criteriaBuilder.greaterThanOrEqualTo(expression, (Comparable)criterion.getOperand(0));
			break;
		case in:
			predicate = expression.in(criterion.getAllOperands());
			break;
		case between:
			predicate = criteriaBuilder.between(expression, (Comparable)criterion.getOperand(0), (Comparable)criterion.getOperand(1));
			break;
		case like:
		case likeObjectString:
			String likeOperand = convertRegexToLike(String.valueOf(criterion.getOperand(0)));
			predicate = criteriaBuilder.like(expression, likeOperand);
			break;
		case isNull:
			predicate = expression.isNull();
			break;
		default:

		}
		if (predicate!= null && criterion.isNegated()) {
			predicate = predicate.not();
		}
		return predicate;
	}

	private String convertRegexToLike(String input) {
		return input.replaceAll("\\.?\\*", "%");
	}

	private boolean validateRelationships(Class<E> entityClass,
										  EntityManager entityManager,
										  List<DataRelationship<?,?>> relationships,
										  DataItem<?, ?> terminatingItem) {
		if (terminatingItem == null) {
			return false;
		}
		Class<?> baseClass = entityClass;
		EntityType<E> baseType;
		for (DataRelationship<?, ?> relationship : relationships) {
			baseType = getEntityType(entityManager.getEntityManagerFactory(), baseClass);
			if (baseType == null) {
				return false;
			}
			DataDomain<?> domain = relationship.getEndingDomain();
			if(TimeMark.class.isAssignableFrom(domain.getDomainClass())) {
		        return false;
		    }
			SingularAttribute attribute = this.getAttribute(baseType, relationship.getDomain(), relationship);
			if (attribute == null) {
				return false;
			}
			baseClass = attribute.getType().getJavaType();
		}
		// check terminating.
		baseType = getEntityType(entityManager.getEntityManagerFactory(), baseClass);
		if (baseType == null) {
			return false;
		}
		SingularAttribute attribute = this.getAttribute(baseType, terminatingItem.getDomain(), terminatingItem);
		if (attribute == null) {
			return false;
		}
		// check last item for op.
		return true;
	}

	private SingularAttribute getAttribute(EntityType entityType, DataDomain domain, DataMember item) {
		PropertyDescriptor pd = domain.getPropertyDescriptor(item);
		if (pd == null) {
			return null;
		}
		try {
			return (SingularAttribute)entityType.getAttribute(pd.getName());
		} catch (IllegalArgumentException iae) {
			LOGGER.debug(iae.getMessage(), iae);
		}
		return null;
	}

	private final static com.google.common.base.Predicate<Class<?>>	MANAGED_TYPE_PREDICATE = new com.google.common.base.Predicate<Class<?>>() {
		@Override
		public boolean apply(Class<?> input) {
            return input != null &&
            		(input.getName().startsWith("com.citi.core") || input.getName().startsWith("com.citi.risk"));
		}
	};

	private Collection<EntityType<E>> resolveEntityTypes(EntityManagerFactory entityManagerFactoryImpl, Class<D> entityClass) {
		Multimap<Class<?>, EntityType<?>> entityMap = ArrayListMultimap.create();
		for (EntityType<?> entityType : entityManagerFactoryImpl.getMetamodel().getEntities()) {
			Class<?> javaType = entityType.getJavaType();
			entityMap.put(javaType, entityType);
			Iterable<Class<?>> interfaces = Iterables.filter(ClassUtils.getAllInterfaces(javaType), MANAGED_TYPE_PREDICATE);
			for (Class<?> interfaze : interfaces) {
				entityMap.put(interfaze, entityType);
			}
		}
		Collection<EntityType<E>> entityTypes = Sets.newHashSet();
		Collection<Class<?>> entityClasses =
				Proxy.isProxyClass(entityClass) ? (Collection) Arrays.asList(entityClass.getInterfaces()) : Arrays.asList(entityClass);
		for (Class<?> clazz : entityClasses) {
			Collection<EntityType<?>> entities = entityMap.get(clazz);
			for(EntityType e : entities)
				if(!Modifier.isAbstract(e.getJavaType().getModifiers()))
					entityTypes.add(e);
		}
		return entityTypes;
	}

	private void filterCriteriaForValueTypeRelns(Criteria<D> criteria,
			 	   							   	  Collection<Criterion<?>> criterions,
			 	   							   	  Collection<Criterion<?>> omitCriterions) {
        for(Criterion<D> criterion : criteria.getAllCriterion()) {
            if(criterion.getDataSelectionItem().getUnderlyingPath().hasRelationships()) {
            	com.citi.risk.core.dictionary.api.DataPath<?,?> path = criterion.getDataSelectionItem().getUnderlyingPath();
                DataRelationship reln = path.getRelationships().get(0);
                if (StringUtils.equals(reln.getName(),"Time mark") || StringUtils.equals(reln.getName(),"Created by")) {
        			continue;
        		}
                if(reln.isDimension() && reln.isValueType()) {
                    criterions.add(criterion);
                } else {
                	omitCriterions.add(criterion);
                }
            } else {
                criterions.add(criterion);
            }
        }
	 }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Collection<CriteriaQuery<E>> buildIdentifiersQuery(Collection identifiers) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		Collection<CriteriaQuery<E>> criteriaQueries = Lists.newArrayList();
		EntityType<E> entityType = getEntityType(entityManager.getEntityManagerFactory(), entityClass);
		
		CriteriaQuery<E> _criteriaQuery = criteriaBuilder.createQuery(entityType.getJavaType());
		// if identifiers is empty or null then return all data from database.
		if(CollectionUtils.isEmpty(identifiers)){
			_criteriaQuery.from(entityType);
		    criteriaQueries.add(_criteriaQuery);
		} else if (entityType.hasSingleIdAttribute()) {
			// entity annotated with single @Id or @EmbeddedId
			Root<E> entity = _criteriaQuery.from(entityType);
			if(ManagedVersion.class.isAssignableFrom(entityClass)) {
				// if entity is managed version then the database primary key is difference with cache key.
				// there are two unique key in domain, 1. identifiers 2, business key + version
				// 
				try {
					String businessKeyField = ((ManagedVersion)entityType.getJavaType().newInstance()).getKeyField();
					if (identifiers.size() > ORACEL_IN_LIMITATION) {
						Predicate predicate = null;
						Iterable<Collection> splitIdentifiers = Iterables.partition(identifiers, ORACEL_IN_LIMITATION);
						for (Collection sids : splitIdentifiers) {
							if (predicate == null) {
								predicate = entity.get(businessKeyField).in(sids);
							} else {
								predicate = criteriaBuilder.or(predicate, entity.get(businessKeyField).in(sids));
							}
						}
						 _criteriaQuery.where(predicate);
					} else {
					    _criteriaQuery.where(entity.get(businessKeyField).in(identifiers));
					}
				} catch (InstantiationException | IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			} else {
				javax.persistence.metamodel.Type<?> idType = entityType.getIdType();
				SingularAttribute idAttribute = entityType.getId(idType.getJavaType());
				if (identifiers.size() > ORACEL_IN_LIMITATION) {
					Predicate predicate = null;
					Iterable<Collection> splitIdentifiers = Iterables.partition(identifiers, ORACEL_IN_LIMITATION);
					for (Collection sids : splitIdentifiers) {
						if (predicate == null) {
							predicate = entity.get(idAttribute.getName()).in(sids);
						} else {
							predicate = criteriaBuilder.or(predicate, entity.get(idAttribute.getName()).in(sids));
						}
					}
					 _criteriaQuery.where(predicate);
				} else {
					_criteriaQuery.where(entity.get(idAttribute.getName()).in(identifiers));
				}
			}
			criteriaQueries.add(_criteriaQuery);
		} else {
			// multiple @Id declaration, commonly entity will be annotated with @IdClass
			// entityType.getIdType() wont get the class in @IdClass, will throw runtimeexception by JPA
			Set<SingularAttribute<? super E, ?>> idClassAttributes = entityType.getIdClassAttributes();
			if (!CollectionUtils.isEmpty(idClassAttributes)) {
				CriteriaQuery cq = generateCriteria(criteriaBuilder, entityType, idClassAttributes, identifiers);
				criteriaQueries.add(cq);
			}
		}
		
		return criteriaQueries;
	}

	private EntityType getEntityType(EntityManagerFactory entityManagerFactory, Class typeClass) {
		try {
			return entityManagerFactory.getMetamodel().entity(typeClass);
		} catch (IllegalArgumentException ex) {
			LOGGER.debug(ex.getMessage(), ex);
		}
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	private CriteriaQuery generateCriteria(CriteriaBuilder criteriaBuilder, EntityType<E> entityType
			, Set<SingularAttribute<? super E, ?>> idClassAttributes
			, Collection identifiers) {
		
		CriteriaQuery<E> _criteriaQuery = criteriaBuilder.createQuery(entityType.getJavaType());
		Root<E> entity = _criteriaQuery.from(entityType);
		
		List<Predicate> predicateList = new ArrayList<>(identifiers.size());
		
		for (Object idObject : identifiers) {
			List<Predicate> andPredicates = new ArrayList<>(idClassAttributes.size());
			
			for (SingularAttribute singularAttribute : idClassAttributes) {
				String fieldName = singularAttribute.getName();
				
				Object valueFromIdObject = getValueFromObject(idObject, singularAttribute);
				
				Predicate p = criteriaBuilder.equal(entity.get(fieldName), valueFromIdObject);
				
				andPredicates.add(p);
			}
			
			if (!CollectionUtils.isEmpty(andPredicates)) {
				predicateList.add(criteriaBuilder.and(andPredicates.toArray(new Predicate[andPredicates.size()])));
			}
		}
		
		Predicate aggregated = criteriaBuilder.or(predicateList.toArray(new Predicate[predicateList.size()]));
		_criteriaQuery.where(aggregated);
		
		return _criteriaQuery;
	}
	
	private Object getValueFromObject(Object object, SingularAttribute singularAttribute) {
		try {
			Field field = (Field) singularAttribute.getJavaMember();
			return field.get(object);
		} catch (Exception e) {
			throw new RuntimeException("error get property " + singularAttribute.getName() + " from object " + object, e);
		}
	}

}
