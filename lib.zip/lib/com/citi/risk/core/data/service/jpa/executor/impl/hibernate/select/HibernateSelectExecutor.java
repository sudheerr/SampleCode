package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.Collection;
import java.util.Collections;

import javax.persistence.EntityManager;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public class HibernateSelectExecutor<K, D extends IdentifiedBy<K>, E extends D> 
				extends AbstractHibernateSelectExecutor<K, D, E, HibernateSelectExecutor<K, D, E> >{

	public HibernateSelectExecutor(Class<E> entityClass, Injector injector) {
		super(entityClass, false, injector);
	}

	@Override
	protected Collection<E> execute(EntityManager entityManager, SelectType selectType) {
		if (selectType == SelectType.Identifiers) {
			return selectByIdentifiers();
		} else if (selectType == SelectType.Criteria) {
			return selectByCriteria(); 
		} else if (selectType == SelectType.Template) {
			return selectByTemplate();
		} else {
			return Collections.emptyList();
		}
	}
	
	public Collection<E> selectByIdentifiers() {
		HibernateSelectByIdentifier<K, D, E> selectStep = this.buidSetp(HibernateSelectByIdentifier.class);
		Collection<E> selectResult = (Collection<E>)selectStep.select(getIdentifiers()).execute();
		if(selectStep.hasOmitCriteria()) {
			selectResult = (Collection<E>) selectStep.getOmitCriteria().getSelect().select((Collection<D>)selectResult);
		}
		return selectResult;
	}

	public Collection<E> selectByCriteria() {
		if (this.getCriteria() == null) {
			return Collections.emptyList();
		}
		HibernateSelectByCriteria<K, D, E> selectStep = this.buidSetp(HibernateSelectByCriteria.class);
		return (Collection<E>)selectStep.select(getCriteria()).execute();
		
	}
	
	public Collection<E> selectByTemplate() {
		if (this.getTemplate() == null) {
			return Collections.emptyList();
		}
		HibernateSelectByTemplate<K, D, E> selectStep = this.buidSetp(HibernateSelectByTemplate.class);
		return (Collection<E>)selectStep.select(getTemplate()).execute();
		
	}

}
