package com.citi.risk.core.data.service.jpa.executor.impl.hibernate;

import java.lang.reflect.Constructor;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.service.jpa.executor.impl.AbstractTxExecutor;
import com.citi.risk.core.data.service.transaction.api.TrxManager;
import com.citi.risk.core.data.service.transaction.api.TrxStatus;
import com.citi.risk.core.data.service.transaction.impl.DefaultTrxManager;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public abstract class AbstractHibernateTxExecutor<E extends IdentifiedBy, R> extends AbstractTxExecutor<E, R> {

	private final static int BATCH_SIZE = 1000;
	private boolean forUpdate;
	
	public AbstractHibernateTxExecutor(Class<E> entityClass, boolean forUpdate, Injector injector) {
		super(entityClass, injector);
		this.forUpdate = forUpdate;
	}
	@Override
	public R execute() {
		TrxManager trxManager = ExecutionContexts.getCurrentExecutionContext().getTrxManager();
		if (trxManager == null) {
			trxManager = this.getInjector().getInstance(DefaultTrxManager.class);
		}
		R retValues = null;
		TrxStatus status = null;
		try {
			status = trxManager.begin(this.getEntityClass(), forUpdate);
			this.setEntityManager(status.getEntityManager());
			retValues = execute(this.getEntityManager());
			status.getEntityManager().flush();
			trxManager.commit(status);
		} catch (Exception ta) {
			if (status != null) {
				trxManager.rollback(status);
			}
			throw ta;
		} finally {
			this.setEntityManager(null);
		}
		return retValues;
	}
	
	protected abstract R execute(EntityManager entityManager);

	protected boolean isForUpdate() {
		return forUpdate;
	}

	protected void flushAndClearBatch(int count, EntityManager entityManager) {
		if ((count % BATCH_SIZE) == 0) {
			entityManager.flush();
			entityManager.clear();
		}
	}

	protected <EX extends HibernateTxStep<E, R>> EX buidSetp(Class<EX> executorClass) {
		try {
			Constructor<EX> cons = executorClass.getConstructor(Class.class, Injector.class);
			EX retValue = cons.newInstance(this.getEntityClass(), this.getInjector());
			((HibernateTxStep<E, R>)retValue).setEntityManager(this.getEntityManager());
			return retValue;
		} catch (Exception e) {
			throw new RuntimeException("Can't create a new executer instance of :" + executorClass.getName(), e);
		}
	}
	
}
