package com.citi.risk.core.data.service.impl;

import java.util.Collection;

import com.citi.risk.core.data.service.api.HibernateDataAccessService;
import com.citi.risk.core.data.service.jpa.JpaExecutor;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;

/**
 * @deprecated not support
 */
@Deprecated
public final class DefaultHibernateDataAccessService implements HibernateDataAccessService {

	@Inject
	Injector injector;

	@Override
	public <T extends IdentifiedBy<?>> Collection<T> select(String hql, Class<T> entityClass) {
        JpaExecutor jpaEexcutor = new JpaExecutor(entityClass, injector);
        return jpaEexcutor.selectHql(hql, entityClass);
	}
	
}
