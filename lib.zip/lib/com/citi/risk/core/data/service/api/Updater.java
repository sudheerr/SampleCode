package com.citi.risk.core.data.service.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;

public interface Updater
{
	<T extends IdentifiedBy<?>> Collection<T> update(Collection<T> entities);
	
	<T extends IdentifiedBy<?>> Collection<T> update(Collection<T> entities, T updateTemplate);

	<T extends IdentifiedBy<?>> Collection<T> update(T selectTemplate, T updateTemplate);

    <T extends IdentifiedBy<?>> Collection<T> update(Criteria selectCriteria, T updateTemplate);

    <K, T extends IdentifiedBy<K>> Collection<T> update(T updateTemplate, Collection<K> identifiers);
    
    public void setDomain(DataDomain domain);

    public void setTimeMark(TimeMark timeMark);

    public void setCreatedBy(CreatedBy createdBy);
}
