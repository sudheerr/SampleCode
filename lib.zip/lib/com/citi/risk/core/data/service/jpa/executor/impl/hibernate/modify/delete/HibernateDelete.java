package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.delete;

import com.citi.risk.core.data.service.jpa.DefaultVersioner;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.HibernateExpireDomain;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.AbstractHibernateSelect;
import com.citi.risk.core.data.subscription.api.DataModifyType;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.google.inject.Injector;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.LockMode;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import java.util.Collections;
import java.util.List;

public class HibernateDelete<K, D extends IdentifiedBy<K>, E extends D> extends AbstractHibernateSelect<K, D, E, List<E>> {

	private List<E> deleteItems;
	private boolean isRemove = true;

	private final static int BATCH_SIZE = 1000;

	public HibernateDelete(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	} 

	public HibernateDelete<K, D, E> delete(List<E> deleteItems) {
		this.deleteItems = deleteItems;
		return this;
	}
	
	public HibernateDelete<K, D, E> isRemove(boolean isRemove) {
		this.isRemove = isRemove;
		return this;
	}

	@Override
	protected List<E> execute(EntityManager entityManager) {
		if (CollectionUtils.isEmpty(deleteItems)) {
			return Collections.emptyList();
		}
		int count = 1;
		for(E entity : deleteItems) {
			final Class<? extends IdentifiedBy> entityClass = entity.getClass();
			if(isRemove && ManagedVersion.class.isAssignableFrom(entityClass)) {
				if (((ManagedVersion)entity).getExpired()) {
					continue;
				}
				K oldKey = entity.key();
				if(entityManager.contains(entity)) {
            		entityManager.detach(entity);
            	}
    			ExecutionContext context = ExecutionContexts.getCurrentExecutionContext();
    			if(!context.isWriteBehind()) {
					new HibernateExpireDomain(entityClass, getInjector())
							.entityManager(entityManager)
							.expire((ManagedVersion) entity)
							.lock(LockMode.OPTIMISTIC)
							.execute();
    			}
				VERSIONER.onDelete((ManagedVersion)entity, null);
				entityManager.persist(entity);
				this.recordDomain(DataModifyType.Delete, entity, oldKey);
			} else { // For RDBMS Clipborad delete
				E toRemove = removeFromEM(entityManager, entity, entityClass);
                this.recordDomain(DataModifyType.Delete, toRemove, null);
			}
			flushAndClearBatch(++count, entityManager);
		}
		return Collections.emptyList();
	}

	private E removeFromEM(EntityManager entityManager, E entity, final Class<? extends IdentifiedBy> entityClass) {
		E toRemove = entity;
		if(!entityManager.contains(entity)) {
			Object key = this.getDBKey(entity);
			boolean isVersioned = this.isEntityVersionedInDB(entity);
			toRemove = isVersioned ? (E)entityManager.find(entityClass, key, LockModeType.PESSIMISTIC_FORCE_INCREMENT)
					: (E)entityManager.find(entityClass, key);
		}
		entityManager.remove(toRemove);
		return toRemove;
	}
	
	protected void flushAndClearBatch(int count, EntityManager entityManager) {
		if ((count % BATCH_SIZE) == 0) {
			entityManager.flush();
			entityManager.clear();
		}
	}
	
}
