package com.citi.risk.core.data.service.api;

import java.util.Collection;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

/**
 * @deprecated will removed
 */
@Deprecated
public interface HibernateDataAccessService {

	<T extends IdentifiedBy<?>> Collection<T> select(String hql, Class<T> entityClass);
	
}
