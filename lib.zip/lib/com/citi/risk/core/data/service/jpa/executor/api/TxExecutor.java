package com.citi.risk.core.data.service.jpa.executor.api;

public interface TxExecutor<R> {

	R execute();

}
