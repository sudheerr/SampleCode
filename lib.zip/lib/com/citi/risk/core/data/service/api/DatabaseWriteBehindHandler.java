package com.citi.risk.core.data.service.api;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Multimap;

public interface DatabaseWriteBehindHandler {

	<K,T extends IdentifiedBy<K>> void process(Multimap<Class,T> entitiesByImplClass);

}
