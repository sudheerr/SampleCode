package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.update;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.ObjectUtils;
import org.hibernate.LockMode;
import org.springframework.util.CollectionUtils;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.jpa.VersionExpiredException;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.HibernateExpireDomain;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.AbstractHibernateSelect;
import com.citi.risk.core.data.subscription.api.DataModifyType;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.google.inject.Injector;

public class HibernateUpdate<K, D extends IdentifiedBy<K>, E extends D> extends AbstractHibernateSelect<K, D, E, List<E>> {

	private List<E> updateItems;
	private boolean useProxyHelper = true;

	private final static int BATCH_SIZE = 1000;

	public HibernateUpdate(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}

	public HibernateUpdate<K, D, E> update(List<E> entities) {
		this.updateItems = entities;
		return this;
	}

	public HibernateUpdate<K, D, E> useProxyHelper(boolean useProxyHelper) {
		this.useProxyHelper = useProxyHelper;
		return this;
	}

	@Override
	protected List<E> execute(EntityManager entityManager) {
		if (CollectionUtils.isEmpty(updateItems)) {
			return Collections.emptyList();
		}
		List<E> updatedEntities = new ArrayList<>();
		int count = 1;
		for(E entity : updateItems) {
			final Class<E> entityClass = ProxyHelper.getRawClass(entity);
			if(ManagedVersion.class.isAssignableFrom(entityClass)) {
				E toExpiredEntity = (E) ProxyHelper.getHoldingValue(((ManagedVersion<?>) entity).getLatest());
				toExpiredEntity = !NullTerminator.objectIsNull(toExpiredEntity) ? toExpiredEntity : entity;
				K oldKey = toExpiredEntity.key();
				if (ObjectUtils.compare(((ManagedVersion) entity).getVersion(), ((ManagedVersion) toExpiredEntity).getVersion()) < 0) {
					throw new VersionExpiredException("cannot update an already expired entity, the to update entity version is smaller than latest entity version. Entity Detail: " +
							"\nEntity Class is: " + entityClass.getSimpleName() +
							", Business Key is: " + ((ManagedVersion) entity).getBusinessKey() +
							", Key is: " + entity.key() +
							", Entity Version is: " + ((ManagedVersion) entity).getVersion() +
							", Entity Expired is: " + ((ManagedVersion) entity).getExpired() + 
							"\nAnd the latest version of this entity detail: " +
							"\nLatest Entity Class is: " + entityClass.getSimpleName() +
							", Latest Entity Business Key is: " + ((ManagedVersion)toExpiredEntity).getBusinessKey() +
							", Latest Entity Key is: " + toExpiredEntity.key() +
							", Latest Entity Version is: " + ((ManagedVersion)toExpiredEntity).getVersion() +
							", Latest Entity Expired is: " + ((ManagedVersion)toExpiredEntity).getExpired()
							);
				}

				if(entityManager.contains(entity)) {
					entityManager.detach(entity);
				}
				ExecutionContext context = ExecutionContexts.getCurrentExecutionContext();
				if(!context.isWriteBehind()) {
					new HibernateExpireDomain(entityClass, getInjector())
							.entityManager(entityManager)
							.expire((ManagedVersion) toExpiredEntity)
							.lock(LockMode.OPTIMISTIC)
							.execute();
				}
				VERSIONER.onUpdate((ManagedVersion) entity, null);

				org.hibernate.Session hibernateSession = entityManager.unwrap(org.hibernate.Session.class);
				hibernateSession.save(entity);
				updatedEntities.add(entity);

				recordDomain(DataModifyType.Update, entity, oldKey);
			} else {
				E target = entityManager.merge(entity);
				updatedEntities.add(target);
				recordDomain(DataModifyType.Update, entity, null);
			}
			flushAndClearBatch(++count, entityManager);
		}
		return updatedEntities;
	}

	protected void flushAndClearBatch(int count, EntityManager entityManager) {
		if ((count % BATCH_SIZE) == 0) {
			entityManager.flush();
			entityManager.clear();
		}
	}
	
	public boolean isUseProxyHelper() {
		return useProxyHelper;
	}

}
