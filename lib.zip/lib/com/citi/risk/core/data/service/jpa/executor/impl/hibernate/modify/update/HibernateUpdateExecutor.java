package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.update;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.citi.risk.core.data.service.jpa.executor.api.TxUpdateExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.ResolveReference;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.Template;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.AbstractHibernateModifyExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByCriteria;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByIdentifier;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByTemplate;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.security.api.SecureAction;
import com.google.inject.Injector;

public class HibernateUpdateExecutor<K, D extends IdentifiedBy<K>, E extends D> 
						extends AbstractHibernateModifyExecutor<K, D, E, HibernateUpdateExecutor<K, D, E>>
						implements TxUpdateExecutor<K, D, E, HibernateUpdateExecutor<K, D, E>> {
	
	public HibernateUpdateExecutor(Class<E> entityClass, Injector injector) {
		super(entityClass, true, injector);
	}
	
	@Override
	public HibernateUpdateExecutor<K, D, E> update(Collection<E> entities) {
		this.setModifyEntities(entities);
		return this;
	}

	@Override
	public HibernateUpdateExecutor<K, D, E> with(E updateTemplate) {
		this.setModifyTemplate(updateTemplate);
		return this;
	}
	
	@Override
	public HibernateUpdateExecutor<K, D, E> useProxyHelper(boolean useProxyHelper) {
		this.setUseProxyHelper(useProxyHelper);
		return this;
	}

	@Override
	public List<E> executeByEntity() {
		
		if(ManagedVersion.class.isAssignableFrom(this.getEntityClass())) {
			this.setNeedResolve(false);
		}
		return updateStep(this.getModifyEntities());
	}
	
	@Override
	public List<E> executeByIdentifiers() {
		HibernateSelectByIdentifier<K, D, E> selectStep = this.buidSetp(HibernateSelectByIdentifier.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getIdentifiers()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Modify);
		this.setNeedResolve(false);
		List<E> results = updateStep(searchResult);
		return results;
	}
	
	@Override
	public List<E> executeByTemplate() {
		HibernateSelectByTemplate<K, D, E> selectStep = this.buidSetp(HibernateSelectByTemplate.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getTemplate()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Modify);
		this.setNeedResolve(false);
		return updateStep(searchResult);
	}
	
	@Override
	public List<E> executeByCriteria() {
		HibernateSelectByCriteria<K, D, E> selectStep = this.buidSetp(HibernateSelectByCriteria.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getCriteria()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Modify);
		this.setNeedResolve(false);
		return updateStep(searchResult);
	}
	
	private List<E> updateStep(Collection<E> searchResult) {
		buildTemplate().modification(this.getModifyTemplate(), searchResult);
		HibernateUpdate<K, D, E> updateStep = (HibernateUpdate<K, D, E>)this.buidSetp(HibernateUpdate.class);
		List<E> results = new ArrayList(searchResult);
		List<E> updateResults = updateStep.update(results).useProxyHelper(this.isUseProxyHelper()).execute();
		if(this.needResolve()) {
			ResolveReference<E> resolve = new ResolveReference(updateResults, results, this.getLoader(), this.getModifyTemplate());
			resolve.getLoaderAndResolve();
		}
		return updateResults;
	}

	protected Template<K, D, E> buildTemplate() {
		return new Template(this.getEntityClass(), this.getEntityManager(), this.getInjector());
	}
	
}
