package com.citi.risk.core.data.service.impl;

import java.util.Collection;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.proxy.api.InvocationType;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.KeyModifiable;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.security.api.SecureAction;

public class NonSecurityDataAccessServiceImpl  extends DefaultDataAccessService {
	
	@InfraInvocation(type=InvocationType.Security)
	protected <E extends IdentifiedBy<?>> Collection<E> filterDataBySecurity(Class<E> domainClass, Collection<E> originalData, SecureAction... secureAction) {
		return originalData;
	}
	
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> selectForUpdate(E selectTemplate) {
		throw new UnsupportedOperationException("selectforupdate skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> selectForUpdate(Criteria<E> criteria, Select<E> additionalSelect) {
		throw new UnsupportedOperationException("selectforupdate skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> Collection<E> selectForUpdate(Class<E> domainClass, Collection<K> identifiers ) {
		throw new UnsupportedOperationException("selectforupdate skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> E selectOneForUpdate(Class<E> domainClass, K id) {
		throw new UnsupportedOperationException("selectoneforupdate skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> E selectOneForUpdate(DataDomain<E> domain, K identifier) {
		throw new UnsupportedOperationException("selectoneforupdate skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> create(Collection<E> entities) {
		throw new UnsupportedOperationException("create skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K> & KeyModifiable<K>> Collection<E> createWriteBehind(Collection<E> entities) {
		throw new UnsupportedOperationException("createWriteBehind skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> E createOne(E entity) {
		throw new UnsupportedOperationException("createOne skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> Collection<E> update(Collection<E> entities) {
		throw new UnsupportedOperationException("update skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K> & KeyModifiable<K>> Collection<E> updateWriteBehind(Collection<E> entities) {
		throw new UnsupportedOperationException("updateWriteBehind skip security is not supported.");
	}
	
	@Deprecated
	@Override
	public <K, E extends IdentifiedBy<K>> Collection<E> update(E selectTemplate, E updateTemplate) {
		throw new UnsupportedOperationException("update skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> Collection<E> update(E updateTemplate, Collection<K> identifiers) {
		throw new UnsupportedOperationException("update skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> void delete(Collection<E> entities) {
		throw new UnsupportedOperationException("delete skip security is not supported.");
	}
	
	@Override
	public <K,E extends IdentifiedBy<K> & KeyModifiable<?>> void deleteWriteBehind(Collection<E> entities) {
		throw new UnsupportedOperationException("deleteWriteBehind skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> void delete(E selectTemplate) {
		throw new UnsupportedOperationException("delete skip security is not supported.");
	}
	
	@Override
	public <E extends IdentifiedBy<?>> void delete(Criteria<E> criteria, Select<E> additionalSelect) {
		throw new UnsupportedOperationException("delete skip security is not supported.");
	}
	
	@Override
	public <K, E extends IdentifiedBy<K>> void delete(Class<E> domainClass, Collection<K> identifiers) {
		throw new UnsupportedOperationException("delete skip security is not supported.");
	}
}
