package com.citi.risk.core.data.service.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;

public interface DBDataAccessService {
	/**
	 * Returns a collection of matched entities for the given selectCriteria from Database.
	 * @param criteria for building a select query
	 * @return collection of entities
	 */
	<T extends IdentifiedBy<?>> Collection<T> selectFromDatabase(Criteria<T> criteria, Select<T> specialSelect);
	
	/**
	 * Returns a collection of matched entities for the given selectTemplate from Database.
	 * @param selectTemplate entity template for building a select query
	 * @return collection of entities
	 */
	<T extends IdentifiedBy<?>> Collection<T> selectFromDatabase(T template);
	
	/**
	 * Returns a collection of matched entities for the given identifiers from Database.
	 * @param entityClass entity class to select
	 * @param identifiers primary keys of entities to select
	 * @return collection of entities
	 */
	<K, T extends IdentifiedBy<K>> Collection<T> selectFromDatabase(Class<T> entityClass, Collection<K> identifiers);
}
