package com.citi.risk.core.data.service.api;

import com.citi.risk.core.dictionary.api.DDI;

public interface Versionable {
    @DDI(name="version")
    Integer getVersion();
    

}
