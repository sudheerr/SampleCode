package com.citi.risk.core.data.service.api;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.concurrent.Callable;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface MapperCallback<K, E extends IdentifiedBy<K>> extends Callable<Collection<E>> {
	
	Method getMethod();
	
	Object getMapper();
	
	Collection<E> execute(Collection<E> value);
	
}
