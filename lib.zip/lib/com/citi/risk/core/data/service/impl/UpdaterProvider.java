package com.citi.risk.core.data.service.impl;

import com.citi.risk.core.clipboard.updater.ClipboardUpdater;
import com.citi.risk.core.data.service.api.Updater;
import com.citi.risk.core.data.store.api.DataStoreType;
import com.citi.risk.core.data.store.api.WriteMode;
import com.citi.risk.core.data.store.impl.JpaUpdater;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class UpdaterProvider
{
    @Inject
    private Injector injector;

    @SuppressWarnings("unchecked")
    public Updater getUpdater(DataStoreType storeType)
    {
    	if(storeType.equals(DataStoreType.MONGO))
    		return injector.getInstance(ClipboardUpdater.class);

    	if (storeType.isSupportsJPA()) {
            return injector.getInstance(JpaUpdater.class);
        }
        return null;
    }
}
