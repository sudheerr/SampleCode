package com.citi.risk.core.data.service.impl;

import java.util.Collection;
import java.util.Collections;

import com.citi.risk.core.data.service.api.Deleter;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Multimap;

public class DatabaseDeleteWriteBehindHandler extends
		AbstractDatabaseWriteBehindHandler {

	@Override
	protected <K, E extends IdentifiedBy<K>> Collection<E> processDB(Multimap<Class, E> entitiesByImplClass) {

		for(Class domainImplClass : entitiesByImplClass.keySet()){
			Collection<E> entities = entitiesByImplClass.get(domainImplClass);
			preProcessEntities(entities);
			Class deleteClass = domainImplHelper.getActiveDeleterClass(domainImplClass);
			Deleter deleter = (Deleter) injector.getInstance(deleteClass);
			
			deleter.delete(entities);
		}
		return Collections.emptyList();
	}

}
