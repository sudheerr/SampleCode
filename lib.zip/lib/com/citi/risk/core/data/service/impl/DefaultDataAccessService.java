package com.citi.risk.core.data.service.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.LockMode;

import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.proxy.impl.DeleteDataInvocationCallable;
import com.citi.risk.core.data.proxy.impl.InsertDataInvocationCallable;
import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.proxy.impl.SelectDataInvocationCallable;
import com.citi.risk.core.data.proxy.impl.UpdateDataInvocationCallable;
import com.citi.risk.core.data.service.api.MapperCallback;
import com.citi.risk.core.data.service.jpa.JPAObjectIdGenerator;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.HibernateExpireDomain;
import com.citi.risk.core.data.service.transaction.api.TrxManager;
import com.citi.risk.core.data.service.transaction.api.TrxStatus;
import com.citi.risk.core.data.service.transaction.impl.DefaultTrxManager;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.CacheAccessor;
import com.citi.risk.core.data.store.cache.impl.AbstractStorer;
import com.citi.risk.core.data.store.impl.DefaultDataKey;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.execution.api.AsyncMethodInvoker;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.KeyModifiable;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.businessobject.TimeMarkPath;
import com.citi.risk.core.lang.create.api.ObjectIdGenerator;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.security.api.SecureAction;
import com.citi.risk.core.security.api.SecuritySelect;
import com.google.common.base.Strings;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.Singleton;
import com.google.inject.name.Named;

@Singleton
public class DefaultDataAccessService extends AbstractDataAccessService {

	@Inject 
	AsyncMethodInvoker asyncMethodInvoker;
	
	@Inject
    @Named("write_behind_queue")
    Provider<Connection> connectionProvider;
	
	@Inject
    @Named("write_behind_queue.requestQueue")
    private String queueName;
	
	@Inject
	private WriteBehindMessageSerializer messageSerializer;
	
	@Inject
	@Named("JPAIdGenerator")
	ObjectIdGenerator objectIdGenerator;
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> getAll(DataKey dataKey) {
		if (dataKey == null || dataKey.getDomain() == null) {
			throw new RuntimeException("Empty DataKey!");
		}
		DataAccessContext dasContext = prepareDASContextForSearch(dataKey, null);

		if (dasContext.isDataInCache()) {
			return selectFromCache(dataKey.getDomain(), dasContext.getDataKeysFromCache());
		} else {
			throw new RuntimeException("Cannot find matched DataKeys from cache, get all from DB is not supported");
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> getAll(DataDomain domain) {
		DataAccessContext dasContext = prepareDASContextForSearch(new DefaultDataKey(domain, null, null), null);
		if (dasContext.isDataInCache()) {
			return selectFromCache(domain, dasContext.getDataKeysFromCache());
		} else {
			throw new RuntimeException("Cannot find matched DataKeys from cache, get all from DB is not supported");
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E get(DataDomain domain, K key) {
		return get(domain, null, key);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E get(DataDomain domain, TimeMark date, K key) {
		if (domain == null || key == null) {
			throw new RuntimeException("Empty domain or empty key can not be accepted!");
		}
		DataAccessContext dasContext = prepareDASContextForSearch(new DefaultDataKey(domain, date, null), null);
		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = selectFromCache(domain, dasContext.getDataKeysFromCache(), key);
		} else {
			results = selectFromDatabase(dasContext, Lists.newArrayList(key));
			results = getRawValueFromValueHolder(results);
		}
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View);
		return Iterables.getFirst(results, null);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> List<E> get(DataDomain domain, List<K> keys) {
		if (domain == null || CollectionUtils.isEmpty(keys)) {
			throw new RuntimeException("domain or keys can not be empty!");
		}
		DataAccessContext dasContext = prepareDASContextForSearch(new DefaultDataKey(domain, null, null), null);
		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = selectFromCache(domain, dasContext.getDataKeysFromCache(), keys);
		} else {
			results = selectFromDatabase(dasContext, keys);
			results = getRawValueFromValueHolder(results);
		}
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View);
		return (List<E>) results;
	}
	
	@SuppressWarnings("unchecked")
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> search(DataKey dataKey, Select<E> select) {
		if (dataKey == null || dataKey.getDomain() == null) {
			throw new RuntimeException("Empty DataKey!");
		}
		Collection<E> results;
		DataAccessContext dasContext = prepareDASContextForSearch(dataKey, null);
		if (dasContext.isDataInCache()) {
			if (select != null) {
				results = selectFromCache(dataKey.getDomain(), dasContext.getDataKeysFromCache(), combineSelect(true, select));
			} else {
				results = selectFromCache(dataKey.getDomain(), dasContext.getDataKeysFromCache());
			}
		} else {
			results = selectFromDatabase(dasContext, getCriteriaFromSelect(select), combineSelect(true, select));
			results = getRawValueFromValueHolder(results);
		}
		
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View);

		return results;
	}
	
	/**
	 * only for abstractquery#search
	 * @param dataKeys
	 * @param select
	 * @return
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> searchOnlyFromCache(Criteria criteria, Select<E> select) {
		DataDomain dataDomain = criteria.getDomain();
		if ( dataDomain == null ) {
			throw new RuntimeException("Empty DataKey!");
		}
		
		Collection<DataKey> dataKeys = getMatchedDataKeysByCriteria(dataDomain, criteria);
        if (isDataKeysEmpty(dataKeys)) {
            return Collections.emptyList();
        }
		
		Collection<E> results;
		if (select != null) {
			results = selectFromCache(dataDomain, dataKeys, combineSelect(true, select));
		} else {
			results = selectFromCache(dataDomain, dataKeys);
		}
		
		results = filterDataBySecurity(dataDomain.getDomainClass(), results, SecureAction.View);
		return results;
	}

	private boolean isDataKeysEmpty(Collection<DataKey> dataKeys) {
		boolean isEmpty = dataKeys.isEmpty();
		if (!isEmpty && dataKeys.size() == 1) {
			DataKey dataKey = dataKeys.iterator().next();
			isEmpty = dataKey.getTimeMark() == null && dataKey.getCreatedBy() == null;
		}		
		return isEmpty;
	}
	
	/**
	 * @deprecated to be refactored
	 */
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	@Override
	@Deprecated
	public <E extends IdentifiedBy<?>> Collection<E> search(DataDomain domain, Select<E> select) {
		SecuritySelect securitySelect = getSecuritySelect(domain.getDomainClass(), SecureAction.View);
		Select<E> combinedSelect = new ParallelSelect<>(combineSelect(false, select, securitySelect), 8, 200000, configuration.getInteger("query.task.timeout", 60));

		Collection<E> results;
		if (isDomainAvailableInCache(domain)){
	        results = cacheManager.search(domain, new ParallelSelect<E>(combinedSelect, 8, 200000, configuration.getInteger("query.task.timeout", 60)));
		}
		else {
			results = loadDomainWithSelect(domain, combinedSelect);
			results = getRawValueFromValueHolder(results);
		}
		return results;
	}

	/**
	 * @deprecated to be refactored
	 */
	@Deprecated
	private boolean isDomainAvailableInCache(DataDomain domain) {
        if(domain.equals(cacheManager.getCacheDomain()))
            return true;
        Set<DataKey> dataKeys = searchDataAvailabilities();
        for (DataKey dataKey : dataKeys) {
            if (domain.equals(dataKey.getDomain()))
                return true;
        }
        return false;
    }
	
	@SuppressWarnings("unchecked")
	@Override
	public <E extends IdentifiedBy<?>> Long count(Criteria<E> criteria) {
		if (criteria == null || criteria.getDomain() == null) {
			throw new RuntimeException("Illegal Criteria.");
		}

		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(criteria, null);

		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(),
					combineSelect(true, criteria.getSelect()));
		} else {
			returnCollection = this.selectFromDatabase(dasContext, criteria, null);
		}

		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);

		return (long) returnCollection.size();
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> select(E selectTemplate) {
		if (selectTemplate == null) {
			throw new RuntimeException("Illegal template.");
		}
		
		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelectTemplate(selectTemplate, null);
		
		Criteria<E> criteria = convertTemplateToCriteria(selectTemplate);
		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), combineSelect(true, criteria.getSelect(), null));
		} else {
			returnCollection = this.selectFromDatabase(dasContext, criteria, null);
			returnCollection = getRawValueFromValueHolder(returnCollection);
		}
		returnCollection = filterResultsByImplClass(returnCollection, ProxyHelper.getRawClass(selectTemplate));
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);

		return returnCollection;
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> select(Criteria<E> criteria, Select<E> specialSelect) {
		if (criteria == null || criteria.getDomain() == null) {
			throw new RuntimeException("Input criteria is null or criteria.getDomain() is null.");
		}

		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(criteria, null);

		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(),
					combineSelect(true, criteria.getSelect(), specialSelect));
		} else {
			returnCollection = this.selectFromDatabase(dasContext, criteria, specialSelect);
			returnCollection = getRawValueFromValueHolder(returnCollection);
		}

		returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);

		return returnCollection;
	}
	
	// FIXME there is inconsistent behavior selecting from db or cache when identifiers is an empty collection.
	// throw exception when the input parameters are incomplete.
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> Collection<E> select(Class<E> entityClass, Collection<K> identifiers) {
		if (entityClass == null) {
			return Collections.emptyList();
		} 
		
		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(entityClass, null);
		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), identifiers);
		} else {
			returnCollection = this.selectFromDatabase(dasContext, identifiers);
			returnCollection = getRawValueFromValueHolder(returnCollection);
		}
		returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);
		
		return returnCollection;
	}
	
	@SuppressWarnings({ "unchecked" })
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E selectOne(Class<E> entityClass, K identifier) {
		if (entityClass == null || identifier == null) {
			return null;
		}
		DataAccessContext dasContext = prepareDASContextForSelect(entityClass, null);

		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), identifier);
		} else {
			results = this.selectFromDatabase(dasContext, Lists.newArrayList(identifier));
			results = getRawValueFromValueHolder(results);
		}

		results = filterResultsByImplClass(results, dasContext.getDomainImplClass());
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View);
		
		if (results.size()>1) {
			LOGGER.warn("There are more than one result when selectOne for entityClass %s and id %s !" , entityClass.getName(), identifier.toString());
		}
		return Iterables.getFirst(results, null);
	}

	@Override
	@SuppressWarnings("unchecked")
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E selectOne(DataDomain<E> domain, K identifier) {
		if (domain == null || identifier == null) {
			return null;
		}
		DataAccessContext dasContext = prepareDASContextForSelect(domain, null);

		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), identifier);
		} else {
			results = this.selectFromDatabase(dasContext, Lists.newArrayList(identifier));
			results = getRawValueFromValueHolder(results);
		}

		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View);
		
		if (results.size()>1) {
			LOGGER.warn("There are more than one result when selectOne for domain %s and id %s !" , domain.getDomainClass().getName(), identifier.toString());
		}
		
		return Iterables.getFirst(results, null);
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> selectForUpdate(E selectTemplate) {
		if (selectTemplate == null) {
			throw new RuntimeException("Illegal template.");
		}

		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelectTemplate(selectTemplate, null);
		Criteria<E> criteria = convertTemplateToCriteria(selectTemplate);
		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(),
					combineSelect(true, criteria.getSelect(), null));
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
			returnCollection = filterResultsByImplClass(returnCollection, ProxyHelper.getRawClass(selectTemplate));
			returnCollection = resolveDeepCopy.lazyDeepCopy(returnCollection);
		} else {
			returnCollection = this.selectFromDatabase(dasContext, criteria, null);
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
			returnCollection = filterResultsByImplClass(returnCollection, ProxyHelper.getRawClass(selectTemplate));
		}
		
		return returnCollection;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> selectForUpdate(Criteria<E> criteria, Select<E> additionalSelect) {
		if (criteria == null || criteria.getDomain() == null) {
			return Collections.emptyList();
		}

		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(criteria, null);

		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(),
					combineSelect(true, criteria.getSelect(), additionalSelect));
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
			returnCollection = resolveDeepCopy.lazyDeepCopy(returnCollection);
		} else {
			returnCollection = this.selectFromDatabase(dasContext, criteria, additionalSelect);
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
		}

		return returnCollection;
	}

	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> Collection<E> selectForUpdate(Class<E> domainClass, Collection<K> identifiers ) {
		if (domainClass == null) {
			return Collections.emptyList();
		} 
		
		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(domainClass, null);
		if (dasContext.isDataInCache()) {
			returnCollection = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), identifiers);
			returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
			returnCollection = resolveDeepCopy.lazyDeepCopy(returnCollection);
		} else {
			returnCollection = this.selectFromDatabase(dasContext, identifiers);
			returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
			returnCollection = getRawValueFromValueHolder(returnCollection);
			returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View, SecureAction.Modify);
		}
		
		return returnCollection;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E selectOneForUpdate(Class<E> domainClass, K id) {
		if (domainClass == null || id == null) {
			return null;
		}
		DataAccessContext dasContext = prepareDASContextForSelect(domainClass, null);

		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), id);
		} else {
			results = this.selectFromDatabase(dasContext, Lists.newArrayList(id));
		}

		results = filterResultsByImplClass(results, dasContext.getDomainImplClass());
		results = getRawValueFromValueHolder(results);
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View, SecureAction.Modify);
		
		if (results.size()>1) {
			LOGGER.warn("There are more than one result when selectOne for entityClass %s and id %s !" , domainClass.getName(), id.toString());
		}
		E result = Iterables.getFirst(results, null);
		
		if (dasContext.isDataInCache()) {
			return (E) resolveDeepCopy.apply(result);
		} else {
			return result;
		}
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> E selectOneForUpdate(DataDomain<E> domain, K identifier) {
		if (domain == null || identifier == null) {
			return null;
		}
		DataAccessContext dasContext = prepareDASContextForSelect(domain, null);

		Collection<E> results;
		if (dasContext.isDataInCache()) {
			results = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), identifier);
		} else {
			results = this.selectFromDatabase(dasContext, Lists.newArrayList(identifier));	
		}

		results = getRawValueFromValueHolder(results);
		results = filterDataBySecurity(dasContext.getDomainClass(), results, SecureAction.View, SecureAction.Modify);
		
		if (results.size()>1) {
			LOGGER.warn("There are more than one result when selectOne for domain %s and id %s !" , domain.getDomainClass().getName(), identifier.toString());
		}
		
		E result = Iterables.getFirst(results, null);
		
		if (dasContext.isDataInCache()) {
			return (E) resolveDeepCopy.apply(result);
		} else {
			return result;
		}
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> selectFromDatabase(Criteria<E> criteria, Select<E> specialSelect) {
		if (criteria == null || criteria.getDomain() == null) {
			throw new RuntimeException("criteria or its domain should not be null");
		}

		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(criteria, null);
		returnCollection = this.selectFromDatabase(dasContext, criteria, specialSelect);

		returnCollection = getRawValueFromValueHolder(returnCollection);
		returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);
		return returnCollection;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> Collection<E> selectFromDatabase(E selectTemplate) {
		if (selectTemplate == null) {
			throw new RuntimeException("Illegal template.");
		}
		
		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelectTemplate(selectTemplate, null);
		Criteria<E> criteria = convertTemplateToCriteria(selectTemplate);
		returnCollection = this.selectFromDatabase(dasContext, criteria, null);
		
		returnCollection = getRawValueFromValueHolder(returnCollection);
		returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);
		return returnCollection;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = SelectDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> Collection<E> selectFromDatabase(Class<E> entityClass, Collection<K> identifiers) {
		if (entityClass == null) {
			return Collections.emptyList();
		} 
		
		Collection<E> returnCollection;
		DataAccessContext dasContext = prepareDASContextForSelect(entityClass, null);
		returnCollection = this.selectFromDatabase(dasContext, identifiers);
		
		returnCollection = getRawValueFromValueHolder(returnCollection);
		returnCollection = this.filterResultsByImplClass(returnCollection, dasContext.getDomainImplClass());
		returnCollection = filterDataBySecurity(dasContext.getDomainClass(), returnCollection, SecureAction.View);
		return returnCollection;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@InfraInvocation(showParametersValue=true, callable = InsertDataInvocationCallable.class)
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> create(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return entities;
		}
		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		Collection<E> results = Lists.newArrayList();
		
		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection storeResults;
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForCreate(Iterables.getFirst(originalData, null), null);
			
			if (!dasContext.isInsertable()) {
				throw new RuntimeException(
						"Cannot create entity, Please use com.citi.risk.core.lang.create.api.Create.getInstance() to create Domain instance");
			}
			
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Create);
			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}
			
			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache by given template");
				}

				storeResults = ((AbstractStorer)dasContext.getStorer()).storeObjects(filteredData);
				createToCache(storeResults, domainImplClassEntry.getKey(),
						Iterables.getFirst(dataKeysFromCache, null));
			} else {
				storeResults = ((AbstractStorer)dasContext.getStorer()).storeObjects(filteredData);
			}
			recordModifiedDomainForTestCase(dasContext.getDomainImplClass());
			results.addAll(storeResults);
		}
		
		return results;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@InfraInvocation(showParametersValue=true, callable = InsertDataInvocationCallable.class)
	@Override
	public <K, E extends IdentifiedBy<K> & KeyModifiable<K>> Collection<E> createWriteBehind(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return entities;
		}
		
		generateEntityID(entities);
		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		Multimap<Class,E> filteredEntitiesByImplClass = ArrayListMultimap.create();
		Collection<E> results = Lists.newArrayList();
		
		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection storeResults = null;
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForCreate(Iterables.getFirst(originalData, null), null);
			
			if (!dasContext.isInsertable()) {
				throw new RuntimeException(
						"Cannot create entity, Please use com.citi.risk.core.lang.create.api.Create.getInstance() to create Domain instance");
			}
			
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Create);
			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}
			filteredEntitiesByImplClass.putAll(domainImplClassEntry.getKey(),filteredData);
			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache by given template");
				}
				createToCache(storeResults, domainImplClassEntry.getKey(), Iterables.getFirst(dataKeysFromCache, null));
			} 
			results.addAll(filteredData);
		}
		
		pushToWriteBehindQueue(filteredEntitiesByImplClass, "Create");
		
		return results;
	}
	
	@Override
	public <E extends IdentifiedBy<?>> void generateEntityID(Collection<E> entities) {
		for (E entity : entities) {
			objectIdGenerator.generate(entity);
		}
	}
	
	@InfraInvocation(showParametersValue=true, callable = InsertDataInvocationCallable.class)
	@Override
	public <E extends IdentifiedBy<?>> E createOne(E entity) {
		if (entity == null) {
			return null;
		}
		Collection<E> storeResults = create(Arrays.asList(entity));
		return  Iterables.getFirst(storeResults, null);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@InfraInvocation(showParametersValue=true, callable = UpdateDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> Collection<E> update(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return entities;
		}

		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		Collection<E> results = Lists.newArrayList();

		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection updatedEntities;
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForUpdate(Iterables.getFirst(originalData, null), null);

			if (!dasContext.isUpdatable()) {
				throw new RuntimeException("target entities cannot be updated, use selectForUpdate before update");
			}
			
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Modify);

			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}

			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache by given template");
				}
				Collection<K> oldKeys = getIdentifiedByKeys(filteredData);
				updatedEntities = dasContext.getUpdater().update(filteredData);
				mergeToCache(updatedEntities, oldKeys, domainImplClassEntry.getKey(),
						Iterables.getFirst(dataKeysFromCache, null));
			} else {
				updatedEntities = dasContext.getUpdater().update(filteredData);
			}

			// TODO some tests will fail if remove this.
			recordModifiedDomainForTestCase(dasContext.getDomainImplClass());
			results.addAll(updatedEntities);
		}

		return results;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <K, E extends IdentifiedBy<K> & KeyModifiable<K>> Collection<E> updateWriteBehind(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return Collections.emptyList();
		}
		
		Collection<E> results = Lists.newArrayList();
		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		Multimap<Class, E> filteredEntitiesByImplClass = ArrayListMultimap.create();
		
		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForUpdate(Iterables.getFirst(originalData, null), null);

			if (!dasContext.isUpdatable()) {
				throw new RuntimeException("target entities cannot be updated, use selectForUpdate before update");
			}
			
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Modify);

			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}
			filteredEntitiesByImplClass.putAll(domainImplClassEntry.getKey(), filteredData);
			results.addAll(filteredData);
			
			Collection<K> oldKeys = getIdentifiedByKeys(filteredData);

			if (ManagedVersion.class.isAssignableFrom(Iterables.getFirst(filteredData, null).getClass())) {
				expireVersions(filteredData);
				for (E entity : filteredData) {
					((ManagedVersion) entity).incrementVersion();
					((JPAObjectIdGenerator) objectIdGenerator).generate(entity, true);
				}
			}

			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache for Domain Impl Class : " + domainImplClassEntry.getKey());
				}
				DataKey dataKey = Iterables.getFirst(dataKeysFromCache, null);
				mergeToCache(filteredData, oldKeys, domainImplClassEntry.getKey(), dataKey);
			} 

		}

		pushToWriteBehindQueue(filteredEntitiesByImplClass, "Update");
		
		return results;
	}
	
	private <K, E extends IdentifiedBy<K>> void expireVersions(Collection<E> entities) {
		TrxManager trxManager = ExecutionContexts.getCurrentExecutionContext().getTrxManager();
		if (trxManager == null) {
			trxManager = injector.getInstance(DefaultTrxManager.class);
		}
		TrxStatus status = null;
		try {
			Class<? extends IdentifiedBy> entityClass = Iterables.getFirst(entities, null).getClass();
			status = trxManager.begin(entityClass, true);
			for (E entity : entities) {
				new HibernateExpireDomain(entityClass, injector)
						.entityManager(status.getEntityManager())
						.expire((ManagedVersion)entity)
						.lock(LockMode.OPTIMISTIC)
						.writeBehind()
						.execute();
			}
			status.getEntityManager().flush();
			trxManager.commit(status);
		} catch (Exception ta) {
			if (status != null) {
				trxManager.rollback(status);
			}
			throw ta;
		}
		
	}
	
	private <E> void pushToWriteBehindQueue(Multimap<Class, E> filteredEntitiesByImplClass, String type) {
        try {
			injector.getInstance(WriteBehindMessageListener.class);
			Class domainClass = domainImplHelper.getDomainByImplClass(filteredEntitiesByImplClass.keySet().iterator().next()).getDomainClass();
        	Session session = connectionProvider.get().createSession(false, Session.AUTO_ACKNOWLEDGE);
    		Queue writeBehindQueue = session.createQueue(queueName + "." + domainClass.getSimpleName());
            MessageProducer messageProducer = session.createProducer(writeBehindQueue);
    		BytesMessage message = session.createBytesMessage();
    		message.writeBytes(messageSerializer.serializeMessage(filteredEntitiesByImplClass));
    		message.setJMSType(type);
    		message.setStringProperty("environment", configuration.getEnvironment().getShortString());
            messageProducer.send(message);
            LOGGER.debug("message :: " + message.getJMSMessageID());
            LOGGER.debug("environmentString :: " + configuration.getEnvironment().getShortString());
            session.close();
        } catch (JMSException jmse) {
        	throw new RuntimeException("Error sending write behind message to jms queue", jmse);
        }
	}

	/**
	 * @deprecated not support
	 */
	@SuppressWarnings({ "unchecked" })
	@Deprecated
	@Override
	@InfraInvocation(showParametersValue=true, callable = UpdateDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> Collection<E> update(E selectTemplate, E updateTemplate) {
		Collection<E> results;
		DataAccessContext dasContext = prepareDASContextForUpdate(selectTemplate, null);

		if (dasContext.isDataInCache()) {
			Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
			if (dataKeysFromCache.size() != 1) {
				throw new RuntimeException("There are more than one DataKey found in Cache by given template");
			}

			Collection<E> dataInCache = selectForUpdate(selectTemplate);
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), dataInCache,
					SecureAction.Modify);

			if (CollectionUtils.isEmpty(filteredData)) {
				return filteredData;
			}
			Collection<K> oldKeys = getIdentifiedByKeys(filteredData);
			results = dasContext.getUpdater().update(filteredData, updateTemplate);

			DataKey dataKey = Iterables.getFirst(dataKeysFromCache, null);
			getLoaderAndResolve(dasContext.getLoaderClass(), results, dataKey);
			mergeToCache(results, oldKeys, dasContext.getDomainImplClass(), dataKey);
		} else {
			results = dasContext.getUpdater().update(selectTemplate, updateTemplate);
			getLoaderAndResolve(dasContext.getLoaderClass(), results,
					new DefaultDataKey(dasContext.getDataDomain(), null, null));
		}

		return results;
	}
	
	@SuppressWarnings({ "unchecked" })
	@InfraInvocation(showParametersValue=true, callable = UpdateDataInvocationCallable.class)
	@Override
	public <K, E extends IdentifiedBy<K>> Collection<E> update(E updateTemplate, Collection<K> identifiers) {
		if (CollectionUtils.isEmpty(identifiers)) {
			return Collections.emptyList();
		}
		Collection<E> results;
		DataAccessContext dasContext = prepareDASContextForUpdate(updateTemplate, null);
		if (dasContext.isDataInCache()) {
			Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
			if (dataKeysFromCache.size() != 1) {
				throw new RuntimeException("There are more than one DataKey found in Cache by given template");
			}

			Collection<E> dataInCache = selectForUpdate(dasContext.getDomainImplClass(), identifiers);
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), dataInCache,
					SecureAction.Modify);

			if (CollectionUtils.isEmpty(filteredData)) {
				return filteredData;
			}

			Collection<K> oldKeys = getIdentifiedByKeys(filteredData);
			results = dasContext.getUpdater().update(filteredData, updateTemplate);

			DataKey dataKey = Iterables.getFirst(dataKeysFromCache, null);
			getLoaderAndResolve(dasContext.getLoaderClass(), results, dataKey);
			mergeToCache(results, oldKeys, dasContext.getDomainImplClass(), dataKey);
		} else {
			results = dasContext.getUpdater().update(updateTemplate, identifiers);
			getLoaderAndResolve(dasContext.getLoaderClass(), results,
					new DefaultDataKey(dasContext.getDataDomain(), null, null));
		}
		
		return results;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = DeleteDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> void delete(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return;
		}

		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		
		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForDelete(Iterables.getFirst(originalData, null), null);
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Remove);

			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}
			
			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache by given template");
				}

				Collection oldKeys = getIdentifiedByKeys((Collection)filteredData);
				Collection currentValueHolders = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), oldKeys);
				ExecutionContexts.getCurrentExecutionContext().getDomainModifyContext().setRollbackItems(domainImplClassEntry.getKey(), currentValueHolders);
				
				dasContext.getDeleter().delete(filteredData);
				removeFromCache(filteredData, oldKeys, dasContext.getDomainImplClass(),
						Iterables.getFirst(dataKeysFromCache, null));
			} else {
				dasContext.getDeleter().delete(filteredData);
			}
			
			recordModifiedDomainForTestCase(dasContext.getDomainImplClass());
		}
	}
	
	@Override
	public <K,E extends IdentifiedBy<K> & KeyModifiable<?>> void deleteWriteBehind(Collection<E> entities) {
		if (CollectionUtils.isEmpty(entities)) {
			return;
		}

		Map<Class, Collection<E>> entitiesByImplClass = groupEntities(entities);
		Multimap<Class,E> filteredEntitiesByImplClass =ArrayListMultimap.create();
		
		for (Entry<Class, Collection<E>> domainImplClassEntry : entitiesByImplClass.entrySet()) {
			Collection<E> originalData = domainImplClassEntry.getValue();
			DataAccessContext dasContext = prepareDASContextForDelete(Iterables.getFirst(originalData, null), null);
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), originalData, SecureAction.Remove);

			if (CollectionUtils.isEmpty(filteredData)) {
				continue;
			}
			filteredEntitiesByImplClass.putAll(domainImplClassEntry.getKey(), filteredData);
			
			Collection oldKeys = getIdentifiedByKeys((Collection)filteredData);
			
			if (ManagedVersion.class.isAssignableFrom(Iterables.getFirst(filteredData, null).getClass())) {
				expireVersions(filteredData);
				for (E entity : filteredData) {
					((ManagedVersion) entity).incrementVersion();
					((JPAObjectIdGenerator) objectIdGenerator).generate(entity, true);
				}
			}

			if (dasContext.isDataInCache()) {
				Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
				if (dataKeysFromCache.size() != 1) {
					throw new RuntimeException("There are more than one DataKey found in Cache by given template");
				}
				
				DataKey dataKey = Iterables.getFirst(dataKeysFromCache, null);
				Collection currentValueHolders = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), oldKeys);
				ExecutionContexts.getCurrentExecutionContext().getDomainModifyContext().setRollbackItems(domainImplClassEntry.getKey(), currentValueHolders);
				removeFromCache(filteredData, oldKeys, dasContext.getDomainImplClass(),dataKey);
			}
			
		}

		pushToWriteBehindQueue(filteredEntitiesByImplClass, "Delete");
	}
	
	@Override
	@InfraInvocation(showParametersValue=true, callable = DeleteDataInvocationCallable.class)
	public <E extends IdentifiedBy<?>> void delete(E selectTemplate) {
		Collection results = selectForUpdate(selectTemplate);
		delete(results);
	}
	
	@Override
	@InfraInvocation(showParametersValue=true)
	public <E extends IdentifiedBy<?>> void delete(Criteria<E> criteria, Select<E> additionalSelect) {
		Collection<E> results = selectForUpdate(criteria, additionalSelect);
		delete(results);
	}

	@SuppressWarnings("unchecked")
	@Override
	@InfraInvocation(showParametersValue=true, callable = DeleteDataInvocationCallable.class)
	public <K, E extends IdentifiedBy<K>> void delete(Class<E> domainClass, Collection<K> identifiers) {
		Class<E> rawClass = ProxyHelper.getRawClassFromGuiceProxy(domainClass);
		if (rawClass.isInterface()) {
			DataDomain<E> domain = parser.parseDomain(domainClass);
			if (domain.getDomainImplClasses() == null || domain.getDomainImplClasses().length==0) {
				throw new RuntimeException("the domain "+domain.getDomainClassString()+" should be annotated with impl class on @DDD");
			}
			for (Class implClass : domain.getDomainImplClasses() ) {
				deleteByImplClass(implClass, identifiers);
			}
		} else {
			deleteByImplClass(rawClass, identifiers);
		}
	}
	
	private <K, E extends IdentifiedBy<K>> void deleteByImplClass(Class<E> domainImplClass, Collection<K> identifiers) {
		DataAccessContext dasContext = prepareDASContextForDelete(domainImplClass, null);
		
		if (dasContext.isDataInCache()) {
			Collection<DataKey> dataKeysFromCache = dasContext.getDataKeysFromCache();
			if (dataKeysFromCache.size() != 1) {
				throw new RuntimeException("There are more than one DataKey found in Cache by given template");
			}
			Collection<E> dataInCache = selectForUpdate(domainImplClass, identifiers);
			Collection<E> filteredData = filterDataBySecurity(dasContext.getDomainClass(), dataInCache, SecureAction.Remove);

			Collection<K> oldKeys = getIdentifiedByKeys(filteredData);
			Collection currentValueHolders = this.selectFromCache(dasContext.getDataDomain(), dasContext.getDataKeysFromCache(), oldKeys);
			ExecutionContexts.getCurrentExecutionContext().getDomainModifyContext().setRollbackItems(domainImplClass, currentValueHolders);
			dasContext.getDeleter().delete(filteredData);
			removeFromCache(filteredData, oldKeys, dasContext.getDomainImplClass(),
					Iterables.getFirst(dataKeysFromCache, null));
		} else {
			dasContext.getDeleter().delete(dasContext.getDomainImplClass(), identifiers);
		}
		if (dasContext.getDomainImplClass() != null) {
			recordModifiedDomainForTestCase(dasContext.getDomainImplClass());
		}
	}
	
	@Override
	public DataKey getBestAvailableDataKey(DataDomain<?> domain) {
		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, BatchFrequency.Daily, null);
		if (CollectionUtils.isNotEmpty(dataKeys)) {
			return DefaultDataKey.cloneDataKey(Iterables.getFirst(dataKeys, null));
		}
		return null;
	}

	@Override
	public DataKey getBestAvailableDataKey(DataDomain<?> domain, BatchFrequency frequency) {
		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, frequency, null);
		if (CollectionUtils.isNotEmpty(dataKeys)) {
			return DefaultDataKey.cloneDataKey(Iterables.getFirst(dataKeys, null));
		}
		return null;
	}

	@Override
	public DataKey getBestAvailableDataKey(DataDomain<?> domain, Class<?> domainImplClass, BatchFrequency frequency) {
		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, frequency, domainImplClass);
		if (CollectionUtils.isNotEmpty(dataKeys)) {
			return DefaultDataKey.cloneDataKey(Iterables.getFirst(dataKeys, null));
		}
		return null;
	}
	
	@Override
	public Set<DataKey> searchDataAvailabilities() {
		return cacheManager.searchDataAvailabilities();
	}
	
	@Override
	public Set<DataKey> searchDataAvailabilities(TimeMark timeMark) {
		return cacheManager.searchDataAvailabilities(timeMark);
	}

	@Override
	public Criteria newBestAvailableCriteria(DataDomain domain) {
		return newBestAvailableCriteria(domain, BatchFrequency.Daily);
	}

	@Override
	public Criteria newBestAvailableCriteria(DataDomain domain, BatchFrequency frequency) {
		BatchFrequency batchFrequency = frequency == null ? BatchFrequency.Daily : frequency;
        parser.parseDomain(TimeMark.class);
        DataPath<TimeMark, Boolean> isBestAvailablePath = create.getInstance(TimeMarkPath.BestAvailable.class);
		DataPath<TimeMark, String> batchFrequencyPath = create.getInstance(TimeMarkPath.BatchFrequencyString.class);
		DataRelationship relationship = domain.getRelationship("Time mark");
        Criteria criteria1 = relationship.append(isBestAvailablePath).eq(true);
        Criteria criteria2 = relationship.append(batchFrequencyPath).eq(batchFrequency.name());
        return criteria1.and(criteria2);
	}

	/**
	 * @deprecated not support
	 */
	@Override
	@Deprecated
	public TimeMark newBestAvailableTimeMark(DataDomain domain) {
		return newBestAvailableTimeMark(domain, BatchFrequency.Daily);
	}

	/**
	 * @deprecated not support
	 */
	@Override
	@Deprecated
	public TimeMark newBestAvailableTimeMark(DataDomain domain, BatchFrequency frequency) {
		return cacheManager.getBestAvailableTimeMark(domain, frequency);
	}
	
	@Override
	public void markModifications() {
		//intentionally-blank override
	}

	@Override
	public void unmarkModifications() {
		//intentionally-blank override
	}

	@Override
	public Collection<Class<?>> getModifiedDomains() {
		return Collections.emptyList();
	}

	@Override
	@InfraInvocation(showParametersValue=true)
	public <T extends IdentifiedBy<?>> Future<Collection<T>> makeDeepCopy(final Collection<T> objects) {
		return new Future<Collection<T>>() {
			private boolean isDone = true;

			@Override
			public boolean cancel(boolean mayInterruptIfRunning) {
				return false;
			}

			@Override
			public boolean isCancelled() {
				return false;
			}

			@Override
			public boolean isDone() {
				return this.isDone;
			}

			@Override
			public Collection<T> get() throws InterruptedException,	ExecutionException {
				return deepCopy(objects);
			}

			@Override
			public Collection<T> get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
				return deepCopy(objects);
			}
			
			private Collection<T> deepCopy(final Collection<T> objects) {
				try {
					return resolveDeepCopy.deepCopy(objects);
				} catch (Exception t) {
					this.isDone = false;
					throw t;
				}
			}
		};
	}
	
	@Override
	@InfraInvocation(showParametersValue=true)
	public <K, E extends IdentifiedBy<K>> Collection<E> execute(Collection<E> domains,
			Class<? extends MapperCallback<K, E>> callbackClass) {
		MapperCallback<K, E> callBack = injector.getInstance(callbackClass);
		return callBack.execute(domains);
	}
	
	@Override
	@InfraInvocation(showParametersValue=true)
	public <K, T extends IdentifiedBy<K>> Collection<T> selectFromIndex(DataDomain<T> domain, String pattern) {
		if (domain == null || Strings.isNullOrEmpty(pattern)) {
			return Collections.emptyList();
		}
		
		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, null, null);
		if(CollectionUtils.isEmpty(dataKeys)) {
			return Collections.emptyList();
		}
		
		Collection<T> results = Lists.newArrayList();
		for (DataKey dataKey : dataKeys) {
			CacheAccessor<K, T> cacheAccessor = cacheManager.getCache(dataKey);
			Collection<T> result = cacheAccessor.search(pattern);
			results.addAll(result);
		}
		return results;
	}
	
	@Override
	@InfraInvocation(showParametersValue=true)
	public <K, T extends IdentifiedBy<K>> Collection<T> getFromIndex(DataDomain<T> domain, TimeMark timeMark, String pattern) {
		if (domain == null || Strings.isNullOrEmpty(pattern)) {
			return Collections.emptyList();
		}
		
		Collection<DataKey> dataKeys = getMatchedDataKeys(domain, timeMark, null);
		if(CollectionUtils.isEmpty(dataKeys)) {
			return Collections.emptyList();
		}
		
		Collection<T> results = Lists.newArrayList();
		for (DataKey dataKey : dataKeys) {
			CacheAccessor<K, T> cacheAccessor = cacheManager.getCache(dataKey);
			Collection<T> result = cacheAccessor.search(pattern);
			results.addAll(result);
		}
		return results;
	}
	
}
