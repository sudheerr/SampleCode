package com.citi.risk.core.data.service.impl;

import java.util.Arrays;
import java.util.Collection;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.store.api.BusinessDays;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.IOSpecification;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.data.store.impl.DefaultDataKey;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Singleton;

@Singleton
public class StitchReferenceResolver<F extends IdentifiedBy<?>> implements Function<F, F>{
	@Inject
	private DictionaryParser parser;

	@Inject
	private CacheManager cacheManager;

	@Inject
	private DomainImplParser domainImplParser;

	@Inject
	private BusinessDays businessDays;

	@Inject
	private Injector injector;

	public <T extends IdentifiedBy<?>> void resolveReferenceForEntity(T object) {
		if (object == null) {
			return;
		}

		Class<?> rawClass = ProxyHelper.getRawClassFromGuiceProxy(object.getClass());
		IOSpecification ioSpecification = getIOSpecification(rawClass);
		if (null == ioSpecification) {
			throw new NullPointerException("IOSpec is missed with class: [" + rawClass + "]");
		}

		Collection<T> results = Arrays.asList(object);
		DataKey dataKey = getDataKey(results);
		getLoaderAndResolve(dataKey.getCreatedBy().getLoaderClass(), results, dataKey);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private <T extends IdentifiedBy<?>> void getLoaderAndResolve(Class loaderClass, Collection<T> results, DataKey dataKey) {

		if (loaderClass != null && !loaderClass.isInterface()) {
			Collection identifiers = Lists.newArrayList();
			for (T entity : results) {
				if (entity != null) {
					identifiers.add(entity.key());
				}
			}

			ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();;
			try
			{
				AbstractLoader correspondingLoader = (AbstractLoader) injector.getInstance(loaderClass);
				correspondingLoader.setIsInTheContextOfService(true);
				executionContext.setCurrentLoader(correspondingLoader);
				correspondingLoader.setCreatedBy(dataKey.getCreatedBy());
				correspondingLoader.setTimeMark(dataKey.getTimeMark());
				correspondingLoader.setIdentifiers(identifiers);
				correspondingLoader.resolve(results);
			}
			finally
			{
				executionContext.setCurrentLoader(null);
			}
		}
	}

	private <T extends IdentifiedBy<?>> DataKey getDataKey(Collection<T> entitiesOfCurrentImpl) {
		T entitie = Iterables.getFirst(entitiesOfCurrentImpl, null);
		return getDataKey(entitie);
	}

	private <T extends IdentifiedBy<?>> DataKey getDataKey(T entity) {
		DataDomain domain = getDomainFromInstance(entity);
		TimeMark timeMark = buildTimeMark(domain, entity);

		CreatedBy createdBy = buildCreateBy(domain, entity);

		DataKey dataKey = new DefaultDataKey(domain, timeMark, createdBy);

		return dataKey;
	}

	private <T extends IdentifiedBy<?>> TimeMark buildTimeMark(DataDomain domain, T entity) {
		TimeMark timeMark = entity.getTimeMark();
		if (NullTerminator.isTimeMarkNullTerminated(timeMark)) {
			timeMark = newBestAvailableTimeMark(domain, BatchFrequency.Daily);
			if(timeMark == null) {
				timeMark= getCurrentBusinessDayTimeMark();
			}
		}
		return timeMark;
	}

	private <T extends IdentifiedBy<?>> CreatedBy buildCreateBy(DataDomain domain, T entity) {
		Class<? extends IdentifiedBy> domainImplClass = ProxyHelper.getRawClassFromGuiceProxy(entity.getClass());
		Class<? extends Loader> loaderClass = getIOSpecification(domainImplClass).getActiveLoaderClass();

		CreatedBy createdBy = entity.getCreatedBy();

		if (NullTerminator.isCreatedByNullTerminated(createdBy)) {
			createdBy = cacheManager.getBestAvailableCreatedBy(domain, loaderClass);
			if (createdBy == null) {
				createdBy = new DefaultCreatedBy().withLoaderClass(loaderClass);
			}
		} else {
			createdBy = createdBy.withLoaderClass(loaderClass);
		}
		return createdBy;
	}

	private TimeMark newBestAvailableTimeMark(DataDomain domain, BatchFrequency frequency) {
		return cacheManager.getBestAvailableTimeMark(domain, frequency);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private <T> DataDomain getDomainFromInstance(T instance) {
		Class<? extends Object> implClass = ProxyHelper.getRawClass(instance);
		IOSpecification iOSpecification = getIOSpecification(implClass);
		Class<?>[] doaminClasses = iOSpecification.getDomainClasses();

		DataDomain domain = null;
		if (doaminClasses != null && doaminClasses.length > 0) {
			domain = parser.parseDomain(doaminClasses[0]);
		}

		if (domain == null) {
			throw new RuntimeException("Template " + implClass + " is not a valid domain.");
		}
		return domain;
	}

	private TimeMark getCurrentBusinessDayTimeMark()
	{
		TimeMark  timeMark = businessDays.getCurrentBusinessPeriodFor(BatchFrequency.Daily);
		TimeMark currentBusinessDayTimeMark = DefaultTimeMark.cloneTimeMark(timeMark);
		currentBusinessDayTimeMark.setBestAvailable(true);
		return currentBusinessDayTimeMark;
	}

	private IOSpecification getIOSpecification(Class<?> clazz) {
		DomainImplSpecification domainImplSpecification = domainImplParser.parse(clazz);
		if (null == domainImplSpecification) {
			return null;
		}
		IOSpecification iOSpecification = domainImplSpecification.getIOSpecification();
		return iOSpecification;
	}

	@Override
	public F apply(F input) {
		resolveReferenceForEntity(input);
		return input;
	}

}
