package com.citi.risk.core.data.service.impl;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.service.api.Deleter;
import com.citi.risk.core.data.service.api.Updater;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.data.store.impl.DefaultDatabaseDataKey;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;

class DataAccessContext {

	private Class domainClass;
	private Class domainImplClass;
	private Class loaderClass;
	private DataDomain dataDomain;
	private Storer storer;
	private Updater updater;
	private Deleter deleter;

	private Collection<DataKey> dataKeysFromCache;
	private boolean insertable;
	private boolean updatable;
	private boolean domainLifeCyclable;

	private TimeMark timeMark;
	private CreatedBy createdBy;
	private Criteria criteria;

	public Class getDomainClass() {
		return domainClass;
	}

	public void setDomainClass(Class domainClass) {
		this.domainClass = domainClass;
	}

	public Class getDomainImplClass() {
		return domainImplClass;
	}

	public void setDomainImplClass(Class domainImplClass) {
		this.domainImplClass = domainImplClass;
	}

	public DataDomain getDataDomain() {
		return dataDomain;
	}

	public void setDataDomain(DataDomain dataDomain) {
		this.dataDomain = dataDomain;
	}

	public Storer getStorer() {
		return storer;
	}

	public void setStorer(Storer storer) {
		this.storer = storer;
	}

	public Updater getUpdater() {
		return updater;
	}

	public void setUpdater(Updater updater) {
		this.updater = updater;
	}

	public Deleter getDeleter() {
		return deleter;
	}

	public void setDeleter(Deleter deleter) {
		this.deleter = deleter;
	}

	public Class getLoaderClass() {
		return loaderClass;
	}

	public void setLoaderClass(Class loaderClass) {
		this.loaderClass = loaderClass;
	}

	public Collection<DataKey> getDataKeysFromCache() {
		return dataKeysFromCache;
	}

	public void setDataKeysFromCache(Collection<DataKey> dataKeysFromCache) {
		this.dataKeysFromCache = dataKeysFromCache;
	}

	public TimeMark getTimeMark() {
		return timeMark;
	}

	public void setTimeMark(TimeMark timeMark) {
		this.timeMark = timeMark;
	}

	public CreatedBy getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(CreatedBy createdBy) {
		this.createdBy = createdBy;
	}

	public Criteria getCriteria() {
		return criteria;
	}

	public void setCriteria(Criteria criteria) {
		this.criteria = criteria;
	}

	public boolean isDataInCache() {
		return dataKeyExist() && !isDBKey();
	}
	
	public void setInsertable(boolean insertable) {
		this.insertable = insertable;
	}

	public void setUpdatable(boolean modifiable) {
		this.updatable = modifiable;
	}

	public void setDomainLifeCyclable(boolean domainLifeCyclable) {
		this.domainLifeCyclable = domainLifeCyclable;
	}

	public boolean isInsertable() {
		return this.domainLifeCyclable ? this.insertable : true;
	}

	public boolean isUpdatable() {
		return this.domainLifeCyclable ? this.updatable : true;
	}

	private boolean dataKeyExist() {
		return CollectionUtils.isNotEmpty(dataKeysFromCache);
	}

	private boolean isDBKey() {
		return dataKeysFromCache != null && dataKeysFromCache.size() == 1
				&& dataKeysFromCache.iterator().next() instanceof DefaultDatabaseDataKey;
	}
}
