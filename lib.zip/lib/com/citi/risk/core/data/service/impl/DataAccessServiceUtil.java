package com.citi.risk.core.data.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.springframework.util.ClassUtils;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMarkPath;
import com.citi.risk.core.lang.create.api.Create;
import com.google.common.base.Function;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public class DataAccessServiceUtil {

	@Inject
	private static Create create;

	private DataAccessServiceUtil() {
	}
	
	public static class ConvertInstance2Domain<T> implements Function<T, DataDomain> {
		private DictionaryParser parser;

		public ConvertInstance2Domain(DictionaryParser dictionaryParser) {
			this.parser = dictionaryParser;
		}

		@Override
		public DataDomain apply(T instance) {
			@SuppressWarnings("rawtypes")
			ConvertInstance2DomainInterface converter = new ConvertInstance2DomainInterface(parser);
			@SuppressWarnings("unchecked")
			Class<?> domainInterface = converter.apply(instance);
			if(domainInterface == null) return null;
			return parser.parseDomain(domainInterface);
		}
	}

	public static class ConvertInstance2DomainInterface<T> implements Function<T, Class<?>> {
		private DictionaryParser parser;

		public ConvertInstance2DomainInterface(DictionaryParser dictionaryParser) {
			this.parser = dictionaryParser;
		}

		@Override
		public Class<?> apply(T instance) {
			List<Class<?>> allImplementedDomains = new ArrayList<>();
			List<Class<?>> allSuperInterfaces = new ArrayList<>();
			List<Class<?>> allNonSuperInterfaces = new ArrayList<>();

			// find all interfaces, including the ones implemented by template's superclasses
			Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(instance.getClass());
			for(Class<?> nextInterface : interfaces) {
				if(parser.parseDomain(nextInterface) == null)
					continue;
				allImplementedDomains.add(nextInterface);
				allSuperInterfaces.addAll(Arrays.asList(nextInterface.getInterfaces()));
			}

			// if template implements only one domain, return it.
			if(allImplementedDomains.size() == 1)
				return allImplementedDomains.get(0);

			// Remove all interfaces which are one of the super interfaces
			for(Class<?> implementedDomain : allImplementedDomains) {
				if(!allSuperInterfaces.contains(implementedDomain))
					allNonSuperInterfaces.add(implementedDomain);
			}

			// find the interface which is implemented only by the given template
			for(Class<?> nonSuperInterface : allNonSuperInterfaces) {
				Set<?> subTypes = NullTerminator.REFLECTIONS.getSubTypesOf(nonSuperInterface);
				if(subTypes.size() == 1 && subTypes.contains(instance.getClass()))
					return nonSuperInterface;
			}

			return null;
		}

	}
	
}
