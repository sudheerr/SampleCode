package com.citi.risk.core.data.service.impl;

import java.util.logging.Logger;

import com.citi.risk.core.data.service.api.Deleter;
import com.citi.risk.core.data.store.api.DataStoreType;
import com.citi.risk.core.data.store.api.WriteMode;
import com.citi.risk.core.data.store.cache.impl.CacheDeleter;
import com.citi.risk.core.data.store.impl.JpaDeleter;
import com.citi.risk.core.data.store.impl.MongoDeleter;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.inject.Inject;
import com.google.inject.Injector;

public class DeleterProvider {
	@Inject
	private Injector injector;
	@Inject
	Logger logger;
	@SuppressWarnings("unchecked")
	public Deleter getDeleter(DataStoreType storeType) {
		
	    if (DataStoreType.CACHE.equals(storeType)) {
			CacheDeleter cacheDeleter = injector.getInstance(CacheDeleter.class);
			return cacheDeleter;
		}

        if (DataStoreType.MONGO.equals(storeType)) {
            MongoDeleter mongoDeleter = injector.getInstance(MongoDeleter.class);
            return mongoDeleter;
        }

        if (storeType != null && storeType.isSupportsJPA()) {         
            return injector.getInstance(JpaDeleter.class);
        }

		return null;
	}
}
