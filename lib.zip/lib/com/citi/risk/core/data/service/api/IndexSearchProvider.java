package com.citi.risk.core.data.service.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;

public interface IndexSearchProvider {
	/**
	 * only for Cache
	 * get collection matched entities for the given domain and pattern from cache index. 
	 * 
	 * @param domain target domain of the entity which should not be empty
	 * @param pattern pattern to match
	 * @return collection entity to be returned. return null if entity is not find in index.
	 */
	<K, T extends IdentifiedBy<K>> Collection<T> selectFromIndex(DataDomain<T> domain, String pattern);
	
	/**
	 * only for Cache
	 * get collection matched entities for the given domain, timeMark and pattern from cache index. 
	 * 
	 * @param domain target domain of the entity which should not be empty
	 * @param timeMark   date to search by, represented by TimeMark interface
	 * @param pattern pattern to match
	 * @return collection entity to be returned. return null if entity is not find in index.
	 */
	<K, T extends IdentifiedBy<K>> Collection<T> getFromIndex(DataDomain<T> domain, TimeMark timeMark, String pattern);
}
