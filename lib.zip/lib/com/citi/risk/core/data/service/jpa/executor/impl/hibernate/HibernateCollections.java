package com.citi.risk.core.data.service.jpa.executor.impl.hibernate;
 
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import org.hibernate.SessionFactory;
import org.hibernate.collection.internal.PersistentBag;
import org.hibernate.collection.internal.PersistentList;
import org.hibernate.collection.internal.PersistentMap;
import org.hibernate.collection.internal.PersistentSet;
import org.hibernate.collection.internal.PersistentSortedMap;
import org.hibernate.collection.internal.PersistentSortedSet;
import org.hibernate.persister.entity.SingleTableEntityPersister;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.hibernate.type.BagType;
import org.hibernate.type.ListType;
import org.hibernate.type.MapType;
import org.hibernate.type.SetType;
import org.hibernate.type.SortedMapType;
import org.hibernate.type.SortedSetType;

import com.citi.risk.core.lang.collection.list.Lists;
import com.citi.risk.core.lang.collection.map.Maps;
import com.citi.risk.core.lang.collection.set.Sets;
 
public class HibernateCollections {
	
	private HibernateCollections() {
	}
 
	public static void clearPersistentCollection(SessionFactory sessionFactory, Object entity) {
		SingleTableEntityPersister singleTableEntityPersister = 
				(SingleTableEntityPersister)sessionFactory.getClassMetadata(entity.getClass());
		if (singleTableEntityPersister == null) {
			return;
		}
		EntityMetamodel entityMetamodel = singleTableEntityPersister.getEntityMetamodel();
		int index = 0;
		for(org.hibernate.type.Type type : entityMetamodel.getPropertyTypes()) {
			if (type.isCollectionType()) {
				if (type.getClass() == SetType.class) {
					Set set = (Set)entityMetamodel.getTuplizer().getPropertyValue(entity, index);
					clearPersistentCollection(sessionFactory, set);
					if (set != null && set.getClass() == PersistentSet.class) {
						entityMetamodel.getTuplizer().setPropertyValue(entity, index, Sets.newHashSet(set));
					}
				} else if (type.getClass() == SortedSetType.class) {
					SortedSet set = (SortedSet)entityMetamodel.getTuplizer().getPropertyValue(entity, index);
					clearPersistentCollection(sessionFactory, set);
					if (set != null && set.getClass() == PersistentSortedSet.class ) {
						entityMetamodel.getTuplizer().setPropertyValue(entity, index, new TreeSet(set));
					}
				} else if (type.getClass() == BagType.class || type.getClass() == ListType.class) {
					Collection collection = (Collection)entityMetamodel.getTuplizer().getPropertyValue(entity, index);
					clearPersistentCollection(sessionFactory, collection);
					if (collection != null && (collection.getClass() == PersistentBag.class || collection.getClass() == PersistentList.class) ) {
						entityMetamodel.getTuplizer().setPropertyValue(entity, index, Lists.newArrayList(collection));
					}
				} else if (type.getClass() == MapType.class) {
					Map map = (Map)entityMetamodel.getTuplizer().getPropertyValue(entity, index);
					clearPersistentMap(sessionFactory, map);
					if (map != null && map.getClass() == PersistentMap.class ) {
						entityMetamodel.getTuplizer().setPropertyValue(entity, index, Maps.newHashMap(map));
					}
				} else if (type.getClass() == SortedMapType.class) {
					SortedMap map = (SortedMap)entityMetamodel.getTuplizer().getPropertyValue(entity, index);
					clearPersistentMap(sessionFactory, map);
					if (map != null && map.getClass() == PersistentSortedMap.class ) {
						entityMetamodel.getTuplizer().setPropertyValue(entity, index, new TreeMap(map));
					}
				}
			} else if (type.isAssociationType()) {
				Object associationObject = entityMetamodel.getTuplizer().getPropertyValue(entity, index);
				if (associationObject != null) {
					clearPersistentCollection(sessionFactory, associationObject);
				}
			}
			index++;
		}
	}
	
	private static void clearPersistentCollection(SessionFactory sessionFactory, Collection collection) {
		for(Object entity : collection) {
			clearPersistentCollection(sessionFactory, entity);
		}
	}
	
	private static void clearPersistentMap(SessionFactory sessionFactory, Map map) {
		for(Object entity : map.values()) {
			clearPersistentCollection(sessionFactory, entity);
		}
	}
 
}
