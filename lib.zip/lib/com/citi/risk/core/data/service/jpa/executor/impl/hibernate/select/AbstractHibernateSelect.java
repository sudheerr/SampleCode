package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.annotations.QueryHints;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.service.jpa.VersionExpiredException;
import com.citi.risk.core.data.service.jpa.VersionMortal;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.HibernateTxStep;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.Template;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.google.common.collect.Lists;
import com.google.inject.Injector;

public abstract class AbstractHibernateSelect<K, D, E extends D, R> extends HibernateTxStep<E, R> {

	private com.citi.risk.core.dictionary.api.Criteria<D> omitCriteria = null;
	private boolean hasOmitCriteria = false;
	
	public AbstractHibernateSelect(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}
	
	public boolean hasOmitCriteria() {
		return hasOmitCriteria;
	}

	protected void setHasOmitCriteria(boolean hasOmitCriteria) {
		this.hasOmitCriteria = hasOmitCriteria;
	}

	public com.citi.risk.core.dictionary.api.Criteria<D> getOmitCriteria() {
		return omitCriteria;
	}

	protected void setOmitCriteria(com.citi.risk.core.dictionary.api.Criteria<D> omitCriteria) {
		this.omitCriteria = omitCriteria;
	}
	
	public Object getDBKey(E entity) {
		return this.buildTemplate().getIdentifierFromPersister(entity);
	}
	
	public boolean isEntityVersionedInDB(E entity) {
		return this.buildTemplate().isEntityVersioned(entity);
	}
	
	public Template<K, D, E> buildTemplate() {
		return new Template(this.getEntityClass(), this.getEntityManager(), this.getInjector());
	}
	
	protected Collection<E> executeQueries(Collection<CriteriaQuery<E>> criteriaQueries, EntityManager entityManager) {
		String defaultFetchSize = CoreModule.getConfiguration().getString(QueryHints.FETCH_SIZE, "5000");
		Collection<E> values = Lists.newArrayList();
		TypedQuery<E> typedQuery;
		for (CriteriaQuery<E> criteriaQuery : criteriaQueries) {
			typedQuery = entityManager.createQuery(criteriaQuery);
			typedQuery.setHint(QueryHints.FETCH_SIZE, defaultFetchSize);
			values.addAll(typedQuery.getResultList());
		}
		return values;
	}
	
}
