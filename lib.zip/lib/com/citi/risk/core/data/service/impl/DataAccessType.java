package com.citi.risk.core.data.service.impl;

public enum DataAccessType {
	SELECT, INSERT, UPDATE, DELETE, AGGREGATE
}