package com.citi.risk.core.data.service.impl;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.api.DatabaseWriteBehindHandler;
import com.citi.risk.core.data.service.api.KeyEncoder;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.CacheOperations;
import com.citi.risk.core.data.store.cache.api.CacheTask;
import com.citi.risk.core.data.store.cache.impl.BestAvailableDataKeyPredicate;
import com.citi.risk.core.data.store.cache.impl.DefaultCacheTask;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.api.MethodProvider;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.KeyModifiable;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.google.common.base.Function;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;

public abstract class AbstractDatabaseWriteBehindHandler implements	DatabaseWriteBehindHandler {

	public static class WriteBehindProcessMethodProvider implements MethodProvider{

		@Override
		public Method get() {
			return MethodUtils.getAccessibleMethod(DatabaseWriteBehindHandler.class ,"process",Multimap.class);
		}
	}

	public static class GroupKeysByImplClass<E extends IdentifiedBy<?>> extends AbstractGroup<Class, E>{

		@Override
		public Class groupOf(E value) {
			return ProxyHelper.getRawClass(value);
		}
		
		@Override
		protected Object process(E item){
			return item.key();
		}
		
	}
	@Inject
	protected DomainImplHelper domainImplHelper;
	
	@Inject
	protected Injector injector;
	
	@Inject
	protected CacheManager cacheManager;
	
	@Inject
	private KeyEncoder keyEncoder;
	
	private static Logger logger = LoggerFactory.getLogger(AbstractDatabaseWriteBehindHandler.class);
	

	@Override
	public <K, T extends IdentifiedBy<K>> void process(Multimap<Class,T> entitiesByImplClass) {
		Multimap<Class,K> allIdentifiers = null;
		Map<Class, Collection<Object>> updatedEntityKeysbyClass = null;
		try {
			ExecutionContext context = ExecutionContexts.getCurrentExecutionContext();
			context.setWriteBehind(true);
			
			allIdentifiers = getIdentifiersByImplClass(entitiesByImplClass);
			Collection<T> entities = processDB(entitiesByImplClass);
			updatedEntityKeysbyClass = (new GroupKeysByImplClass<T>()).groupIntoMapWithProcessing(entities);
		} catch (Exception e) {
			logger.error("Async database operation failed ", e);
			logger.debug(" " + allIdentifiers);
			throw new RuntimeException(e);
		}finally{
			cleanupAndReloadCache(entitiesByImplClass,allIdentifiers, updatedEntityKeysbyClass);
		}

	}

	protected abstract <K,E extends IdentifiedBy<K>> Collection<E> processDB(Multimap<Class,E> entitiesByImplClass);
	
	@SuppressWarnings("rawtypes")
	private <T extends IdentifiedBy<K>, K> Multimap<Class, K> getIdentifiersByImplClass(
			Multimap<Class, T> entitiesByImplClass) {
		Multimap<Class, K> allIdentifiers = ArrayListMultimap.create();
		for(Class domainImplClass : entitiesByImplClass.keySet()){
			allIdentifiers.putAll(domainImplClass,getKeys(entitiesByImplClass.get(domainImplClass)));
		}
		return allIdentifiers;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private <T extends IdentifiedBy<K>, K> void cleanupAndReloadCache(Multimap<Class, T> entitiesByImplClass, 
				Multimap<Class, K> allIdentifiers, Map<Class, Collection<Object>> updatedEntityKeysbyClass) {
		//Reload the identifiers in cache.
		for (Class domainImplClass : entitiesByImplClass.keySet()) {
			Class loaderClass = domainImplHelper.getActiveLoaderClass(domainImplClass);
			DataKey dataKey = getDataKey(domainImplClass,loaderClass);
			Cache cache = cacheManager.getUnderlyingCache(dataKey);
			cache.remove(allIdentifiers.get(domainImplClass));

			CacheTask cacheTask = (new DefaultCacheTask())
					.domain(dataKey.getDomain()).loaderClass(loaderClass)
					.timeMark(dataKey.getTimeMark())
					.createdBy(dataKey.getCreatedBy())
					.operation(CacheOperations.Reload);
			
			if (updatedEntityKeysbyClass != null
					&& !updatedEntityKeysbyClass.isEmpty()) {
				cacheTask.setIdentifiers(updatedEntityKeysbyClass
						.get(domainImplClass));
			} else {
				cacheTask.setIdentifiers(getKeys(entitiesByImplClass
						.get(domainImplClass)));
			}
			
			try {
				cacheManager.reload(cacheTask).get();
			} catch (InterruptedException | ExecutionException e1) {
				logger.error("Cache reload operation failed ", e1);
				throw new RuntimeException(e1);
			}
		}
	}

	private DataKey getDataKey(Class domainImplClass, Class loaderClass) {
		DataDomain dataDomain = domainImplHelper.getDomainByImplClass(domainImplClass);
		Collection<DataKey> keys = cacheManager.getMatchedDataKeys(new BestAvailableDataKeyPredicate(dataDomain,
				null, loaderClass));
		if (keys.size() != 1) {
			throw new RuntimeException("There are more than one DataKey found in Cache for Domain Impl Class : " + domainImplClass);
		}
		return Iterables.getFirst(keys, null);
	}

	private <K, T extends IdentifiedBy<K>> Collection<K> getKeys(Collection<T> entities) {
		return com.citi.risk.core.lang.collection.list.Lists.newArrayList(Collections2.transform(entities, new Function<T, K>() {
			@Override
			public K apply(T input) {
				return input.key();
			}
		}));
	}

	
	@SuppressWarnings("rawtypes")
	protected <E extends IdentifiedBy<?>> void preProcessEntities(
			Collection<E> entities) {
		for(E entity : entities){
			if(ManagedVersion.class.isAssignableFrom(entity.getClass())){
				int version = ((ManagedVersion<?>) entity).getVersion();
				((ManagedVersion<?>) entity).setVersion(--version);
			}
		}
	}

}
