package com.citi.risk.core.data.service.impl;

import com.citi.risk.core.data.service.api.KeyEncoder;

public class DefaultKeyEncoder implements KeyEncoder {
	
	private static final int ENCODING_MULTIPLIER = -1;
	private static final String ENCODING_STRING = "-";

	@SuppressWarnings("unchecked")
	@Override
	public <K> K encode(K key) {
		K tempKey;
		if (Long.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) encode((Long) key);
		} else if (Integer.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) encode((Integer) key);
		} else if (String.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) encode((String) key);
		} else {
			throw new RuntimeException("Key encoding not supported for the given key type");
		}
		return tempKey;
	}
	
	private Long encode(Long key) {
		return key.longValue() * ENCODING_MULTIPLIER;
	}

	private Integer encode(Integer key) {
		return key.intValue() * ENCODING_MULTIPLIER;
	}
	
	private String encode(String key) {
		StringBuilder builder = new StringBuilder();
		builder.append(ENCODING_STRING).append(key);
		return builder.toString();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <K> K decode(K key) {
		K tempKey;
		if (Long.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) decode((Long) key);
		} else if (Integer.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) decode((Integer) key);
		} else if (String.class.isAssignableFrom(key.getClass())) {
			tempKey = (K) decode((String) key);
		} else {
			throw new RuntimeException("Key decoding not supported for the given key type");
		}
		return tempKey;
	}

	private Long decode(Long key) {
		return key.longValue() * ENCODING_MULTIPLIER;
	}

	private Integer decode(Integer key) {
		return key.intValue() * ENCODING_MULTIPLIER;
	}
	
	private String decode(String key) {
		return key.substring(1);
	}

}
