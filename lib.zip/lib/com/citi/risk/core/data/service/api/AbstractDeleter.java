package com.citi.risk.core.data.service.api;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.impl.DefaultDataKey;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;

public abstract class AbstractDeleter implements Deleter {
    
	private DataDomain domain;
	private TimeMark timeMark;
	private CreatedBy createdBy;
	private DataKey dataKey;

	public DataDomain getDomain() {
		return domain;
	}

	@Override
	public void setDomain(DataDomain domain) {
		this.domain = domain;
	}

	public TimeMark getTimeMark() {
		return timeMark;
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		this.timeMark = timeMark;
	}

	public CreatedBy getCreatedBy() {
		return createdBy;
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		this.createdBy = createdBy;
	}

	public DataKey getDataKey() {
		if (dataKey == null)
			dataKey = new DefaultDataKey(getDomain(), timeMark, createdBy);
		return dataKey;
	}
}
