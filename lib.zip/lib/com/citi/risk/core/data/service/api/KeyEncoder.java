package com.citi.risk.core.data.service.api;

public interface KeyEncoder {
	
	public <K> K encode(K key);
	
	public <K> K decode(K key);

}
