package com.citi.risk.core.data.service.jpa.executor.impl.hibernate;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.service.jpa.executor.impl.AbstractTxExecutor;
import com.google.inject.Injector;

public abstract class HibernateTxStep<E, R> extends AbstractTxExecutor<E, R> {

	private static final Logger LOGGER = LoggerFactory.getLogger(HibernateTxStep.class);

	public HibernateTxStep(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}

	@Override
	public R execute() {
		if (this.getEntityManager() == null) {
			throw new RuntimeException("Entity Manager can not be null in Trx Steps.");
		}
		try {
			R returnValue =  execute(getEntityManager());
			getEntityManager().flush();
			return returnValue;
		} catch(Exception thrown) {
			if(LOGGER.isWarnEnabled()) LOGGER.warn("Exception/Error during flush()", thrown);
			throw new RuntimeException(thrown);
		}
	}
	
	protected abstract R execute(EntityManager entityManager);
	
}


