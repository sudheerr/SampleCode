package com.citi.risk.core.data.service.jpa.executor.api;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface TxSelectExecutor<K, D extends IdentifiedBy<?>, E extends D> 
			extends BasicTxSelectExecutor<K, D, E, TxSelectExecutor<K, D, E>> {

}
