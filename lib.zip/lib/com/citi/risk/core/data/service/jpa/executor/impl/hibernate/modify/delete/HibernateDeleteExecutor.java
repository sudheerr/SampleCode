package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.delete;


import com.citi.risk.core.data.service.jpa.executor.api.TxDeleteExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.AbstractHibernateModifyExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByCriteria;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByIdentifier;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectByTemplate;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.security.api.SecureAction;
import com.google.inject.Injector;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class HibernateDeleteExecutor<K, D extends IdentifiedBy<K>, E extends D> 
						extends AbstractHibernateModifyExecutor<K, D, E, HibernateDeleteExecutor<K, D, E>>
						implements TxDeleteExecutor<K, D, E, HibernateDeleteExecutor<K, D, E>> {

	public HibernateDeleteExecutor(Class<E> entityClass, Injector injector) {
		super(entityClass, true, injector);
	}

	@Override
	public HibernateDeleteExecutor<K, D, E> delete(Collection<E> entities) {
		this.setModifyEntities(entities);
		return this;
	}
	
	@Override
	public HibernateDeleteExecutor<K, D, E> isRemove(boolean isRemove) {
		this.setUseProxyHelper(isRemove);
		return this;
	}
	
	@Override
	public List<E> executeByEntity() {
		return deleteStep(this.getModifyEntities());
	}
	
	@Override
	public List<E> executeByIdentifiers() {
		HibernateSelectByIdentifier<K, D, E> selectStep = this.buidSetp(HibernateSelectByIdentifier.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getIdentifiers()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Remove);
		return deleteStep(searchResult);
	}
	
	@Override
	public List<E> executeByTemplate() {
		HibernateSelectByTemplate<K, D, E> selectStep = this.buidSetp(HibernateSelectByTemplate.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getTemplate()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Remove);
		return deleteStep(searchResult);
	}

	@Override
	public List<E> executeByCriteria() {
		HibernateSelectByCriteria<K, D, E> selectStep = this.buidSetp(HibernateSelectByCriteria.class);
		Collection<E> searchResult = (Collection<E>)selectStep.select(this.getCriteria()).execute();
		searchResult = filterSearchResult(selectStep, searchResult, SecureAction.Remove);
		return deleteStep(searchResult);
	}
	
	private List<E> deleteStep(Collection<E> searchResult) {
		HibernateDelete<K, D, E> deleteStep = (HibernateDelete<K, D, E>) this.buidSetp(HibernateDelete.class);
		List<E> results = new ArrayList(searchResult);
		results = deleteStep.delete(results).isRemove(isUseProxyHelper()).execute();
		return results;
	}

}
