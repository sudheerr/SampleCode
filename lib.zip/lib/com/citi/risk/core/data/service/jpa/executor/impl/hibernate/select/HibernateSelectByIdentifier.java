package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.Template;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public class HibernateSelectByIdentifier<K, D extends IdentifiedBy<K>, E extends D> extends AbstractHibernateSelect<K, D, E, Collection<E>> {
	
	private Collection<K> identifiers = null;
	private boolean onlyUnExpired = false;

	public HibernateSelectByIdentifier(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}
	
	public HibernateSelectByIdentifier<K, D, E> select(Collection<K> identifiers) {
		this.identifiers = identifiers;
		return this;
	}
	
	public HibernateSelectByIdentifier<K, D, E> select(K identifier) {
		this.identifiers = new ArrayList();
		this.identifiers.add(identifier);
		return this;
	}
	
	public HibernateSelectByIdentifier<K, D, E> onlyUnExpired() {
		this.onlyUnExpired = true;
		return this;
	}

	@Override
	protected Collection<E> execute(EntityManager entityManager) {
		Template<K, D, E> criteriaTemplate = this.buildTemplate();
		criteriaTemplate.templateFor(identifiers, onlyUnExpired);
		Collection<E> values = this.executeQueries(criteriaTemplate.getCriteriaQuery(), entityManager);
		if (criteriaTemplate.hasOmitCriteria()) {
			this.setHasOmitCriteria(true);
			this.setOmitCriteria(criteriaTemplate.getOmitCriteria());
		}
		return values;
	}
	
}
