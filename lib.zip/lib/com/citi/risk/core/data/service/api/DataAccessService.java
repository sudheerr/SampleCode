package com.citi.risk.core.data.service.api;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.data.service.transaction.api.Transactional;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.impl.DataKeyPredicate;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.KeyModifiable;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.select.Select;

public interface DataAccessService extends SearchProvider, IndexSearchProvider{

	/**
	 * Returns count of matched entities for the given selectCriteria.
	 * @param criteria for building a select query
	 * @return count of matched entities for the given selectTemplate
	 */
	<T extends IdentifiedBy<?>> Long count(Criteria<T> criteria);

	/**
	 * Returns a collection of matched entities for the given selectTemplate.
	 * @param selectTemplate entity template for building a select query
	 * @return collection of entities
	 */
	<T extends IdentifiedBy<?>> Collection<T> select(T selectTemplate);
	
	/**
	 * Returns a collection of matched entities for the given selectTemplate for edit usage.
	 * @param selectTemplate entity template for building a select query
	 * @return
	 */
	<T extends IdentifiedBy<?>> Collection<T> selectForUpdate(T selectTemplate);
	
	/**
	 * Returns a Future that will deepCopy the given objects.
	 * @param objects
	 * @return
	 */
	<T extends IdentifiedBy<?>> Future<Collection<T>> makeDeepCopy(Collection<T> objects); 
	
	/**
	 * Returns a collection of matched entities for the given criteria and select for edit usage.
	 * @param criteria for building a select query
	 * @param additionalSelect for additional select
	 * @return
	 */
	<T extends IdentifiedBy<?>> Collection<T> selectForUpdate(Criteria<T> criteria, Select<T> additionalSelect);

	/**
	 * Returns a collection of matched entities for the given identifiers.
	 * @param entityClass entity class to select
	 * @param identifiers primary keys of entities to select
	 * @return collection of entities
	 */
	<K, T extends IdentifiedBy<K>> Collection<T> select(Class<T> entityClass, Collection<K> identifiers);


	/**
	 * Returns a collection of matched entities for the given identifiers for edit usage.
	 * @param entityClass entity class to select
	 * @param dentifiers primary keys of entities to select
	 * @return
	 */
	<K, T extends IdentifiedBy<K>> Collection<T> selectForUpdate(Class<T> entityClass, Collection<K> identifiers);
	
	/**
	 * Returns a matched entity for the given identifier.
	 * @param entityClass entity class to select
	 * @param id is a primary key
	 * @return matched entity
	 */
	<K,T extends IdentifiedBy<K>> T selectOne(Class<T> entityClass, K id);
	
	/**
	 * Returns a matched entity for the given identifier for edit usage.
	 * @param entityClass entity class to select
	 * @param id is a primary key
	 * @return matched entity
	 */
	<K, T extends IdentifiedBy<K>> T selectOneForUpdate(Class<T> entityClass, K id);

	/**
	 * get one matched entity for the given domain and identifier. when domain exists in cache, 
	 * use best available time mark and input identifier to query the cache. otherwise query the underlying database.
	 * the result is not supposed be edited.
	 * 
	 * @param domain target domain of the entity which should not be empty
	 * @param identifier identifier of the entity
	 * @return single entity to be returned. return null is entity is not find in cache or database.
	 */
	<K, T extends IdentifiedBy<K>> T selectOne(DataDomain<T> domain, K identifier);
	
	/**
	 * same as {@link #selectOne(DataDomain, K)} only that when you call this method, you are planning to edit the result.
	 * if not, just use the {@link #selectOne(DataDomain, K)} 
	 * 
	 * @param domain target domain of the entity which should not be empty
	 * @param identifier identifier of the entity
	 * @return single entity to be returned. return null is entity is not find in cache or database.
	 */
	<K, T extends IdentifiedBy<K>> T selectOneForUpdate(DataDomain<T> domain, K identifier);
	
	/**
	 * Insert or update a collection of provided entities.
	 * @param entities entity objects to store (insert or update).
	 * @return collection of stored entities
	 */
	@Transactional(value=Transactional.TxType.REQUIRED)
	<T extends IdentifiedBy<?>> Collection<T> create(Collection<T> entities);
	
	/**
	 * Insert a collection of provided entities using write behind strategy.
	 * @param entities entity objects to store (insert or update).
	 * @return collection of stored entities
	 */
	@Transactional(value=Transactional.TxType.REQUIRED)
	<K,T extends IdentifiedBy<K> & KeyModifiable<K>> Collection<T> createWriteBehind(Collection<T> entities);
	
	/**
	 * Generate and set ids for entities using CustomTableGenerator for @id fields. 
	 * @param entities objects that need id generation
	 */
	<T extends IdentifiedBy<?>> void generateEntityID(Collection<T> entities);

	/**
	 * Insert or update the given entity.
	 * @param entity object to store (insert or update).
	 * @return stored entity
	 */
	@Transactional(value=Transactional.TxType.REQUIRED)
	<T extends IdentifiedBy<?>> T createOne(T entity);
	
    /**
     * Delete a collection of provided entities.
     * @param entities entity objects to delete.
     */
	@Transactional(value=Transactional.TxType.REQUIRED)
    <T extends IdentifiedBy<?>> void delete(Collection<T> entities);
    
    /**
     * Delete a collection of provided entities using write behind approach
     * @param entities entity objects to delete
     */
	@Transactional(value=Transactional.TxType.REQUIRED)
    public <K,T extends IdentifiedBy<K> & KeyModifiable<?>> void deleteWriteBehind(Collection<T> entities);
	/**
	 * @deprecated
	 * Delete entities matching the given selectTemplate
	 * @param selectTemplate entity template for building a delete query
	 */
    @Deprecated
	@Transactional(value=Transactional.TxType.REQUIRED)
	<T extends IdentifiedBy<?>> void delete(T selectTemplate);

	/**
	 * @deprecated
	 * Delete entities matching the given selectCriteria
	 * @param criteria for building a delete query
	 */
	@Deprecated
	@Transactional(value=Transactional.TxType.REQUIRED)
	<T extends IdentifiedBy<?>> void delete(Criteria<T> criteria, Select<T> additionalSelect);

	/**
	 * Delete entities matching the given identifiers.
	 * @param entityClass entity class to delete
	 * @param identifiers primary keys of entities to delete
	 */
	@Transactional(value=Transactional.TxType.REQUIRED)
	<K, T extends IdentifiedBy<K>> void delete(Class<T> entityClass, Collection<K> identifiers);

	/**
     * Update a collection of provided entities.
     * @param entities entity objects to update.
     * @return collection of updated entities
     */
	@Transactional(value=Transactional.TxType.REQUIRED)
    <K, T extends IdentifiedBy<K>> Collection<T> update(Collection<T> entities);
    
    /** update a collection of provided entities with write behind approach
     * @param entities entity objects to update
     */
	@Transactional(value=Transactional.TxType.REQUIRED)
    <K, E extends IdentifiedBy<K> & KeyModifiable<K>> Collection<E> updateWriteBehind(Collection<E> entities);
    
	/**
	 * @deprecated
	 * Update entities matching the given selectTemplate with the set values provided by the updateTemplate.
	 * @param selectTemplate entity template for building a select query
	 * @param updateTemplate to apply <b>set</b> properties to matched entities by selectTemplate
	 * @return a collection of updated entities
	 */
    @Deprecated
	@Transactional(value=Transactional.TxType.REQUIRED)
	<K, T extends IdentifiedBy<K>> Collection<T> update(T selectTemplate, T updateTemplate);

	/**
	 * @deprecated
	 * Update entities matching the given identifiers with the set values provided by the updateTemplate.
	 * @param updateTemplate to apply <b>set</b> properties to matched entities by identifiers
	 * @param identifiers primary keys of entities to select
	 * @return a collection of updated entities
	 */
    @Deprecated
	@Transactional(value=Transactional.TxType.REQUIRED)
	<K, T extends IdentifiedBy<K>> Collection<T> update(T updateTemplate, Collection<K> identifiers);

	/**
	 * Start tracking modified domains.
	 * @see com.citi.risk.core.dictionary.api.DataDomain
	 */
	void markModifications();

	/**
	 * Stop tracking modified domains.
	 * @see com.citi.risk.core.dictionary.api.DataDomain
	 */
	void unmarkModifications();

	/**
	 * Return a list of modified domains from the time method markModifications() has been invoked.
	 * @return a collection of modified domains.
	 */
	Collection<Class<?>> getModifiedDomains();

	/**
	 * Gets an item from the datasource by domain, data and key. Same key can be present across multiple domains and dates.
	 *
	 * @param domain domain to search by
	 * @param date   date to search by, represented by TimeMark interface
	 * @param key    key to lookup
	 * @param <K>    key type to lookup by
	 * @param <E>    value type in datasource, extends IdentifiedBy of type K
	 * @return value from the datasource
	 * @see com.citi.risk.core.dictionary.api.DataDomain
	 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
	 * @see com.citi.risk.core.lang.businessobject.TimeMark
	 */
	<K, E extends IdentifiedBy<K>> E get(DataDomain domain, TimeMark date, K key);

	/**
	 * Gets items from the datasource by domain, data and key. The data is returned for the best available date (latest)
	 *
	 * @param domain domain to search by
	 * @param key    key to lookup
	 * @param <K>    key type to lookup by
	 * @param <E>    value type in datasource, extends IdentifiedBy of type K
	 * @return value from the datasource
	 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
	 */
	<K, E extends IdentifiedBy<K>> E get(DataDomain domain, K key);

	/**
	 * Gets items from the datasource by domain and list of keys. Same key can be present across multiple domains and dates.
	 *
	 * @param domain domain to search by
	 * @param keys   keys to lookup
	 * @param <K>    key type to lookup by
	 * @param <E>    value type in datasource, extends IdentifiedBy of type K
	 * @return list of values from the datasource
	 * @see com.citi.risk.core.dictionary.api.DataDomain
	 * @see com.citi.risk.core.lang.businessobject.IdentifiedBy
	 */
	<K, E extends IdentifiedBy<K>> List<E> get(DataDomain domain, List<K> keys);

	/**
	 * Get best available DataKey by domain. If there are more than one DataKey matched, the first one will return.
	 * For more strict query, use other two methods.
	 * @param domain
	 * @return
	 */
	DataKey getBestAvailableDataKey(DataDomain<?> domain);

	/**
	 * Get best available DataKey by domain and frequency.
	 * @param domain
	 * @param frequency
	 * @return
	 */
	DataKey getBestAvailableDataKey(DataDomain<?> domain, BatchFrequency frequency);

	/**
	 * Get best available DataKey by domain, domainImplClass and frequency. There will be at most one matched DataKey.
	 * @param domain
	 * @param domainImplClass
	 * @param frequency
	 * @return
	 */
	DataKey getBestAvailableDataKey(DataDomain<?> domain, Class<?> domainImplClass, BatchFrequency frequency);
	
	/**
	 * Represents status of a datasource
	 */
	public enum Status {
		Uninitialied, Initializing, Ready
	};

	/**
	 * @deprecated
	 */
	@Deprecated
	Set<DataKey> searchDataAvailabilities();

	/**
	 * @deprecated
	 */
	@Deprecated
	Set<DataKey> searchDataAvailabilities(TimeMark timeMark);

	/**
	 * @deprecated
	 * Use {@link #getBestAvailableDataKey(DataDomain, BatchFrequency)}.getTimeMark(). And then use the retrived timemark to generate the criteria on your domain.
	 * etc. criteria = domain.getRelationShip("Time mark").appendPath(timeMarkKeyPath).eq(timeMark.getTimeMarkKey())
	 * If you are using this criteria for DataAccessService.select api, then no need to do it since DataAccessService will automatically select bestAvailable data
	 *  
	 */
	@Deprecated
	Criteria newBestAvailableCriteria(DataDomain domain, BatchFrequency frequency);

	/**
	 * @deprecated
	 * Use {@link #getBestAvailableDataKey(DataDomain)}.getTimeMark(). And then use the retrived timemark to generate the criteria on your domain.
	 * etc. criteria = domain.getRelationShip("Time mark").appendPath(timeMarkKeyPath).eq(timeMark.getTimeMarkKey())
	 * If you are using this criteria for DataAccessService.select api, then no need to do it since DataAccessService will automatically select bestAvailable data
	 *  
	 */
	@Deprecated
	Criteria newBestAvailableCriteria(DataDomain domain);

	/**
	 * @deprecated
	 * Use {@link #getBestAvailableDataKey(DataDomain, BatchFrequency)}.getTimeMark  instead
	 */
	@Deprecated
    TimeMark newBestAvailableTimeMark(DataDomain domain, BatchFrequency frequency);

	/**
	 * @deprecated
	 * Use {@link #getBestAvailableDataKey(DataDomain)}.getTimeMark instead
	 */
	@Deprecated
    TimeMark newBestAvailableTimeMark(DataDomain domain);
	
    <K, E extends IdentifiedBy<K>> Collection<E> execute(Collection<E> domains, Class<? extends MapperCallback<K, E>> callbackClass);


    
}
