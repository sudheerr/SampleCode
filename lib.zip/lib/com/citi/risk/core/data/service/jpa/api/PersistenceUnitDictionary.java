package com.citi.risk.core.data.service.jpa.api;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.transaction.PlatformTransactionManager;

public interface PersistenceUnitDictionary {
	
	EntityManager createEntityManager(Class<?> entityClass);
	 
	PlatformTransactionManager getTransactionManager(Class<?> entityClass);

	PlatformTransactionManager getTransactionManager(String persistenceUnitName);

	String getPersistenceUnitName(Class<?> entityClass);

	void putEntityManagerFactory(String persistenceUnitName, EntityManagerFactory entityManagerFactory);

}
