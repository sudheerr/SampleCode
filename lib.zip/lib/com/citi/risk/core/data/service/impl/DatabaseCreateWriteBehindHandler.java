package com.citi.risk.core.data.service.impl;

import java.util.Collection;

import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.data.store.cache.impl.AbstractStorer;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;

public class DatabaseCreateWriteBehindHandler extends
		AbstractDatabaseWriteBehindHandler {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	protected <K, E extends IdentifiedBy<K>> Collection<E> processDB(Multimap<Class, E> entitiesByImplClass) {
		Collection<E> results = Lists.newArrayList();
		for(Class domainImplClass : entitiesByImplClass.keySet()){
			Collection<E> entities = entitiesByImplClass.get(domainImplClass);
			preProcessEntities(entities);
			Class storerClass = domainImplHelper.getActiveStorerClass(domainImplClass);
			Storer storer = (Storer) injector.getInstance(storerClass);
			DataDomain dataDomain = domainImplHelper.getDomainByImplClass(domainImplClass);
			storer.setDomain(dataDomain);
			((AbstractStorer) storer).setRequireReturns(true);
			Collection<E> storeResults = ((AbstractStorer)storer).storeObjects(entities);
			results.addAll(storeResults);
		}
		return results;
	}

}
