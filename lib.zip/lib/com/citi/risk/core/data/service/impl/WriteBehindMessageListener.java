package com.citi.risk.core.data.service.impl;

import java.io.IOException;
import java.util.Collection;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQMessageConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.service.api.DatabaseWriteBehindHandler;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.IOSpecification;
import com.citi.risk.core.dictionary.api.DomainImplDictionary;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.google.inject.Provider;
import com.google.inject.name.Named;


public class WriteBehindMessageListener {

    private static Logger logger = LoggerFactory.getLogger(WriteBehindMessageListener.class);
    
	private Configuration configuration;
	
	private Session session;
	
	@Inject
	private WriteBehindMessageSerializer messageSerializer;
	
	@Inject
	private DomainImplDictionary domainDictionary;
	
	@Inject
	Injector injector;
	
	@Inject
	@Named("write_behind_queue.responseQueue")
	private String notificationQueueName;
	
	private static final String UPDATE_HANDLER = "Update";
	private static final String DELETE_HANDLER = "Delete";
	private static final String CREATE_HANDLER = "Create";

    @Inject
	public WriteBehindMessageListener(@Named("write_behind_queue") Provider<Connection> connectionProvider, @Named("write_behind_queue.requestQueue") String queueName, Configuration configuration, DomainImplDictionary domainDictionary) {
		this.configuration = configuration;
		this.domainDictionary = domainDictionary; 
		
		try {
	    	session = connectionProvider.get().createSession(false, Session.AUTO_ACKNOWLEDGE);
	    	Collection<DomainImplSpecification> domainImplSpecifications = domainDictionary.getAllDomainImplSpecifications();
	    	for (DomainImplSpecification domainImplSpecification : domainImplSpecifications) {
	    		IOSpecification ioSpecs = domainImplSpecification.getIOSpecification();
	    		if (ioSpecs == null) {
	    			continue;
	    		}
	    		logger.debug("domain classes :: " + ioSpecs.getDomainClasses());
	    		for (Class domainClass : ioSpecs.getDomainClasses()) {
					Queue writeBehindQueue = session.createQueue(queueName + "." + domainClass.getSimpleName());
					
					String messageFilter = "environment = '" + configuration.getEnvironment().getShortString() + "'";
			
					MessageConsumer messageConsumer = session.createConsumer(writeBehindQueue, messageFilter);
					messageConsumer.setMessageListener(new WriteBehindMessageListenerInstance());
	    		}
	    	}
		} catch (JMSException jmse) {
			throw new RuntimeException(jmse);
		} catch (Exception e) {
			throw e;
		}
	}
    
    private class WriteBehindMessageListenerInstance implements MessageListener {

    	@Override
    	@InfraInvocation
		public void onMessage(final Message message) {
			String messageID = null;
			
			try {
				messageID = message.getJMSMessageID();
				logger.debug("Message :: " + messageID);
				logger.debug("Type :: " + message.getJMSType());
				DatabaseWriteBehindHandler writeBehindHandler = getHandler(message.getJMSType());
				byte[] messageBytes = new byte[(int) ((BytesMessage) message).getBodyLength()];
				((BytesMessage) message).readBytes(messageBytes);
				Multimap entitiesByImplClass = messageSerializer.deserializeMessage(messageBytes);
				
				writeBehindHandler.process(entitiesByImplClass);
				WriteBehindMessageListener.this.sendNotification(messageID, true, null);
			} catch (JMSException | IOException | ClassNotFoundException e) {
				logger.error("Error while reading write behind message from queue", e);
				sendNotification(messageID, false, e);
				throw new RuntimeException("Error while processing write behind message", e);
			} catch (Exception e) {
				logger.error("Error while processing write behind message from queue", e);
				sendNotification(messageID, false, e);
			}
		}
    }
    
	private void sendNotification(String messageID, boolean success, Exception e) {
		try {
			Queue notificationQueue = session.createQueue(notificationQueueName);
			TextMessage message = session.createTextMessage();
			message.setJMSCorrelationID(messageID);
			message.setJMSType(success ? "SUCCESS" : "FAILURE");
			message.setStringProperty("environment", configuration.getEnvironment().getShortString());
			if (!success) {
				message.setText(e.getMessage());
			}
            MessageProducer producer = session.createProducer(notificationQueue);
            producer.send(message);
            producer.close();
		} catch (JMSException jmse) {
			logger.error("Error sending write behind notification message to notification queue", jmse);
		}
	}
	
	private DatabaseWriteBehindHandler getHandler(String action) {
		DatabaseWriteBehindHandler handler;
		if (UPDATE_HANDLER.equals(action)) {
			handler = injector.getInstance(DatabaseUpdateWriteBehindHandler.class);
			return handler;
		} else if (DELETE_HANDLER.equals(action)) {
			handler = injector.getInstance(DatabaseDeleteWriteBehindHandler.class);;
			return handler;
		}
		else if(CREATE_HANDLER.equals(action)){
			handler = injector.getInstance(DatabaseCreateWriteBehindHandler.class);
			return handler;
		}
		throw new RuntimeException("Cannot find handler for action :: " + action);
	}
}
