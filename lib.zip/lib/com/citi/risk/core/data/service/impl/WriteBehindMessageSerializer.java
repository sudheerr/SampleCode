package com.citi.risk.core.data.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;


public class WriteBehindMessageSerializer {
	
	JsonSerializationFacade jsonSerializationFacade;
	
    private static Logger logger = LoggerFactory.getLogger(WriteBehindMessageSerializer.class);
    
    @Inject
    public WriteBehindMessageSerializer(JsonSerializationFacade jsonSerializationFacade) {
    	this.jsonSerializationFacade = jsonSerializationFacade;
    }
	
	@SuppressWarnings("rawtypes")
	public <E> byte[] serializeMessage(Multimap<Class, E> entitiesByImplClass) {
		byte[] serializedBytes;
		Multimap<Class, byte[]> serializedMap = ArrayListMultimap.create();
		for (Class domainImplClass : entitiesByImplClass.keySet()) {
			serializeToMap(serializedMap, domainImplClass, entitiesByImplClass.get(domainImplClass));
		}
		
		try {
	    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    	ObjectOutputStream oos = new ObjectOutputStream(baos);
	    	oos.writeObject((Serializable)serializedMap);
	    	serializedBytes = baos.toByteArray();
	        oos.close();
	        baos.close();
		} catch (IOException jmse) {
			throw new RuntimeException("Error serializing write behind message", jmse);
		}
		
		return serializedBytes;
	}
	
	private <E> void serializeToMap(Multimap<Class, byte[]> serializedMap, Class domainImplClass, Collection<E> entities) {
		for (E entity : entities) {
			serializedMap.put(domainImplClass, jsonSerializationFacade.serializeToByteArray(entity));
		}
	}
	
	public <E> Multimap<Class, E> deserializeMessage(byte[] serializedBytes) throws IOException, ClassNotFoundException {
		ByteArrayInputStream bais = null;
		ObjectInputStream ois = null;
		
		Multimap<Class, E> entitiesByImplClass = ArrayListMultimap.create();

		try {
			bais = new ByteArrayInputStream(serializedBytes);
			ois = new ObjectInputStream(bais);
			Multimap<Class, byte[]> serializedMap = (Multimap<Class, byte[]>) ois.readObject();
			for (Class domainImplClass : serializedMap.keySet()) {
				deserializeToMap(entitiesByImplClass, domainImplClass, serializedMap.get(domainImplClass));
			}
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
					logger.warn("Unable to close object stream", e);
				}
			}

			if (bais != null) {
				try {
					bais.close();
				} catch (IOException e) {
					logger.warn("Unable to close byte stream", e);
				}
			}
		}
		
		return entitiesByImplClass;
	}
	
	private <E> void deserializeToMap(Multimap<Class, E> entitiesByImplClass, Class domainImplClass, Collection<byte[]> entityBytes) {
		for (byte[] entity : entityBytes) {
			entitiesByImplClass.put(domainImplClass, (E) jsonSerializationFacade.deserializeByByteArray(entity, domainImplClass));
		}
	}
}
