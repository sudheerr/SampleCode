package com.citi.risk.core.data.service.jpa.executor.api;

import java.util.Collection;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface TxDeleteExecutor<K, D extends IdentifiedBy<?>, E extends D, TR extends TxDeleteExecutor<K, D, E, TR>> 
					extends BasicTxSelectExecutor<K, D, E, TR> {
	
	TR delete(Collection<E> entities);
	
	TR isRemove(boolean isRemove);
}
