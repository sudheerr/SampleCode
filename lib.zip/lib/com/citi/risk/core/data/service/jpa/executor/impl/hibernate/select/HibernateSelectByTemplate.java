package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.Collection;
import java.util.Collections;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaQuery;

import org.hibernate.Session;
import org.hibernate.ejb.EntityManagerImpl;

import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.Template;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Lists;
import com.google.inject.Injector;

public class HibernateSelectByTemplate<K, D extends IdentifiedBy<K>, E extends D> extends AbstractHibernateSelect<K, D, E, Collection<E>> {
	
	private E template = null;

	public HibernateSelectByTemplate(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}

	public final HibernateSelectByTemplate<K, D, E> select(E template) {
		this.template = template;
		return this;
	}

	@Override
	protected final Collection<E> execute(EntityManager entityManager) {
		if (template == null) {
			return Collections.emptyList();
		}
		Collection<E> values = Lists.newArrayList();
		
		Template<K, D, E> criteriaTemplate = this.buildTemplate();
		criteriaTemplate.templateFor(template);
		Session session = ((EntityManagerImpl)entityManager).getSession();
		org.hibernate.Criteria criteria = session.createCriteria(this.getEntityClass()).setResultTransformer(org.hibernate.Criteria.DISTINCT_ROOT_ENTITY).add(criteriaTemplate.getHibernateCriterion());
		
		this.setOmitCriteria(criteriaTemplate.getOmitCriteria());
		this.setHasOmitCriteria(criteriaTemplate.hasOmitCriteria());
		
		values.addAll(criteria.list());
		
		Collection<CriteriaQuery<E>> criteriaQueries = criteriaTemplate.getCriteriaQuery();
		
		for (CriteriaQuery<E> criteriaQuery : criteriaQueries) {
			values.addAll(entityManager.createQuery(criteriaQuery).getResultList());
		}
		
		return values;
	}
	
}
