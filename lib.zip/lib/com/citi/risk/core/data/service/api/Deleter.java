package com.citi.risk.core.data.service.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.TimeMark;

public interface Deleter {

	/**
     * Delete a collection of provided entities.
     * @param entities entity objects to delete.
     */
    <T extends IdentifiedBy<?>> void delete(Collection<T> entities);
    
    /**
     * Delete entities matching the given selectTemplate
     * @param selectTemplate entity template for building a delete query
     */
    <T extends IdentifiedBy<?>> void delete(T selectTemplate);

    /**
     * Delete entities matching the given selectCriteria
     * @param criteria for building a delete query
     */
    void delete(Criteria criteria);

    /**
     * Delete entities matching the given identifiers.
     * @param entityClass entity class to delete
     * @param identifiers primary keys of entities to delete
     */
    <K, T extends IdentifiedBy<K>> void delete(Class<T> entityClass, Collection<K> identifiers);
    
    

	public void setDomain(DataDomain domain);

	public void setTimeMark(TimeMark timeMark);

	public void setCreatedBy(CreatedBy createdBy);

}
