package com.citi.risk.core.data.service.impl;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import com.citi.risk.core.data.mybatis.ManagedMapperProvider;
import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.api.MapperCallback;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;

public abstract class AbstractMapperCallback<K, E extends IdentifiedBy<K>> implements MapperCallback<K, E>,
		ManagedExecution {

	private Collection<E> executeParam = null;

	@Inject
	private ExecutorService executorService;

	@Override
	public final Collection<E> call() throws Exception {
		try {
			return this.call(executeParam);
		} catch (Exception ta) {
			throw new ExecutionException("call fail", ta);
		}
	}

	@Override
	public final TaskType getType() {
		return TaskType.DataStore;
	}

	@Override
	public final String getExecutionName() {
		StringBuilder sb = new StringBuilder("Mapper : ");
		Object mapper = this.getMapper();
		Method method = this.getMethod();

		if (method == null) {
			if (mapper == null) {
				sb.append("NULL");
			} else {
				Object obj = Proxy.getInvocationHandler(mapper);
				if (obj instanceof ManagedMapperProvider) {
					ManagedMapperProvider mmp = (ManagedMapperProvider) obj;
					sb.append(mmp.getMapperType().getSimpleName());
				}
			}
			sb.append(", Method : ").append("NULL");
		} else {
			sb.append(this.getMethod().getDeclaringClass().getSimpleName());
			sb.append(", Method : ").append(method.getName());
		}
		return sb.toString();
	}

	@Override
	public String getExecutionParameters() {
		StringBuilder sb = new StringBuilder("DataAccessService.execute\nDomain Type : ");
		if (executeParam == null) {
			sb.append("NULL");
		} else if (!executeParam.isEmpty()) {
			E param = executeParam.iterator().next();
			sb.append(ProxyHelper.getRawClass(param).getName());
		}
		return sb.toString();
	}

	@Override
	public final boolean isNewThread() {
		return false;
	}

	@Override
	public final Collection<E> execute(Collection<E> value) {
		executeParam = value;
		Future<Collection<E>> future = executorService.submit(this);
		try {
			return future.get();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		} catch (ExecutionException e) {
			throw new RuntimeException("Execute fail!", e.getCause() == null ? e : e.getCause());
		}
	}

	protected abstract Collection<E> call(Collection<E> value);

}
