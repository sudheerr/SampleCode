package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.Collection;
import java.util.Set;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.service.jpa.executor.api.BasicTxSelectExecutor;
import com.citi.risk.core.data.service.jpa.executor.api.TxExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.AbstractHibernateTxExecutor;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public abstract class AbstractHibernateSelectExecutor<K, D extends IdentifiedBy<K>, E extends D, TR extends TxExecutor<Collection<E>>> 
								extends AbstractHibernateTxExecutor<E, Collection<E>> 
								implements BasicTxSelectExecutor<K, D, E, TR> {
	
	private Collection<K> identifiers;
	private E template;
	private Criteria<D> criteria;
	protected SelectType type = null;
	

	public AbstractHibernateSelectExecutor(Class<E> entityClass, boolean forUpdate, Injector injector) {
		super(entityClass, forUpdate, injector);
	}

	@Override
	public TR select(Collection<K> identifiers) {
		this.identifiers = identifiers;
		this.type = SelectType.Identifiers;
		return (TR)this;
	}

	@Override
	public TR select(E template) {
		this.template = template;
		this.type = SelectType.Template;
		return (TR)this;
	}

	@Override
	public TR select(Criteria<D> criteria) {
		this.criteria = criteria;
		this.type = SelectType.Criteria;
		return (TR)this;
	}

	@Override
	protected Collection<E> execute(EntityManager entityManager) {
		return this.execute(entityManager, type);
	}
	
	protected abstract Collection<E> execute(EntityManager entityManager, SelectType selectType);
	
	
	protected Collection<K> getIdentifiers() {
		return identifiers;
	}

	protected E getTemplate() {
		return template;
	}

	protected Criteria<D> getCriteria() {
		return criteria;
	}

	protected SelectType getType() {
		return type;
	}

	public enum SelectType {
		Identifiers, Template, Criteria, Entity
	}
	
}
