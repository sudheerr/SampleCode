package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.insert;

import java.util.Collection;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.service.jpa.executor.api.TxInsertExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.AbstractHibernateTxExecutor;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public class HibernateInsertExecutor<K, D extends IdentifiedBy<K>, E extends D> 
							extends AbstractHibernateTxExecutor<E, Collection<E>> 
							implements TxInsertExecutor<E> {
	
	private Collection<E> storeItems; 

	public HibernateInsertExecutor(Class<E> entityClass, Injector injector) {
		super(entityClass, true, injector);
	}

	@Override
	public TxInsertExecutor<E> insert(Collection<E> storeItems) {
		this.storeItems = storeItems;
		return this;
	}

	@Override
	public TxInsertExecutor<E> useProxyHelper() {
		return this;
	}

	@Override
	protected Collection<E> execute(EntityManager entityManager) {
		HibernateInsert<K, D, E> insertStep = this.buidSetp(HibernateInsert.class);
		return insertStep.insert(storeItems).execute();
	}

}
