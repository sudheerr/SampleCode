package com.citi.risk.core.data.service.jpa.executor.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface BasicTxSelectExecutor<K, D extends IdentifiedBy<?>, E extends D, TR extends TxExecutor<Collection<E>>> extends TxExecutor<Collection<E>> {
	
	TR select(Collection<K> identifiers);

	TR select(E template);
	
	TR select(Criteria<D> criteria);
}
