package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select;

import java.util.Collection;
import java.util.Collections;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.Template;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Injector;

public class HibernateSelectByCriteria<K, D extends IdentifiedBy<K>, E extends D> extends AbstractHibernateSelect<K, D, E, Collection<E>> {
	
	private Criteria<D> criteria = null;

	public HibernateSelectByCriteria(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}

	public HibernateSelectByCriteria<K, D, E> select(Criteria<D> criteria) {
		this.criteria = criteria;
		return this;
	}
	
	@Override
	protected Collection<E> execute(EntityManager entityManager) {
		if (criteria == null) {
			return Collections.emptyList();
		}
		Template<K, D, E> criteriaTemplate = this.buildTemplate();
		criteriaTemplate.templateFor(criteria);
		Collection<E> values = this.executeQueries(criteriaTemplate.getCriteriaQuery(), entityManager);
		this.setHasOmitCriteria(criteriaTemplate.hasOmitCriteria());
		this.setOmitCriteria(criteriaTemplate.getOmitCriteria());
		return values;
	}
	
}
