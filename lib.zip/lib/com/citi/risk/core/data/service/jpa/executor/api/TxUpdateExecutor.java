package com.citi.risk.core.data.service.jpa.executor.api;

import java.util.Collection;

import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface TxUpdateExecutor<K, D extends IdentifiedBy<?>, E extends D, TR extends TxUpdateExecutor<K, D, E, TR>> 
					extends BasicTxSelectExecutor<K, D, E, TR> {
	
	TR update(Collection<E> entities);
	 
	TR with(E updateTemplate);
	
	TR useProxyHelper(boolean useProxyHelper);

}
