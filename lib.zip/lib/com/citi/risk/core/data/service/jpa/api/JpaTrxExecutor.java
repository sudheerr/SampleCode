package com.citi.risk.core.data.service.jpa.api;

import java.util.Collection;

public interface JpaTrxExecutor<E> {

	Collection<? extends E> execute();

}
