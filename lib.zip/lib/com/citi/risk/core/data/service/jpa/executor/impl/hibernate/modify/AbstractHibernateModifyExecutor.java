package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;

import com.citi.risk.core.ioc.impl.guice.CoreModule;
import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.data.service.impl.DomainImplHelper;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.ResolveReference;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.AbstractHibernateSelect;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.AbstractHibernateSelectExecutor;
import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.security.api.SecurableDictionary;
import com.citi.risk.core.security.api.SecureAction;
import com.citi.risk.core.security.api.SecurityRealm;
import com.citi.risk.core.security.api.SecuritySelect;
import com.citi.risk.core.security.api.User;
import com.citi.risk.core.security.api.UserSecurityService;
import com.citi.risk.core.security.filter.DataSecurityFilter;
import com.citi.risk.core.security.impl.SecurityUtil;
import com.google.inject.Injector;

public abstract class AbstractHibernateModifyExecutor<K, D extends IdentifiedBy<K>, E extends D, TR extends AbstractHibernateModifyExecutor<K, D, E, TR>> 
							extends AbstractHibernateSelectExecutor<K, D, E, TR> {

	private Collection<E> modifyEntities; 
	private E modifyTemplate;
	private boolean needResolve = true;
	private boolean useProxyHelper = true;
	private AbstractLoader<K, D, E> loader;
	
	public AbstractHibernateModifyExecutor(Class<E> entityClass, boolean forUpdate, Injector injector) {
		super(entityClass, forUpdate, injector);
		DomainImplHelper domainImplHelper = injector.getInstance(DomainImplHelper.class); 
		loader = (AbstractLoader<K, D, E>)injector.getInstance(domainImplHelper.getActiveLoaderClass(entityClass));
	}

	public AbstractLoader<K, ? super E, E> getLoader() {
		return loader;
	}

	protected Collection<E> getModifyEntities() {
		return modifyEntities;
	}

	protected void setModifyEntities(Collection<E> modifyEntities) {
		this.modifyEntities = modifyEntities;
		this.type = SelectType.Entity;
	}

	protected E getModifyTemplate() {
		return modifyTemplate;
	}

	protected void setModifyTemplate(E modifyTemplate) {
		this.modifyTemplate = modifyTemplate;
	}
	
	public boolean needResolve() {
		return needResolve;
	}

	public void setNeedResolve(boolean needResolve) {
		this.needResolve = needResolve;
	}
	
	public boolean isUseProxyHelper() {
		return useProxyHelper;
	}

	public void setUseProxyHelper(boolean useProxyHelper) {
		this.useProxyHelper = useProxyHelper;
	}
	
	@Override
	protected Collection<E> execute(EntityManager entityManager, SelectType selectType) {
		if (selectType == SelectType.Criteria) {
			return this.executeByCriteria();
		} else if (selectType == SelectType.Template) {
			return this.executeByTemplate();
		} else if (selectType == SelectType.Identifiers) {
			return this.executeByIdentifiers();
		} else if (selectType == SelectType.Entity) {
			return this.executeByEntity();
		} else {
			throw new RuntimeException();
		}
	}
	
	public abstract List<E> executeByEntity();
	
	public abstract List<E> executeByCriteria();
	
	public abstract List<E> executeByTemplate();
	
	public abstract List<E> executeByIdentifiers();

	protected <E extends IdentifiedBy<?>> SecuritySelect<E> getSecuritySelect(SecureAction action) {
		UserSecurityService userSecurityService = this.getInjector().getInstance(UserSecurityService.class);
		SecurableDictionary securableDictionary = this.getInjector().getInstance(SecurableDictionary.class);
		if (userSecurityService == null || securableDictionary == null) {
			return null;
		}
		User user = ExecutionContexts.getCurrentExecutionContext().getUser();
		if (user == null) {
			return null;
		}
		DomainImplHelper domainImplHelper = this.getInjector().getInstance(DomainImplHelper.class); 
		Class<D> domainClass = domainImplHelper.getDomainByImplClass(this.getEntityClass()).getDomainClass();
		SecurityRealm securityRealm = SecurityUtil.getApplicableSecurityRealm(domainClass, securableDictionary);
		if (null == securityRealm) {
			return null;
		}
		DataSecurityFilter<E> filter = (DataSecurityFilter<E>) userSecurityService.getAuthorizedFilter(user, domainClass, action, securityRealm);
		if (null == filter) {
			return null;
		}
		SecuritySelect<E> securitySelect = filter.toSecuritySelect();
		return securitySelect;
	}
	
	protected <EX extends AbstractHibernateSelect<K, D, E, Collection<E>>> Collection<E> filterSearchResult( EX selectStep, Collection<E> searchResult, SecureAction secureAction) {
		Collection<E> newSearchResult = searchResult;
		if(this.needResolve()) {
			ResolveReference<E> resolve = new ResolveReference(newSearchResult, this.getLoader(), this.getModifyTemplate());
			resolve.getLoaderAndResolve();
		}
		
		if (!CollectionUtils.isEmpty(newSearchResult) && selectStep.hasOmitCriteria()) {
			newSearchResult = (Collection<E>) selectStep.getOmitCriteria().getSelect().select((Collection<D>) newSearchResult);
		}
		SecuritySelect<IdentifiedBy<?>> securitySelect = this.getSecuritySelect(secureAction);
		if(securitySelect != null) {
			ParallelSelect parallelSelect = new ParallelSelect(securitySelect, 8, 200000, CoreModule.getConfiguration().getInteger("query.task.timeout", 60));
			newSearchResult = parallelSelect.select(newSearchResult);
		}
		return newSearchResult;
	}
}
