package com.citi.risk.core.data.service.impl;

import java.util.Collection;
import java.util.Set;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.google.inject.Singleton;

@Singleton
public class NonEntitlementDataAccessService extends DefaultDataAccessService {
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> search(DataKey dataKey, Select<E> select) {
		DataDomain domain = dataKey.getDomain();
		Select<E> newSelect = new ParallelSelect<>(select, 8, 200000, configuration.getInteger("query.task.timeout", 60));
		Collection<E> results;
		if (this.isDomainAvailableInCache(domain))
			results = cacheManager.search(dataKey, newSelect);
		else
			results = loadDomainWithSelect(domain, newSelect);
		return results;
	}

	/**
	 * @deprecated not support
	 */
	@Override
	@Deprecated
	public <E extends IdentifiedBy<?>> Collection<E> search(DataDomain domain, Select<E> select) {
		
		Select<E> newSelect = new ParallelSelect<>(select, 8, 200000, configuration.getInteger("query.task.timeout", 60));

		Collection<E> results;
		if (this.isDomainAvailableInCache(domain)){
			results = cacheManager.search(domain, new ParallelSelect<E>(newSelect, 8, 200000, configuration.getInteger("query.task.timeout", 60)));
		}
		else
			results = loadDomainWithSelect(domain, newSelect);
		return results;
	}

	/**
	 * @deprecated not support
	 */
	@Deprecated
	private boolean isDomainAvailableInCache(DataDomain domain) {
        if(domain.equals(cacheManager.getCacheDomain()))
            return true;
        Set<DataKey> dataKeys = searchDataAvailabilities();
        for (DataKey dataKey : dataKeys) {
            if (domain.equals(dataKey.getDomain()))
                return true;
        }
        return false;
    }
}
