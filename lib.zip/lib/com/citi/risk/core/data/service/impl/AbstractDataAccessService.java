package com.citi.risk.core.data.service.impl;

import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.data.proxy.api.InvocationType;
import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.api.DBDataAccessService;
import com.citi.risk.core.data.service.api.DataAccessService;
import com.citi.risk.core.data.service.api.Deleter;
import com.citi.risk.core.data.service.api.Updater;
import com.citi.risk.core.data.store.api.BusinessDays;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.data.store.cache.api.CacheManager;
import com.citi.risk.core.data.store.cache.api.CacheOperations;
import com.citi.risk.core.data.store.cache.api.CacheTask;
import com.citi.risk.core.data.store.cache.api.CacheView;
import com.citi.risk.core.data.store.cache.api.Storer;
import com.citi.risk.core.data.store.cache.impl.AbstractStorer;
import com.citi.risk.core.data.store.cache.impl.BestAvailableDataKeyPredicate;
import com.citi.risk.core.data.store.cache.impl.CriteriaDataKeyPredicate;
import com.citi.risk.core.data.store.cache.impl.DefaultCacheTask;
import com.citi.risk.core.data.store.cache.impl.DefaultDataKeyPredicate;
import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.data.store.impl.DefaultDataKey;
import com.citi.risk.core.data.store.impl.DefaultDatabaseDataKey;
import com.citi.risk.core.data.store.impl.HistoricalLoadable;
import com.citi.risk.core.data.store.impl.LoaderProvider;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.DDL;
import com.citi.risk.core.dictionary.api.DDR;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.api.DataRelationship;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.impl.Criterias;
import com.citi.risk.core.dictionary.impl.CriterionSelect;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark.BatchFrequency;
import com.citi.risk.core.lang.create.api.Create;
import com.citi.risk.core.lang.group.AbstractGroup;
import com.citi.risk.core.lang.group.Group;
import com.citi.risk.core.lang.select.ComparableSelects;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.lang.select.SelectByTransformed;
import com.citi.risk.core.lang.transform.ResolveDeepCopy;
import com.citi.risk.core.security.api.SecurableDictionary;
import com.citi.risk.core.security.api.SecureAction;
import com.citi.risk.core.security.api.SecurityRealm;
import com.citi.risk.core.security.api.SecuritySelect;
import com.citi.risk.core.security.api.User;
import com.citi.risk.core.security.api.UserSecurityService;
import com.citi.risk.core.security.filter.AbstractDataSecurityFilter;
import com.citi.risk.core.security.filter.DataSecurityFilter;
import com.citi.risk.core.security.impl.SecurityUtil;
import com.citi.risk.core.util.TimeMarkConvertor;
import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.google.inject.Injector;

public abstract class AbstractDataAccessService implements DataAccessService, DBDataAccessService{

	protected final static Logger LOGGER = LoggerFactory.getLogger(AbstractDataAccessService.class);

	@Inject
	CacheManager cacheManager;

	@Inject
	DomainImplHelper domainImplHelper;

	@Inject
	TimeMarkConvertor timeMarkConvertor;

	@Inject
	BusinessDays businessDays;

	@Inject
	LoaderProvider loaderProvider;

	@Inject
	Injector injector;

	@Inject
	DomainImplParser domainImplParser;

	@Inject
	Configuration configuration;

	@Inject
	DictionaryParser parser;

	@Inject
	ResolveDeepCopy resolveDeepCopy;

	@Inject
	UserSecurityService userSecurityService;

	@Inject
	SecurableDictionary securableDictionary;
	
	@Inject
	DictionaryParser dictionaryParser;
	
	@Inject
    Create create;

	protected Collection<DataKey> getMatchedDataKeys(DataDomain<?> dataDomain, TimeMark timeMark, CreatedBy createdBy) {
		Collection<DataKey> keys = cacheManager.getMatchedDataKeys(new DefaultDataKeyPredicate(dataDomain, timeMark,
				createdBy));
		if (keys == null) {
			keys = Lists.newArrayList((DataKey) new DefaultDatabaseDataKey(dataDomain));
		}
		return keys;
	}

	protected Collection<DataKey> getBestAvailableDataKeys(DataDomain<?> dataDomain, BatchFrequency frequency,
			Class<?> domainImplClass) {
		Class<?> loaderClass = null;
		if (domainImplClass != null) {
			loaderClass = getActiveLoaderForDomainImpl(domainImplClass);
		}
		Collection<DataKey> keys = cacheManager.getMatchedDataKeys(new BestAvailableDataKeyPredicate(dataDomain,
				frequency, loaderClass));

		return keys;
	}

	protected <E extends IdentifiedBy<?>> Collection<E> selectFromCache(DataDomain dataDomain,
			Collection<DataKey> dataKeys) {
		if (dataKeys.isEmpty()) {
			return Collections.emptyList();
		}
		CacheView<?, E> cacheView = (CacheView) cacheManager.getCache(dataDomain);
		Collection<DataKey> cacheKeys = cacheView.getAllDataKeys();
		if (cacheKeys.size() == dataKeys.size()) {
			return cacheView.getAll();
		} else {
			List<E> values = new ArrayList<>();
			for (DataKey dataKey : dataKeys) {
				values.addAll(cacheView.getCache(dataKey).getAll());
			}
			return values;
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected <E extends IdentifiedBy<?>> Collection<E> selectFromCache(DataDomain dataDomain,
			Collection<DataKey> dataKeys, Select<E> select) {
		if (dataKeys.isEmpty()) {
			return Collections.emptyList();
		}
		CacheView<?, E> cacheView = (CacheView) cacheManager.getCache(dataDomain);
		Collection<DataKey> cacheKeys = cacheView.getAllDataKeys();
		if (cacheKeys.size() == dataKeys.size()) {
			return cacheView.search(select);
		} else {
			List<E> values = new ArrayList<>();
			for (DataKey dataKey : dataKeys) {
				values.addAll(cacheView.getCache(dataKey).getAll());
			}
			return select.select(values);
		}
	}

	protected <K, E extends IdentifiedBy<K>> Collection<E> selectFromCache(DataDomain dataDomain,
			Collection<DataKey> dataKeys, K identifier) {
		CacheView<K, E> cacheView = (CacheView) cacheManager.getCache(dataDomain);
		List<E> values = new ArrayList<>();
		for (DataKey dataKey : dataKeys) {
			E value = cacheView.getCache(dataKey).get(identifier);
			if (value != null) {
				values.add(value);
			}
		}
		return values;
	}
	
	protected <K, E extends IdentifiedBy<K>> Collection<E> selectFromCache(DataDomain dataDomain,
			Collection<DataKey> dataKeys, Collection<K> identifiers) {
		CacheView<K, E> cacheView = (CacheView) cacheManager.getCache(dataDomain);
		List<E> values = new ArrayList<>();
		for (DataKey dataKey : dataKeys) {
			values.addAll( cacheView.getCache(dataKey).getAll(identifiers));
		}
		return values;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected <E extends IdentifiedBy<?>> Collection<E> selectFromDatabase(DataAccessContext dasContext,
			Criteria<E> criteria, Select<E> specialSelect) {
		DataDomain dataDomain = dasContext.getDataDomain();
		TimeMark timeMark = dasContext.getTimeMark();
		CreatedBy createdBy = dasContext.getCreatedBy();

		List<Class<?>> loaderClasses = this.getLoaders(dataDomain, dasContext.getDomainImplClass(),
				timeMark == null ? BatchFrequency.Daily : timeMark.getBatchFrequency());
		List<E> values = new ArrayList<>();
		Loader<?, E> loader;
		for (Class loaderClass : loaderClasses) {
			loader = (Loader<?, E>) this.injector.getInstance(loaderClass);
			TimeMark loaderTimeMark = timeMark;
			if (loaderTimeMark == null) {
				loaderTimeMark = this.getCurrentBusinessDayTimeMark();
			}
			loader.setTimeMark(loaderTimeMark);

			CreatedBy loadercreatedBy = createdBy;
			if (NullTerminator.isCreatedByNullTerminated(loadercreatedBy)) {
				loadercreatedBy = cacheManager.getBestAvailableCreatedBy(dataDomain, loaderClass);
				if (loadercreatedBy == null) {
					loadercreatedBy = new DefaultCreatedBy().withVerionNumber(0).withLoaderClass(
							(Class<? extends Loader>) loaderClass);
				}
			}
			loader.setCreatedBy(loadercreatedBy);
			loader.setIsInTheContextOfService(true);
			loader.setCriteria(criteria);
			loader.setIsDBSpecific(true);
			try {
				values.addAll((Collection) loader.load().get());
			} catch (InterruptedException | ExecutionException e) {
				LOGGER.error(String.format("Loader: %s, Criteria: %s, Exception Message: %s", loader.getClass()
						.getName(), criteria == null ? "null" : criteria.toString(), e.getMessage()));
				throw new RuntimeException(e);
			}
		}
		return this.combineSelect(true, specialSelect, criteria == null ? null : criteria.getSelect()).select(values);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected <K, E extends IdentifiedBy<K>> Collection<E> selectFromDatabase(DataAccessContext dasContext,
			Collection<K> identifiers) {
		DataDomain dataDomain = dasContext.getDataDomain();
		Class implClass = dasContext.getDomainImplClass();
		TimeMark timeMark = dasContext.getTimeMark();
		CreatedBy createdBy = dasContext.getCreatedBy();

		List<Class<?>> loaderClasses = this.getLoaders(dataDomain, implClass, timeMark == null ? BatchFrequency.Daily
				: timeMark.getBatchFrequency());
		List<E> values = new ArrayList<>();
		for (Class loaderClass : loaderClasses) {
			Loader<K, E> loader;
			loader = (Loader<K, E>) this.injector.getInstance(loaderClass);
			TimeMark loaderTimeMark = timeMark;
			if (loaderTimeMark == null) {
				loaderTimeMark = this.getCurrentBusinessDayTimeMark();
			}
			loader.setTimeMark(loaderTimeMark);

			CreatedBy loadercreatedBy = createdBy;
			if (NullTerminator.isCreatedByNullTerminated(loadercreatedBy)) {
				loadercreatedBy = cacheManager.getBestAvailableCreatedBy(dataDomain, loaderClass);
				if (loadercreatedBy == null) {
					loadercreatedBy = new DefaultCreatedBy().withVerionNumber(0).withLoaderClass(
							(Class<? extends Loader>) loaderClass);
				}
			}
			loader.setCreatedBy(loadercreatedBy);

			loader.setIsInTheContextOfService(true);
			loader.setIdentifiers(identifiers);
			loader.setIsDBSpecific(true);
			try {
				values.addAll((Collection) loader.load().get());
			} catch (InterruptedException | ExecutionException e) {
				LOGGER.error(String.format("Loader: %s, Criteria: %s, Exception Message: %s", loader.getClass()
						.getName(), implClass == null ? "null" : implClass.toString(), e.getMessage()));
				throw new RuntimeException(e);
			}
		}
		return values;
	}
	
	private List<Class<?>> getLoaders(DataDomain domain, Class domainImplClass, BatchFrequency batchFrequency) {
		List<Class<?>> loaderClasses = loaderProvider.queryLoaderClasses(domain, domainImplClass, batchFrequency, true,
				null, null, null);
		if (loaderClasses.isEmpty()) {
			loaderClasses = getActiveLoaderClassesFromIOSpec(domain);
		}
		return loaderClasses;
	}

	private List<Class<?>> getActiveLoaderClassesFromIOSpec(DataDomain domain) {
		List<Class<?>> loaderClasses = new ArrayList<>();
		if (domain.getDomainImplClasses() != null) {
			for (Class<?> domainImplClass : domain.getDomainImplClasses()) {
				Class<?> loaderClass = getActiveLoaderForDomainImpl(domainImplClass);
				if (loaderClass != null) {
					loaderClasses.add(loaderClass);
				}
			}
		}
		return loaderClasses;
	}

	private Class<?> getActiveLoaderForDomainImpl(Class<?> domainImpl) {
		DomainImplSpecification domainImplSpec = domainImplParser.parse(domainImpl);

		if (null == domainImplSpec)
			return null;

		if (domainImplSpec.getIOSpecification() != null)
			return domainImplSpec.getIOSpecification().getActiveLoaderClass();
		return null;
	}

	private TimeMark getCurrentBusinessDayTimeMark() {
		TimeMark timeMark = businessDays.getCurrentBusinessPeriodFor(BatchFrequency.Daily);
		TimeMark currentBusinessDayTimeMark = DefaultTimeMark.cloneTimeMark(timeMark);
		currentBusinessDayTimeMark.setBestAvailable(true);
		return currentBusinessDayTimeMark;
	}

	protected DataDomain getDomainByImplClass(Class implClass) {
		return domainImplHelper.getDomainByImplClass(implClass);
	}

	protected TimeMark getTimeMarkFromCriteria(Criteria criteria) {
		return timeMarkConvertor.getTimeMark(criteria);
	}

	protected CreatedBy getCreatedByFromCriteria(Criteria criteria) {
		CreatedBy createdBy = null;

		Collection<Criterion<?>> criterions = criteria.getAllCriterion();
		for (Criterion<?> criterion : criterions) {
			if (criterion.getDataSelectionItem().getUnderlyingPath().hasRelationships()) {
				DataPath<?, ?> path = criterion.getDataSelectionItem().getUnderlyingPath();
				DataRelationship relationship = path.getRelationships().get(0);
				if (StringUtils.equals(relationship.getEndingDomain().getName(),"Created By")) {
					createdBy = DefaultCreatedBy.newCreatedBy(criterion.getOperand(0).toString());
				}
			}
		}
		return createdBy;
	}

	protected <E> Select<E> combineSelect(boolean needParallel, Select<E>... selections) {
		Select<E> newSelect = null;
		if (selections.length == 0) {
			return null;
		}
		for (int i = 0; i < selections.length; i++) {
			if (selections[i] != null) {
				if(newSelect == null){
					newSelect = selections[i];
				}else{
					newSelect = newSelect.and(selections[i]);
				}
			}
		}
		if (needParallel) {
			return new ParallelSelect<>(newSelect, 8, 200000, configuration.getInteger("query.task.timeout", 60));
		} else {
			return newSelect;
		}
	}

	@InfraInvocation(type=InvocationType.Security)
	protected <E extends IdentifiedBy<?>> Collection<E> filterDataBySecurity(Class<E> domainClass,
			Collection<E> originalData, SecureAction... secureAction) {
		if (CollectionUtils.isEmpty(originalData)) {
			return originalData;
		}
		SecuritySelect<E> securitySelect = getSecuritySelect(domainClass, secureAction);
		Collection<E> filteredData = Lists.newArrayList(originalData);
		if (securitySelect != null) {
			ParallelSelect parallelSelect = new ParallelSelect(securitySelect, 8, 200000, configuration.getInteger("query.task.timeout", 60));
			return parallelSelect.select(filteredData);
		}
		return filteredData;
	}

	@InfraInvocation(type=InvocationType.Security)
	protected <E extends IdentifiedBy<?>> SecuritySelect<E> getSecuritySelect(Class<E> domainClass, SecureAction... actions) {
		User user = ExecutionContexts.getCurrentExecutionContext().getUser();
        if (domainClass == null || userSecurityService == null || user == null) {
 
            return null;
        }
 
        SecurityRealm securityRealm = SecurityUtil.getApplicableSecurityRealm(domainClass, securableDictionary);
        if (null == securityRealm) {
            return null;
        }
 
        final List<DataSecurityFilter<E>> filters = Lists.newArrayList();
 
        for(SecureAction action : actions) {
            DataSecurityFilter<E> filter = (DataSecurityFilter<E>) userSecurityService.getAuthorizedFilter(user,
                    domainClass, action, securityRealm);
            if(filter != null)
                filters.add(filter);
        }
        return  buildSecuritySelect(user, filters);
	}
	
	 private <E extends IdentifiedBy<?>> SecuritySelect<E> buildSecuritySelect(User user, final List<DataSecurityFilter<E>> filters) {
	        SecuritySelect<E> securitySelect = null;
	        if (CollectionUtils.isNotEmpty(filters)) {
	            if (filters.size() > 1) {
	                securitySelect = new AbstractDataSecurityFilter<E>(user) {
	                    @Override
	                    public boolean apply(E input) {
	                        return Predicates.and(filters).apply(input); // chain the filters for different actions by AND
	                    }
	                }.toSecuritySelect();
	            } else {
	                securitySelect = filters.get(0).toSecuritySelect();
	            }
	        }
	 
	        return securitySelect;
	    }
	
	@SuppressWarnings("rawtypes")
	protected DataAccessContext prepareDASContextForSearch(DataKey dataKey,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;

		DataDomain domain = dataKey.getDomain();
		TimeMark timeMark = dataKey.getTimeMark();
		CreatedBy createdBy = dataKey.getCreatedBy();

		Collection<DataKey> matchedDataKeys = getMatchedDataKeys(domain, timeMark, createdBy);

		context.setDataDomain(domain);
		context.setDomainClass(domain.getDomainClass());
		context.setTimeMark(timeMark);
		context.setCreatedBy(createdBy);
		context.setDataKeysFromCache(matchedDataKeys);

		return context;

	}
	

	@SuppressWarnings("rawtypes")
	protected <E extends IdentifiedBy<?>> DataAccessContext prepareDASContextForSelect(Criteria<E> criteria,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;

		DataDomain domain = criteria.getDomain();
		TimeMark timeMark = this.getTimeMarkFromCriteria(criteria);
		CreatedBy createdBy = this.getCreatedByFromCriteria(criteria);
		Collection<DataKey> dataKeys;
		dataKeys = this.getMatchedDataKeysByCriteria(domain, criteria);

		context.setDataDomain(domain);
		context.setDomainClass(domain.getDomainClass());
		context.setDomainImplClass(criteria.getDomainImplClass());
		context.setTimeMark(timeMark);
		context.setCreatedBy(createdBy);
		context.setCriteria(criteria);
		context.setDataKeysFromCache(dataKeys);

		return context;
	}
	
	protected Collection<DataKey> getMatchedDataKeysByCriteria(DataDomain<?> dataDomain, Criteria criteria) {
		Collection<DataKey> dataKeys;
		CacheView cacheView = (CacheView)cacheManager.getCache(dataDomain);
		if (cacheView == null) {
			dataKeys = Lists.newArrayList((DataKey) new DefaultDatabaseDataKey(dataDomain));
		} else {
			dataKeys = cacheView.getAllDataKeys();
			DataDomain<DataKey> dataKeyDomain = (DataDomain<DataKey>) dictionaryParser.parseDomain(DataKey.class);
			CriteriaDataKeyPredicate predicate = new CriteriaDataKeyPredicate(dataKeyDomain, criteria);
			dataKeys = predicate.filter(dataKeys);
			if (!predicate.hasDataKeyCriteria()) {
				return getBestAvailableDataKeys(dataDomain, null, null);
			}
		}
		return dataKeys;
	}
	
	@SuppressWarnings("rawtypes")
	protected <E extends IdentifiedBy<?>> DataAccessContext prepareDASContextForSelectTemplate(E template,
			DataAccessContext existingContext) {
		DataAccessContext context = prepareDASContext(template, existingContext);

		context.setTimeMark(template.getTimeMark());
		context.setCreatedBy(template.getCreatedBy());

		return context;
	}

	@SuppressWarnings("rawtypes")
	protected DataAccessContext prepareDASContextForSelect(Class entityClass,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;

		DataDomain domain;
		if (entityClass.isInterface()) {
			domain = parser.parseDomain(entityClass);
		} else {
			domain = this.getDomainByImplClass(entityClass);
		}
		if (domain == null) {
			return null;
		}

		Class rawClass = ProxyHelper.getRawClassFromGuiceProxy(entityClass);
		Class implClass = rawClass.isInterface() ? null : rawClass;
		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, null, implClass);

		context.setDataDomain(domain);
		context.setDomainClass(domain.getDomainClass());
		context.setTimeMark(null);
		context.setCreatedBy(null);
		context.setDomainImplClass(implClass);
		context.setDataKeysFromCache(dataKeys);

		return context;
	}

	@SuppressWarnings({ "rawtypes", })
	protected DataAccessContext prepareDASContextForSelect(DataDomain domain,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;

		Collection<DataKey> dataKeys = getBestAvailableDataKeys(domain, null, null);

		context.setDataDomain(domain);
		context.setDomainClass(domain.getDomainClass());
		context.setDomainImplClass(null);
		context.setDataKeysFromCache(dataKeys);

		return context;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected <E extends IdentifiedBy<?>> DataAccessContext prepareDASContextForCreate(E entity,
			DataAccessContext existingContext) {
		DataAccessContext context = prepareDASContext(entity, existingContext);

		Class updateClass = domainImplHelper.getActiveStorerClass(context.getDomainImplClass());
		Storer storer = (Storer) injector.getInstance(updateClass);
		storer.setDomain(context.getDataDomain());
		((AbstractStorer) storer).setRequireReturns(true);
		context.setStorer(storer);;

		return context;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected <E extends IdentifiedBy<?>> DataAccessContext prepareDASContextForUpdate(E entity,
			DataAccessContext existingContext) {
		DataAccessContext context = prepareDASContext(entity, existingContext);

		Class updateClass = domainImplHelper.getActiveUpdaterClass(context.getDomainImplClass());
		Updater updater = (Updater) injector.getInstance(updateClass);

		context.setUpdater(updater);

		return context;
	}
	
	protected <E extends IdentifiedBy<?>> DataAccessContext prepareDASContextForDelete(E entity,
			DataAccessContext existingContext) {
		DataAccessContext context = prepareDASContext(entity, existingContext);

		Class<? extends Deleter> deleterClass = domainImplHelper.getActiveDeleterClass(context.getDomainImplClass());
		Deleter deleter = (Deleter) injector.getInstance(deleterClass);

		context.setDeleter(deleter);

		return context;
	}
	
	protected DataAccessContext prepareDASContextForDelete(Class domainImplClass,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;
		
		DataDomain domain = getDomainByImplClass(domainImplClass);
		Collection<DataKey> dataKeys = this.getBestAvailableDataKeys(domain, null, domainImplClass);
		Class<? extends Deleter> deleterClass;
		deleterClass = domainImplHelper.getActiveDeleterClass(domainImplClass);
		Deleter deleter = injector.getInstance(deleterClass);
		
		context.setDataDomain(domain);
		context.setDomainClass(domain.getDomainClass());
		context.setTimeMark(null);
		context.setCreatedBy(null);
		context.setDomainImplClass(domainImplClass);
		context.setDataKeysFromCache(dataKeys);
		context.setDeleter(deleter);
		
		return context;
	}
	
	@SuppressWarnings("rawtypes")
	private <E extends IdentifiedBy<?>> DataAccessContext prepareDASContext(E entity,
			DataAccessContext existingContext) {
		DataAccessContext context = existingContext == null ? new DataAccessContext() : existingContext;
		
		Class domainImplClass = ProxyHelper.getRawClass(entity);
		DataDomain dataDomain = domainImplHelper.getDomainByImplClass(domainImplClass);
		Class domainClass = dataDomain.getDomainClass(); 
		Class loaderClass = getActiveLoaderForDomainImpl(domainImplClass);

		Collection<DataKey> dataKeysFromCache = getBestAvailableDataKeys(dataDomain, null, domainImplClass);

		context.setDomainClass(domainClass);
		context.setDomainImplClass(domainImplClass);
		context.setDataDomain(dataDomain);
		context.setDataKeysFromCache(dataKeysFromCache);
		context.setLoaderClass(loaderClass);

		return context;
	}

	protected <E extends IdentifiedBy<?>> Collection<E> filterResultsByImplClass(Collection<E> results, Class implClass) {

		Collection<E> returnCollection = Lists.newArrayList();
		if (implClass != null) {
			for (E value : results) {
				if (ProxyHelper.isInstanceof(implClass, value)) {
					returnCollection.add(value);
				}
			}
		} else {
			returnCollection = results;
		} 
		return returnCollection;
	}
	
	protected <E extends IdentifiedBy<?>> Collection<E> getRawValueFromValueHolder(Collection<E> values) {
		return ProxyHelper.getValuesParallel(values);
	}

	protected <E extends IdentifiedBy<?>> E getRawValueFromValueHolder(E value) {
		return ProxyHelper.getHoldingValue(value);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected Criteria getCriteriaFromSelect(Select select) {
		if (select == null) {
			return null;
		}
		Criteria criteria = null;
		Collection<Select> allSelects = select.parse();
		for (Select s : allSelects) {
			if (s instanceof CriterionSelect) {
				CriterionSelect criterionSelect = (CriterionSelect) s;
				if (criteria == null) {
					criteria = criterionSelect.getCriterion().criteria();
				} else {
					criteria = criteria.and(criterionSelect.getCriterion().criteria());
				}
			}
		}

		return criteria;
	}
	
	protected void recordModifiedDomainForTestCase(Class<?> implClass) {
		Set<Class<?>> modfiedDomains = ExecutionContexts.getCurrentExecutionContext().getModifiedDomains();
		if (modfiedDomains != null && !modfiedDomains.contains(implClass)) {
			modfiedDomains.add(implClass);
		}
	}

	protected <E extends IdentifiedBy<?>> Map<Class, Collection<E>> groupEntities(Collection<E> entities) {
		Collection<E> entitiesCopy = Lists.newArrayList(entities);
		Group<Class,E> groupByImplClass = new GroupByImplClass<>();
		Map<Class, Collection<E>> groupedEntities = groupByImplClass.groupIntoMapWithProcessing(entitiesCopy);
		return groupedEntities;
	}
	
	class  GroupByImplClass<E extends IdentifiedBy<?>> extends AbstractGroup<Class, E>{
		@Override
		public Class groupOf(E value) {
			return ProxyHelper.getRawClass(value);
		}
		
		@Override
		protected Object process(E item){
			return getRawValueFromValueHolder(item);
		}
		
	}
	
	protected <T> Criteria<T> convertTemplateToCriteria(T template) {
		return templateToCriteria(template);
	}

	private <T> Criteria templateToCriteria(T template, DataPath... contextPath) {
		DataDomain domain = domainImplHelper.getDomain(template);
		Criteria criteria = null;

		for (Method method : domain.getDomainClass().getMethods()) {
			try {
				if (!isManagedVersionMethod(method, template)) {
					criteria = appendCriteria(template, domain, criteria, method, contextPath);
				}
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				LOGGER.debug(e.getMessage(), e);
			}
		}
		if (null == criteria)
			throw new UnsupportedOperationException("There is no value in " + template.getClass() + ".");
		criteria.setDomainImplClass(template.getClass());
		return criteria;
	}

	private <T> Criteria appendCriteria(T template, DataDomain domain, Criteria criteria, Method method,
			DataPath... contextPath) throws IllegalAccessException, InvocationTargetException {
		Criteria appendedCriteria = criteria;
		Object value = method.invoke(template);
		if (isValueAvailable(value)) {
			Criteria nextCriteria = getCriteriaForMethod(domain, method, value, contextPath);
			if (nextCriteria != null) {
				appendedCriteria = (criteria == null) ? nextCriteria : criteria.and(nextCriteria);
			}
		}
		return appendedCriteria;
	}
	
	private <T> boolean isManagedVersionMethod(Method method, T template) {
        if (StringUtils.equals(method.getName(),"incrementVersion")
                || (StringUtils.equals(method.getName(),"getIdentifier") && ManagedVersion.class.isAssignableFrom(template
                .getClass())))
            return true;
        return false;
    }

	private Criteria getCriteriaForMethod(DataDomain domain, Method method, Object value,
			DataPath... contextPath) {
		Criteria nextCriteria = null;

		DDI itemAnnotation = method.getAnnotation(DDI.class);
		DDL listAnnotation = method.getAnnotation(DDL.class);
		DDR relnAnnotation = method.getAnnotation(DDR.class);
		if (itemAnnotation != null)
			nextCriteria = Criterias.buildCriteriaForDDI(domain, value, itemAnnotation, contextPath);
		else if (listAnnotation != null)
			nextCriteria = Criterias.buildCriteriaForDDL();
		else if (relnAnnotation != null)
			nextCriteria = buildCriertiaForDDR(domain, value, relnAnnotation, contextPath);

		return nextCriteria;
	}

	private boolean isValueAvailable(Object value) {
		if (value == null)
			return false;

		if (Collection.class.isAssignableFrom(value.getClass())) {
			return !((Collection<?>) value).isEmpty();
		}
		return true;
	}

	private Criteria buildCriertiaForDDR(DataDomain domain, Object value, DDR relnAnnotation,
			DataPath... contextPath) {
		Criteria nextCriteria;
		if (StringUtils.equals(relnAnnotation.name(),"Time mark")) {
			if (NullTerminator.isTimeMarkNullTerminated((TimeMark) value))
				return null;
			nextCriteria = domain.getRelationship("Time mark").eq((TimeMark) value);
		} else if (StringUtils.equals(relnAnnotation.name(),"Created by")) {
			if (NullTerminator.isCreatedByNullTerminated((CreatedBy) value))
				return null;
			nextCriteria = domain.getRelationship("Created by").eq((CreatedBy) value);
		} else {
			relationshipValidation(value, relnAnnotation);
			
			DataPath nextPath = (contextPath == null || contextPath.length == 0) ? domain.getRelationship(relnAnnotation.name())
					.path() : contextPath[0].append(domain.getRelationship(relnAnnotation.name()).path());
			nextCriteria = templateToCriteria(value, nextPath);
		}
		return nextCriteria;
	}
	
	private void relationshipValidation(Object value, DDR relnAnnotation)  {
        if (!relnAnnotation.isDimension() || Collection.class.isAssignableFrom(value.getClass()))
            throw new UnsupportedOperationException(
                    "Conversion of multi-dimensional items to criteria is not supported.");
        if (!relnAnnotation.isValueType())
            throw new UnsupportedOperationException(
                    "Conversion of non-valueType item to criteria is not supported.");
    }

	private void findImplClasses(DataDomain domain, Criterion criterion, Map<Class<?>, List<Criterion>> criterions) {
		for (Class<?> domainImplClass : domain.getDomainImplClasses()) {
			if (!criterions.containsKey(domainImplClass)) {
				criterions.put(domainImplClass, (List) Lists.newArrayList());
			}
			criterions.get(domainImplClass).add(criterion);
		}

	}

	private void findEqualCriterionsAndImplClasses(DataDomain domain, Criterion criterion,
			Map<Class<?>, List<Criterion>> criterions) {
		Class<?>[] domainImplClasses = domain.getDomainImplClasses();

		for (Class<?> domainImplClass : domainImplClasses) {
			if (!criterions.containsKey(domainImplClass))
				criterions.put(domainImplClass, Lists.newArrayList(criterion));
			else
				criterions.get(domainImplClass).add(criterion);
		}
	}

	protected <E extends IdentifiedBy<?>> void findEqualCriterions(DataDomain domain, Select<E> select,
			Map<Class<?>, List<Criterion>> criterions) {

		Collection<Select<E>> selectsList = select.parse();

		for (Select<E> s : selectsList) {
			if (s instanceof CriterionSelect) {
				CriterionSelect criterionSelect = (CriterionSelect) s;
				SelectByTransformed transformedSelect = (SelectByTransformed) criterionSelect.getSelect();

				if (((transformedSelect.getSelect() instanceof ComparableSelects.EqualsTo) || (transformedSelect
						.getSelect() instanceof ComparableSelects.Like)) && (!criterionSelect.isNegated())) {
					findDomainImplClasses(domain, criterions, criterionSelect);
				}
			}
		}
	}

	private void findDomainImplClasses(DataDomain domain, Map<Class<?>, List<Criterion>> criterions,
			CriterionSelect criterionSelect) {
		Criterion criterion = criterionSelect.getCriterion();

		if (criterion.getDataSelectionItem().getUnderlyingPath().hasRelationships())
			findImplClasses(domain, criterion, criterions);
		else if (criterion.getDataSelectionItem().getUnderlyingPath().isTerminatedWithAnItem())
			findEqualCriterionsAndImplClasses(domain, criterion, criterions);
	}

	/**
	 * @deprecated
	 */
	@Deprecated
	protected <E extends IdentifiedBy<?>> Collection<E> loadDomainWithSelect(DataDomain domain, Select<E> select) {
		Map<Class<?>, List<Criterion>> criterions = Maps.newHashMap();
		Collection<E> results;
		TimeMark criteriaTimeMark = timeMarkConvertor.getTimeMark(domain, select);
		findEqualCriterions(domain, select, criterions);
		results = getResultsFromLoaderForCriterions(domain, criterions, criteriaTimeMark);

		return select.select(results);
	}
	
	 @SuppressWarnings({ "unchecked", "rawtypes" })
    private <E extends IdentifiedBy<?>> Collection<E> getResultsFromLoaderForCriterions(DataDomain domain, Map<Class<?>, List<Criterion>> criterions, TimeMark criteriaTimeMark) {
        Collection<E> results = new ArrayList<>();
        try {
            if (criterions.keySet().isEmpty())
                throw new RuntimeException("No equality criteria found in DB Query");
            else {
                for (Entry<Class<?>, List<Criterion>> implClassEntry : criterions.entrySet()) {
                    Loader loader = prepareLoader(domain, criteriaTimeMark, implClassEntry);
                    results.addAll((Collection<E>) loader.load().get());
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return Collections.emptyList();
        }
        return results;
    }

	private Loader prepareLoader(DataDomain domain, TimeMark criteriaTimeMark,
			Entry<Class<?>, List<Criterion>> implClassEntry) {
		BatchFrequency batchFrequency = BatchFrequency.Daily;
		Collection<Criterion<?>> criterionsForImplClass = new ArrayList<>();
		for (Criterion criterion : implClassEntry.getValue()) {
		    criterionsForImplClass.add(criterion);
		}
		Criteria criteria = Criterias.createCriteria(criterionsForImplClass);
		if (criteriaTimeMark != null)
		    batchFrequency = criteriaTimeMark.getBatchFrequency();
		Loader loader = loaderProvider.getLoader(batchFrequency, domain, implClassEntry.getKey(), true, criteriaTimeMark);
		loader.setCriteria(criteria);
		return loader;
	}

	public <T extends IdentifiedBy<?>> void setTimeMarksAndCreatedByToItems(Collection<T> items,DataKey dataKey) {
        for (T item : items) {
            item.setTimeMark(dataKey.getTimeMark());
            item.setCreatedBy(dataKey.getCreatedBy());
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public <T extends IdentifiedBy<?>> void removeFromCache(Collection<T> items, Collection<?> expiredKeys, Class domainImplClass, DataKey baDataKey) {

        if (!cacheManager.doesCacheExist(baDataKey)) {
            return;
        }
        
        if(!domainImplHelper.isInitialLoad(domainImplClass)) {
        	return;
        }

		if (ManagedVersion.class.isAssignableFrom(domainImplClass) && baDataKey.getCreatedBy() != null && HistoricalLoadable.class.isAssignableFrom(baDataKey.getCreatedBy().getLoaderClass())) {
			Cache cache = cacheManager.getUnderlyingCache(baDataKey);
			Collection<T> expiredItems = cache.getAll(expiredKeys);
			removeFromCacheWithManagedVersion(items, expiredItems, domainImplClass, baDataKey);
		} else {
			TimeMark timeMark = baDataKey.getTimeMark();
			CreatedBy createdBy = baDataKey.getCreatedBy();
			DataDomain domain = baDataKey.getDomain();

			Class loaderClass = domainImplHelper.getActiveLoaderClass(domainImplClass);

			CacheTask cacheTask = (new DefaultCacheTask()).domain(domain).loaderClass(loaderClass).timeMark(timeMark).createdBy(createdBy).operation(CacheOperations.Remove);
			cacheTask.setOptionalPayload(items);
			try {
				cacheManager.remove(cacheTask).get();
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		}
    }

	private <T extends IdentifiedBy<?>> void removeFromCacheWithManagedVersion(Collection<T> items, Collection<T> expiredItems, Class domainImplClass, DataKey baDataKey) {
		if (!cacheManager.doesCacheExist(baDataKey)) {
			return;
		}

		if (!domainImplHelper.isInitialLoad(domainImplClass)) {
			return;
		}

		TimeMark timeMark = baDataKey.getTimeMark();
		CreatedBy createdBy = baDataKey.getCreatedBy();
		DataDomain domain = baDataKey.getDomain();

		Class loaderClass = domainImplHelper.getActiveLoaderClass(domainImplClass);

		CacheTask cacheTask = (new DefaultCacheTask()).domain(domain).loaderClass(loaderClass).timeMark(timeMark).createdBy(createdBy).operation(CacheOperations.RemoveManagedVersion);
		cacheTask.setOptionalPayload(items);
		cacheTask.setExpiredOptionalPayload(expiredItems);
		try {
			cacheManager.removeManagedVersion(cacheTask).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
	}

	public <T extends IdentifiedBy<?>> void mergeToCache(Collection<T> items, Collection<?> expiredKeys, Class targetImplClass, DataKey baDataKey) {
		if (!cacheManager.doesCacheExist(baDataKey)) {
			return;
		}

		if(!domainImplHelper.isInitialLoad(targetImplClass)) {
			return;
		}
		Cache cache = cacheManager.getUnderlyingCache(baDataKey);
		Collection<T> expiredItems = cache.getAll(expiredKeys);

		if (ManagedVersion.class.isAssignableFrom(targetImplClass) && baDataKey.getCreatedBy() != null && HistoricalLoadable.class.isAssignableFrom(baDataKey.getCreatedBy().getLoaderClass())) {
			mergeToCacheWithManagedVersion(items, expiredItems, targetImplClass, baDataKey);
		} else {
			mergeToCache(items, targetImplClass, baDataKey);
		}
	}

	public <T extends IdentifiedBy<?>> void createToCache(Collection<T> items, Class targetImplClass,DataKey baDataKey) {
		mergeToCache(items, Collections.emptyList(), targetImplClass, baDataKey);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    private <T extends IdentifiedBy<?>> void mergeToCache(Collection<T> items, Class targetImplClass,DataKey baDataKey) {

        if (!cacheManager.doesCacheExist(baDataKey)) {
            return;
        }

		if(!domainImplHelper.isInitialLoad(targetImplClass)) {
        	return;
        }

        Cache cache = cacheManager.getUnderlyingCache(baDataKey);
        Class rawImplClass = ProxyHelper.getRawClassFromGuiceProxy(targetImplClass);
    
        Class<? extends Loader> activeLoaderClass = domainImplHelper.getActiveLoaderClass(rawImplClass);
        DataDomain targetDomain = cache.getDomain();
        TimeMark timeMark = cache.getTimeMark();
        CreatedBy createdBy = cache.getCreatedBy();
        DataKey dataKey = new DefaultDataKey(targetDomain, timeMark, createdBy);
        CacheTask task = new DefaultCacheTask().domain(targetDomain).loaderClass(activeLoaderClass)
                .createdBy(createdBy).timeMark(timeMark).operation(CacheOperations.Put);
        setTimeMarksAndCreatedByToItems(items, dataKey);
        task.setOptionalPayload(items);

        try {
            cacheManager.put(task).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
        
    }

	protected <K, E extends IdentifiedBy<K>> Collection<K> getIdentifiedByKeys(final Collection<E> entites)  {
		return com.citi.risk.core.lang.collection.list.Lists.newArrayList(Collections2.transform(entites, new Function<E, K>() {
			@Override
			public K apply(E input) {
				if (ManagedVersion.class.isAssignableFrom(input.getClass())) {
					E latestVh = ((ManagedVersion<?>) input).getLatest();
					if (latestVh != null) {
						return latestVh.key();
					}
				}
				return input.key();
			}
		}));
	}
	
	private <T extends IdentifiedBy<?>> void mergeToCacheWithManagedVersion(Collection<T> items, Collection<T> oldItems, Class targetImplClass, DataKey baDataKey) {
		if (!cacheManager.doesCacheExist(baDataKey)) {
			return;
		}
		if (!domainImplHelper.isInitialLoad(targetImplClass)) {
			return;
		}

		Cache cache = cacheManager.getUnderlyingCache(baDataKey);
		Class rawImplClass = ProxyHelper.getRawClassFromGuiceProxy(targetImplClass);
		Class<? extends Loader> activeLoaderClass = domainImplHelper.getActiveLoaderClass(rawImplClass);
		DataDomain targetDomain = cache.getDomain();
		TimeMark timeMark = cache.getTimeMark();
		CreatedBy createdBy = cache.getCreatedBy();
		DataKey dataKey = new DefaultDataKey(targetDomain, timeMark, createdBy);
		CacheTask task = new DefaultCacheTask().domain(targetDomain).loaderClass(activeLoaderClass)
				.createdBy(createdBy).timeMark(timeMark).operation(CacheOperations.PutManagedVersion);
		setTimeMarksAndCreatedByToItems(items, dataKey);
		task.setOptionalPayload(items);
		task.setExpiredOptionalPayload(oldItems);

		try {
			cacheManager.putManagedVersion(task).get();
		} catch (InterruptedException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    protected <T extends IdentifiedBy<?>> void getLoaderAndResolve(Class loaderClass, Collection<T> results, DataKey dataKey) {
    	getLoaderAndResolve(loaderClass, results, null, dataKey);
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private <T extends IdentifiedBy<?>> void getLoaderAndResolve(Class loaderClass, Collection<T> results, Collection<T> sources, DataKey dataKey) {
        setTimeMarksAndCreatedByToItems(results, dataKey);
        if (loaderClass != null && !loaderClass.isInterface()) {
			Collection identifiers = Lists.newArrayList();
			for (T entity : results) {
				if (entity != null) {
					identifiers.add(entity.key());
				}
			}
			
			ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();;
			try
			{
				AbstractLoader correspondingLoader = (AbstractLoader) injector.getInstance(loaderClass);
				correspondingLoader.setIsInTheContextOfService(true);
				executionContext.setCurrentLoader(correspondingLoader);
				correspondingLoader.setCreatedBy(dataKey.getCreatedBy());
				correspondingLoader.setTimeMark(dataKey.getTimeMark());
				correspondingLoader.setIdentifiers(identifiers);
				
				if (null == sources) {
					correspondingLoader.resolve(results);
				}
				else
				{
					T target = Iterables.getFirst(results, null);
					Class<? extends IdentifiedBy> dataClass = target.getClass();
					int size = results.size();
					T[] targetArray = (T[])Array.newInstance(dataClass, size);
					T[] sourceArray = (T[])Array.newInstance(dataClass, size);
					correspondingLoader.resolve(results.toArray(targetArray), sources.toArray(sourceArray));
				}
			}
			finally
			{
				executionContext.setCurrentLoader(null);
			}
		}
    }
    
}
