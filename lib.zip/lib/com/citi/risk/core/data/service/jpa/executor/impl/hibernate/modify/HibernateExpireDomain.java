package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.ejb.EntityManagerImpl;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.type.CustomType;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.service.jpa.VersionExpiredException;
import com.citi.risk.core.data.service.jpa.VersionMortal;
import com.citi.risk.core.data.service.jpa.VersionMortalField;
import com.citi.risk.core.data.service.jpa.VersionMotralFieldCategory;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.HibernateTxStep;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.IOSpecification;
import com.citi.risk.core.data.subscription.api.DataModifyType;
import com.citi.risk.core.data.version.impl.BeforeAndAfterImpl;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.google.inject.Injector;

public class HibernateExpireDomain extends HibernateTxStep<ManagedVersion, Integer> {
	private static final Logger LOGGER = LoggerFactory.getLogger(HibernateExpireDomain.class);
	
	private LockMode lockMode;
	private ManagedVersion entity;
	private boolean isWriteBehind;

	public HibernateExpireDomain(Class entityClass, Injector injector) {
		super(entityClass, injector);
		this.isWriteBehind = false;
	}

	public HibernateExpireDomain expire(ManagedVersion entity) {
		this.entity = entity;
		return this;
	}

	public HibernateExpireDomain lock(LockMode lockMode) {
		this.lockMode = lockMode;
		return this;
	}

	public HibernateExpireDomain writeBehind() {
		this.isWriteBehind = true;
		return this;
	}
	
	public HibernateExpireDomain entityManager(EntityManager entityManager) {
		setEntityManager(entityManager);
		return this;
	}

	@Override
	protected Integer execute(EntityManager entityManager) {
		VersionMortal versionMortal = findVersionMortal(entity.getClass());
		Query query;
		if (isWriteBehind) {
			query = checkVersionExistsQuery(entity.getClass(), entity, entityManager);
			if (query.uniqueResult() == null) {
				return 0;
			}
		}
		if (versionMortal == null) {
			query = buildDefaultExpiredQuery(entity.getClass(), entity, entityManager);
		} else {
			query = buildCustomExpiredQuery(versionMortal, entity.getClass(), entity, entityManager);
		}
		int count = query.setLockMode("e", lockMode).executeUpdate();
		if (count == 0) {
			recordDomain(entityManager, entity);
			String queryString = query.getQueryString();
			ClassMetadata classMetadata = ((EntityManagerImpl) entityManager).getSession().getSessionFactory()
					.getClassMetadata(entity.getClass());
			Serializable identifier = classMetadata.getIdentifier(entity);
			queryString = StringUtils.replace(queryString, ":id", identifier.toString());
			queryString = StringUtils.replace(queryString, ":expired", "true");
			queryString = StringUtils.replace(queryString, ":oldExpired", "false");
			throw new VersionExpiredException("Can't make entity expired, the below sql change no entry in database:\n"
					+ "SQL: {" + queryString+ "}\n"
					+ "entity class is: "+ entity.getClass().getSimpleName() + ", Business Key is: " + entity.getBusinessKey()
					+ ", Entity Identifier is: " + identifier
					+ ", Entity Version is: " + entity.getVersion() + ", Entity Expired is: " + entity.getExpired());
		}
		return count;
	}

	private void recordDomain(EntityManager entityManager, ManagedVersion<?> entity) {
		DomainImplSpecification domainImplSepc = getInjector().getInstance(DomainImplParser.class).parse(
				entity.getClass());
		IOSpecification ioSpec = domainImplSepc.getIOSpecification();
		if (ioSpec != null && StringUtils.isNotBlank(ioSpec.getManagedVersionBusinessKeyField())
				&& StringUtils.isNotBlank(ioSpec.getManagedVersionVersionField())) {
			Criteria query = buildGetEntityByBKQuery(entity.getClass(), entity, entityManager,
					ioSpec.getManagedVersionBusinessKeyField(), ioSpec.getManagedVersionVersionField());
			List<Object> ids = query.list();
			recordDomain(DataModifyType.Update, entity, null);
			if (CollectionUtils.isNotEmpty(ids)) {
				for (Object id : ids) {
					recordDomain(DataModifyType.Update, entity, id);
				}
			}
		}
	}

	private VersionMortal findVersionMortal(Class<?> entityClass) {
		if (entityClass == Object.class) {
			return null;
		}
		VersionMortal ann = (VersionMortal) entityClass.getAnnotation(VersionMortal.class);
		if (ann == null) {
			return findVersionMortal(entityClass.getSuperclass());
		}
		return ann;
	}

	private Query checkVersionExistsQuery(Class entityClass, ManagedVersion entity, EntityManager entityManager) {
		String queryString = "SELECT e from " + entityClass.getSimpleName() + " e WHERE e.id = :id";
		ClassMetadata classMetadata = ((EntityManagerImpl) entityManager).getSession().getSessionFactory()
				.getClassMetadata(entityClass);
		Query query = ((EntityManagerImpl) entityManager).getSession().createQuery(queryString);
		query.setParameter("id", classMetadata.getIdentifier(entity), classMetadata.getIdentifierType());
		return query;
	}

	private Criteria buildGetEntityByBKQuery(Class entityClass, ManagedVersion entity, EntityManager entityManager,
			String bkField, String versionField) {
		Session session = ((EntityManagerImpl) entityManager).getSession();
		Criteria criteria = session.createCriteria(entityClass)
			   .setProjection(Projections.id())
			   .add(Restrictions.eq(bkField, entity.getBusinessKey()))
			   .add(Restrictions.gt(versionField, entity.getVersion()));
		
		return criteria;
	}

	private Query buildDefaultExpiredQuery(Class entityClass, ManagedVersion entity, EntityManager entityManager) {
		String updateString = "UPDATE " + entityClass.getSimpleName() + " e SET e.expired = :expired";
		ClassMetadata classMetadata = ((EntityManagerImpl) entityManager).getSession().getSessionFactory()
				.getClassMetadata(entityClass);
		Date validThru = null;
		if (ArrayUtils.contains(classMetadata.getPropertyNames(), "validThru")) {
			validThru = new Date();
			updateString += ", validThru = :validThru";
		}
		updateString += " WHERE e.id = :id AND e.expired = :oldExpired"; // and version = :version
		Query query = ((EntityManagerImpl) entityManager).getSession().createQuery(updateString);
		query.setParameter("id", classMetadata.getIdentifier(entity), classMetadata.getIdentifierType());
		query.setParameter("expired", true, classMetadata.getPropertyType("expired"));
		query.setParameter("oldExpired", false, classMetadata.getPropertyType("expired"));
		if (validThru != null) {
			query.setParameter("validThru", validThru, classMetadata.getPropertyType("validThru"));
		}
		return query;
	}

	private Query buildCustomExpiredQuery(VersionMortal versionMortal, Class entityClass, ManagedVersion entity,
			EntityManager entityManager) {
		ClassMetadata classMetadata = ((EntityManagerImpl) entityManager).getSession().getSessionFactory()
				.getClassMetadata(entityClass);
		VersionMortalField[] fields = versionMortal.fields();

		StringBuilder updateFields = new StringBuilder("UPDATE " + entityClass.getSimpleName() + " e SET e.");
		StringBuilder updateWhere = new StringBuilder(" WHERE e.id = :id AND e.");

		Map<String, Object> value = new HashMap();
		Map<String, Type> types = new HashMap();

		// expired
		VersionMortalField field = getFeild(fields, VersionMotralFieldCategory.Expired);
		if (field != null && StringUtils.isNotBlank(field.name())) {
			updateFields.append(field.name()).append(" = :expired");
			updateWhere.append(field.name()).append(" = :oldExpired");
			value.put("expired", Boolean.TRUE);
			types.put("expired", classMetadata.getPropertyType(field.name()));
			value.put("oldExpired", Boolean.FALSE);
			types.put("oldExpired", classMetadata.getPropertyType(field.name()));
		} else {
			throw new VersionExpiredException("Can't find Expired field in " + entityClass.getSimpleName()
					+ ", Business Key is: " + entity.getBusinessKey() + ", Entity Version is: " + entity.getVersion());
		}

		// validthru
		field = getFeild(fields, VersionMotralFieldCategory.ValidThru);
		if (field != null && StringUtils.isNotBlank(field.name())) {
			value.put("validThru", new Date());
			types.put("validThru", classMetadata.getPropertyType(field.name()));
			updateFields.append(", ").append(field.name()).append(" = :validThru");
		}

		// Version
		field = getFeild(fields, VersionMotralFieldCategory.Version);
		if (field != null && StringUtils.isNotBlank(field.name())) {
			value.put("version", classMetadata.getPropertyValue(entity, field.name()));
			types.put("version", classMetadata.getPropertyType(field.name()));
			updateWhere.append(" AND e.").append(field.name()).append(" = :version");
		}

		// Other fields
		for (int index = 0; index < fields.length; index++) {
			if (fields[index] != null && VersionMotralFieldCategory.Other == fields[index].category()
					&& StringUtils.isNotBlank(fields[index].name())) {
				String fieldName = "PARAM_" + index;
				value.put(fieldName, getFieldValue(fields[index], classMetadata.getPropertyType(fields[index].name())));
				types.put(fieldName, classMetadata.getPropertyType(fields[index].name()));
				updateFields.append(", e.").append(fields[index].name()).append(" = :").append(fieldName);
			}
		}
		updateFields.append(updateWhere);
		LOGGER.info(updateFields.toString());
		Query query = ((EntityManagerImpl) entityManager).getSession().createQuery(updateFields.toString());
		query.setParameter("id", classMetadata.getIdentifier(entity), classMetadata.getIdentifierType());
		for (Map.Entry<String, Object> entry : value.entrySet()) {
			query.setParameter(entry.getKey(), entry.getValue(), types.get(entry.getKey()));
		}
		return query;
	}

	private Object getFieldValue(VersionMortalField field, Type type) {
		if (type instanceof CustomType && ((CustomType) type).getUserType().returnedClass() == BeforeAndAfterImpl.class) {
			Object o = parseIdentifier(field.valueClass(), field.value());
			return new BeforeAndAfterImpl(o, o);
		}
		return parseIdentifier(field.valueClass(), field.value());
	}

	private VersionMortalField getFeild(VersionMortalField[] fields, VersionMotralFieldCategory category) {
		for (int index = 0; index < fields.length; index++) {
			if (category == fields[index].category()) {
				return fields[index];
			}
		}
		return null;
	}

	private Object parseIdentifier(Class idType, String idValue) {
		if (String.class.isAssignableFrom(idType))
			return idValue;
		if (Long.class.isAssignableFrom(idType))
			return Long.valueOf(idValue);
		if (Double.class.isAssignableFrom(idType))
			return Double.valueOf(idValue);
		if (Integer.class.isAssignableFrom(idType))
			return Integer.valueOf(idValue);
		if (Boolean.class.isAssignableFrom(idType)) {
			return Boolean.valueOf(idValue);
		}
		if (idType.isEnum()) {
			return Enum.valueOf(idType, idValue);
		}
		throw new RuntimeException("unable to convert identifier to: " + idType.getName());
	}

}
