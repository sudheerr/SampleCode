package com.citi.risk.core.data.service.jpa.executor.impl.hibernate;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Collections;

import org.springframework.util.CollectionUtils;

import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

public class ResolveReference<E extends IdentifiedBy<?>> {

	private Collection<E> targetItems = Collections.emptyList();
	private Collection<E> sourceItems = Collections.emptyList();
	private AbstractLoader loader = null;
	private E modifyTemlate = null;
	
	public ResolveReference(Collection<E> resolveItems, AbstractLoader loader, E modifyTemlate) {
		this.targetItems = resolveItems;
		this.loader = loader;
		this.modifyTemlate = modifyTemlate;
	}
	
	public ResolveReference(Collection<E> resolveItems, Collection<E> sourceItems, AbstractLoader loader, E modifyTemlate) {
		this.targetItems = resolveItems;
		this.sourceItems = sourceItems;
		this.loader = loader;
		this.modifyTemlate = modifyTemlate;
	}
	
	public void getLoaderAndResolve() {
		if(loader == null || loader.getClass().isInterface() || CollectionUtils.isEmpty(targetItems)) {
			return;
		}
		setTimeMarkAndCreatedByToItems();
		Collection identifiers = Lists.newArrayList();
		for (E entity : targetItems) {
			if (entity != null) {
				identifiers.add(entity.key());
			}
		}
		ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();;
		try
		{
			E item = Iterables.getFirst(targetItems, null);
			loader.setIsInTheContextOfService(true);
			executionContext.setCurrentLoader(loader);
			loader.setCreatedBy(item.getCreatedBy());
			loader.setTimeMark(item.getTimeMark());
			loader.setIdentifiers(identifiers);
			
			if(CollectionUtils.isEmpty(sourceItems)) { 
				loader.resolve(targetItems);
			} else {
				Class<? extends IdentifiedBy> dataClass = item.getClass();
				int size = targetItems.size();
				E[] targetArray = (E[])Array.newInstance(dataClass, size);
				E[] sourceArray = (E[])Array.newInstance(dataClass, size);
				loader.resolve(targetItems.toArray(targetArray), sourceItems.toArray(sourceArray));
			}
		}
		finally
		{
			executionContext.setCurrentLoader(null);
		}
	}

	private void setTimeMarkAndCreatedByToItems() {
		
		TimeMark timeMark = null;
		CreatedBy createdBy = null;
		
		if(modifyTemlate != null) {
			timeMark = NullTerminator.isTimeMarkNullTerminated(modifyTemlate.getTimeMark()) ? null : modifyTemlate.getTimeMark();
			createdBy = NullTerminator.isCreatedByNullTerminated(modifyTemlate.getCreatedBy()) ? null : modifyTemlate.getCreatedBy();
		} else if(!CollectionUtils.isEmpty(sourceItems)) {
			E firstItem = Iterables.getFirst(sourceItems, null);
			timeMark = NullTerminator.isTimeMarkNullTerminated(firstItem.getTimeMark()) ? null : firstItem.getTimeMark();
			createdBy = NullTerminator.isCreatedByNullTerminated(firstItem.getCreatedBy()) ? null : firstItem.getCreatedBy();
		}
		if(timeMark == null && createdBy == null) {
			return;
		}
	    setTargets(timeMark, createdBy);
	}

	private void setTargets(TimeMark timeMark, CreatedBy createdBy) {
		for (E item : targetItems) {
	        item.setTimeMark(timeMark);
	        item.setCreatedBy(createdBy);
	    }
	}
	
}
