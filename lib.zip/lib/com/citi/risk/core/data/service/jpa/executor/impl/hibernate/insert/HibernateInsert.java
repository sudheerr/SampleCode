package com.citi.risk.core.data.service.jpa.executor.impl.hibernate.insert;

import java.util.Collection;

import javax.persistence.EntityManager;

import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.HibernateTxStep;
import com.citi.risk.core.data.subscription.api.DataModifyType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.google.inject.Injector;

public class HibernateInsert<K, D extends IdentifiedBy<K>, E extends D> extends HibernateTxStep<E, Collection<E>> {

	private Collection<E> insertItems;
    
	private final static int BATCH_SIZE = 1000;

	public HibernateInsert(Class<E> entityClass, Injector injector) {
		super(entityClass, injector);
	}
	
	public HibernateInsert<K, D, E> insert(Collection<E> insertItems) {
		this.insertItems = insertItems;
		return this;
	}

	@Override
	protected Collection<E> execute(EntityManager entityManager) {
		int count = 1;
		for (E entity : insertItems) {
		 	final Class<? extends IdentifiedBy> entityClass = ProxyHelper.getRawClass(entity);
			if(ManagedVersion.class.isAssignableFrom(entityClass)) {
				VERSIONER.onCreate((ManagedVersion)entity);
			}
			org.hibernate.Session session = entityManager.unwrap(org.hibernate.Session.class);
			session.save(entity);
			this.recordDomain(DataModifyType.Insert, entity, null);
			flushAndClearBatch(++count, entityManager);
		}
		return insertItems;
	}

	protected void flushAndClearBatch(int count, EntityManager entityManager) {
		if ((count % BATCH_SIZE) == 0) {
			entityManager.flush();
			entityManager.clear();
		}
	}
}
