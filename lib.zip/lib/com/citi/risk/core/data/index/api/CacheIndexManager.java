package com.citi.risk.core.data.index.api;

import java.util.concurrent.Future;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface CacheIndexManager extends CacheIndexAccessorManager {

	<K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> createIndex(Cache<K, E> cache);
	
	<K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> dropIndex(Cache<K, E> cache);

	<K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> rebuildIndex(Cache<K, E> cache);

	void addCacheIndex(DataKey dataKey, CacheIndex cacheIndex);
	
	void clearAll();
}
