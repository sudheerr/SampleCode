package com.citi.risk.core.data.index.api;

import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface IndexPaths<K, E extends IdentifiedBy<K>> {

	Object[] getIndexValues(E domain);

	Object getIndexValue(E value, int index);

	Class<?>[] getIndexTypes();

	Class<?> getIndexType(int index);

	String getName(int index);

	String[] getNames();

	int getCount();

	int getIndex(DataPath<E, ?> indexPath);

	Class<?> getIdentifiedByKeyType();

}
