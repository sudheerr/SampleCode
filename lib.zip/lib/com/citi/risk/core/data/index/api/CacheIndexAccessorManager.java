package com.citi.risk.core.data.index.api;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface CacheIndexAccessorManager {

	<K, E extends IdentifiedBy<K>> CacheIndexAccessor<K, E> getCacheIndex(DataKey dataKey);

	boolean isInCacheIndex(DataKey dataKey);

}
