package com.citi.risk.core.data.index.api;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

import java.util.Collection;

public interface Indexes<K, E extends IdentifiedBy<K>> {

	DataKey getDataKey();

	Object getIndexValue(K key, DataPath<E, ?> indexPath);

	Collection<K> getKeys();

}
