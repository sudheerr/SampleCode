package com.citi.risk.core.data.index.impl;

public class EmptyObjectUtils {
	
	private EmptyObjectUtils() {};
	
	public static Object[] getEmptyObjectArray(int index) {
		return new Object[index];
	}

}
