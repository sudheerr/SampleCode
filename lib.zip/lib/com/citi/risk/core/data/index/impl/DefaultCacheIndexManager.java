package com.citi.risk.core.data.index.impl;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.index.api.CacheIndex;
import com.citi.risk.core.data.index.api.CacheIndexAccessor;
import com.citi.risk.core.data.index.api.CacheIndexManager;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.create.api.Create;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public final class DefaultCacheIndexManager implements CacheIndexManager {
	private final ConcurrentHashMap<DataKey, CacheIndex<?, ?>> cacheIndexes = new ConcurrentHashMap<>();

	private final ExecutorService indexExecutorService;

	@Inject
	private Create create;


	@Inject
	public DefaultCacheIndexManager(final ExecutorService indexExecutorService) {
		this.indexExecutorService = indexExecutorService;
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> createIndex(Cache<K, E> cache) {
		if(cache == null) {
			throw new RuntimeException("cache does not exist : " + cache );
		}
		if(!cache.supportIndex()) {
			throw new RuntimeException("domain does not have index : " + cache.getDomain().getName() );
		}
		CreateIndexCallable<K, E> callable = create.getInstance(CreateIndexCallable.class);
		callable.setCache(cache);
		return indexExecutorService.submit(callable);
	}

	@Override
	public void addCacheIndex(DataKey dataKey, CacheIndex cacheIndex){
		cacheIndexes.put(dataKey, cacheIndex);
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> dropIndex(Cache<K, E> cache) {
		if(cache == null) {
			throw new RuntimeException("cache does not exist : " + cache );
		}
		
		if(!cache.isIndexed()) {
			throw new RuntimeException("domain has not build index : " + cache.getDomain().getName() );
		}
		
		DropIndexCallable<K, E> callable = create.getInstance(DropIndexCallable.class);
		callable.setCache(cache);
		cacheIndexes.remove(cache.key());
		return indexExecutorService.submit(callable);
	}

	@Override
	public <K, E extends IdentifiedBy<K>> Future<CacheIndexAccessor<K, E>> rebuildIndex(Cache<K, E> cache) {
		if(cache == null) {
			throw new RuntimeException("cache does not exist : " + cache );
		}
		
		if(!cache.supportIndex()) {
			throw new RuntimeException("domain does not have index : " + cache.getDomain().getName() );
		}
		RebuildIndexCallable<K, E> callable = create.getInstance(RebuildIndexCallable.class);
		callable.setCache(cache);
		return indexExecutorService.submit(callable);
	}

	@Override
	public <K, E extends IdentifiedBy<K>> CacheIndexAccessor<K, E> getCacheIndex(DataKey dataKey) {
		CacheIndex cacheIndex = cacheIndexes.get(dataKey);
		return cacheIndex;
	}

	@Override
	public boolean isInCacheIndex(DataKey dataKey) {
		return cacheIndexes.containsKey(dataKey);
	}

	@Override
	public void clearAll() {
		dropAll();
		cacheIndexes.clear();
	}
	
	private void dropAll() {
		for (Entry<DataKey, CacheIndex<?, ?>> keyEntry : cacheIndexes.entrySet()) {
		    CacheIndex cacheIndex = keyEntry.getValue();
		    cacheIndex.drop();
		}
	}
}
