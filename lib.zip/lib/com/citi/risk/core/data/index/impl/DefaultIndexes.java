package com.citi.risk.core.data.index.impl;

import com.citi.risk.core.data.index.api.Indexes;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

import java.util.Collection;

public class DefaultIndexes<K, E extends IdentifiedBy<K>> implements Indexes<K, E> {

	private Collection<K> keys;

	public DefaultIndexes(Collection<K> keys) {
		this.keys = keys;
	}

	@Override
	public DataKey getDataKey() {
		return null;
	}

	@Override
	public Object getIndexValue(K key, DataPath<E, ?> indexPath) {
		return null;
	}

	@Override
	public Collection<K> getKeys() {
		return keys;
	}

}
