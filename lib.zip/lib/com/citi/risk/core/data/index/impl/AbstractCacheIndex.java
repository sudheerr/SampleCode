package com.citi.risk.core.data.index.impl;

import com.citi.risk.core.data.index.api.CacheIndex;
import com.citi.risk.core.data.index.api.IndexPaths;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public abstract class AbstractCacheIndex<K, E extends IdentifiedBy<K>> implements CacheIndex<K, E> {
	private DataKey dataKey;
	protected IndexPaths<K, E> indexPaths;

	public AbstractCacheIndex(DataKey dataKey) {
		this.dataKey = dataKey;
		this.indexPaths = new DefaultIndexPaths<>(dataKey.getDomain());
	}

	@Override
	public DataKey getDataKey() {
		return dataKey;
	}

}
