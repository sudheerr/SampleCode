package com.citi.risk.core.data.index.impl;

import com.citi.risk.core.data.index.api.CacheIndex;
import com.citi.risk.core.data.index.api.CacheIndexAccessor;
import com.citi.risk.core.data.index.api.IndexTaskCallable;
import com.citi.risk.core.data.index.impl.lucene.LuceneCacheIndex;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.execution.api.TaskType;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public class DropIndexCallable<K, E extends IdentifiedBy<K>> implements IndexTaskCallable<K, E> {
	private Cache<K, E> cache;

	@Override
	public void setCache(Cache<K, E> cache) {
		this.cache = cache;
	}

	@Override
	public Cache<K, E> getCache() {
		return cache;
	}

	@Override
	public CacheIndexAccessor<K, E> call() throws Exception {
		CacheIndex<K, E> cacheIndex = new LuceneCacheIndex<>(cache.key());
		cacheIndex.drop();
		return null;
	}

	@Override
	public TaskType getType() {
		return TaskType.CacheIndex;
	}

	@Override
	public String getExecutionName() {
		return this.getClass().getSimpleName();
	}

	@Override
	public String getExecutionParameters() {
		return null;
	}

	@Override
	public boolean isNewThread() {
		return false;
	}
}
