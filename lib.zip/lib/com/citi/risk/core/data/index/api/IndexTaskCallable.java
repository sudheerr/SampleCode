package com.citi.risk.core.data.index.api;

import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.execution.api.ManagedExecution;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

import java.util.concurrent.Callable;

public interface IndexTaskCallable <K, E extends IdentifiedBy<K>> extends Callable<CacheIndexAccessor<K, E>>, ManagedExecution {

	void setCache(Cache<K, E> cache);

	Cache<K, E> getCache();
}
