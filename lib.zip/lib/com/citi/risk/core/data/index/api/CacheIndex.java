package com.citi.risk.core.data.index.api;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

public interface CacheIndex<K, E extends IdentifiedBy<K>> extends CacheIndexAccessor<K, E> {

	DataKey getDataKey();

	Indexes<K, E> search(String reg);
	
	void build(Cache<K, E> cache);
	
	void drop();

	void rebuild(Cache<K, E> cache);

}
