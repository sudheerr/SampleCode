package com.citi.risk.core.data.index.impl.lucene;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DoubleField;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FloatField;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.data.index.api.CacheIndexType;
import com.citi.risk.core.data.index.api.Indexes;
import com.citi.risk.core.data.index.impl.AbstractCacheIndex;
import com.citi.risk.core.data.index.impl.DefaultIndexes;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.data.store.cache.api.Cache;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.collection.list.Lists;

public class LuceneCacheIndex<K, E extends IdentifiedBy<K>> extends AbstractCacheIndex<K, E> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LuceneCacheIndex.class);
	public static final String IDENTIFIED_BY_KEY = "IdentifiedByKey";
	public static final String IDENTIFIED_BY_KEY_RAW_VALUE = "IdentifiedByKeyRawValue";
	private Directory index;
	private IndexSearcher indexSearcher;
	
	public LuceneCacheIndex(DataKey dataKey) {
		super(dataKey);
		createIndexDirectory(dataKey);
	}

	private void createIndexDirectory(DataKey dataKey) {
		if (dataKey.getDomain().getIndexType() != CacheIndexType.File) {
			index = new RAMDirectory();
		} else {
			try {
				//TODO
				String fileDirectory = null;
				index = FSDirectory.open(Paths.get(fileDirectory));
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	@Override
	public void build(Cache<K, E> cache) {
		IndexWriter indexWriter = getIndexWriter();
		Collection<E> domains = cache.getAll();
		for (E entity : domains) {
			insert(entity, indexWriter);
		}
		try {
			indexWriter.close();
		} catch (IOException e) {
			LOGGER.error("Failed to close index writer!", e);
		}
	}

	@Override
	public void rebuild(Cache<K, E> cache) {
		IndexWriter indexWriter = getIndexWriter();
		Collection<E> domains = cache.getAll();
		for (E entity : domains) {
			insert(entity, indexWriter);
		}
		try {
			indexWriter.close();
		} catch (IOException e) {
			LOGGER.error("Failed to close index writer!", e);
		}
	}

	private void insert(E entity, IndexWriter indexWriter) {
		Object[] values = indexPaths.getIndexValues(entity);
		Class<?>[] types = indexPaths.getIndexTypes();
		Document doc = new Document();

		for (int i = 0; i < indexPaths.getCount(); i++) {
			if (IDENTIFIED_BY_KEY.equals(indexPaths.getName(i))) {
				// Do not create index for entity which has null key.
				if (values[i] == null) {
					return;
				}
				if (types[i] == String.class) {
					doc.add(new StringField(IDENTIFIED_BY_KEY_RAW_VALUE, (String) values[i], Field.Store.YES));
				} else if (types[i] == long.class || types[i] == Long.class) {
					doc.add(new LongField(IDENTIFIED_BY_KEY_RAW_VALUE, (long) values[i], Field.Store.YES));
				} else if (types[i] == int.class || types[i] == Integer.class) {
					doc.add(new IntField(IDENTIFIED_BY_KEY_RAW_VALUE, (int) values[i], Field.Store.YES));
				} else if (types[i] == double.class || types[i] == Double.class) {
					doc.add(new DoubleField(IDENTIFIED_BY_KEY_RAW_VALUE, (double) values[i], Field.Store.YES));
				} else if (types[i] == float.class || types[i] == Float.class) {
					doc.add(new FloatField(IDENTIFIED_BY_KEY_RAW_VALUE, (float) values[i], Field.Store.YES));
				} else {
					return;
				}
			}
			if (null != values[i]) {
				doc.add(new StringField(indexPaths.getName(i), values[i].toString(), Field.Store.NO));
			}
		}

		try {
			indexWriter.addDocument(doc);
			
		} catch (IOException e) {
			LOGGER.error("Failed to create index for entity : " + entity, e);
		}
	}

	@Override
	public Indexes<K, E> search(String regex) {
		BooleanQuery query = new BooleanQuery();

		IndexSearcher _indexSearcher = this.getIndexSearcher();
		for (int _index = 0; _index < indexPaths.getCount(); _index++) {
			PrefixQuery prefixQuery = new PrefixQuery(new Term(indexPaths.getName(_index), regex));
			WildcardQuery wildcardQuery = new WildcardQuery(new Term(indexPaths.getName(_index), "*" + regex + "*"));
			query.add(prefixQuery, BooleanClause.Occur.SHOULD);
			query.add(wildcardQuery, BooleanClause.Occur.SHOULD);
		}

		TopDocs topDocs;
		Collection<K> keys = new ArrayList<>();
		try {
			topDocs = _indexSearcher.search(query, 100);
		} catch (IOException e) {
			LOGGER.debug(e.getMessage(), e);
			return null;
		}
		ScoreDoc[] queryResults = topDocs.scoreDocs;

		try {
			for (ScoreDoc scoreDoc : queryResults) {
				Document doc = _indexSearcher.doc(scoreDoc.doc);
				if (Number.class.isAssignableFrom(this.indexPaths.getIdentifiedByKeyType())) {
					keys.add((K) doc.getField(IDENTIFIED_BY_KEY_RAW_VALUE).numericValue());
				} else {
					keys.add((K) doc.get(IDENTIFIED_BY_KEY_RAW_VALUE));
				}
			}
		} catch (IOException e) {
			LOGGER.debug("failed to Search index with regex :" + regex, e);
			return null;
		}

		Indexes<K, E> indexes = new DefaultIndexes<>(keys);
		return indexes;
	}
	
	@Override
	public void drop() {
		IndexWriter indexWriter = getIndexWriter();
		try {
			indexWriter.deleteAll();
			indexWriter.close();
		} catch (IOException e) {
			LOGGER.error("Failed to drop index!", e);
		}
	}


	@Override
	public Collection<DataKey> getDataKeys() {
		return Lists.newArrayList(this.getDataKey());
	}

	@Override
	public Collection<Indexes<K, E>> searchAll(String reg) {
		return  Lists.newArrayList(this.search(reg));
	}
	
	@Override
	public int getIndexedSize() {
		IndexReader indexReader = null;
		try {
			indexReader = DirectoryReader.open(index);
			return indexReader.maxDoc();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (indexReader != null) {
				try {
					indexReader.close();
				} catch (Exception e) {
					LOGGER.error("failed to close indexReader", e);
				}
			}
		}
	}
	
	private IndexWriter getIndexWriter() {
		IndexWriter indexWriter;
		Analyzer analyzer = new StandardAnalyzer();
		IndexWriterConfig config = new IndexWriterConfig(analyzer);
		config.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
		try {
			indexWriter = new IndexWriter(index, config);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return indexWriter;
	}
	
	private IndexSearcher getIndexSearcher() {
		if(indexSearcher != null) {
			return indexSearcher;
		}
		
		try {
			IndexReader indexReader = DirectoryReader.open(index);
			indexSearcher = new IndexSearcher(indexReader);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		return indexSearcher;
	}
}
