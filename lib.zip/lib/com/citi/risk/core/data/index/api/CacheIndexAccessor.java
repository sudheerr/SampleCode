package com.citi.risk.core.data.index.api;

import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

import java.util.Collection;

public interface CacheIndexAccessor<K, E extends IdentifiedBy<K>> {
	Collection<DataKey> getDataKeys();

	Collection<Indexes<K, E>> searchAll(String reg);
	
	int getIndexedSize();
}
