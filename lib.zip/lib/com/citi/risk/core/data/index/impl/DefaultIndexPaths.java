package com.citi.risk.core.data.index.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.common.data.temporal.api.HasTemporalsToTimeSeries;
import com.citi.risk.core.data.index.api.IndexPaths;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.DataPath;
import com.citi.risk.core.dictionary.impl.DefaultDataPath;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.collection.Triplet;
import com.citi.risk.core.util.ReflectGenerics;
import com.google.common.collect.Lists;

public class DefaultIndexPaths<K, E extends IdentifiedBy<K>> implements IndexPaths<K, E> {
	private static final Logger LOGGER=LoggerFactory.getLogger(DefaultIndexPaths.class);
	private final static DataPath[] EMPTY_DATA_PATH = new DataPath[0]; 
	private final static Class<?>[] EMPTY_INDEX_TYPE = new Class<?>[0]; 
	
	private String[] names = ArrayUtils.EMPTY_STRING_ARRAY;
	private DataPath<E, ?>[] paths = EMPTY_DATA_PATH;
	private Class<?>[] indexType = EMPTY_INDEX_TYPE;

	private static DefaultDataPath KEY_PATH = new DefaultDataPath((DataItem)null);

	public DefaultIndexPaths(DataDomain<E> dataDomain) {
		
		Triplet<ArrayList<String>, ArrayList<DataPath>, ArrayList<Class>> triplet = new Triplet<>();

		triplet.setFirst(Lists.<String>newArrayList());
		triplet.setSecond(Lists.<DataPath>newArrayList());
		triplet.setThird(Lists.<Class>newArrayList());

		parserDomain(dataDomain, triplet);
		
		names = triplet.getFirst().toArray(new String[triplet.getFirst().size()]);
		paths = triplet.getSecond().toArray(new DataPath[triplet.getSecond().size()]);
		indexType = triplet.getThird().toArray(new Class[triplet.getThird().size()]);
		triplet.getFirst().clear();
		triplet.getSecond().clear();
		triplet.getThird().clear();
	}
	
	private void parserDomain(DataDomain<E> dataDomain, Triplet<ArrayList<String>, ArrayList<DataPath>, ArrayList<Class>> triplet) {
		this.parserIdentifiedByDomain(dataDomain, null, null, triplet);
		//parse managedVersionDomain 
		this.parserDataItemDomain(dataDomain, null, null, null, triplet);
	}
	
	private void parserIdentifiedByDomain(DataDomain<E> dataDomain,
							  String prfixName, DataPath prefixDataPath,
							  Triplet<ArrayList<String>, ArrayList<DataPath>, ArrayList<Class>> triplet) {
		if (!IdentifiedBy.class.isAssignableFrom(dataDomain.getDomainClass())) {
			LOGGER.info("prefixDataPath : " + prefixDataPath.toString());
			return;
		}
		Class<?> identifiedByKeyClazz = ReflectGenerics.getTypeArgumentsForInterface(IdentifiedBy.class, dataDomain.getDomainClass()).get(0);
		if (identifiedByKeyClazz != null) {
			triplet.getFirst().add(join(prfixName, "IdentifiedByKey"));
			triplet.getSecond().add(KEY_PATH);
			triplet.getThird().add(identifiedByKeyClazz);
		}
	}
	
	private boolean parserDataItemDomain(DataDomain<E> dataDomain,
							  String prefixName, DataPath prefixDataPath, String itemName,
							  Triplet<ArrayList<String>, ArrayList<DataPath>, ArrayList<Class>> triplet) {
		if (itemName != null) {
			DataItem di = dataDomain.getItem(itemName);
			if (di != null) {
				DataPath dataPath;
				dataPath = prefixDataPath == null ?	new DefaultDataPath(di) : prefixDataPath.append(di);
				triplet.getFirst().add(join(prefixName, di.getName()));
				triplet.getSecond().add(dataPath);
				triplet.getThird().add(di.getJavaSimpleType());
				return true;
			}
		} else {
			for (DataItem di : dataDomain.getAllItems()) {
				if (di.isIndexed()) {
					parserDataItemDomain(dataDomain, prefixName, prefixDataPath, di.getName(), triplet);
				}
			}
			return true;
		}
		return false;
	}
	
	private String join(String first, String second) {
		return StringUtils.isEmpty(first) ? second : first + "." + second;
	}

	private Type getIndentifiedByKeyType(Class<?> klass) {
		Type[] types = klass.getGenericInterfaces();
		if (ArrayUtils.isEmpty(types)) {
			return null;
		}
		for(Type type : types) {
			if (type instanceof Class && IdentifiedBy.class.isAssignableFrom((Class)type)) {
				Type _type = getIndentifiedByKeyType((Class)type);
				if (_type != null) {
					return _type;
				}
			}
			else if (ParameterizedType.class.isAssignableFrom(type.getClass())) {
				ParameterizedType pt = (ParameterizedType)type;
				if (pt.getRawType() == IdentifiedBy.class) {
					return pt.getActualTypeArguments()[0];
				} else {
					Type _type = getIndentifiedByKeyType((Class)pt.getRawType());
					if (_type != null) {
						return _type;
					}
				}
			}
		}
		return null;
	}
	
	@Override
	public Object[] getIndexValues(E domain) {
		if (domain == null) {
			return EmptyObjectUtils.getEmptyObjectArray(this.getCount());
		}
		Object[] values = new Object[this.getCount()];
		for(int index = 0; index < this.getCount(); index++) {
			values[index] = this.getIndexValue(domain, index); 
		}
		return values;
	}
	
	@Override
	public Object getIndexValue(E domain, int index) {
		if (index < 0 || index > this.getCount()) {
			return null;
		}
		if (paths[index] == this.KEY_PATH) {
			return ((IdentifiedBy)domain).key();
		}
		return paths[index].getTranform().apply(domain);
	}
	
	@Override
	public Class<?>[] getIndexTypes() {
		return indexType;
	}
	
	@Override
	public Class<?> getIndexType(int index) {
		return index >= names.length ? null : indexType[index];
	}
	
	@Override
	public String getName(int index) {
		return index >= names.length ? null : names[index];
	}
	
	@Override
	public int getCount() {
		return names.length;
	}
	
	@Override
	public int getIndex(DataPath<E, ?> indexPath) {
		if (indexPath == null) {
			return -1;
		}
		for(int index = 0; index < paths.length; index++) {
			if (paths[index].equals(indexPath)) {
				return index;
			}
		}
		return -1;
	}

	@Override
	public Class<?> getIdentifiedByKeyType() {
		int idx = this.getIndex(KEY_PATH);
		return this.getIndexType(idx);
	}

	@Override
	public String[] getNames() {
		return this.names;
	}

}
