package com.citi.risk.core.data.index.api;

public enum CacheIndexType {
	Default, File, Memory
}
