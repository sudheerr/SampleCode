package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.clipboard.api.ClipboardContentQuerying;

class DefaultRdbmsQuerying implements ClipboardContentQuerying {

	private DefaultRdbmsUpdater updater;

	DefaultRdbmsQuerying(DefaultRdbmsUpdater updater) {
		this.updater = updater;
	}

	@Override
	public ClipboardContentQuery and(String attribute) {
		throw new UnsupportedOperationException("multiple query condition is not supported now");
	}

	@Override
	public Integer execute() {
		return updater.execute();
	}
}
