package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.select.AbstractSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.payload.api.Payload;

public class ClipboardSelectHelper {
	
	private ClipboardSelectHelper() {
	}

    public static <E> Select getContentSelect(final Criteria<E> contentDomainCriteria) {
        if (null == contentDomainCriteria) {
            return null;
        }

        return new AbstractSelect() {
            @Override
            public boolean apply(Object input) {
                Select select = contentDomainCriteria.getSelect();
                if (Payload.class.isAssignableFrom(input.getClass())) {

                    Collection<E> content = ((Payload) input).getContent(select.getDomainClass());
                    for (E object : content) {
                        boolean apply = select.apply(object);
                        if (apply)
                            return apply;
                    }

                    return false;
                } else {
                    return select.apply(input);
                }
            }
        };
    }

    public static <E> Select<Payload> getContentSelectWithPayload(final Criteria<E> contentDomainCriteria) {
        if (null == contentDomainCriteria) {
            return null;
        }

        return new AbstractSelect<Payload>() {
            @Override
            public boolean apply(Payload input) {
                Select select = contentDomainCriteria.getSelect();

                Collection<E> content = input.getContent(select.getDomainClass());
                for (E object : content) {
                    boolean apply = select.apply(object);
                    if (apply)
                        return apply;
                }

                return false;

            }
        };
    }

    @SuppressWarnings("serial")
    public static <E> Select<E> getContentSelectWithoutPayload(final Criteria<E> contentDomainCriteria) {
        if (null == contentDomainCriteria) {
            return null;
        }

        return contentDomainCriteria.getSelect();       
    }
}
