package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.io.impl.AbstractSerializer;
import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.payload.api.Content;
import com.google.inject.Inject;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.bson.BSON;
import org.bson.BSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class ContentSerializer extends AbstractSerializer<Collection<Content<?, ?>>, Collection<DBObject>> {
    @Inject
    JsonSerializationFacade jsonService;

    BlockingQueue<DBObject> queue;

    public void setQueue(BlockingQueue<DBObject> queue) {
        this.queue = queue;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
    public Collection<DBObject> serialize(Collection<Content<?, ?>> contents) {
        List<DBObject> bsonContents = new ArrayList<>();
        for (Content content : contents) {
            byte[] objectOnByteArray;
            objectOnByteArray = jsonService.serializeToByteArray(content.getContentObject());
            BSONObject bsonObject = BSON.decode(objectOnByteArray);
            BasicDBObject bsonContent =
                    new BasicDBObject("parentId", content.getParentId()).append("domainInterfaces", content.getDomainInterfaces())
                            .append("contentKey", content.getKey()).append("contentClass", content.getContentClass())
                            .append("content", bsonObject).append("version", content.getVersion()).append("Is Expired", false);
            bsonContents.add(bsonContent);
        }
        queue.addAll(bsonContents);
        return bsonContents;
    }

}
