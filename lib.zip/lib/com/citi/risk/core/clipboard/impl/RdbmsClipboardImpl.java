package com.citi.risk.core.clipboard.impl;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.springframework.util.ClassUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.clipboard.deleter.RdbmsClipboardDeleter;
import com.citi.risk.core.clipboard.loader.RdbmsClipboardLoader;
import com.citi.risk.core.clipboard.storer.RdbmsClipboardStorer;
import com.citi.risk.core.clipboard.updater.RdbmsClipboardUpdater;
import com.citi.risk.core.data.store.api.IOSpec;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.create.api.IdGenerator;
import com.citi.risk.core.payload.api.Content;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.PayloadImpl;

@Access(value = AccessType.PROPERTY)
@TypeDefs({ @TypeDef(name = "rdbmsContentType", typeClass = RdbmsContentType.class) })
@Entity
@IOSpec(domainClasses = { Clipboard.class }, implSchema = "relational-clipboard", activeLoaderDefault = RdbmsClipboardLoader.class, activeStorerDefault = RdbmsClipboardStorer.class, activeUpdaterDefault = RdbmsClipboardUpdater.class, activeDeleterDefault = RdbmsClipboardDeleter.class, idGenerateClass = IdGenerator.class)
@Table(name = "CMN_CLIPBOARD")
public class RdbmsClipboardImpl<P extends IdentifiedBy<?>> extends AbstractClipboardImpl<P> {

	private String contentDomainInterfaces;
	private transient P content;
	private String contentKey;
	private transient Class<P> contentClass;

	public RdbmsClipboardImpl() {
		//intentionally-blank override
	}

	protected RdbmsClipboardImpl(Class<P> contentClass) {
		this.contentClass = contentClass;
	}

	public static <P extends IdentifiedBy<?>> RdbmsClipboardImpl<P> newInstance(Class<P> contentClass) {
		RdbmsClipboardImpl<P> clipboard = new RdbmsClipboardImpl(contentClass);
		clipboard.setClipboardId(UUID.randomUUID().toString());
		clipboard.setCreatedTime(new Date());
		return clipboard;
	}

	public static <P extends IdentifiedBy<?>> RdbmsClipboardImpl<P> newInstance(String user, Scope scope,
			Class<P> contentClass) {
		RdbmsClipboardImpl<P> clipboard = new RdbmsClipboardImpl(contentClass);
		clipboard.setClipboardId(UUID.randomUUID().toString());
		clipboard.setCreatedTime(new Date());
		clipboard.setUser(user);
		clipboard.setScopeId(scope.getId());
		clipboard.setScopeType(scope.getType());
		clipboard.setAdditionalInfo(scope.getAdditionalInfo());
		return clipboard;
	}

	@Override
	@Id
	@NotNull
	@GeneratedValue(generator = "clipboard-uuid")
	@GenericGenerator(name = "clipboard-uuid", strategy = "com.citi.risk.core.clipboard.impl.ClipboardIdGenerator")
	@Column(name = "ID")
	public String getId() {
		return super.getId();
	}

	@Column(name = "CLIPBOARD_ID")
	@Override
	public String getClipboardId() {
		return super.getClipboardId();
	}

	@Column(name = "CLIPBOARD_USER")
	@Override
	public String getUser() {
		return super.getUser();
	}

	@Column(name = "CLIPBOARD_SCOPE")
	@Override
	public String getScopeId() {
		return super.getScopeId();
	}

	@Column(name = "CREATED_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	@Override
	public Date getCreatedTime() {
		return super.getCreatedTime();
	}

	@Transient
	@Override
	public Class<P> getContentClass() {
		return (Class<P>) (contentClass != null ? contentClass
				: (this.content != null ? this.content.getClass() : null));
	}

	@Transient
	@Override
	public P getContent() {
		return this.content;
	}

	@Type(type = "rdbmsContentType", parameters = { @Parameter(name = "rdbmsContentName", value = "contentType"),
			@Parameter(name = "idName", value = "clipboardId") })
	@Column(name = "CONTENT_SERIALISE_OBJECT")
	public Object getContentsForPersist() {
		if (getContentClass() == null) {
			return null;
		}
		if (Payload.class.isAssignableFrom(getContentClass())) {
			return ((PayloadImpl) this.content).getContentForPersist();
		} else {
			return this.content;
		}
	}

	public void setContentsForPersist(Object value) {
		this.content = (P) value;
	}

	@Override
	public void setContent(P content) {
		this.contentClass = (Class) content.getClass();
		super.setContentType(content.getClass().getName());
		this.content = content;
		setContentDomainInterfaces(getDomainInterfaces(content));
	}

	@Column(name = "CONTENT_TYPE")
	@Override
	public String getContentType() {
		return super.getContentType();
	}

	@Override
	@Column(name = "CLIPBOARD_VERSION")
	public Integer getVersion() {
		return super.getVersion();
	}

	@Column(name = "CONTENT_KEY")
	@Override
	public String getContentKey() {
		return contentKey;
	}

	@Override
	public void setContentKey(String contentKey) {
		this.contentKey = contentKey;
	}

	@Column(name = "CONTENT_DOMAIN_INTERFACE")
	@Lob
	@Override
	public String getContentDomainInterfaces() {
		return contentDomainInterfaces;
	}

	@Override
	public void setContentDomainInterfaces(String contentDomainInterfaces) {
		this.contentDomainInterfaces = contentDomainInterfaces;
	}

	@Transient
	@Override
	public Integer getContentVersion() {
		if (this.content != null && !Payload.class.isAssignableFrom(getContentClass()) && this.content instanceof ManagedVersion) {
			return ((ManagedVersion) this.content).getVersion();
		}
		return 0;
	}

	@Column(name = "SCOPE_TYPE")
	@Override
	public String getScopeType() {
		return super.getScopeType();
	}

	@Column(name = "ADDITIONAL_INFO")
	@Override
	public String getAdditionalInfo() {
		return super.getAdditionalInfo();
	}

	private <P> String getDomainInterfaces(P object) {
		if (!Payload.class.isAssignableFrom(object.getClass())) {
			StringBuilder domainInterfaces = new StringBuilder(object.getClass().getName());
			Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(object.getClass());
			for (Class<?> nextInterface : interfaces) {
				if (nextInterface.isAnnotationPresent(DDD.class))
					domainInterfaces.append("," + nextInterface.getName());
			}

			return domainInterfaces.toString();
		} else {
			StringBuilder domainInterfaces = new StringBuilder();

			for (Content _content : ((Payload) object).getContent()) {
				domainInterfaces.append("," + _content.getDomainInterfaces());
			}

			String out = domainInterfaces.toString();

			return out.length() != 0 ? out.substring(1) : "";
		}
	}

	@Column(name = "EXPIRED")
	@Override
	public Boolean getExpired() {
		return super.getExpired();
	}

	@Column(name = "VALID_FROM")
	@Temporal(TemporalType.TIMESTAMP)
	@Override
	public Date getValidFrom() {
		return super.getValidFrom();
	}

	@Column(name = "VALID_TO")
	@Temporal(TemporalType.TIMESTAMP)
	@Override
	public Date getValidThru() {
		return super.getValidThru();
	}

	@Transient
	@Override
	public boolean isPayload() {
		if (this.getContentClass() == null) {
			return this.content != null ? Payload.class.isAssignableFrom(this.content.getClass()) : false;
		} else {
			return StringUtils.equals(this.getContentClass().getName(), Payload.class.getName());
		}
	}

}
