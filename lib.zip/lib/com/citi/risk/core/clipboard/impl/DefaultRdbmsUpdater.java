package com.citi.risk.core.clipboard.impl;

import java.util.List;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.clipboard.api.ClipboardContentUpdating;
import com.citi.risk.core.lang.collection.Triplet;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.inject.Injector;

class DefaultRdbmsUpdater extends AbstractContentUpdater {

	private static final String SPLITTER = ".";

	private List<Triplet<String, String, String>> conditions;

	DefaultRdbmsUpdater(Injector injector) {
		super(injector);
		this.conditions = Lists.newArrayList();
	}

	@Override
	public Integer execute() {
		return new BlobUpdater(true, getInjector(), getUpdatings(), conditions).execute();
	}

	@Override
	public ClipboardContentQuery where(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new IllegalArgumentException("input parameter is empty");
		}
		if (attribute.contains(SPLITTER)) {
			throw new IllegalArgumentException("input parameter is illegal with : \".\"");
		}
		return new DefaultRdbmsQuery(attribute, this);
	}

	void addCondition(Triplet<String, String, String> condition) {
		this.conditions.add(condition);
	}
	
}
