package com.citi.risk.core.clipboard.impl;

import org.bson.types.ObjectId;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.clipboard.api.ClipboardContentQuerying;
import com.citi.risk.core.lang.collection.Triplet;
import com.google.common.base.Strings;

class DefaultRdbmsQuery implements ClipboardContentQuery {

	private String attribute;
	private DefaultRdbmsUpdater updater;

	public DefaultRdbmsQuery(String attribute, DefaultRdbmsUpdater updater) {
		this.attribute = attribute;
		this.updater = updater;
	}

	@Override
	public ClipboardContentQuerying eq(String value) {
		if (Strings.isNullOrEmpty(value)) {
			throw new IllegalArgumentException("input value is empty");
		}
		
		updater.addCondition(new Triplet<String, String, String>(attribute, "=", value));
		
		return new DefaultRdbmsQuerying(updater);
	}

	@Override
	public ClipboardContentQuerying eq(ObjectId value) {
		throw new UnsupportedOperationException("does not support eq objectId");
	}

}
