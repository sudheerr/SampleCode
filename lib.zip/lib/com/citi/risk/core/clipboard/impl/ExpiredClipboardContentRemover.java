package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.collect.Lists;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.WriteResult;

public class ExpiredClipboardContentRemover extends AbstractExpiredMongoRemover<Integer> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpiredClipboardContentRemover.class);

	public ExpiredClipboardContentRemover(Injector injector) {
		super(ContentImpl.class, injector);
	}

	@Override
	public Integer execute() {
		DBCollection dbContentColl = getDBCollection();
		DBCollection dbClipboardColl = new ExpiredClipboardRemover(getInjector()).getDBCollection();

		Collection<Object> aliveParentIds = getIds(dbClipboardColl.find(ExpiredClipboardRemover.CLIPBOARD_NON_EXPIRED, getResultProjection()));
		Collection<Object> expiredParentIds = getIds(dbClipboardColl.find(ExpiredClipboardRemover.CLIPBOARD_EXPIRED, getResultProjection()));

		LOGGER.info("All Content Count - Before: {}", dbContentColl.count());

		int aliveContentCountBefore = dbContentColl.find(buildQuery(aliveParentIds), getResultProjection()).count();
		LOGGER.info("Alive Content Count - Before: {}", aliveContentCountBefore);

		int expiredContentCountBefore = dbContentColl.find(buildQuery(expiredParentIds), getResultProjection()).count();
		LOGGER.info("Expired Content Count - Before: {}", expiredContentCountBefore);

		WriteResult removed = null;
		if (expiredContentCountBefore != 0) {
			removed = dbContentColl.remove(buildQuery(expiredParentIds));
		}

		LOGGER.info("All Content Count - After: {}", dbContentColl.count());

		int aliveContentCountAfter = dbContentColl.find(buildQuery(aliveParentIds), getResultProjection()).count();
		LOGGER.info("Alive Content Count - After: {}", aliveContentCountAfter);

		int expiredContentCountAfter = dbContentColl.find(buildQuery(expiredParentIds), getResultProjection()).count();
		LOGGER.info("Expired Content Count - After: {}", expiredContentCountAfter);

		return removed == null ? 0 : removed.getN();
	}
	
	private Collection<Object> getIds(DBCursor cursor) {
		Collection<Object> ids = Lists.newArrayListWithCapacity(cursor.count());
		while(cursor.hasNext()) {
			ids.add(cursor.next().get("_id"));
		}
		
		return ids;
	}
	
	private BasicDBObject buildQuery(Collection<Object> ids) {
		BasicDBObject query = new BasicDBObject();
		query.put("parentId", new BasicDBObject("$in", ids));

		return query;
	}
}
