package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.inject.Injector;

public class ClipboardContentUpdaterFactory {
	
	private ClipboardContentUpdaterFactory() {
	}

	/**
	 * Create a JsonUpdater to update data in MongoDB.
	 * Two domain class {@link ClipboardImpl} and {@link ContentImpl} can be accepted.
	 * 
	 * @param injector
	 * @param domainImplClass
	 * @return
	 */
	public static ClipboardContentUpdater newJsonUpdater(Injector injector, Class<?> domainImplClass) {
		return new DefaultJsonUpdater(injector, domainImplClass);
	}
	
	/**
	 * Create a RdbmsUpdater to update Blob data within a db record.
	 * 
	 * @param injector
	 * @return
	 */
	public static ClipboardContentUpdater newRdbmsUpdater(Injector injector) {
		return new DefaultRdbmsUpdater(injector);
	}
}
