package com.citi.risk.core.clipboard.impl;

import org.bson.types.ObjectId;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.clipboard.api.ClipboardContentQuerying;
import com.mongodb.BasicDBObject;

class DefaultJsonQuery implements ClipboardContentQuery {

	private String attribute;
	private DefaultJsonUpdater jsonUpdater;
	private BasicDBObject dbObject;

	DefaultJsonQuery(String attribute, DefaultJsonUpdater jsonUpdater, BasicDBObject dbObject) {
		this.attribute = attribute;
		this.jsonUpdater = jsonUpdater;
		this.dbObject = dbObject;
	}

	@Override
	public ClipboardContentQuerying eq(String value) {
		this.dbObject.append(this.attribute, value);
		return new DefaultJsonQuerying(jsonUpdater, dbObject);
	}

	@Override
	public ClipboardContentQuerying eq(ObjectId value) {
		this.dbObject.append(this.attribute, value);
		return new DefaultJsonQuerying(jsonUpdater, dbObject);
	}
}
