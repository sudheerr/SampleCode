package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.dictionary.api.Criteria;

/**
 * Created by rg67529 on 11/21/2014.
 */
public class ClipboardCriteriaWrapper {
	
	private ClipboardCriteriaWrapper() {
	}

    public static Criteria setDomainImpl(Criteria criteria, Class<? extends Clipboard> clzz) {

        criteria.setDomainImplClass(clzz);
        return criteria;
    }

}
