package com.citi.risk.core.clipboard.impl;

import java.util.Collection;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Transient;

import org.apache.commons.lang3.ClassUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.payload.api.Content;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.citi.risk.core.payload.impl.PayloadImpl;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.Lists;

public abstract class AbstractClipboardImpl<P extends IdentifiedBy<?>> implements Clipboard<P> {

	private static final long serialVersionUID = -8020188242132715037L;

	private String id;
	private String clipboardId;
	private Integer version;
	private String user;
	private String scopeId;
	private String scopeType;
	private String additionalInfo;
	private Date createdTime;
	private P contentObject;
	private String contentType;
	private Collection<Content> contents = Lists.newArrayList();
	private transient TimeMark timeMark;
	private transient CreatedBy createdBy;
	private Boolean expired;
	private Date validFrom;
	private Date validThru;
	private transient ManagedVersion<String> latest;
	

	public AbstractClipboardImpl() {
	}

	@Override
	public String key() {
		return id;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getClipboardId() {
		return clipboardId;
	}

	@Override
	public void setClipboardId(String clipboardId) {
		this.clipboardId = clipboardId;
	}

	@Override
	public Integer getVersion() {
		return version;
	}

	@Override
	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public String getUser() {
		return this.user;
	}

	@Override
	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public String getScopeId() {
		return this.scopeId;
	}

	@Override
	public void setScopeId(String scopeId) {
		this.scopeId = scopeId;
	}

	@Override
	public String getScopeType() {
		return this.scopeType;
	}

	@Override
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}

	@Transient
	@Override
	public Scope getScope() {
		return new ScopeImpl(this.scopeId, this.scopeType, this.additionalInfo);
	}

	@Override
	public void setScope(Scope scope) {
		if (scope == null) {
			this.scopeId = null;
			this.scopeType = null;
			this.additionalInfo = null;
		} else {
			this.scopeId = scope.getId();
			this.scopeType = scope.getType();
			this.additionalInfo = scope.getAdditionalInfo();
		}
	}

	@Override
	public String getAdditionalInfo() {
		return this.additionalInfo;
	}

	@Override
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	@Override
	public Date getCreatedTime() {
		return this.createdTime;
	}

	@Override
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	// TODO:
	@Override
	public String getContentDomainInterfaces() {
		if (this.contentObject == null) {
			return null;
		}
		Class cKlass = ProxyHelper.getRawClass(this.contentObject);
		StringBuilder domainInterfaces = 
				new StringBuilder(cKlass.getName()).append(',');
		for (Class<?> nextInterface : ClassUtils.getAllInterfaces(cKlass)) {
			if (nextInterface.isAnnotationPresent(DDD.class)) {
				domainInterfaces.append(nextInterface.getName()).append(',');
			}
		}
		return domainInterfaces.toString();
	}

	public void setContentDomainInterfaces(String domainInterface) {
	}
	
	@Override
	public P getContent() {
		if (this.contentObject != null) {
			return (P) this.contentObject;
		} else {
			Object ret = new PayloadImpl(this.clipboardId, this.version, this.contents);
			return (P) ret;
		}
	}

	@Override
	public void setContent(P content) {
		if (content instanceof Payload) {
			this.setContentAsPayload((Payload) content);
		} else {
			this.setContentObject(content);
		}
	}

	public void setContentAsPayload(Payload content) {
		this.contentObject = null;
		this.contents.clear();
		this.contents.addAll(content.getContent());
		this.contentType = PayloadImpl.class.getName();
	}
	
	public P getContentObject() {
		return this.contentObject;
	}

	public void setContentObject(P contentObject) {
		if (contentObject != null && contentObject instanceof Payload) {
			return;
		}
		this.contentObject = contentObject;
		if (contentObject != null) {
			this.contentType = ProxyHelper.getRawClass(this.contentObject).getName();
		} else {
			contentType = null;
		}
		this.contents.clear();
	}

	@Override
	public String getContentKey() {
		return (this.contentObject == null || contentObject.key() == null) ? null : contentObject.key().toString();
	}
	
	public void setContentKey(String contentKey) {
	}

	@Override
	public Integer getContentVersion() {
		if (contentObject != null && contentObject instanceof ManagedVersion) {
			return ((ManagedVersion) this.contentObject).getVersion();
		}
		return 0;
	}
	public void setContentVersion(Integer version) {
	}

	@Override
	public Class<P> getContentClass() {
		return contentObject == null ? (Class)PayloadImpl.class : ProxyHelper.getRawClass(this.contentObject);
	}

	@Override
	public String getContentType() {
		return contentType;
	}
	
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Override
	@Transient
	public TimeMark getTimeMark() {
		return this.timeMark;
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		this.timeMark = timeMark;
	}

	@Override
	@Transient
	public CreatedBy getCreatedBy() {
		return this.createdBy;
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public void setCreatedByString(String createdByKey) {
		this.createdBy = DefaultCreatedBy.newCreatedBy(createdByKey);
	}

	@Override
	@Transient
	public String getCreatedByString() {
		return createdBy == null ? "" : createdBy.toString();
	}

	@Override
	@Transient
	public String getTimeMarkString() {
		return this.timeMark == null ? "" : this.timeMark.toString();
	}

	@Override
	public void setTimeMarkString(String timeMarkKey) {
		this.timeMark = DefaultTimeMark.getTimeMarkfromKey(timeMarkKey);
	}

	@Transient
	@Override
	public String getKeyField() {
		return "id";
	}

	@Override
	@Transient
	@JsonIgnore
	public String getBusinessKey() {
		return clipboardId;
	}

	@Override
	public void nullifyIdentifier() {
		this.id = null;
	}

	@Override
	public Integer incrementVersion() {
		this.version++;
		return version;
	}

	@Override
	public void setExpired(Boolean expired) {
		this.expired = expired;
	}

	@Override
	public Boolean getExpired() {
		return expired;
	}

	@Override
	public Date getValidFrom() {
		return this.validFrom;
	}

	@Override
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	@Override
	public Date getValidThru() {
		return this.validThru;
	}

	@Override
	public void setValidThru(Date validThru) {
		this.validThru = validThru;
	}

	@Transient
	@Override
	public String getIdentifier() {
		return this.id;
	}

	public void setPrimaryKey(String id) {
		this.id = id;
		for (Content content : contents) {
			((ContentImpl) content).setParentId(id);
			((ContentImpl) content).setId(UUID.randomUUID().toString());
		}
	}

	public Collection<Content> getContents() {
		return this.contents;
	}

	@Override
	@JsonIgnore
	@Transient
	public ManagedVersion<String> getLatest() {
		return this.latest;
	}

	@Override
	public void setLatest(ManagedVersion<String> value) {
		this.latest = value;
	}
	
	@Override
	public Collection getContentsByDomainImpl(Class implClass) {
		Collection contentObjects = Lists.newArrayList();
		Class contentClass = this.getContentClass();
		if (contentClass != null && Payload.class.isAssignableFrom(contentClass)) {
			contentObjects.addAll(getContentObjects(implClass));
		} else {
			if (!NullTerminator.objectIsNull(this.getContent()) && implClass.equals(this.getContent().getClass())) {
				contentObjects.add(this.getContent());
			}
		}

		return contentObjects;
	}

	private Collection getContentObjects(Class implClass) {
		Collection contentObjects = Lists.newArrayList();
		
		Payload payload = (Payload) this.getContent();
		if (!NullTerminator.objectIsNull(payload)) {
			for (Content content : payload.getContent()) {
				if (!NullTerminator.objectIsNull(content) && implClass.equals(content.getClass())) {
					contentObjects.add(content.getContentObject());
				}
			}
		}
		return contentObjects;
	}
	
}