package com.citi.risk.core.clipboard.impl;

import org.bson.BSONObject;

import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Strings;
import com.google.inject.Injector;

class RemoveUpdating extends AbstractContentUpdating<String> {

	public RemoveUpdating() {
		super();
	}

	public RemoveUpdating(String oldAttribute, AbstractContentUpdater updater, Injector injector) {
		super(oldAttribute, updater, injector);
		addPair();
	}

	@Override
	void doModify(BSONObject bsonObj, Pair<String, String> pair) {
		String toRemove = pair.getFirst();
		if (!bsonObj.containsField(toRemove)) {
			throw new RuntimeException("field does not exist : " + toRemove + " on bson: " + bsonObj);
		}
		bsonObj.removeField(toRemove);		
	}
	
	private void addPair() {
		if (Strings.isNullOrEmpty(getAttribute())) {
			return;
		}
		add(Pair.create(getAttribute(), ""));
	}

}
