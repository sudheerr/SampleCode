package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;
import com.google.inject.Singleton;

@Singleton
@SuppressWarnings({"unchecked", "rawtypes"})
public class MongoClipboardService extends DefaultClipboardService{

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(
			Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		Criteria clipboardCriteria = clipboardIdPath.in(clipboardIds);
		clipboardCriteria.setDomainImplClass(ClipboardImpl.class);
		return super.select(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(
			Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(ClipboardImpl.class);
		return super.select(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(
			Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(ClipboardImpl.class);
		return super.selectForUpdate(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<P> selectContent(
			Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(ClipboardImpl.class);
		return super.selectContent(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<P> selectContentForUpdate(
			Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(ClipboardImpl.class);
		return super.selectContentForUpdate(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		Criteria clipboardCriteria = clipboardIdPath.in(clipboardIds);
		clipboardCriteria.setDomainImplClass(ClipboardImpl.class);
		deleteClipboards(super.select(clipboardCriteria, contentDomainSelect), false);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(ClipboardImpl.class);
		deleteClipboards(super.select(clipboardCriteria, contentDomainSelect), false);
	}

}
