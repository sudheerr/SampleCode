package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.clipboard.api.ClipboardContentQuerying;
import com.google.common.base.Strings;
import com.mongodb.BasicDBObject;

class DefaultJsonQuerying implements ClipboardContentQuerying {

	private DefaultJsonUpdater jsonUpdater;
	private BasicDBObject dbObject;

	DefaultJsonQuerying(DefaultJsonUpdater jsonUpdater, BasicDBObject dbObject) {
		super();
		this.jsonUpdater = jsonUpdater;
		this.dbObject = dbObject;
	}

	@Override
	public ClipboardContentQuery and(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new RuntimeException("attribute is null");
		}

		return new DefaultJsonQuery(attribute, jsonUpdater, dbObject);
	}

	@Override
	public Integer execute() {
		return jsonUpdater.execute();
	}
}
