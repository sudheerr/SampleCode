package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.data.service.jpa.executor.api.TxExecutor;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.api.PersistenceSpecification;
import com.citi.risk.core.data.store.db.api.MongoDBDictionary;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;

public abstract class AbstractExpiredMongoRemover<R> implements TxExecutor<R> {

	private Class<?> domainImplClass;
	private Injector injector;

	public AbstractExpiredMongoRemover(Class<?> domainImplClass, Injector injector) {
		this.domainImplClass = domainImplClass;
		this.injector = injector;
	}

	public Class<?> getDomainImplClass() {
		return domainImplClass;
	}

	public Injector getInjector() {
		return injector;
	}

	protected DBCollection getDBCollection() {
		DomainImplParser domainImplParser = getInjector().getInstance(DomainImplParser.class);

		DomainImplSpecification domainImplSpec = domainImplParser.parse(this.domainImplClass);
		if (domainImplSpec == null) {
			throw new IllegalArgumentException("No @IOSpec is specified");
		}

		PersistenceSpecification persistenceSpec = domainImplSpec.getPersistenceSpecification();
		if (persistenceSpec == null) {
			throw new IllegalArgumentException("No @Table is specified");
		}

		DB db = getInjector().getInstance(MongoDBDictionary.class).getDB(persistenceSpec.getSchemaName());
		String dBCollectionName = persistenceSpec.getCollectionName();

		return db.getCollection(dBCollectionName);
	}

	protected BasicDBObject getResultProjection() {
		BasicDBObject projection = new BasicDBObject();
		projection.put("_id", 1);

		return projection;
	}

}
