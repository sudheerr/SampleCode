package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.loader.ClipboardLoader;
import com.citi.risk.core.data.store.api.LoaderType;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.spring.batch.api.BatchParameter;
import com.citi.risk.core.spring.batch.impl.AbstractBatchLoaderExecutionCallable;

public class ClipboardBatchCallable extends AbstractBatchLoaderExecutionCallable {
	private LoaderType loaderType = LoaderType.DEFAULT;
	private String batchName = DefaultCreatedBy.DEFAULT_PROCESS;
	
	private Class[] loaderClasses=new Class[]{
			ClipboardLoader.class
		};
	
	@Override
	public boolean isTrade() {
		return true;
	}

	@Override
	public boolean isCDM() {
		return true;
	}

	@Override
	public LoaderType getLoaderType() {
		return loaderType;
	}

	@Override
	public String getBatchName() {
		return batchName;
	}

	@Override
	public Class[] getLoaderClasses() {
		return loaderClasses;
	}

}