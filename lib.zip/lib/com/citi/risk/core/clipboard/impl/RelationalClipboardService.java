package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.annotation.Service;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.PayloadImpl;
import com.google.inject.Singleton;

@Singleton
@SuppressWarnings({"unchecked", "rawtypes"})
@Service
public class RelationalClipboardService extends DefaultClipboardService {

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> create(String user, Scope scope, P payloadObject) {
		Clipboard<P> clipboard = (Clipboard<P>) RdbmsClipboardImpl.newInstance(user, scope, payloadObject.getClass());
		clipboard.setContent(payloadObject);
		return create(clipboard);
	}

	/**
	 * @deprecated will Removed.
	 */
	@Deprecated
	@InfraInvocation
	@Override
	public Clipboard<Payload> create(String user, Scope scope, Criteria... criterias) {
		Clipboard<Payload> clipboard = RdbmsClipboardImpl.newInstance(user, scope, Payload.class);
		PayloadImpl payloadImpl = PayloadImpl.newInstance();
		for (Criteria criteria : criterias) {
			Collection domainObjects = dataAccessService.select(criteria, null);
			payloadImpl.add(domainObjects);
		}
		clipboard.setContent(payloadImpl);
		return create(clipboard);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Clipboard<Payload> create(String user, Scope scope, Collection<P> contents) {
		Clipboard clipboard = RdbmsClipboardImpl.newInstance(user, scope, Payload.class);
		PayloadImpl payload = PayloadImpl.newInstance(clipboard.getClipboardId());
		payload.add(contents);
		clipboard.setContent(payload);

		return create(clipboard);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		Criteria clipboardCriteria = clipboardIdPath.in(clipboardIds);
		clipboardCriteria.setDomainImplClass(RdbmsClipboardImpl.class);

		return super.select(clipboardCriteria, contentDomainSelect);
	}

	/**
	 * @deprecated will Removed.
	 */
	@Deprecated
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(
			Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(RdbmsClipboardImpl.class);
		return super.select(clipboardCriteria, contentDomainSelect);
	}

	@Override
	@InfraInvocation
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(
			Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(RdbmsClipboardImpl.class);
		return super.selectForUpdate(clipboardCriteria, contentDomainSelect);
	}

	@Override
	@InfraInvocation
	public <P extends IdentifiedBy<?>> Collection<P> selectContent(
			Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(RdbmsClipboardImpl.class);
		return super.selectContent(clipboardCriteria, contentDomainSelect);
	}

	@Override
	@InfraInvocation
	public <P extends IdentifiedBy<?>> Collection<P> selectContentForUpdate(
			Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(RdbmsClipboardImpl.class);
		return super.selectContentForUpdate(clipboardCriteria, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		Criteria clipboardCriteria = clipboardIdPath.in(clipboardIds);
		clipboardCriteria.setDomainImplClass(RdbmsClipboardImpl.class);
		deleteClipboards(super.select(clipboardCriteria, contentDomainSelect), false);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		((Criteria)clipboardCriteria).setDomainImplClass(RdbmsClipboardImpl.class);
		deleteClipboards(super.select(clipboardCriteria, contentDomainSelect), false);
	}

}
