package com.citi.risk.core.clipboard.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.citi.risk.core.configuration.api.Configuration;
import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.ClipboardPath;
import com.citi.risk.core.clipboard.api.ClipboardService;
import com.citi.risk.core.data.proxy.impl.ProxyHelper;
import com.citi.risk.core.data.service.api.DataAccessService;
import com.citi.risk.core.data.service.impl.StitchReferenceResolver;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.Criterion;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.create.api.Create;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.lang.transform.ChainedTransform;
import com.citi.risk.core.lang.transform.ResolveDeepCopy;
import com.citi.risk.core.lang.transform.UnwrapProxy;
import com.citi.risk.core.payload.api.Content;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.citi.risk.core.payload.impl.PayloadImpl;
import com.google.common.base.Function;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;

@SuppressWarnings({"unchecked", "rawtypes"})
public abstract class AbstractClipboardService implements ClipboardService {

    @Inject
    protected DataAccessService dataAccessService;

    @Inject
    protected Dictionary dictionary;

    @Inject
    protected Create create;
    
    @Inject
	protected ResolveDeepCopy resolveDeepCopy;
	
	@Inject
	protected ClipboardPath.ClipboardId clipboardIdPath;
	
	@Inject
	protected ClipboardPath.Expired expiredPath;

    @Inject
    protected Configuration configuration;
	
	protected Criteria appendExpiredCriteria(Criteria criteria) {
		Collection<Criterion> criterions = criteria.getAllCriterion();
		for (Criterion criterion : criterions) {
			if (criterion.getDataSelectionItem().getUnderlyingPath().equals(expiredPath)) {
				return criteria;
			}
		}
		return criteria.and(expiredPath.eq(false));
	}
	
	protected <P extends IdentifiedBy<?>> Collection<Clipboard<P>> filterExpiredClipboards(
			Collection<Clipboard<P>> clipboards) {
		if (CollectionUtils.isEmpty(clipboards)) {
			return Collections.emptyList();
		}
		Select unExpiredSelect = expiredPath.eq(false).getSelect();
		return unExpiredSelect.select(clipboards);
	}
	
    protected <P extends IdentifiedBy<?>> Collection<Clipboard<P>> filterClipboards(Collection<Clipboard<P>> clipboards, Select contentDomainSelect) {
    	Collection<Clipboard<P>> results = new ArrayList<>();
        
        if (contentDomainSelect == null) {
        	results.addAll(clipboards);
        } else {
            results.addAll(filterClipboardsBySelect(clipboards, contentDomainSelect));
        }
        return Collections2.transform(results, new UnwrapProxy<Clipboard<P>>());
    }

	private <P extends IdentifiedBy<?>> Collection<Clipboard<P>> filterClipboardsBySelect(Collection<Clipboard<P>> clipboards, Select contentDomainSelect) {
		Collection<Clipboard<P>> results = new ArrayList<>();
		
		Class domainClass = contentDomainSelect.getDomainClass();
		for (Clipboard clipboard : clipboards) {
		    Collection contentInClipboard = getContentInClipboardByDomainClass(domainClass, clipboard);

		    if (CollectionUtils.isNotEmpty(contentInClipboard)) {
		        ParallelSelect parallelSelect = new ParallelSelect(contentDomainSelect, 8, 200000, configuration.getInteger("query.task.timeout", 60));

		        if (CollectionUtils.isNotEmpty(parallelSelect.select(contentInClipboard)))
		            results.add(clipboard);
		    }

		}
		
		return results;
	}

    private <P extends IdentifiedBy<?>> Collection<P> getContentInClipboardByDomainClass(Class<P> domainClass, Clipboard<P> clipboard) {
        Collection<P> contents = Lists.newArrayList();

        if (domainClass == null || domainClass.isAssignableFrom(clipboard.getContentClass())) {
        	contents.add(clipboard.getContent());
        }
        
        return contents;
        
    }

    protected <P extends IdentifiedBy<?>> Collection getContentInClipboardForContent(Class<P> domainClass, Clipboard<?> clipboard) {
        Collection<P> contents;
        if (clipboard.getContentClass() != null && Payload.class.isAssignableFrom(clipboard.getContentClass())) {
            contents = getContentObjects(domainClass, clipboard);
        } else {
            contents = Lists.newArrayList();
            if (clipboard.getContentClass() != null && (null == domainClass || domainClass.isAssignableFrom(clipboard.getContentClass()))) {
                contents.add((P) clipboard.getContent());
            }
        }
        return contents;
    }

	private <P extends IdentifiedBy<?>> Collection<P> getContentObjects(Class<P> domainClass, Clipboard<?> clipboard) {
		Collection<P> contents;
		if (null == domainClass) {
		    Collection<Content> contentImpls = ((Payload) clipboard.getContent()).getContent();
		    contents = Lists.newArrayList();
		    if (contentImpls != null)
		        for (Content content : contentImpls) {
		            contents.add((P) content.getContentObject());
		        }
		} else {
		    contents = ((Payload) clipboard.getContent()).getContent(domainClass);
		}
		return contents;
	}

    protected <P extends IdentifiedBy<?>> void deleteClipboards(Collection<Clipboard<P>> clipboards, boolean atomic) {
        if (CollectionUtils.isNotEmpty(clipboards)) {
            ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
            executionContext.setAtomic(atomic);
            dataAccessService.delete(clipboards);
        }
    }
    
    protected <P extends IdentifiedBy<?>> void setContentToClipboard(P payloadObject, Clipboard clipboard) {
        if (Payload.class.isAssignableFrom(payloadObject.getClass())) {
            Collection<Content> contents = ((PayloadImpl) payloadObject).getContent();
            if (CollectionUtils.isNotEmpty(contents)) {
                clipboard.setContent(getNewPayload(clipboard, contents));
            } else
                clipboard.setContent(payloadObject);
        } else {
            clipboard.setContent(payloadObject);
        }
    }

	private Payload getNewPayload(Clipboard clipboard, Collection<Content> contents) {
		Payload newPayload = PayloadImpl.newInstance();
		for (Content c : contents) {
		    if (c.getContentObject() != null) {
		        ContentImpl entity = (ContentImpl) c;
		        if (entity.getParentId() == null || entity.getParentId().equals(clipboard.getId()))
		            newPayload.add(c.getContentObject());
		    }
		}
		return newPayload;
	}
    
    protected <P extends IdentifiedBy<?>> Clipboard<P> getHistoryClipboard(Clipboard<P> clipboard, Integer version) {
        Criteria criteria = create.getInstance(ClipboardPath.Version.class).eq(version);
        criteria.and(create.getInstance(ClipboardPath.Expired.class).eq(true));
        criteria.and(create.getInstance(ClipboardPath.ClipboardId.class).eq(clipboard.getClipboardId()));

        Collection<Clipboard<P>> historyClipboards = select(criteria, null);
        
        Clipboard<P> historyClipboard = Iterables.getFirst(historyClipboards, null);
        return historyClipboard;
    }

    protected <P extends IdentifiedBy<?>> Clipboard<P> getLatestClipboard(Clipboard<P> clipboard) {
        Collection<Clipboard<P>> lastestClipboards = select(Arrays.asList(clipboard.getClipboardId()), null);
        Clipboard<P> lastestClipboard = Iterables.getFirst(lastestClipboards, null);
        return lastestClipboard;
    }

    protected <P extends IdentifiedBy<?>> void checkVersion(Integer inputVersion, Integer incomingVersion, Clipboard<P> lastestClipboard) {
        if (null == lastestClipboard) {
            throw new RuntimeException("couldn't find clipboard with clipbardId");
        }

        Integer latestVersion = lastestClipboard.getVersion();
        if (null != incomingVersion && !latestVersion.equals(incomingVersion)) {
        	throw new RuntimeException("input object should always be the latest version");
        }

        if (inputVersion <= 0) {
            throw new RuntimeException("input version must be more than zero");
        }

        if (inputVersion >= latestVersion) {
            throw new RuntimeException("input version must be smaller than lastestVersion");
        }
    }

    protected <P extends IdentifiedBy<?>> Multimap<Integer, String> getVersionToIdsMap(Collection<Clipboard<P>> latestClipboards) {
        Multimap<Integer, String> versionToIds = ArrayListMultimap.create();
        Map<String, Clipboard<P>> lastestClipboardsMap = Maps.newHashMap();

        for (Clipboard<P> latestClipboard : latestClipboards) {
            Integer lastestVersion = latestClipboard.getVersion();
            Integer historyVersion = lastestVersion - 1;
            versionToIds.put(historyVersion, latestClipboard.getClipboardId());
            lastestClipboardsMap.put(latestClipboard.getClipboardId(), latestClipboard);
        }
        return versionToIds;
    }

    protected <P extends IdentifiedBy<?>> Map<String, Clipboard<P>> getLatestClipboardMap(Collection<Clipboard<P>> latestClipboards) {
        Map<String, Clipboard<P>> lastestClipboardsMap = Maps.newHashMap();

        for (Clipboard<P> latestClipboard : latestClipboards) {
            lastestClipboardsMap.put(latestClipboard.getClipboardId(), latestClipboard);
        }
        return lastestClipboardsMap;
    }

    protected <P extends IdentifiedBy<?>> Map<String, Clipboard<P>> getInputCliboardmap(Collection<Clipboard<P>> clipboards) {
        Map<String, Clipboard<P>> inputCliboardMap = Maps.newHashMap();
        for (Clipboard<P> clipboard : clipboards) {
            inputCliboardMap.put(clipboard.getClipboardId(), clipboard);
        }
        return inputCliboardMap;
    }

    protected <P extends IdentifiedBy<?>> void checkVersions(Map<String, Clipboard<P>> inputCliboards, Map<String, Clipboard<P>> latestClipboardsMap) {
        for (Map.Entry<String, Clipboard<P>> entry : inputCliboards.entrySet()) {
            String clipboardid = entry.getKey();
            Clipboard<P> clipboard = entry.getValue();
            Integer incomingVersion = clipboard.getVersion();
            Clipboard<P> latestClipboard = latestClipboardsMap.get(clipboardid);
            if (null == latestClipboard) {
                throw new RuntimeException("couldn't find clipboard with clipbardId");
            }

            Integer latestVersion = latestClipboard.getVersion();
            if (null != incomingVersion && !latestVersion.equals(incomingVersion)) {
            	throw new RuntimeException("input object should always be the latest version");
            }

            if (latestVersion <= 1) {
                throw new RuntimeException("latest version must be more than one");
            }
        }
    }

    protected <P extends IdentifiedBy<?>> List<Clipboard<P>> getNeedUpdatedClipboards(Multimap<Integer, String> versionToIds,
                                                                                    Map<String, Clipboard<P>> lastestClipboardsMap) {
        List<Clipboard<P>> lastestClipboardCopys = Lists.newArrayList();
        for (Map.Entry<Integer, Collection<String>> entry : versionToIds.asMap().entrySet()) {

            Integer version = entry.getKey();
            Collection<String> value = entry.getValue();
            Criteria criteria = create.getInstance(ClipboardPath.Expired.class).eq(true);
            criteria.and(create.getInstance(ClipboardPath.Version.class).eq(version));
            criteria.and(create.getInstance(ClipboardPath.ClipboardId.class).in(value));

            Collection<Clipboard<P>> historyClipboards = select(criteria, null);
            for (Clipboard<P> histoaryClipboard : historyClipboards) {
                Clipboard<P> lastestClipboard = lastestClipboardsMap.get(histoaryClipboard.getClipboardId());
                // because lastestclipbord comes from cache, so need copy.When java serialization is done, can change to it.
                Clipboard<P> lastestClipboardCopy = getCopyClipboard(lastestClipboard);
                setContentToClipboard(histoaryClipboard.getContent(), lastestClipboardCopy);
                lastestClipboardCopys.add(lastestClipboardCopy);
            }
        }
        return lastestClipboardCopys;
    }

    protected <P extends IdentifiedBy<?>> Clipboard<P> getCopyClipboard(Clipboard<P> lastestClipboard) {
    	if (lastestClipboard == null) {
    		return null;
    	}
    	Clipboard<P> clipboard;
    	if (ProxyHelper.isInstanceof(ClipboardImpl.class, lastestClipboard)) {
    		clipboard = new ClipboardImpl();
    	} else if (ProxyHelper.isInstanceof(RdbmsClipboardImpl.class, lastestClipboard)) {
    		clipboard = new RdbmsClipboardImpl();
    	} else {
    		throw new IllegalArgumentException("Incorrect Clipboard type : " + lastestClipboard.getClass());
    	}
        clipboard.setClipboardId(lastestClipboard.getClipboardId());
        clipboard.setVersion(lastestClipboard.getVersion());
        clipboard.setAdditionalInfo(lastestClipboard.getAdditionalInfo());
        clipboard.setId(lastestClipboard.getId());
        clipboard.setCreatedBy(lastestClipboard.getCreatedBy());
        
        clipboard.setCreatedByString(lastestClipboard.getCreatedByString());
        clipboard.setCreatedTime(lastestClipboard.getCreatedTime());
        clipboard.setExpired(lastestClipboard.getExpired());
        clipboard.setScope(lastestClipboard.getScope());
        clipboard.setScopeId(lastestClipboard.getScopeId());
        clipboard.setScopeType(lastestClipboard.getScopeType());
        clipboard.setTimeMark(lastestClipboard.getTimeMark());
        if (null != lastestClipboard.getTimeMark()) {
			clipboard.setTimeMarkString(lastestClipboard.getTimeMarkString());
		}
        clipboard.setUser(lastestClipboard.getUser());
        clipboard.setValidFrom(lastestClipboard.getValidFrom());
        clipboard.setValidThru(lastestClipboard.getValidThru());
        return clipboard;
    }
    
    @Inject
	private ClipboardCopy clipboardCopy;

	protected <P extends IdentifiedBy<?>> Collection<Clipboard<P>> makeDeepCopy(Collection<Clipboard<P>> clipboards) {
		ChainedTransform chainedTransform = new ChainedTransform(Arrays.asList(clipboardCopy));
		return Collections2.transform(clipboards, chainedTransform);
	}
	
	public static class ClipboardCopy implements Function<Clipboard,Clipboard>
	{
		@Inject
		private ResolveDeepCopy resolveDeepCopy;
		
		@Inject
		private StitchReferenceResolver stitchRefResolver;
		
	    @Inject
	    private DataAccessService dataAccessService;
	    
		@Override
		public Clipboard apply(Clipboard oldClipboard) {

			Clipboard newClipboard = new ClipboardImpl();
			copyBasicAttribute(oldClipboard, newClipboard);

			copyContent(oldClipboard, newClipboard);

			return newClipboard;
		}

		private void copyContent(Clipboard oldClipboard, Clipboard newClipboard) {
			IdentifiedBy content = oldClipboard.getContent();
			List<IdentifiedBy> list = Lists.newArrayList();
			if (content instanceof Payload) {
				Payload payload = (Payload) content;
				Collection<Content> contentsInPayload = payload.getContent();
				for (Content contentinPayload : contentsInPayload) {
					IdentifiedBy contentObject = contentinPayload.getContentObject();
					list.add(contentObject);
				}
				Collection transform = resolveDeepCopy.lazyDeepCopy(list);

				Payload newPayload = new PayloadImpl();
				newPayload.setCreatedBy(payload.getCreatedBy());
				newPayload.setId(payload.getId());
				newPayload.setTimeMark(payload.getTimeMark());
				newPayload.setTimeMarkString(payload.getTimeMarkString());
				newPayload.add(transform);
				newClipboard.setContent(newPayload);
			} else {
				if (null != content) {
					Collection<IdentifiedBy> transform = resolveDeepCopy.lazyDeepCopy(Arrays.asList(content));
					newClipboard.setContent(Iterables.getFirst(transform, null));
				}

			}
		}

		private void copyBasicAttribute(Clipboard oldClipboard, Clipboard newClipboard) {
			newClipboard.setClipboardId(oldClipboard.getClipboardId());
			newClipboard.setVersion(oldClipboard.getVersion());
			newClipboard.setAdditionalInfo(oldClipboard.getAdditionalInfo());
			newClipboard.setId(oldClipboard.getId());
			newClipboard.setCreatedBy(oldClipboard.getCreatedBy());
			newClipboard.setCreatedByString(oldClipboard.getCreatedByString());
			newClipboard.setCreatedTime(oldClipboard.getCreatedTime());
			newClipboard.setExpired(oldClipboard.getExpired());
			newClipboard.setScope(oldClipboard.getScope());
			newClipboard.setScopeId(oldClipboard.getScopeId());
			newClipboard.setScopeType(oldClipboard.getScopeType());
			newClipboard.setTimeMark(oldClipboard.getTimeMark());
			if (null != oldClipboard.getTimeMark()) {
				newClipboard.setTimeMarkString(oldClipboard.getTimeMarkString());
			}
			newClipboard.setUser(oldClipboard.getUser());
			newClipboard.setValidFrom(oldClipboard.getValidFrom());
			newClipboard.setValidThru(oldClipboard.getValidThru());
		}
	}
}
