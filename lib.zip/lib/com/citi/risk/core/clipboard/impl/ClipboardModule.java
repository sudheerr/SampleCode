package com.citi.risk.core.clipboard.impl;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.ClipboardService;
import com.citi.risk.core.clipboard.loader.ClipboardLoader;
import com.citi.risk.core.clipboard.loader.RdbmsClipboardLoader;
import com.citi.risk.core.data.lang.PackageUtil;
import com.citi.risk.core.data.service.jpa.AbstractJpaDataAccessModule;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.impl.AbstractMongoConnectModule;
import com.citi.risk.core.dictionary.api.DomainDefinition;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.collect.Lists;
import com.google.inject.AbstractModule;
import com.google.inject.Inject;
import com.google.inject.name.Names;

public class ClipboardModule extends AbstractModule {
    private ClipboardModule() {

    }

    private static final AtomicReference<ClipboardModule> instance = new AtomicReference<>();

    public static ClipboardModule getInstance() {
        ClipboardModule singleton = instance.get();

        if (singleton == null) {
            instance.compareAndSet(null, new ClipboardModule());
            singleton = instance.get();
        }

        return singleton;
    }

    @Override
    protected void configure() {
        install(new AbstractMongoConnectModule() {
            @Override
            public String getSchemaName() {
                return PackageUtil.getSchemaName(ClipboardImpl.class);
            }
        });

        install(new AbstractMongoConnectModule() {
            @Override
            public String getSchemaName() {
                return "common-lib-test-service";
            }
        });
        install(new AbstractJpaDataAccessModule() {
            @Override
            public String getSchemaName() {
                return "relational-clipboard";
            }
        });

        // any non-annotated clipboardService injections will be bound to DefaultClipboardService

        bind(ClipboardService.class).to(DefaultClipboardService.class);
        bind(ClipboardService.class).annotatedWith(Names.named("MongoClipboardService")).to(MongoClipboardService.class);
		if (RdbmsClipboardFilter.needFilter()) {
			bind(ClipboardService.class).annotatedWith(Names.named("RdbmsClipboardService")).to(MockRelationalClipboardService.class);
		} else {
			bind(ClipboardService.class).annotatedWith(Names.named("RdbmsClipboardService")).to(RelationalClipboardService.class);
		}
		bind(ClipboardLoader.class);
        bind(RdbmsClipboardLoader.class);
        bind(ClipboardDomainDefinition.class);
        bind(ClipboardGuiceInitiator.class).asEagerSingleton();
    }

    public final static class ClipboardDomainDefinition implements DomainDefinition {

        @Override
        public List<String> getDomainPackage() {
            List<String> list = Lists.newArrayList();
            list.add("com.citi.risk.core.gui.api");
            return list;
        }

        @Override
        public List<Class<?>> getDomainClassList() {
            List<Class<?>> list = Lists.newArrayList();
            list.add(Clipboard.class);
            return list;
        }
    }
    public static class ClipboardGuiceInitiator {
        @Inject
        private ClipboardGuiceInitiator(DomainImplParser domainImplParser) {
        	domainImplParser.parse(ClipboardImpl.class);
            domainImplParser.parse(RdbmsClipboardImpl.class);
            domainImplParser.parse(ContentImpl.class);
        }
    }


}
