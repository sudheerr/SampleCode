package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.collection.list.Lists;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.payload.api.Payload;
import com.google.inject.Singleton;

@Singleton
public class MockRelationalClipboardService extends AbstractClipboardService {

	private Clipboard NULL_CLIPBOARD = NullTerminator.create(Clipboard.class);

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(
			Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}


	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> create(Clipboard<P> clipboard) {
		return clipboard;
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> create(Collection<Clipboard<P>> clipboards) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> create(String user, Scope scope, P payloadObject) {
		return NULL_CLIPBOARD;
	}

	@Override
	public Clipboard<Payload> create(String user, Scope scope, Criteria... criterias) {
		return NULL_CLIPBOARD;
	}

	@Override
	public <P extends IdentifiedBy<?>> Clipboard<Payload> create(String user,
			Scope scope, Collection<P> contents) {
		return NULL_CLIPBOARD;
	}


	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject) {
		return NULL_CLIPBOARD;
	}

	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, Integer version) {
		return NULL_CLIPBOARD;
	}

	@Override
	public Clipboard<Payload> update(String clipboardId, Collection<IdentifiedBy<?>> contents) {
		return NULL_CLIPBOARD;
	}

	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, boolean atomic) {
		return NULL_CLIPBOARD;
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect, boolean atomic) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect, boolean atomic) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect, boolean atomic) {
		//intentionally-blank override
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<P> selectContent(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<P> selectContentForUpdate(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		return Lists.newArrayList();
	}

	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> revertToVersion(Clipboard<P> clipboard, Integer version) {
		return NULL_CLIPBOARD;
	}

	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> revertToPrior(Collection<Clipboard<P>> clipboards) {
		return Lists.newArrayList();
	}

	@Override
	protected <P extends IdentifiedBy<?>> Collection<Clipboard<P>> makeDeepCopy(Collection<Clipboard<P>> clipboards) {
		return Lists.newArrayList();
	}

}

