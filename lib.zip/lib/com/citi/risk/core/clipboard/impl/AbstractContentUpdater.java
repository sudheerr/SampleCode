package com.citi.risk.core.clipboard.impl;

import java.util.Collection;
import java.util.Map;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.clipboard.api.ClipboardContentUpdating;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.google.inject.Injector;

abstract class AbstractContentUpdater implements ClipboardContentUpdater {

	private Injector injector;
	private Map<Class<? extends AbstractContentUpdating>, AbstractContentUpdating> updatings;

	AbstractContentUpdater(Injector injector) {
		this.injector = injector;
		this.updatings = Maps.newHashMap();
	}

	void add(Class<? extends AbstractContentUpdating> klass, AbstractContentUpdating updating) {
		AbstractContentUpdating existing = this.updatings.get(klass);
		if (existing == null) {
			try {
				existing = klass.newInstance();
				existing.setInjector(injector);
				existing.setUpdater(this);
			} catch (InstantiationException | IllegalAccessException e) {
				throw new RuntimeException("Exception while adding RdbmsUpdating to Updater", e);
			}
			this.updatings.put(klass, existing);
		}

		existing.add(updating);
	}
	
	Injector getInjector() {
		return injector;
	}

	Map<Class<? extends AbstractContentUpdating>, AbstractContentUpdating> getUpdatings() {
		return updatings;
	}
	
	@Override
	public ClipboardContentUpdating<String> rename(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new IllegalArgumentException("cannot rename an empty key");
		}
		return new RenameUpdating(attribute, this, getInjector());
	}

	@Override
	public ClipboardContentUpdater remove(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new RuntimeException("cannot remove an empty key");
		}
		add(RemoveUpdating.class, new RemoveUpdating(attribute, this, getInjector()));
		return this;
	}

	@Override
	public ClipboardContentUpdating add(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new IllegalArgumentException("Empty input paramter");
		}

		return new AddValueUpdating(attribute, this, getInjector());
	}
	
	@Override
	public ClipboardContentUpdating change(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new RuntimeException("cannot change value for an empty key");
		}
		return new ChangeValueUpdating(attribute, this, getInjector());
	}
	
	@Override
	public Collection<Object> get(String attribute, String where, String eqValue) {
		throw new UnsupportedOperationException();
	}

}
