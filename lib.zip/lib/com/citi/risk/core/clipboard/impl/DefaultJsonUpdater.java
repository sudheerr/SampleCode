package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import org.apache.commons.collections.MapUtils;
import org.bson.BSONObject;

import com.citi.risk.core.clipboard.api.ClipboardContentQuery;
import com.citi.risk.core.data.store.api.DomainImplParser;
import com.citi.risk.core.data.store.api.PersistenceSpecification;
import com.citi.risk.core.data.store.db.api.MongoDBDictionary;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

class DefaultJsonUpdater extends AbstractContentUpdater {

	private Class<?> domainImplClass;
	private BasicDBObject queryTemplate;

	DefaultJsonUpdater(Injector injector, Class<?> domainImplClass) {
		super(injector);
		checkDomainImplClass(domainImplClass);
		this.domainImplClass = domainImplClass;
		this.queryTemplate = new BasicDBObject();
	}

	@Override
	public Integer execute() {
		if (MapUtils.isEmpty(getUpdatings())) {
			return 0;
		}
		DBCollection dbColl = getDBCollection();
		DBObject updateQuery = this.queryTemplate;

		DBCursor dbCursor = dbColl.find(updateQuery);
		int count = 0;
		while (dbCursor.hasNext()) {
			DBObject dbRecord = dbCursor.next();
			DBObject dbRecordId = new BasicDBObject("_id", dbRecord.get("_id"));
			BSONObject bsonObject = (BSONObject) dbRecord.get(getAttributePrefix());
			BSONObject changedBSONObject = applyChanges(bsonObject);
			DBObject updateTemplate = new BasicDBObject("$set", new BasicDBObject(getAttributePrefix(), changedBSONObject));
			dbColl.update(dbRecordId, updateTemplate);
			count++;
		}
		
		return count;
	}
	
	@Override
	public ClipboardContentQuery where(String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new RuntimeException("attribute is null");
		}

		return new DefaultJsonQuery(attribute, this, this.queryTemplate);
	}

	private DBCollection getDBCollection() {
		DomainImplParser domainImplParser = getInjector().getInstance(DomainImplParser.class);
		PersistenceSpecification persistenceSpec = domainImplParser.parse(this.domainImplClass)
				.getPersistenceSpecification();
		DB db = getInjector().getInstance(MongoDBDictionary.class).getDB(persistenceSpec.getSchemaName());
		String dBCollectionName = persistenceSpec.getCollectionName();
		return db.getCollection(dBCollectionName);
	}

	private String getAttributePrefix() {
		if (domainImplClass.equals(ContentImpl.class)) {
			return "content";
		} else if (domainImplClass.equals(ClipboardImpl.class)) {
			return "contentObject";
		}
		throw new RuntimeException("incorrect domain impl class");
	}

	private void checkDomainImplClass(Class implClass) {
		if (implClass.equals(ContentImpl.class) || implClass.equals(ClipboardImpl.class) ) {
			return;
		}
		throw new RuntimeException("incorrect domain impl class: "+ implClass.getName() + ". should be either contentImpl or clipboardImpl!");
		
	}
	
	private BSONObject applyChanges(BSONObject bsonObj) {
		for (AbstractContentUpdating updating : getUpdatings().values()) {
			updating.modify(bsonObj);
		}
		return bsonObj;
	}

	@Override
	public Collection<Object> get(String attribute, String whereCondition, String eqValue) {
		if (whereCondition == null || eqValue == null) {
			throw new RuntimeException("where condition should not be null");
		}
		Collection<Object> returnValues = Lists.newArrayList();
		DBCollection dbColl = getDBCollection();
		BasicDBObject updateQuery = new BasicDBObject(whereCondition, eqValue);
		
		DBCursor dbCursor = dbColl.find(updateQuery);
		while (dbCursor.hasNext()) {
			DBObject dbRecord = dbCursor.next();
			BSONObject bsonObject = (BSONObject) dbRecord.get(getAttributePrefix());
			for (BSONObject bsonObj : AbstractContentUpdating.getLeafBsons(bsonObject, attribute)) {
				Object value = bsonObj.get(AbstractContentUpdating.getLeafAttribute(attribute));
				returnValues.add(value);
			}
		}
		return returnValues;
	}

}
