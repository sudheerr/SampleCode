package com.citi.risk.core.clipboard.impl;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.deleter.RdbmsClipboardDeleter;
import com.citi.risk.core.clipboard.loader.RdbmsClipboardLoader;
import com.citi.risk.core.clipboard.storer.RdbmsClipboardStorer;
import com.citi.risk.core.clipboard.updater.RdbmsClipboardUpdater;
import com.citi.risk.core.data.store.api.DomainImplSpecification;
import com.citi.risk.core.data.store.impl.DefaultDomainImplSpecification;
import com.citi.risk.core.data.store.impl.DefaultIOSpecification;
import com.citi.risk.core.data.store.impl.DefaultPersistenceSpecification;
import com.citi.risk.core.ioc.impl.guice.CoreModule;

public final class RdbmsClipboardFilter {
	
	private RdbmsClipboardFilter() {
	}

	private static Boolean FILTER = null;
	private static final DomainImplSpecification DUMMY_DOMAIN_IMPL_SPECIFICATION;
	private static final String RDBMS_CLIPBOARD_ENABLED = System.getProperty("rdbms.clipboard.enabled", null);

	static {
		DUMMY_DOMAIN_IMPL_SPECIFICATION = new DefaultDomainImplSpecification();
		DUMMY_DOMAIN_IMPL_SPECIFICATION.setIOSpecification(new DefaultIOSpecification());
		DUMMY_DOMAIN_IMPL_SPECIFICATION.getIOSpecification().setIsInitialLoad(false);
		DUMMY_DOMAIN_IMPL_SPECIFICATION.getIOSpecification().setDomainClasses(new Class[]{Clipboard.class});
		DUMMY_DOMAIN_IMPL_SPECIFICATION.setPersistenceSpecification(new DefaultPersistenceSpecification());
	}

	public static boolean filter(Class klass) {
		if (needFilter() && (
				klass == RdbmsClipboardImpl.class
						|| klass == RdbmsClipboardLoader.class
						|| klass == RdbmsClipboardStorer.class
						|| klass == RdbmsClipboardUpdater.class
						|| klass == RdbmsClipboardDeleter.class
						|| klass == RelationalClipboardService.class)) {
			return true;
		}
		return false;
	}

	public static synchronized boolean needFilter() {
		if (FILTER == null) {
			if (RDBMS_CLIPBOARD_ENABLED != null) {
				FILTER = StringUtils.equalsIgnoreCase(RDBMS_CLIPBOARD_ENABLED,"false");
			} else {
				FILTER = !CoreModule.getConfiguration().getBoolean("rdbms.clipboard.enabled", true);
			}
		}
		return FILTER;
	}

	public static DomainImplSpecification getDummyRdbmsDomainImplSpecification() {
		return DUMMY_DOMAIN_IMPL_SPECIFICATION;
	}

}

