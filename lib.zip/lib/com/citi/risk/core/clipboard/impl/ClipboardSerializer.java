package com.citi.risk.core.clipboard.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.bson.BSON;
import org.bson.BSONObject;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.io.impl.AbstractSerializer;
import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.inject.Inject;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class ClipboardSerializer extends AbstractSerializer<Collection<Clipboard<?>>, List<DBObject>> {
    @Inject
    JsonSerializationFacade jsonService;

    BlockingQueue<DBObject> queue;

    private boolean header = false;

    public void setQueue(BlockingQueue<DBObject> queue) {
        this.queue = queue;
    }

    public void setHeader(boolean header) {
        this.header = header;
    }

    public boolean getHeader() {
        return this.header;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
    public List<DBObject> serialize(Collection<Clipboard<?>> source) {
        List<DBObject> bsonContents = new ArrayList<>();
        for (Clipboard clipboard : source) {
            BasicDBObject clipboardDbObject =
                    new BasicDBObject("_id", clipboard.getId()).append("clipboardId", clipboard.getClipboardId())
                            .append("user", clipboard.getUser()).append("scope", clipboard.getScopeId())
                            .append("createdTime", clipboard.getCreatedTime())
                            .append("payloadType", clipboard.getContentClass() == null ? null : clipboard.getContentClass().getName())
                            .append("version", clipboard.getVersion()).append("scopeType", clipboard.getScopeType())
                            .append("additionalInfo", clipboard.getAdditionalInfo() == null ? null : clipboard.getAdditionalInfo())
                            .append("Is Expired", false).append("validFrom", clipboard.getValidFrom())
                            .append("validThru", clipboard.getValidThru());
            if (!header && clipboard.getContentClass() != null && !Payload.class.isAssignableFrom(clipboard.getContentClass())) {
                byte[] objectOnByteArray = jsonService.serializeToByteArray(clipboard.getContent());
                BSONObject bsonObject = BSON.decode(objectOnByteArray);
                clipboardDbObject =
                        clipboardDbObject.append("domainInterfaces", clipboard.getContentDomainInterfaces())
                                .append("contentKey", clipboard.getContentKey())
                                .append("contentVersion", clipboard.getContentVersion()).append("contentObject", bsonObject);
            } else {
                clipboardDbObject =
                        clipboardDbObject.append("domainInterfaces", null).append("contentKey", null)
                                .append("contentVersion", null).append("contentObject", null);
            }
            bsonContents.add(clipboardDbObject);
        }
        queue.addAll(bsonContents);
        return bsonContents;
    }

}
