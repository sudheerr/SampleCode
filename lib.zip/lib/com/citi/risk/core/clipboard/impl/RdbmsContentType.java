package com.citi.risk.core.clipboard.impl;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.persister.entity.SingleTableEntityPersister;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.collection.list.Lists;
import com.citi.risk.core.payload.api.Content;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.PayloadImpl;
import com.google.common.base.Strings;
import com.google.inject.Injector;

public class RdbmsContentType implements UserType, ParameterizedType {

	private static final Logger LOGGER = LoggerFactory.getLogger(RdbmsContentType.class);
	private static final String RDBMS_CONTENT_COLUMN_NAME = "rdbmsContentName";
	private static final String ID_COLUMN_NAME = "idName";
	private String rdbmsContentName;
	private String idName;
	private JsonSerializationFacade jsonService;

	private int[] sqlTypes = new int[] { java.sql.Types.VARCHAR };

	@Override
	public void setParameterValues(Properties parameters) {
		this.rdbmsContentName = parameters.getProperty(RDBMS_CONTENT_COLUMN_NAME);
		this.idName = parameters.getProperty(ID_COLUMN_NAME);
		if (Strings.isNullOrEmpty(this.rdbmsContentName)) {
			throw new HibernateException("cannot get rdbmsContentName");
		}
		if (Strings.isNullOrEmpty(this.idName)) {
			throw new HibernateException("cannot get idName");
		}
	}

	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return value;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		if(x != null && y != null){
			Object xContent = x;
			Object yContent = y;
			if(x instanceof PayloadImpl) {
				xContent = ((PayloadImpl)x).getContentForPersist();
			}
			if(y instanceof PayloadImpl) {
				yContent = ((PayloadImpl)y).getContentForPersist();
			}
			return xContent == yContent;
		}
		
		return x == y;
	}

	@Override
	public int hashCode(Object x) throws HibernateException {
		return x == null ? 0 : x.hashCode();
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner)
			throws HibernateException, SQLException {

		prepareInjectMembers(session);

		SingleTableEntityPersister persister = (SingleTableEntityPersister) session.getFactory().getClassMetadata(
				owner.getClass());

		String rdbmsContentClassName = rs.getString(getColumnIndex(rs.getMetaData(), persister, this.rdbmsContentName));
		if (Strings.isNullOrEmpty(rdbmsContentClassName)) {
			throw new HibernateException("cannot get rdbms content class name");
		}

		String id = rs.getString(getColumnIndex(rs.getMetaData(), persister, this.idName));
		if (Strings.isNullOrEmpty(id)) {
			throw new HibernateException("cannot get id");
		}

		Object result;
		Blob blob = rs.getBlob(names[0]);
		if (blob != null) {
			try {
				Class<?> clazz = Class.forName(rdbmsContentClassName);
				byte[] objectOnByteArray = blob.getBytes(1, (int) blob.length());

				if (Payload.class.isAssignableFrom(clazz)) {
					result = deserializeToPayload(objectOnByteArray);
				} else {
					result = deserializeToObject(clazz, objectOnByteArray);
				}
				return result;
			} catch (ClassNotFoundException | SQLException e) {
				LOGGER.error("Clipboard id = " + id, e);
			}
		}

		return null;
	}

	private Object deserializeToObject(Class<?> clazz, byte[] objectOnByteArray) {
		Object result;
		try {
			result = jsonService.deserializeByByteArray(objectOnByteArray, clazz);
		} catch(Exception e) {
			LOGGER.error("Failed to deserializeByByteArray", e);
			result = NullTerminator.create(clazz);
		}
		return result;
	}

	private Object deserializeToPayload(byte[] objectOnByteArray) {
		Object result;
		try {
			Collection contents = Lists.newArrayList();
			RdbmsContainer.Item[] entities = jsonService.deserializeByByteArray(objectOnByteArray,
					RdbmsContainer.class).getObjects();
			Payload newPayload = new PayloadImpl();
			for (RdbmsContainer.Item item : entities) {
				Object o = jsonService.deserializeByByteArray(item.getObject(),
						Class.forName(item.getClassType()));
				contents.add(o);
			}
			newPayload.add(contents);
			result = newPayload;
		} catch(Exception e) {
			LOGGER.error("Failed to deserializeByByteArray", e);
			result = NullTerminator.create(PayloadImpl.class);
		}
		return result;
	}

	private int getColumnIndex(ResultSetMetaData metaData, SingleTableEntityPersister persister, String propertyName)
			throws SQLException {
		String colunAliaseName = persister.getPropertyAliases("", persister.getPropertyIndex(propertyName))[0];
		for (int index = 1; index <= metaData.getColumnCount(); index++) {
			if (StringUtils.startsWith(metaData.getColumnLabel(index), colunAliaseName)) {
				return index;
			}
		}
		return -1;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session)
			throws HibernateException, SQLException {
		if (value != null) {
			prepareInjectMembers(session);
			byte[] blobBytes;
			if (Collection.class.isAssignableFrom(value.getClass())) {
				List<RdbmsContainer.Item> toSerialize = Lists.newArrayList();
				for (Content content : (Collection<Content>) value) {
					toSerialize.add(new RdbmsContainer.Item(
							jsonService.serializeToByteArray(content.getContentObject()), content.getContentClass()));
				}
				blobBytes = jsonService.serializeToByteArray(new RdbmsContainer(toSerialize
						.toArray(new RdbmsContainer.Item[toSerialize.size()])));
			} else {
				blobBytes = jsonService.serializeToByteArray(value);
			}
			st.setBlob(index, new ByteArrayInputStream(blobBytes));
		} else {
			LOGGER.warn("payload content is null.");
		}
	}

	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

	@Override
	public Class<?> returnedClass() {
		return Object.class;
	}

	@Override
	public int[] sqlTypes() {
		return sqlTypes.clone();
	}

	private void prepareInjectMembers(SessionImplementor session) {
		SessionFactoryImplementor factory = session.getFactory();
		Injector injector = (Injector) factory.getProperties().get("INJECTOR");
		if (injector == null) {
			throw new HibernateException("cannot get Injector from hibernate session");
		}
		if (jsonService == null) {
			this.jsonService = injector.getInstance(JsonSerializationFacade.class);
			if (this.jsonService == null) {
				throw new HibernateException("cannot get JsonSerializationFacade from Injector");
			}
		}
	}

}
