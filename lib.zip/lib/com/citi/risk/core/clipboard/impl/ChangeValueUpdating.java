package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import org.apache.commons.lang3.ClassUtils;
import org.bson.BSON;
import org.bson.BSONObject;
import org.bson.types.BasicBSONList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Strings;
import com.google.inject.Injector;

class ChangeValueUpdating extends AbstractContentUpdating<Object> {

	private Logger LOGGER = LoggerFactory.getLogger(ChangeValueUpdating.class);
	
	ChangeValueUpdating() {
		super();
	}
	
	ChangeValueUpdating(String attribute, AbstractContentUpdater updater, Injector injector) {
		super(attribute, updater, injector);
	}
	
	@Override
	public ClipboardContentUpdater to(Object value) {
		if (value instanceof BSONObject) {
			throw new RuntimeException("value should not be instance of bsonObject");
		}
		
		if (Strings.isNullOrEmpty(getAttribute())) {
			LOGGER.warn("invalid input attributes");
			return getUpdater();
		}
		if ("_id".equals(getAttribute())) {
			throw new RuntimeException("Change _id is not a valid operation");
		}

		add(Pair.create(getAttribute(), value));
		getUpdater().add(ChangeValueUpdating.class, this);

		return getUpdater();
	}


	@Override
	void doModify(BSONObject bsonObj, Pair<String, Object> pair) {
		if (!bsonObj.containsField(pair.getFirst())) {
			throw new RuntimeException("field: " + pair.getFirst() + " is not existed in the target BSON");
		}
		changeValue(bsonObj, pair.getFirst(), pair.getSecond());
		
	}
	
	void changeValue(BSONObject bsonObj, String attribute, Object value) {
		JsonSerializationFacade jsonService = getInjector().getInstance(JsonSerializationFacade.class);
		Class valueClass = value.getClass();
		if (valueClass.equals(String.class) || ClassUtils.isPrimitiveOrWrapper(valueClass)) {
			bsonObj.put(attribute, value);
		} else if (Collection.class.isAssignableFrom(valueClass)) {
			BSONObject bson = BSON.decode(jsonService.serializeToByteArray(value));
			bsonObj.put(attribute, getCollectionBson(valueClass, bson));
		} else {
			BSONObject bson = BSON.decode(jsonService.serializeToByteArray(value));
			BasicBSONList list = new BasicBSONList();
			list.add(valueClass.getName());
			list.add(bson);
			bsonObj.put(attribute, list);
		}
	}

	private BasicBSONList getCollectionBson(Class valueClass, BSONObject bson) {
		BasicBSONList bsonList = new BasicBSONList();
		for (String key : bson.keySet()) {
			bsonList.add(bson.get(key));
		}
		BasicBSONList list = new BasicBSONList();
		list.add(valueClass.getName());
		list.add(bsonList);
		return list;
	}

}
