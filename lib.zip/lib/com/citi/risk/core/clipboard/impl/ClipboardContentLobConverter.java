package com.citi.risk.core.clipboard.impl;

import org.bson.BSON;
import org.bson.BSONObject;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.MongoLobConverter;

@SuppressWarnings({"unchecked", "rawtypes"})
public class ClipboardContentLobConverter extends MongoLobConverter<Clipboard> {

	@Override
	public Object convertToEntityAttribute(Clipboard domain,  BSONObject dbData) {
		try {
			String contentClassName = domain.getContentType();
			if(contentClassName.contains("$$EnhancerByCGLIB"))
				contentClassName = contentClassName.substring(0, contentClassName.indexOf("$$EnhancerByCGLIB"));

			Class klass = Class.forName(contentClassName);
			return jsonService.deserializeByByteArray(BSON.encode(dbData), klass);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

}
