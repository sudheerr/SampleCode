package com.citi.risk.core.clipboard.impl;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.bson.BSONObject;
import org.bson.BasicBSONObject;
import org.bson.types.BasicBSONList;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.clipboard.api.ClipboardContentUpdating;
import com.citi.risk.core.lang.collection.Pair;
import com.citi.risk.core.lang.collection.list.Lists;
import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import com.google.inject.Injector;

abstract class AbstractContentUpdating<T> implements ClipboardContentUpdating<T> {

	private String attribute;
	private AbstractContentUpdater updater;
	private Injector injector;
	private Set<Pair<String, T>> pairs;

	AbstractContentUpdating() {
		this.pairs = Sets.newHashSet();
	}

	AbstractContentUpdating(String attribute, AbstractContentUpdater updater, Injector injector) {
		this.attribute = attribute;
		this.injector = injector;
		this.updater = updater;
		this.pairs = Sets.newHashSet();
	}

	void add(Pair<String, T> pair) {
		this.pairs.add(pair);
	}

	void add(AbstractContentUpdating<T> updating) {
		if (updating != null && CollectionUtils.isNotEmpty(updating.getPairs())) {
			this.pairs.addAll(updating.getPairs());
		}
	}
	
	Injector getInjector() {
		return injector;
	}

	void setInjector(Injector injector) {
		this.injector = injector;
	}

	String getAttribute() {
		return attribute;
	}

	Set<Pair<String, T>> getPairs() {
		return Sets.newHashSet(pairs);
	}

	AbstractContentUpdater getUpdater() {
		return updater;
	}
	
	void setUpdater(AbstractContentUpdater updater) {
		this.updater = updater;
	}
	
	@Override
	public ClipboardContentUpdater to(T attribute) {
		throw new RuntimeException("Operation is not supported");
	}
	
	void modify(BSONObject bsonObj) {
		for (Pair<String, T> pair : getPairs()) {
			String _attribute = pair.getFirst();
			String leafAttribute = getLeafAttribute(_attribute);
			for (BSONObject leafBson : getLeafBsons(bsonObj, _attribute)) {
				doModify(leafBson, Pair.<String, T>create(leafAttribute, pair.getSecond()));
			}
		}
		return;
	}
	
	abstract void doModify(BSONObject bsonObj, Pair<String, T> pair);
	
	public static Collection<BSONObject> getLeafBsons(BSONObject bsonObject, String attribute) {
		if (Strings.isNullOrEmpty(attribute)) {
			throw new IllegalArgumentException("input attribute can not be null");
		}
		
		
		List<BSONObject> leafBsons = Lists.newArrayList();
		String[] subStrings = attribute.split("\\.");
		//attribute is already on top level of this bson
		if (subStrings.length == 1) {
			leafBsons.add(bsonObject);
			return leafBsons;
		} 
		
		String topAttribute = subStrings[0];
		String subAttribute = attribute.substring(topAttribute.length()+1);
		Collection<BSONObject> subBsonObjects = getBasicBsonObjects((BSONObject) bsonObject.get(topAttribute));
		
		for (BSONObject subBsonObject : subBsonObjects) {
			leafBsons.addAll(getLeafBsons(subBsonObject, subAttribute));
		}
		
		return leafBsons;
		
	}

	private static Collection<BSONObject> getBasicBsonObjects(BSONObject bsonObject) {
		Collection<BSONObject> basicBSONObjects = Lists.newArrayList();
		if (bsonObject instanceof BasicBSONObject) {
			basicBSONObjects.add(bsonObject);
		} else if (bsonObject instanceof BasicBSONList) {
			for (Object object : (BasicBSONList)bsonObject) {
				if (object instanceof BSONObject){
					basicBSONObjects.addAll(getBasicBsonObjects((BSONObject)object));
				}
			}
		}
		return basicBSONObjects;
		
	}

	public static String getLeafAttribute(String attribute) {
		String[] subStrings = attribute.split("\\.");
		return subStrings[subStrings.length-1] ;
	}

}
