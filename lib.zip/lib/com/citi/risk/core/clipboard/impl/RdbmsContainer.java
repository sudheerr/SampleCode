package com.citi.risk.core.clipboard.impl;


/**
 * Created by ml72548 on 4/30/15.
 */
public class RdbmsContainer {

    private Item[] objects;

    public RdbmsContainer(Item[] objects) {
        this.objects = objects != null ? objects.clone() : null;
    }


    public RdbmsContainer() {
    	//intentionally-blank override
    }

    public Item[] getObjects() {
        return objects;
    }

    public void setObjects(Item[] objects) {
        this.objects = objects != null ? objects.clone() : null;
    }

    public static class Item {
        private byte[] object;
        private String classType;

        public Item() {
        	//intentionally-blank override
        }

        public Item(byte[] object, String classType) {
            this.object = object != null ? object.clone() : null;
            this.classType = classType;
        }


        public byte[] getObject() {
            return object;
        }

        public void setObject(byte[] object) {
            this.object = object != null ? object.clone() : null;
        }

        public String getClassType() {
            return classType;
        }

        public void setClassType(String classType) {
            this.classType = classType;
        }
    }
}
