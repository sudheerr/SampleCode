package com.citi.risk.core.clipboard.impl;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.clipboard.deleter.ClipboardDeleter;
import com.citi.risk.core.clipboard.loader.ClipboardLoader;
import com.citi.risk.core.clipboard.storer.ClipboardStorer;
import com.citi.risk.core.clipboard.updater.ClipboardUpdater;
import com.citi.risk.core.data.service.jpa.Convert;
import com.citi.risk.core.data.store.api.IOSpec;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.PayloadImpl;

@Table(name = "clipboard", schema="clipboard")
@IOSpec(domainClasses = { Clipboard.class }, 
		implSchema = "clipboard", 
		activeLoaderDefault = ClipboardLoader.class, 
		activeStorerDefault = ClipboardStorer.class, 
		activeUpdaterDefault = ClipboardUpdater.class, 
		activeDeleterDefault = ClipboardDeleter.class)
public class ClipboardImpl<P extends IdentifiedBy<?>> extends AbstractClipboardImpl<P> {
	public ClipboardImpl() {
		//intentionally-blank override
	}

    public static <P extends IdentifiedBy<?>> ClipboardImpl<P> newInstance() {
        ClipboardImpl clipboard = new ClipboardImpl();
        clipboard.setClipboardId(UUID.randomUUID().toString());
        return clipboard;
    }

    public static <P extends IdentifiedBy<?>> ClipboardImpl<P> newInstance(String user, Scope scope, Class<P> payloadClass) {
        ClipboardImpl clipboard = new ClipboardImpl();
        clipboard.setClipboardId(UUID.randomUUID().toString());
        clipboard.setUser(user);
        clipboard.setScopeId(scope.getId());
        clipboard.setScopeType(scope.getType());
        clipboard.setAdditionalInfo(scope.getAdditionalInfo());
        if (payloadClass != null) {
        	clipboard.setContentType(payloadClass.getName());
        }
        return clipboard;
    }
	
	@Override
	@Id
	@NotNull
	@Column(name = "_id")
	public String getId() {
		return super.getId();
	}

	@Override
	@Column(name = "clipboardId")
	public String getClipboardId() {
		return super.getClipboardId();
	}

	@Override
	@Column(name = "version")
	public Integer getVersion() {
		return super.getVersion();
	}

	@Override
	@Column(name = "user")
	public String getUser() {
		return super.getUser();
	}

	@Override
	@Column(name = "scope")
	public String getScopeId() {
		return super.getScopeId();
	}

	@Override
	@Column(name = "scopeType")
	public String getScopeType() {
		return super.getScopeType();
	}

	@Override
	@Column(name = "additionalInfo")
	public String getAdditionalInfo() {
		return super.getAdditionalInfo();
	}

	@Override
	@Column(name = "createdTime")
	public Date getCreatedTime() {
		return super.getCreatedTime();
	}

	@Override
	@Column(name = "contentObject")
	@Lob
	@Convert(converter = com.citi.risk.core.clipboard.impl.ClipboardContentLobConverter.class)
	public P getContentObject() {
		return super.getContentObject();
	}

	@Override
	@Column(name = "contentKey")
	public String getContentKey() {
		return super.getContentKey();
	}

	@Override
	@Column(name = "contentVersion")
	public Integer getContentVersion() {
		return super.getContentVersion();
	}

	@Override
	@Column(name = "payloadType")
	public String getContentType() {
		return super.getContentType();
	}

	@Override
	@Column(name = "validFrom")
	public Date getValidFrom() {
		return super.getValidFrom();
	}

	@Override
	@Column(name = "validThru")
	public Date getValidThru() {
		return super.getValidThru();
	}

	@Override
	@Column(name = "Is Expired")
	public Boolean getExpired() {
		return super.getExpired();
	}

	@Override
	@Column(name = "domainInterfaces")
	public String getContentDomainInterfaces() {
		return super.getContentDomainInterfaces();
	}
	

	@Override
	public boolean isPayload() {
		if (this.getContentType() == null) {
			return this.getContentObject() == null;
		} else {
			return StringUtils.equals(this.getContentType(), PayloadImpl.class.getName())
					|| StringUtils.equals(this.getContentType(), Payload.class.getName()); 
		}
	}

}