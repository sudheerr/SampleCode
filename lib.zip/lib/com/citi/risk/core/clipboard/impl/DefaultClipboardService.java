package com.citi.risk.core.clipboard.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.Scope;
import com.citi.risk.core.data.proxy.api.InfraInvocation;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.ParallelSelect;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.payload.api.Payload;
import com.citi.risk.core.payload.impl.PayloadImpl;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.inject.Singleton;

@Singleton
@SuppressWarnings({"rawtypes", "unchecked"})
public class DefaultClipboardService extends AbstractClipboardService{
	
	/************************************* Select Functions  *******************************************************************/
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
        Collection clipboards = dataAccessService.select(clipboardTemplate);
        return filterClipboards(filterExpiredClipboards(clipboards), contentDomainSelect);
    }

	/**
	 * @deprecated will Removed.
	 */
	@InfraInvocation
	@Override
	@Deprecated
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		Collection<Clipboard<P>> clipboards = (Collection<Clipboard<P>>) (Object) dataAccessService.select(
				clipboardIdPath.in(clipboardIds).and(expiredPath.eq(false)), null);
		return filterClipboards(clipboards, contentDomainSelect);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		Collection<Clipboard<P>> clipboards = dataAccessService.select(appendExpiredCriteria(clipboardCriteria
				.and(dataAccessService.newBestAvailableCriteria(dictionary.getDomain(Clipboard.class)))), null);
	     clipboards = filterClipboards(clipboards, contentDomainSelect);
	     return clipboards;
	}
	
	/*************************************SelectForUpdate Functions  *******************************************************************/
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
    	return makeDeepCopy(select(clipboardTemplate, contentDomainSelect));
    }
	
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
       return makeDeepCopy(select(clipboardIds, contentDomainSelect));
    }

	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
    	return makeDeepCopy(select(clipboardCriteria, contentDomainSelect));
    }

    /*************************************Create Functions  *******************************************************************/
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Clipboard<P> create(Clipboard<P> clipboard) {
        return dataAccessService.createOne(clipboard);
    }

	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> create(Collection<Clipboard<P>> clipboards) {
        return dataAccessService.create(clipboards);
    }
	
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Clipboard<P> create(String user, Scope scope, P payloadObject) {
		Clipboard<P> clipboard = (Clipboard<P>) ClipboardImpl.newInstance(user, scope, payloadObject.getClass());
		clipboard.setContent(payloadObject);
		return create(clipboard);
	}

	@InfraInvocation
	@Override
	public Clipboard<Payload> create(String user, Scope scope, Criteria... criterias) {
		Clipboard<Payload> clipboard = ClipboardImpl.newInstance(user, scope, Payload.class);
		PayloadImpl payloadImpl = PayloadImpl.newInstance();
		for (Criteria criteria : criterias) {
			Collection domainObjects = dataAccessService.select(criteria, null);
			payloadImpl.add(domainObjects);
		}
		clipboard.setContent(payloadImpl);
		return create(clipboard);
	}
	
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> Clipboard<Payload> create(String user, Scope scope, Collection<P> contents) {
		Clipboard clipboard = ClipboardImpl.newInstance(user, scope, Payload.class);
		PayloadImpl payload = PayloadImpl.newInstance(clipboard.getClipboardId());
		payload.add(contents);
		clipboard.setContent(payload);
		
		return create(clipboard);
	}
	
	/*************************************Update Functions  *******************************************************************/
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject) {
		Collection<Clipboard<P>> clipboards = (Collection<Clipboard<P>>)(Object) dataAccessService.select(clipboardIdPath.eq(clipboardId).and(expiredPath.eq(false)), null);
		if (clipboards == null || clipboards.isEmpty()){
			return null;
		}

		ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
		executionContext.setAtomic(false);

		Clipboard clipboard = clipboards.iterator().next();
		if (clipboard.getContentClass() != null &&
				!clipboard.getContentClass().isAssignableFrom(payloadObject.getClass())) {
			throw new RuntimeException("new payload type is not same as original payload type");
		}

		clipboard = getCopyClipboard(clipboard);

		setContentToClipboard(payloadObject, clipboard);
		Collection<Clipboard> updatedClipboards = dataAccessService.update(Arrays.asList(clipboard));
		return updatedClipboards.iterator().next();
    }

	@InfraInvocation
    @Override
   	public  Clipboard<Payload> update(String clipboardId, Collection<IdentifiedBy<?>> contents) {
		Collection<Clipboard<Payload>> clipboards = (Collection<Clipboard<Payload>>)(Object) dataAccessService.select(clipboardIdPath.eq(clipboardId).and(expiredPath.eq(false)), null);
		if (clipboards == null || clipboards.isEmpty()){
			return null;
		}

   		ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
   		executionContext.setAtomic(false);

   		Clipboard<Payload> clipboard = clipboards.iterator().next();
   		
   		if (clipboard.getContentClass() != null &&
   				!Payload.class.isAssignableFrom(clipboard.getContentClass())) {
   			throw new RuntimeException("new payload type is must Payload");
   		}
   		
		if (null == contents) {
			return clipboard;
		}

   		Payload payload = clipboard.getContent();

   		clipboard = getCopyClipboard(clipboard);
   		
   		Payload newPayload = PayloadImpl.newInstance();
		for (IdentifiedBy c : contents) {
			newPayload.add(c);
		}
		newPayload.setTimeMark(payload.getTimeMark());
		newPayload.setCreatedBy(payload.getCreatedBy());
		clipboard.setContent(newPayload);
   		
   		Collection<Clipboard<Payload>> updatedClipboards = dataAccessService.update(Arrays.asList(clipboard));
   		Clipboard<Payload> updatedClipboard = updatedClipboards.iterator().next();
   		return updatedClipboard;

   	}

	/**
	 * @deprecated will Removed.
	 */
    @Deprecated
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, boolean atomic) {
    	Collection<Clipboard<Payload>> clipboards = (Collection<Clipboard<Payload>>)(Object) dataAccessService.select(clipboardIdPath.eq(clipboardId).and(expiredPath.eq(false)), null);
		if (clipboards == null || clipboards.isEmpty()){
			return null;
		}

        ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
        executionContext.setAtomic(atomic);

        Clipboard clipboard = clipboards.iterator().next();
        if (clipboard.getContentClass() != null &&
        		!clipboard.getContentClass().isAssignableFrom(payloadObject.getClass())) {
        	throw new RuntimeException("new payload type is not same as original payload type");
        }
        
   		clipboard = getCopyClipboard(clipboard);

        setContentToClipboard(payloadObject, clipboard);
        Collection<Clipboard> updatedClipboards = dataAccessService.update(Arrays.asList(clipboard));
        return updatedClipboards.iterator().next();
    }

	/**
	 * @deprecated will Removed.
	 */
    @Deprecated
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, Integer version) {
    	Collection<Clipboard<Payload>> clipboards = (Collection<Clipboard<Payload>>)(Object)dataAccessService.select(clipboardIdPath.eq(clipboardId).and(expiredPath.eq(false)), null);
    	for (Clipboard<Payload> clipboard : clipboards) {
			if ( clipboard.getVersion() > version ) {
				throw new RuntimeException("Cannot update an old version.");
			}
		}
        return update(clipboardId, payloadObject, false);
    }
    
    
    /*************************************Delete Functions  *******************************************************************/
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect) {
		deleteClipboards(select(clipboardIds, contentDomainSelect), false);
	}

	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect) {
		deleteClipboards(select(clipboardTemplate, contentDomainSelect), false);
	}
	
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect) {
		deleteClipboards(select(clipboardCriteria, contentDomainSelect), false);
	}

	/**
	 * @deprecated will Removed.
	 */
	@Deprecated
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect, boolean atomic) {
		deleteClipboards(select(clipboardIds, contentDomainSelect), atomic);
	}

	/**
	 * @deprecated will Removed.
	 */
	@Deprecated
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect, boolean atomic) {
		deleteClipboards(select(clipboardTemplate, contentDomainSelect), atomic);
	}

	/**
	 * @deprecated will Removed.
	 */
	@Deprecated
	@InfraInvocation
	@Override
	public <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect, boolean atomic) {
		deleteClipboards(select(clipboardCriteria, contentDomainSelect), atomic);
	}
	
	
	/*************************************SelectContent Functions  *******************************************************************/
	@InfraInvocation
    @Override
    public <P extends IdentifiedBy<?>> Collection<P> selectContent(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
        Collection<Clipboard<?>> clipboards = select((Criteria) clipboardCriteria.and(dataAccessService.newBestAvailableCriteria(clipboardCriteria.getDomain())), null);
        Class<P> domainClass = contentDomainSelect.getDomainClass();
        Collection<P> allContent = Lists.<P>newArrayList();

        for (Clipboard<?> clipboard : clipboards) {
            Collection contentInClipboard = getContentInClipboardForContent(domainClass, clipboard);
            allContent.addAll(contentInClipboard);
        }
        if (CollectionUtils.isNotEmpty(allContent)) {
            ParallelSelect parallelSelect = new ParallelSelect(contentDomainSelect, 8, 200000, configuration.getInteger("query.task.timeout", 60));
            return parallelSelect.select(allContent);
        }
        return Collections.emptyList();
    }

	@InfraInvocation
    @Override
	public <P extends IdentifiedBy<?>> Collection<P> selectContentForUpdate(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect) {
		Collection<P> selectContents = selectContent(clipboardCriteria, contentDomainSelect);
		return resolveDeepCopy.lazyDeepCopy(selectContents);
	}
	
	
	/*************************************Revert Functions  *******************************************************************/
	@Override
	@InfraInvocation
    public <P extends IdentifiedBy<?>> Clipboard<P> revertToVersion(Clipboard<P> clipboard, Integer version) {

        Clipboard<P> latestClipboard = getLatestClipboard(clipboard);
        checkVersion(version, clipboard.getVersion(), latestClipboard);

        Clipboard<P> historyClipboard = getHistoryClipboard(clipboard, version);
        Clipboard<P> latestClipboardCopy = getCopyClipboard(latestClipboard);
        setContentToClipboard(historyClipboard.getContent(), latestClipboardCopy);

        ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
        executionContext.setAtomic(false);
        
        Collection<Clipboard<P>> updatedClipboards = dataAccessService.update(Arrays.asList(latestClipboardCopy));
        Clipboard<P> updatedClipboard = Iterables.getFirst(updatedClipboards, null);

        return updatedClipboard;
    }
    
	@Override
	@InfraInvocation
    public <P extends IdentifiedBy<?>> Collection<Clipboard<P>> revertToPrior(Collection<Clipboard<P>> clipboards) {

        Map<String, Clipboard<P>> inputCliboardMap = getInputCliboardmap(clipboards);

        Collection<Clipboard<P>> latestClipboards = select(inputCliboardMap.keySet(), null);
        Map<String, Clipboard<P>> latestClipboardMap = getLatestClipboardMap(latestClipboards);

        checkVersions(inputCliboardMap, latestClipboardMap);

        Multimap<Integer, String> versionToIds = getVersionToIdsMap(latestClipboards);

        List<Clipboard<P>> needUpdatedClipboards = getNeedUpdatedClipboards(versionToIds, latestClipboardMap);
        ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
        executionContext.setAtomic(true);
        Collection<Clipboard<P>> updatedClipboards = dataAccessService.update(needUpdatedClipboards);

        return updatedClipboards;
    }

}
