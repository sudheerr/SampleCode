package com.citi.risk.core.clipboard.impl;

import java.util.Collection;

import org.apache.commons.lang3.ClassUtils;
import org.bson.BSON;
import org.bson.BSONObject;
import org.bson.types.BasicBSONList;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.lang.collection.Pair;
import com.google.inject.Injector;

class AddValueUpdating extends AbstractContentUpdating<Object> {

	AddValueUpdating() {
		super();
	}

	AddValueUpdating(String attribute, AbstractContentUpdater updater, Injector injector) {
		super(attribute, updater, injector);
	}

	@Override
	public ClipboardContentUpdater to(Object attribute) {
		if (attribute == null || attribute instanceof BSONObject) {
			throw new IllegalArgumentException("Input parameter is null");
		}

		add(Pair.create(getAttribute(), attribute));
		getUpdater().add(AddValueUpdating.class, this);

		return getUpdater();
	}

	@Override
	void doModify(BSONObject bsonObj, Pair<String, Object> pair) {
		String attribute = pair.getFirst();
		Object value = pair.getSecond();

		if (bsonObj.containsField(attribute)) {
			throw new RuntimeException("Attribute already exists : " + attribute+ " on bson: " + bsonObj);
		}

		addValue(bsonObj, attribute, value);
		
	}
	
	void addValue(BSONObject bsonObj, String attribute, Object value) {
		JsonSerializationFacade jsonService = getInjector().getInstance(JsonSerializationFacade.class);
		Class valueClass = value.getClass();
		if (valueClass.equals(String.class) || ClassUtils.isPrimitiveOrWrapper(valueClass)) {
			bsonObj.put(attribute, value);
		} else if (Collection.class.isAssignableFrom(valueClass)) {
			BSONObject bson = BSON.decode(jsonService.serializeToByteArray(value));
			BasicBSONList bsonList = new BasicBSONList();
			for (String key : bson.keySet()) {
				bsonList.add(bson.get(key));
			}
			BasicBSONList list = getBsonList(valueClass, bsonList);
			bsonObj.put(attribute, list);
		} else {
			BSONObject bson = BSON.decode(jsonService.serializeToByteArray(value));
			BasicBSONList list = getBsonList(valueClass, bson);
			bsonObj.put(attribute, list);
		}
	}

	private BasicBSONList getBsonList(Class valueClass, BSONObject bson) {
		BasicBSONList list = new BasicBSONList();
		list.add(valueClass.getName());
		list.add(bson);
		return list;
	}
}
