package com.citi.risk.core.clipboard.impl;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.bson.BSON;
import org.bson.BSONObject;
import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.hibernate.jdbc.Work;

import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.AbstractHibernateTxExecutor;
import com.citi.risk.core.io.json.JsonSerializationFacade;
import com.citi.risk.core.lang.collection.Triplet;
import com.google.common.collect.Lists;
import com.google.inject.Injector;

public class BlobUpdater extends AbstractHibernateTxExecutor<RdbmsClipboardImpl, Integer> {

	private static final String CONTENT_TYPE = "CONTENT_TYPE";
	private static final String CONTENT_SERIALISE_OBJECT = "CONTENT_SERIALISE_OBJECT";
	private static final String ID = "ID";
	private static final String PAYLOAD = "com.citi.risk.core.payload.api.Payload";
	private static final String PAYLOADIMPL = "com.citi.risk.core.payload.impl.PayloadImpl";
	private static final String QUERY_SQL = "select ID, CONTENT_TYPE, CONTENT_SERIALISE_OBJECT from COMMON_CORE.CMN_CLIPBOARD";
	private static final String UPDATE_SQL = "update COMMON_CORE.CMN_CLIPBOARD set CONTENT_SERIALISE_OBJECT = ? where ID = ?";

	private Map<Class<? extends AbstractContentUpdating>, AbstractContentUpdating> updatings;
	private List<Triplet<String, String, String>> conditions;
	private int updateCount = 0;

	public BlobUpdater(boolean forUpdate, Injector injector,
			Map<Class<? extends AbstractContentUpdating>, AbstractContentUpdating> updatings,
			List<Triplet<String, String, String>> conditions) {
		super(RdbmsClipboardImpl.class, forUpdate, injector);
		this.updatings = updatings;
		this.conditions = conditions;
	}

	@Override
	protected Integer execute(EntityManager entityManager) {
		if (MapUtils.isEmpty(this.updatings)) {
			return 0;
		}
		org.hibernate.Session hibernateSession = entityManager.unwrap(org.hibernate.Session.class);
		hibernateSession.doWork(new HibernateSessionWork());

		return this.updateCount;
	}
	
	public class HibernateSessionWork implements Work {

		@Override
		public void execute(Connection connection) throws SQLException {

			Statement stmt = null;
			ResultSet resultSet = null;
			PreparedStatement preparedStmt = null;
			try {
				stmt = connection.createStatement();
				resultSet = stmt.executeQuery(prepareQuerySQL());
				preparedStmt = getPreparedStmt(connection, resultSet);
			} finally {
				if (stmt != null) {
					stmt.close();
				}
				if (resultSet != null) {
					resultSet.close();
				}
				if (preparedStmt != null) {
					preparedStmt.close();
				}
			}
		}

		private PreparedStatement getPreparedStmt(Connection connection, ResultSet resultSet) throws SQLException {
			PreparedStatement preparedStmt;
			preparedStmt = connection.prepareStatement(UPDATE_SQL);

			while (resultSet.next()) {
				String id = resultSet.getString(ID);
				String className = resultSet.getString(CONTENT_TYPE);
				Blob blob = resultSet.getBlob(CONTENT_SERIALISE_OBJECT);

				byte[] objectOnByteArray = blob.getBytes(1, (int) blob.length());

				if (className.equals(PAYLOAD) || className.equals(PAYLOADIMPL)) {
					JsonSerializationFacade jsonService = getInjector().getInstance(JsonSerializationFacade.class);
					RdbmsContainer.Item[] entities = jsonService.deserializeByByteArray(objectOnByteArray,
							RdbmsContainer.class).getObjects();
					RdbmsContainer.Item[] newEntities = getNewEntities(entities);
					byte[] updatedByteArr = jsonService.serializeToByteArray(new RdbmsContainer(newEntities));
					addToPrepareStmt(preparedStmt, id, updatedByteArr);

				} else {
					byte[] updatedByteArr = applyChanges(objectOnByteArray);
					addToPrepareStmt(preparedStmt, id, updatedByteArr);
				}
			}
			BlobUpdater.this.updateCount = preparedStmt.executeBatch().length;
			return preparedStmt;
		}

		private RdbmsContainer.Item[] getNewEntities(RdbmsContainer.Item[] entities) {
			RdbmsContainer.Item[] newEntities = new RdbmsContainer.Item[entities.length];
			for (int i = 0; i < entities.length; i++) {
				RdbmsContainer.Item oldItem = entities[i];
				byte[] oldSingleContent = oldItem.getObject();
				byte[] newSingleContent = applyChanges(oldSingleContent);

				RdbmsContainer.Item newItem = new RdbmsContainer.Item(newSingleContent, oldItem
						.getClassType());
				newEntities[i] = newItem;
			}
			return newEntities;
		}

		private String prepareQuerySQL() {
			StringBuilder sb = new StringBuilder(QUERY_SQL);
			List<Triplet<String, String, String>> _conditions = Lists.newArrayList(BlobUpdater.this.conditions);
			if (CollectionUtils.isNotEmpty(_conditions)) {
				sb.append(" where ");
				Iterator<Triplet<String, String, String>> it = _conditions.iterator();
				appendSingleCondition(it.next(), sb);
				if (it.hasNext()) {
					sb.append(" and ");
					appendSingleCondition(it.next(), sb);
				}
			}
			return sb.toString();
		}

		private void appendSingleCondition(Triplet<String, String, String> item, StringBuilder sb) {
			sb.append(item.getFirst()).append(item.getSecond()).append("'").append(item.getThird()).append("'");
		}

		private void addToPrepareStmt(PreparedStatement preparedStmt, String id, byte[] updatedByteArr)
				throws SQLException {
			preparedStmt.setBlob(1, new ByteArrayInputStream(updatedByteArr));
			preparedStmt.setString(2, id);
			preparedStmt.addBatch();
		}

		private byte[] applyChanges(byte[] singleContent) {
			BSONObject bsonObj = BSON.decode(singleContent);
			for (Entry<Class<? extends AbstractContentUpdating>, AbstractContentUpdating> entry : BlobUpdater.this.updatings
					.entrySet()) {
				AbstractContentUpdating updating = entry.getValue();
					updating.modify(bsonObj);
			}
			return BSON.encode(bsonObj);
		}

	}
}