package com.citi.risk.core.clipboard.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.WriteResult;

public class ExpiredClipboardRemover extends AbstractExpiredMongoRemover<Integer> {

	public static final DBObject CLIPBOARD_EXPIRED = new BasicDBObject("Is Expired", true);
	public static final DBObject CLIPBOARD_NON_EXPIRED = new BasicDBObject("Is Expired", false);
	private static final Logger LOGGER = LoggerFactory.getLogger(ExpiredClipboardRemover.class);

	public ExpiredClipboardRemover(Injector injector) {
		super(ClipboardImpl.class, injector);
	}

	@Override
	public Integer execute() {
		DBCollection dbColl = getDBCollection();

		LOGGER.info("All Clipboards Count - Before: {}", dbColl.count());

		int aliveClipboardsCountBefore = dbColl.find(CLIPBOARD_NON_EXPIRED, getResultProjection()).count();
		LOGGER.info("Alive Clipboards Count - Before: {}", aliveClipboardsCountBefore);

		int expiredClipboardsCountBefore = dbColl.find(CLIPBOARD_EXPIRED, getResultProjection()).count();
		LOGGER.info("Expired Clipboards Count - Before: {}", expiredClipboardsCountBefore);

		WriteResult removed = dbColl.remove(CLIPBOARD_EXPIRED);

		LOGGER.info("All Clipboards Count - After: {}", dbColl.count());

		int aliveClipboardsCountAfter = dbColl.find(CLIPBOARD_NON_EXPIRED, getResultProjection()).count();
		LOGGER.info("Alive Clipboards Count - After: {}", aliveClipboardsCountAfter);

		int expiredClipboardsCountAfter = dbColl.find(CLIPBOARD_EXPIRED, getResultProjection()).count();
		LOGGER.info("Expired Clipboards Count - After: {}", expiredClipboardsCountAfter);

		return removed.getN();
	}

}
