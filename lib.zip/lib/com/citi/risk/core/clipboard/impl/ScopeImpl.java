package com.citi.risk.core.clipboard.impl;

import com.citi.risk.core.clipboard.api.Scope;

@SuppressWarnings("serial")
public final class ScopeImpl implements Scope {
	
    private String id;
    private String type;
    private String additionalInfo;

    public ScopeImpl() {
    	//intentionally-blank override
    }

    public ScopeImpl(String id, String type, String additionalInfo) {
        this.id = id;
        this.type = type;
        this.additionalInfo = additionalInfo;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    @Override
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
