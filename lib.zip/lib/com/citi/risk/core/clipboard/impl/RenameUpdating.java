package com.citi.risk.core.clipboard.impl;

import org.bson.BSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.clipboard.api.ClipboardContentUpdater;
import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Strings;
import com.google.inject.Injector;

class RenameUpdating extends AbstractContentUpdating<String> {

	private static final Logger LOGGER = LoggerFactory.getLogger(RenameUpdating.class);

	RenameUpdating() {
		super();
	}

	RenameUpdating(String oldAttribute, AbstractContentUpdater updater, Injector injector) {
		super(oldAttribute, updater, injector);
	}

	@Override
	public ClipboardContentUpdater to(String attribute) {
		if (Strings.isNullOrEmpty(getAttribute()) || Strings.isNullOrEmpty(attribute)) {
			LOGGER.warn("invalid input attributes");
			return getUpdater();
		}

		add(Pair.create(getAttribute(), attribute));
		getUpdater().add(RenameUpdating.class, this);

		return getUpdater();
	}

	@Override
	void doModify(BSONObject bsonObj, Pair<String, String> pair) {
		if (!bsonObj.containsField(pair.getFirst())) {
			throw new RuntimeException("field does not exist : " + pair.getFirst() + " on bson: " + bsonObj);
		}
		if (bsonObj.containsField(pair.getSecond())) {
			throw new RuntimeException("field already exist : " + pair.getSecond() + " on bson: " + bsonObj);
		}
		bsonObj.put(pair.getSecond(), bsonObj.get(pair.getFirst()));
		bsonObj.removeField(pair.getFirst());		
	}

}
