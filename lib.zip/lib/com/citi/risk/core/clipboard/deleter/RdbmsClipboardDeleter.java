package com.citi.risk.core.clipboard.deleter;


import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;

import com.citi.risk.core.clipboard.impl.RdbmsClipboardImpl;
import com.citi.risk.core.data.service.api.AbstractDeleter;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.delete.HibernateDeleteExecutor;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;

@SuppressWarnings({"unchecked", "rawtypes"})
public class RdbmsClipboardDeleter<P extends IdentifiedBy<?>> extends AbstractDeleter {
    @Inject
    private Injector injector;

    @Override
    public <T extends IdentifiedBy<?>> void delete(Collection<T> entities) {
    	if (CollectionUtils.isEmpty(entities)) {
    		return;
    	}

		for (T clipboard : entities) {
			((RdbmsClipboardImpl<P>)clipboard).setExpired(true);
		}

		HibernateDeleteExecutor executor = new HibernateDeleteExecutor(RdbmsClipboardImpl.class, injector);
		executor.delete((Collection<RdbmsClipboardImpl<P>>)entities).isRemove(false).execute();
    }

    @Override
    public <T extends IdentifiedBy<?>> void delete(T selectTemplate) {
        throw new UnsupportedOperationException("Delete by template is not supported for Clipboard");
    }

    @Override
    public void delete(Criteria criteria) {
        throw new UnsupportedOperationException("Delete by criteria is not supported for Clipboard");
    }

    @Override
    public <K, T extends IdentifiedBy<K>> void delete(Class<T> entityClass, Collection<K> identifiers) {
        throw new UnsupportedOperationException("Delete by identifiers is not supported for Clipboard");
    }

}
