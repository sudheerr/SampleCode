package com.citi.risk.core.clipboard.deleter;

import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.LocalDateTime;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.ClipboardImpl;
import com.citi.risk.core.data.service.api.AbstractDeleter;
import com.citi.risk.core.data.service.jpa.Versioner;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.MongoSynchronizeExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.insert.MongoInsert;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.update.MongoUpdate;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
@SuppressWarnings({"unchecked", "rawtypes"})
public class ClipboardDeleter extends AbstractDeleter {
    @Inject
    private Versioner versioner;
    @Inject
    private Injector injector;
    
    private static final DBObject CLIPBOARD_NOT_EXPIRED = new BasicDBObject("Is Expired", false);

    @Override
    public <T extends IdentifiedBy<?>> void delete(Collection<T> entities) {
    	if (CollectionUtils.isEmpty(entities)) {
            return;
        }
    	
    	MongoSynchronizeExecutor mongoSynchronizeExecutor = new MongoSynchronizeExecutor(ClipboardImpl.class, injector);
    	
    	Collection<ClipboardImpl> clipbards = this.checkMongoClipboardImpl(entities);
    	Map<String, Clipboard> clipboardsById = this.getIds(clipbards);
    	Set<String> ids = clipboardsById.keySet();
        
    	final Date now = LocalDateTime.now().toDate();
    	ClipboardImpl template = new ClipboardImpl<>();
    	template.setClipboardId(null);
    	template.setExpired(true);
    	template.setValidThru(now);

    	MongoUpdate<ClipboardImpl> mongoUpdate = new MongoUpdate<>(ClipboardImpl.class, injector);
    	BasicDBObject queryDbObject = new BasicDBObject().append("_id", new BasicDBObject("$in", ids));
    	mongoUpdate.query(queryDbObject).appendQuery(CLIPBOARD_NOT_EXPIRED).setExpectCount(ids.size()).update(template).execute();
    	
    	if (!mongoUpdate.isSuccessed()) {
    		throw new RuntimeException("MongoClipboardDeleter: Failed to delete MongoDB");
    	}
    	
		insertDeletedClipboard(clipbards);
		
		for (Entry<String, Clipboard> clipboardById : clipboardsById.entrySet()) {
			mongoSynchronizeExecutor.synchronizeDelete(clipboardById.getValue(), clipboardById.getKey()).execute();
		}
    }

    private void insertDeletedClipboard(Collection<ClipboardImpl> clipboards) {
		for (ClipboardImpl clipboard : clipboards) {
			versioner.onDelete(clipboard, null);
			clipboard.setId(UUID.randomUUID().toString());
			clipboard.setContentObject(null);
		}
		MongoInsert<ClipboardImpl> MongoClipboardImplInsert =  new MongoInsert<>(ClipboardImpl.class, injector);
        MongoClipboardImplInsert.insert(clipboards).withBatch().execute();
	}
    
	@Override
    public <T extends IdentifiedBy<?>> void delete(T selectTemplate) {
        throw new UnsupportedOperationException("Delete by template is not supported for Clipboard");
    }

    @Override
    public void delete(Criteria criteria) {
        throw new UnsupportedOperationException("Delete by criteria is not supported for Clipboard");
    }

    @Override
    public <K, T extends IdentifiedBy<K>> void delete(Class<T> entityClass, Collection<K> identifiers) {
        throw new UnsupportedOperationException("Delete by identifiers is not supported for Clipboard");
    }
    
    private Map<String, Clipboard> getIds(Collection<ClipboardImpl> clipbards) {
    	Map<String, Clipboard> ids = Maps.newHashMap();
        for (ClipboardImpl clipbard : clipbards) {
            ids.put(clipbard.getId(), clipbard);
        }
        return ids;
    }
    
    private Collection<ClipboardImpl> checkMongoClipboardImpl(Collection entities) {
    	Collection<ClipboardImpl> clipbards = Lists.newArrayList();
        for (Object entity : entities) {
            if (!ClipboardImpl.class.isInstance(entity)) {
                throw new RuntimeException("ClipboardUpdater: can not update a non-clipboard object");
            }
            clipbards.add((ClipboardImpl) entity);
        }
        return clipbards;
    }
    
}
