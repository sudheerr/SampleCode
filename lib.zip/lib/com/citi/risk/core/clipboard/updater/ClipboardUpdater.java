package com.citi.risk.core.clipboard.updater;

import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.LocalDateTime;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.ClipboardImpl;
import com.citi.risk.core.data.service.jpa.Versioner;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.MongoSynchronizeExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.insert.MongoInsert;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.update.MongoUpdate;
import com.citi.risk.core.data.store.impl.AbstractUpdater;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.collection.list.Lists;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.google.inject.Injector;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
@SuppressWarnings({"unchecked", "rawtypes"})
public class ClipboardUpdater extends AbstractUpdater {

	@Inject
    private Injector injector;
	
    @Inject
    private Versioner versioner;
    
    private static final DBObject CLIPBOARD_NOT_EXPIRED = new BasicDBObject("Is Expired", false);

	@Override
	public <T extends IdentifiedBy<?>> Collection<T> update(T selectTemplate, T updateTemplate) {
    	throw new RuntimeException("unsupported action");
	}

	@Override
	public <T extends IdentifiedBy<?>> Collection<T> update(Criteria selectCriteria, T updateTemplate) {
    	throw new RuntimeException("unsupported action");
	}

	@Override
	public <K, T extends IdentifiedBy<K>> Collection<T> update(T updateTemplate, Collection<K> identifiers) {
    	throw new RuntimeException("unsupported action");
	}

	@Override
	public <T extends IdentifiedBy<?>> Collection<T> update(Collection<T> entities) {
    	if (CollectionUtils.isEmpty(entities)) {
            return entities;
        }
    	
    	MongoSynchronizeExecutor mongoSynchronizeExecutor = new MongoSynchronizeExecutor(ClipboardImpl.class, injector);
    	
    	Collection<ClipboardImpl> clipbards = this.checkMongoClipboardImpl(entities);
    	Map<String, Clipboard> clipboardsById = this.getIds(clipbards);
    	Set<String> ids = clipboardsById.keySet();
        
    	final Date now = LocalDateTime.now().toDate();
    	
    	ClipboardImpl template = new ClipboardImpl<>();
    	template.setExpired(true);
    	template.setValidThru(now);

    	MongoUpdate<ClipboardImpl> mongoUpdate = new MongoUpdate(ClipboardImpl.class, injector);
    	BasicDBObject queryDbObject = new BasicDBObject().append("_id", new BasicDBObject("$in", ids));
    	mongoUpdate.query(queryDbObject).appendQuery(CLIPBOARD_NOT_EXPIRED).setExpectCount(ids.size()).update(template).execute();
    	
    	if (!mongoUpdate.isSuccessed()) {
    		throw new RuntimeException("Failed to update MongoDB");
    	}
    	
		insertUpdateClipboardAndContents(clipbards, now);
		
		for (Entry<String, Clipboard> clipboardById : clipboardsById.entrySet()) {
			mongoSynchronizeExecutor.synchronizeUpdate(clipboardById.getValue(), clipboardById.getKey()).execute();
		}
		
		return entities;
    }
    
    private void insertUpdateClipboardAndContents(Collection<ClipboardImpl> entities, Date now) {
    	Collection<ContentImpl> allContents = Lists.newArrayList();
    	for (ClipboardImpl clipboard : entities) {
			versioner.onUpdate(clipboard, null);
			clipboard.setPrimaryKey(UUID.randomUUID().toString());
			allContents.addAll(clipboard.getContents());
        	clipboard.setCreatedTime(now);
		}

    	MongoInsert<ClipboardImpl> MongoClipboardImplInsert =  new MongoInsert(ClipboardImpl.class, injector);
        MongoClipboardImplInsert.insert(entities).withBatch().execute();
        if (!allContents.isEmpty()) {
        	MongoInsert<ContentImpl> contenImplInsert =  new MongoInsert(ContentImpl.class, injector);
        	contenImplInsert.insert(allContents).withBatch().execute();
        }
    }

    private Map<String, Clipboard> getIds(Collection<ClipboardImpl> clipbards) {
    	Map<String, Clipboard> ids = Maps.newHashMap();
        for (ClipboardImpl clipbard : clipbards) {
            ids.put(clipbard.getId(), clipbard);
        }
        return ids;
    }
    
    private Collection<ClipboardImpl> checkMongoClipboardImpl(Collection entities) {
    	Collection<ClipboardImpl> clipbards = Lists.newArrayList();
        for (Object entity : entities) {
            if (!ClipboardImpl.class.isInstance(entity)) {
                throw new RuntimeException("ClipboardUpdater: can not update a non-clipboard object");
            }
            clipbards.add((ClipboardImpl) entity);
        }
        return clipbards;
    }
    
}
