package com.citi.risk.core.clipboard.updater;

/**
 * Created by rg67529 on 8/19/2014.
 */

import java.util.Collection;
import java.util.Collections;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.RdbmsClipboardImpl;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.modify.update.HibernateUpdateExecutor;
import com.citi.risk.core.data.store.impl.AbstractUpdater;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;

@SuppressWarnings({"unchecked", "rawtypes"})
public class RdbmsClipboardUpdater<P extends IdentifiedBy<?>> extends AbstractUpdater {
    public final static Logger LOGGER = LoggerFactory.getLogger(RdbmsClipboardUpdater.class);

    @Inject
    private Injector injector;
    
    @Override
    public <T extends IdentifiedBy<?>> Collection<T> update(Collection<T> entities) {
    	 if (CollectionUtils.isEmpty(entities)) {
         	Collections.emptyList();
         }

         HibernateUpdateExecutor<?, Clipboard<P>, RdbmsClipboardImpl<P>> executor = new HibernateUpdateExecutor(RdbmsClipboardImpl.class, injector);
         executor.update((Collection<RdbmsClipboardImpl<P>>)entities).useProxyHelper(false).execute();
         return entities;
    }

    @Override
    public <T extends IdentifiedBy<?>> Collection<T> update(T selectTemplate, T updateTemplate) {
        throw new UnsupportedOperationException("update by template is not supported by clipboard");
    }

    @Override
    public <T extends IdentifiedBy<?>> Collection<T> update(Criteria selectCriteria, T updateTemplate) {
        throw new UnsupportedOperationException("update by template is not supported by clipboard");
    }

    @Override
    public <K, T extends IdentifiedBy<K>> Collection<T> update(T updateTemplate, Collection<K> identifiers) {
        throw new UnsupportedOperationException("update by template is not supported by clipboard");
    }
}
