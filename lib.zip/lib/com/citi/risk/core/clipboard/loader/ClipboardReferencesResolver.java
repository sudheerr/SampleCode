package com.citi.risk.core.clipboard.loader;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.data.service.impl.DomainImplHelper;
import com.citi.risk.core.data.store.api.Loader;
import com.citi.risk.core.data.store.impl.AbstractLoader;
import com.citi.risk.core.data.store.impl.JpaLoader;
import com.citi.risk.core.execution.api.ExecutionContext;
import com.citi.risk.core.execution.impl.ExecutionContexts;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;
import com.citi.risk.core.lang.stitch.AccumulatingThrowable;
import com.citi.risk.core.payload.api.Content;
import com.citi.risk.core.payload.api.Payload;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.inject.Injector;

public class ClipboardReferencesResolver<P extends IdentifiedBy<?>> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClipboardReferencesResolver.class);
	
    private Injector injector;
    private DomainImplHelper domainImplHelper;
	private TimeMark timeMark;
	private CreatedBy createdBy;
	private Boolean isInTheContextOfCacheLoad;
	private Boolean isInTheContextOfService;

    public ClipboardReferencesResolver(Injector injector,
			DomainImplHelper domainImplHelper, TimeMark timeMark,
			CreatedBy createdBy, Boolean isInTheContextOfCacheLoad,
			Boolean isInTheContextOfService) {
		this.injector = injector;
		this.domainImplHelper = domainImplHelper;
		this.timeMark = timeMark;
		this.createdBy = createdBy;
		this.isInTheContextOfCacheLoad = isInTheContextOfCacheLoad;
		this.isInTheContextOfService = isInTheContextOfService;
	}

	protected void resolveReferences(Collection<? extends Clipboard<P>> items) {
		final AccumulatingThrowable accumulatingThrowable = new AccumulatingThrowable();
		Collection allContents = Lists.newArrayList();
		try {
			collectContentsFromClipboards(items, allContents);
		} catch (AccumulatingThrowable t) {
			accumulatingThrowable.addThrowable(t);
		}

		if (CollectionUtils.isNotEmpty(allContents)) {
			Multimap<Class, IdentifiedBy> contentsByImplClass = groupEntities(allContents);
			for (Class domainImplClass : contentsByImplClass.keySet()) {
				try {
					getLoaderAndResolve(items, domainImplClass, contentsByImplClass.get(domainImplClass));
				} catch (AccumulatingThrowable t) {
					if (CollectionUtils.isNotEmpty(t.getIdentifiables())) {
						accumulatingThrowable.addThrowable(t);
					}
				} catch (Exception e) {
					LOGGER.error("error occurred during resolve clipboard reference for domain : " + domainImplClass.getName(), e);
				}
			}
		}
		
		if(CollectionUtils.isNotEmpty(accumulatingThrowable.getIdentifiables())) {
			throw accumulatingThrowable;
		}
    }

    private <T extends IdentifiedBy<?>> void getLoaderAndResolve(Collection<? extends Clipboard<P>> items, Class implClass, Collection<T> contents) {
    	Class<? extends Loader> loaderClass = domainImplHelper.getActiveLoaderClass(implClass);
    	if(ObjectUtils.equals(loaderClass, JpaLoader.class)) {
    		LOGGER.warn("skip resolve clipboard because activeLoaderDefault() is not specified in @IOSpec in " + implClass.getName());
    		return;
    	}
    	
		CreatedBy createdByClone = createdBy.clone().withLoaderClass(loaderClass);

		final ExecutionContext executionContext = ExecutionContexts.getCurrentExecutionContext();
		final Loader priorLoader = executionContext.getCurrentLoader();
		try {
			AbstractLoader underlyingLoader = (AbstractLoader) injector.getInstance(loaderClass);
			underlyingLoader.setIsInTheContextOfService(isInTheContextOfService);
			underlyingLoader.setIsInTheContextOfCacheLoad(isInTheContextOfCacheLoad);
			underlyingLoader.setCreatedBy(createdByClone);
			underlyingLoader.setTimeMark(timeMark);
			executionContext.setCurrentLoader(underlyingLoader);
			for (T result : contents) {
				result.setTimeMark(timeMark);
				result.setCreatedBy(createdByClone);
			}
			underlyingLoader.resolveClipboardReferences(items, contents);

		} finally {
			executionContext.setCurrentLoader(priorLoader);
		}
	}
    
   	private <T extends IdentifiedBy> Multimap groupEntities(Collection<T> entities) {
		Collection<T> entitiesCopy = Lists.newArrayList(entities);
		Multimap<Class<? extends IdentifiedBy>, T> entitiesByImplClass = ArrayListMultimap.create();

		for (T entity : entitiesCopy) {
			entitiesByImplClass.put(entity.getClass(), entity);
		}

		return entitiesByImplClass;
    }
   	
	private void collectContentsFromClipboards(Collection<? extends Clipboard<P>> clipboards, Collection contents) {
		final AccumulatingThrowable accumulatingThrowable = new AccumulatingThrowable();
		for (Clipboard clipboard : clipboards) {
			try {
				Class contentClass = clipboard.getContentClass();
				if (contentClass != null && Payload.class.isAssignableFrom(contentClass)) {
					extractPayloadContents(contents, clipboard);
				} else {
					extractClipboardContent(contents, clipboard);
				}
			} catch (Exception e) {
				accumulatingThrowable.addThrowable(clipboard, e);
			}
		}

		if (!accumulatingThrowable.getIdentifiables().isEmpty()) {
			throw accumulatingThrowable;
		}

	}

	private void extractClipboardContent(Collection contents, Clipboard clipboard) {
		if (clipboard.getContent() == null
				|| NullTerminator.isCreatedByNullTerminator(clipboard.getContent()))
			throw new RuntimeException("Content deserialization exception");
		contents.add(clipboard.getContent());
	}

	private void extractPayloadContents(Collection contents, Clipboard clipboard) {
		Payload payload = (Payload) clipboard.getContent();
		if (NullTerminator.isCreatedByNullTerminator(payload))
			throw new RuntimeException("Content deserialization exception");
		Collection<Content> currentContents = payload.getContent();
		if (currentContents == null)
			throw new RuntimeException("Content deserialization exception");
		for (Content content : currentContents) {
			if (content == null || NullTerminator.isCreatedByNullTerminator(content))
				throw new RuntimeException("Content deserialization exception");
			contents.add(content.getContentObject());
		}
	}
	

}
