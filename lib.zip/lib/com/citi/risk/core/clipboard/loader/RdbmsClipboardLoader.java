package com.citi.risk.core.clipboard.loader;

/**
 * Created by rg67529 on 8/13/2014.
 */

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.api.ClipboardPath;
import com.citi.risk.core.clipboard.impl.RdbmsClipboardImpl;
import com.citi.risk.core.data.service.impl.DomainImplHelper;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.select.HibernateSelectExecutor;
import com.citi.risk.core.data.store.api.DataStoreType;
import com.citi.risk.core.data.store.api.LoaderSpec;
import com.citi.risk.core.data.store.impl.HistoricalLoadable;
import com.citi.risk.core.data.store.impl.JpaLoader;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;
@SuppressWarnings({"unchecked", "rawtypes"})
@LoaderSpec(domainClass = Clipboard.class, domainImplClass = RdbmsClipboardImpl.class, isIEM = true, dataStoreType = DataStoreType.CACHE)
public class RdbmsClipboardLoader<P extends IdentifiedBy<?>> extends JpaLoader<String, Clipboard<P>, RdbmsClipboardImpl<P>> implements HistoricalLoadable {
    private static final long serialVersionUID = 1L;
    public final static Logger LOGGER = LoggerFactory.getLogger(RdbmsClipboardLoader.class);

    @Inject
    Injector injector;
    @Inject
    private DomainImplHelper domainImplHelper;

    @Override
    public Collection<RdbmsClipboardImpl<P>> buildItems() {
        Criteria clipCriteria = injector.getInstance(ClipboardPath.Expired.class).eq(false);
        clipCriteria.setDomainImplClass(RdbmsClipboardImpl.class);

        HibernateSelectExecutor<String, Clipboard<P>, RdbmsClipboardImpl<P>> selectExecutor = new HibernateSelectExecutor(RdbmsClipboardImpl.class, injector);
        Collection clipboards = (Collection)selectExecutor.select(clipCriteria).execute();

        return clipboards;
    }

    @Override
    public Collection<RdbmsClipboardImpl<P>> buildItems(Criteria clipCriteria) {
        HibernateSelectExecutor<String, Clipboard<P>, RdbmsClipboardImpl<P>> selectExecutor = new HibernateSelectExecutor(RdbmsClipboardImpl.class, injector);
        return (Collection)selectExecutor.select(clipCriteria).execute();
    }

    @Override
    public Collection<RdbmsClipboardImpl<P>> buildItems(Collection<String> identifiers) {
    	HibernateSelectExecutor<String, Clipboard<P>, RdbmsClipboardImpl<P>> selectExecutor = new HibernateSelectExecutor(RdbmsClipboardImpl.class, injector);
    	
    	return selectExecutor.select(identifiers).execute();
    }

    @Override
    protected void resolveReferences(Collection<? extends Clipboard<P>> items) {
    	ClipboardReferencesResolver referenceResolver = new ClipboardReferencesResolver<IdentifiedBy<?>>(injector, domainImplHelper, getTimeMark(), getCreatedBy(), isInTheContextOfCacheLoad(), isInTheContextOfService());
    	referenceResolver.resolveReferences(items);
    }

    @Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
	
}


