package com.citi.risk.core.clipboard.loader;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.ClipboardImpl;
import com.citi.risk.core.data.service.impl.DomainImplHelper;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.select.MongoSelect;
import com.citi.risk.core.data.store.api.DataStoreType;
import com.citi.risk.core.data.store.api.LoaderSpec;
import com.citi.risk.core.data.store.impl.HistoricalLoadable;
import com.citi.risk.core.data.store.impl.MongoLoader;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@SuppressWarnings({"unchecked", "rawtypes"})
@LoaderSpec(domainClass = Clipboard.class, isIEM = true, dataStoreType = DataStoreType.MONGO)
public class ClipboardLoader<P extends IdentifiedBy<?>> extends MongoLoader<String, Clipboard<P>, ClipboardImpl<P>> implements HistoricalLoadable {
    private static final long serialVersionUID = 2690718577149094373L;
    private static final DBObject CLIPBOARD_NOT_EXPIRED = new BasicDBObject("Is Expired", false);
    
    @Inject
    private DomainImplHelper domainImplHelper;

    @Override
    public Collection<ClipboardImpl<P>> buildItems() {
    	MongoSelect<ClipboardImpl> select = new MongoSelect(ClipboardImpl.class, injector);
    	Collection<ClipboardImpl> result = select.select(CLIPBOARD_NOT_EXPIRED).execute();
    	fetchContent(result);
    	return (Collection<ClipboardImpl<P>>)(Object)result;
    }

    @Override
    public Collection<ClipboardImpl<P>> buildItems(Collection<String> identifiers) {
    	MongoSelect<ClipboardImpl> select = new MongoSelect(ClipboardImpl.class, injector);
    	BasicDBObject queryDbObject = new BasicDBObject().append("_id", new BasicDBObject("$in", identifiers));
    	Collection<ClipboardImpl> result = select.select(queryDbObject).execute();
    	fetchContent(result);
    	return (Collection<ClipboardImpl<P>>)(Object)result;
    }

    @Override
    public Collection<ClipboardImpl<P>> buildItems(Criteria criteria) {
    	MongoSelect<ClipboardImpl> select = new MongoSelect(ClipboardImpl.class, injector);
    	Collection<ClipboardImpl> result = select.select(criteria).execute();
    	fetchContent(result);
    	return (Collection<ClipboardImpl<P>>)(Object)result;
    }
    
    private void fetchContent(Collection<ClipboardImpl> clipboards) {
    	Collection<ContentImpl> contents = this.getContents(clipboards);
    	if (contents.isEmpty()) {
    		return;
    	}
    	Map<String, ClipboardImpl> keyMap = new HashMap(clipboards.size());
    	for (ClipboardImpl clipboard : clipboards) {
    		keyMap.put(clipboard.getId(), clipboard);
		}
    	ClipboardImpl temp;
    	for (ContentImpl content : contents) {
    		temp = keyMap.get(content.getParentId());
    		if (temp != null) {
    			temp.getContents().add(content);
    		}
    	}
    }
    
    private Collection<ContentImpl> getContents(Collection<ClipboardImpl> clipboards) {
    	Set<String> contentParentIds = getClipboardIds(clipboards);
    	if (contentParentIds.isEmpty()) {
    		return Collections.emptyList();
    	}
    	MongoSelect<ContentImpl> select = new MongoSelect(ContentImpl.class, injector);
        BasicDBObject query = new BasicDBObject().append("parentId", new BasicDBObject("$in", getClipboardIds(clipboards)));
        return select.select(query).execute();
    }
    
    private Set<String> getClipboardIds(Collection<ClipboardImpl> clipboards) {
    	Set<String> ids = Sets.newHashSet();
    	for(ClipboardImpl clipboard : clipboards) {
    		if (clipboard.isPayload()) {
    			ids.add(clipboard.getId());
    		}
    	}
    	return ids;
    }
    
    @Override
    protected void resolveReferences(Collection<? extends Clipboard<P>> items) {
    	ClipboardReferencesResolver referenceResolver = new ClipboardReferencesResolver<IdentifiedBy<?>>(injector, domainImplHelper, getTimeMark(), getCreatedBy(), isInTheContextOfCacheLoad(), isInTheContextOfService());
    	referenceResolver.resolveReferences(items);
    }
    
    @Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}


