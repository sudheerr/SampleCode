package com.citi.risk.core.clipboard.api;

import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.impl.DefaultDataPath;
import com.google.common.base.Function;
import com.google.inject.Inject;
import java.util.Date;
import javax.annotation.Generated;
import javax.annotation.Nullable;

@Generated(
	value="com.citi.risk.core.dictionary.ui.handlers.PathCodeGen",
	date="2015-06-04T15:19:008+0800",
	comments="@see com.citi.risk.core.clipboard.api.Clipboard"
)
public final class ClipboardPath {
	private ClipboardPath() {}

	public static final class Id extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public Id(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("_id"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getId();
		}
	}

	public static final class ClipboardId extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ClipboardId(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("clipboardId"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getClipboardId();
		}
	}

	public static final class User extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public User(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("user"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getUser();
		}
	}

	public static final class ScopeId extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ScopeId(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("scope"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getScopeId();
		}
	}

	public static final class ScopeType extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ScopeType(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("scopeType"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getScopeType();
		}
	}

	public static final class AdditionalInfo extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public AdditionalInfo(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("additionalInfo"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getAdditionalInfo();
		}
	}

	public static final class CreatedTime extends DefaultDataPath<Clipboard, Date> implements Function<Clipboard, Date> {
		@Inject
		public CreatedTime(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("createdTime"));
		}

		@Nullable
		@Override
		public Date apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getCreatedTime();
		}
	}

	public static final class ContentType extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ContentType(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("content Type"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getContentType();
		}
	}

	public static final class ContentDomainInterfaces extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ContentDomainInterfaces(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("content domain interfaces"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getContentDomainInterfaces();
		}
	}

	public static final class ContentKey extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public ContentKey(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("content key"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getContentKey();
		}
	}

	public static final class ContentVersion extends DefaultDataPath<Clipboard, Integer> implements Function<Clipboard, Integer> {
		@Inject
		public ContentVersion(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("content version"));
		}

		@Nullable
		@Override
		public Integer apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getContentVersion();
		}
	}

	public static final class Expired extends DefaultDataPath<Clipboard, Boolean> implements Function<Clipboard, Boolean> {
		@Inject
		public Expired(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("Is Expired"));
		}

		@Nullable
		@Override
		public Boolean apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getExpired();
		}
	}

	public static final class TimeMark extends DefaultDataPath<Clipboard, com.citi.risk.core.lang.businessobject.TimeMark> 
						implements Function<Clipboard, com.citi.risk.core.lang.businessobject.TimeMark> {
		@Inject
		public TimeMark(Dictionary dictionary) {
			super(dictionary.getDomain(Clipboard.class).getRelationship("Time mark"));
		}

		@Nullable
		@Override
		public com.citi.risk.core.lang.businessobject.TimeMark apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getTimeMark();
		}
	}

	public static final class CreatedBy extends DefaultDataPath<Clipboard, com.citi.risk.core.lang.businessobject.CreatedBy> 
						implements Function<Clipboard, com.citi.risk.core.lang.businessobject.CreatedBy> {
		@Inject
		public CreatedBy(Dictionary dictionary) {
			super(dictionary.getDomain(Clipboard.class).getRelationship("Created by"));
		}

		@Nullable
		@Override
		public com.citi.risk.core.lang.businessobject.CreatedBy apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getCreatedBy();
		}
	}

	public static final class Version extends DefaultDataPath<Clipboard, Integer> implements Function<Clipboard, Integer> {
		@Inject
		public Version(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("version"));
		}

		@Nullable
		@Override
		public Integer apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getVersion();
		}
	}

	public static final class ValidFrom extends DefaultDataPath<Clipboard, Date> implements Function<Clipboard, Date> {
		@Inject
		public ValidFrom(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("Valid From"));
		}

		@Nullable
		@Override
		public Date apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getValidFrom();
		}
	}

	public static final class ValidThru extends DefaultDataPath<Clipboard, Date> implements Function<Clipboard, Date> {
		@Inject
		public ValidThru(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("Valid Thru"));
		}

		@Nullable
		@Override
		public Date apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getValidThru();
		}
	}

	public static final class Identifier extends DefaultDataPath<Clipboard, String> implements Function<Clipboard, String> {
		@Inject
		public Identifier(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(Clipboard.class).getItem("Identifier"));
		}

		@Nullable
		@Override
		public String apply(@Nullable Clipboard input) {
			return (input == null) ? null : input.getIdentifier();
		}
	}

}