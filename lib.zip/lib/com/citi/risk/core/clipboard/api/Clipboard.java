package com.citi.risk.core.clipboard.api;

import java.util.Collection;
import java.util.Date;

import com.citi.risk.core.data.service.api.Versionable;
import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.ManagedVersion;
import com.citi.risk.core.security.api.EnforcementMode;
import com.citi.risk.core.security.api.SecureDomain;
import com.citi.risk.core.security.api.SecurityProvider;
import com.citi.risk.core.security.api.SecurityRealm;

@DDD(name = "Clipboard")
@SecureDomain(name = "Clipboard", securityProvider = SecurityProvider.CRAC, enforcementMode = EnforcementMode.LENIENT, 
			securityRealms = SecurityRealm.WHOLESALE_CREDIT)
public interface Clipboard<P extends IdentifiedBy<?>> extends IdentifiedBy<String>, Versionable, ManagedVersion<String> {

    @DDI(name = "_id")
    public String getId();

    public void setId(String id);

    @DDI(name = "clipboardId")
    public String getClipboardId();

    public void setClipboardId(String clipboardId);

    @DDI(name = "user")
    public String getUser();

    public void setUser(String user);

    @DDI(name = "scope")
    public String getScopeId();

    public void setScopeId(String scope);

    @DDI(name = "scopeType")
    public String getScopeType();

    public void setScopeType(String scopeType);

    @DDI(name = "additionalInfo")
    public String getAdditionalInfo();

    public void setAdditionalInfo(String additionalInfo);

    @DDI(name = "createdTime")
    public Date getCreatedTime();

    public void setCreatedTime(Date createdTime);

    public Class<P> getContentClass();

    @DDI(name = "content Type")
    public String getContentType();

    public P getContent();

    public void setContent(P content);

    @DDI(name = "content domain interfaces")
    public String getContentDomainInterfaces();

    @DDI(name = "content key")
    public String getContentKey();

    @DDI(name = "content version")
    public Integer getContentVersion();

    public Scope getScope();

    public void setScope(Scope scope);

    @Override
    @DDI(name = "Is Expired")
    public Boolean getExpired();

    @Override
    public void setExpired(Boolean expired);
    
    public boolean isPayload();
    
    public Collection getContentsByDomainImpl(Class implClass);

}
