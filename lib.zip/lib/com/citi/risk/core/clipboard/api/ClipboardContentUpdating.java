package com.citi.risk.core.clipboard.api;

public interface ClipboardContentUpdating<T> {

	ClipboardContentUpdater to(T attribute);
}