package com.citi.risk.core.clipboard.api;

import java.util.Collection;

import com.citi.risk.core.data.service.jpa.executor.api.TxExecutor;

public interface ClipboardContentUpdater extends TxExecutor<Integer> {

	/**
	 * Rename an attribute name to another. E.g. rename 'name' to 'newName'. This is the generic API for both JSON and
	 * RDBMS and it only operates on content of a clipboard.<br/>
	 * 
	 * @param attribute
	 *            This attribute supports hierarchy representing an attribute of an Object. E.g. if attribute is
	 *            a.b.key, key under b will be renamed. The new assigned name should be in the same level with original
	 *            name respectively. E.g. a.b.newKey
	 * @return
	 */
	ClipboardContentUpdating<String> rename(String attribute);

	/**
	 * Remove an attribute from object.
	 * 
	 * @param attribute
	 *            This attribute supports hierarchy representing an attribute of an Object. E.g. if attribute is
	 *            a.b.key, key under b will be removed.
	 * @return
	 */
	ClipboardContentUpdater remove(String attribute);

	/**
	 * Add a key-value pair to an existing Clipboard content.
	 * 
	 * @param attribute
	 * @return
	 */
	<T> ClipboardContentUpdating<T> add(String attribute);
	
	/**
	 * change value of the field, E.g. change 'name' to 'John'.This is the generic API for both JSON and
	 * RDBMS and it only operates on content of a clipboard.<br/>
	 * 
	 * @param attribute field name
	 * @return
	 */
	<T> ClipboardContentUpdating<T> change(String attribute);
	
	/**
	 * Where clause for an update. This attribute only takes effect on Clipboard domain itself. E.g. CLIPBOARD_ID.
	 * 
	 * @param attribute
	 * @return
	 */
	ClipboardContentQuery where(String attribute);
	
	/**
	 * Only support mongo clipboard.
	 * Get attribute's value from the clipboard content
	 * E.g.
	 * jsonUpdater.get("address.city", "_id", content.getId());
	 * returns "Shanghai"
	 * @see JsonUpdaterTest.testGet();
	 * 
	 * @param attribute: attribut full name
	 * @param where clipboard condition
	 * @param eqValue clipboard condition
	 * @return attribut value
	 */
	Collection<Object> get(String attribute, String where, String eqValue);
}
