package com.citi.risk.core.clipboard.api;

import java.util.Collection;

import com.citi.risk.core.data.service.transaction.api.Transactional;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.lang.annotation.Service;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;
import com.citi.risk.core.payload.api.Payload;
@SuppressWarnings("rawtypes")
@Service(about = Clipboard.class)
@Transactional(value=Transactional.TxType.REQUIRED)
public interface ClipboardService{
	/******************************* Create Methods *************************************/
	
	/**
	 * Create one clipboard
	 * if it's ClipboardImpl, created in mongo, if it's RdbmsClipboardImpl, created in RDBMS
	 * @param clipboard to be created
	 * @return Clipboard created
	 */
	<P extends IdentifiedBy<?>> Clipboard<P> create(Clipboard<P> clipboard);  
	
	/**
	 * Create bulk of clipboards
	 * if it's ClipboardImpl, created in mongo, if it's RdbmsClipboardImpl, created in RDBMS
	 * @param clipboards to be created
	 * @return Collection<Clipboard> created
	 */
	<P extends IdentifiedBy<?>> Collection<Clipboard<P>> create(Collection<Clipboard<P>> clipboards);
	
	<P extends IdentifiedBy<?>> Clipboard<Payload> create(String user, Scope scope, Collection<P> contents) ;
	
	<P extends IdentifiedBy<?>> Clipboard<P> create(String user, Scope scope, P payloadObject); 
	
	Clipboard<Payload> create(String user, Scope scope, Criteria... criterias);
	
	
	/******************************* Select Methods *************************************/
	/**
	 * @param	clipboardIds select clipboard with identifiers
	 * @param	contentDomainSelect	filter clipboards with contentDomainSelect
	 * @return: Collection<Clipboard<P>>
	 * */
	<P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Collection<String> clipboardIds, Select<P> contentDomainSelect); 

	/**
	 * @param	clipboardTemplate
	 * @param	contentDomainSelect	filter clipboards with contentDomainSelect
	 * @return: Collection<Clipboard<P>>
	 * */
	<P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect); 

    <P extends IdentifiedBy<?>> Collection<Clipboard<P>> select(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect); 
    
    <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Collection<String> clipboardIds, Select<P> contentDomainSelect); 
   
    <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect); 
	
    <P extends IdentifiedBy<?>> Collection<Clipboard<P>> selectForUpdate(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect); 
    
    /**
	 * @param	clipboardId	select clipboard with identifier
	 * @param	payloadObject update selected clipboard with payloadObject
	 * @return: Clipboard<P>
	 * */
	<P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject);

	/**
	 * @deprecated will Removed. Not support this logic to change the clipboard's version to a certain value. clipboard is ManagedVersion.
	 * @param	clipboardId	select clipboard with identifier
	 * @param	payloadObject update selected clipboard with payloadObject
	 * @param	version
	 * @return: Clipboard<P>
	 * @throws 	version is older than current record version
	 */
	@Deprecated
    <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, Integer version);
    
	/**
	 * @deprecated will Removed. atomic is default false.
	 * @param	clipboardId	select clipboard with identifier
	 * @param	payloadObject update selected clipboard with payloadObject
	 * @param	atomic 
	 * @return: Clipboard<P>
	 */
	@Deprecated
    <P extends IdentifiedBy<?>> Clipboard<P> update(String clipboardId, P payloadObject, boolean atomic);
    
	/**
	 * @param	clipboardId	select clipboard with identifier
	 * @param	contents update the contents of selected clipboard to contents.
	 * @return: Clipboard<Payload>
	 * @throws	selected clipboard not be Payload type.
	 * */
    Clipboard<Payload> update(String clipboardId, Collection<IdentifiedBy<?>> contents);

    /**
     * Support delete from Mongo and Rdbms at the same time
	 * @param	clipboardIds select clipboard with identifiers
	 * @param	contentDomainSelect	filter clipboards with contentDomainSelect
	 * */
    <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect);

    <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect);

    <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect);

	/**
	 * @deprecated will Removed. atomic is default false.
	 */
    @Deprecated
    <P extends IdentifiedBy<?>> void delete(Collection<String> clipboardIds, Select<P> contentDomainSelect, boolean atomic);

	/**
	 * @deprecated will Removed. atomic is default false.
	 */
    @Deprecated
    <P extends IdentifiedBy<?>> void delete(Clipboard<P> clipboardTemplate, Select<P> contentDomainSelect, boolean atomic);

	/**
	 * @deprecated will Removed. atomic is default false.
	 */
    @Deprecated
    <P extends IdentifiedBy<?>> void delete(Criteria<Clipboard<P>> clipboardCriteria, Select<P> contentDomainSelect, boolean atomic);
    
    /**
   	 * @param	clipboardCriteria select clipboard with criteria
   	 * @param	contentDomainSelect	filter clipboards with contentDomainSelect
   	 * @return	all contents of selected clipboards
   	 * */
    <P extends IdentifiedBy<?>> Collection<P> selectContent(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect);
    
    /**
   	 * @param	clipboardCriteria select clipboard with criteria
   	 * @param	contentDomainSelect filter clipboards with contentDomainSelect
   	 * @return	makeDeepCopy for all contents of selected clipboards
   	 * */
    <P extends IdentifiedBy<?>> Collection<P> selectContentForUpdate(Criteria<Clipboard<?>> clipboardCriteria, Select<P> contentDomainSelect);
    
    /**
   	 * @param	clipboard
   	 * @param	version	revert the clipboard to the version 
   	 * @return	Clipboard returned clipboard's contents will be the same as clipboard with version and the version will be incremented 
   	 * @throws	clipboard's version is not the latest
   	 * @throws	version is smaller than 0 or bigger than the latest version
   	 * */
    <P extends IdentifiedBy<?>> Clipboard<P> revertToVersion(Clipboard<P> clipboard, Integer version);
    
	/**
	 * @deprecated will Removed.
	 * @param	clipboards need reverted
	 * @return	Clipboard returned clipboard's contents will be the same as Last version and the version will be incremented 
	 * @throws	Can't find the clipboards with the id of Input clipboards
	 * @throws	version is smaller than 0 or bigger than the latest version
	 */
    @Deprecated
    <P extends IdentifiedBy<?>> Collection<Clipboard<P>> revertToPrior(Collection<Clipboard<P>> clipboards);

}
