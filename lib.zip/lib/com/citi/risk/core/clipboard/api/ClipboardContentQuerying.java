package com.citi.risk.core.clipboard.api;

public interface ClipboardContentQuerying {

	ClipboardContentQuery and(String attribute);

	Integer execute();
}