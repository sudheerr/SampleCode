package com.citi.risk.core.clipboard.api;

import org.bson.types.ObjectId;


public interface ClipboardContentQuery {
	
	ClipboardContentQuerying eq(String value);
	
	ClipboardContentQuerying eq(ObjectId value);
}