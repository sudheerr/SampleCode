package com.citi.risk.core.clipboard.api;

import java.io.Serializable;

public interface Scope extends Serializable {
	
    String getId();

    void setId(String id);

    String getType();

    void setType(String type);

    String getAdditionalInfo();

    void setAdditionalInfo(String additionalInfo);
    
}
