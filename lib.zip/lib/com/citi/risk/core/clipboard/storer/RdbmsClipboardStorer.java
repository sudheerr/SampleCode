package com.citi.risk.core.clipboard.storer;

/**
 * Created by rg67529 on 8/12/2014.
 */

import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import org.springframework.util.CollectionUtils;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.RdbmsClipboardImpl;
import com.citi.risk.core.data.service.jpa.executor.impl.hibernate.insert.HibernateInsertExecutor;
import com.citi.risk.core.data.store.api.StorerSpecification;
import com.citi.risk.core.data.store.cache.impl.AbstractStorer;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.google.inject.Inject;
import com.google.inject.Injector;

@SuppressWarnings({"unchecked", "rawtypes"})
@StorerSpecification
public class  RdbmsClipboardStorer<P extends IdentifiedBy<?>> extends AbstractStorer<String, Clipboard<P>, RdbmsClipboardImpl<P>> {
    private static final long serialVersionUID = 1L;

    @Inject
    private Injector injector;

    @Override
    public Collection<RdbmsClipboardImpl<P>> storeItemsWithReturns(Collection<RdbmsClipboardImpl<P>> clipboards) {
		if (!CollectionUtils.isEmpty(clipboards)) {
			for (RdbmsClipboardImpl<P> rdbmsClipboardImpl : clipboards) {
				rdbmsClipboardImpl.setCreatedTime(new Date());
			}
			
			HibernateInsertExecutor<String, Clipboard<P>, RdbmsClipboardImpl<P>> executor = new HibernateInsertExecutor(RdbmsClipboardImpl.class, injector);
			return (Collection<RdbmsClipboardImpl<P>>) executor.insert(clipboards).execute();
		}
		return Collections.emptyList();
    }

    @Override
    public void storeItems(Collection<RdbmsClipboardImpl<P>> toStoreItems) {
    	storeItemsWithReturns(toStoreItems);
    }
    
    @Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}




