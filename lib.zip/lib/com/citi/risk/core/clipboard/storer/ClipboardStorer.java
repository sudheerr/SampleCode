package com.citi.risk.core.clipboard.storer;

import java.util.Collection;
import java.util.Date;
import java.util.UUID;

import com.citi.risk.core.clipboard.api.Clipboard;
import com.citi.risk.core.clipboard.impl.ClipboardImpl;
import com.citi.risk.core.data.service.jpa.Versioner;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.MongoSynchronizeExecutor;
import com.citi.risk.core.data.service.jpa.executor.impl.mongo.insert.MongoInsert;
import com.citi.risk.core.data.store.api.StorerSpecification;
import com.citi.risk.core.data.store.cache.impl.AbstractStorer;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.payload.impl.ContentImpl;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Injector;
@SuppressWarnings({"unchecked", "rawtypes"})
@StorerSpecification
public class ClipboardStorer<P extends IdentifiedBy<?>> extends AbstractStorer<String, Clipboard<P>, ClipboardImpl<P>> {
	
    private static final long serialVersionUID = 6823695906776476245L;
    @Inject
    private Injector injector;

    @Inject
    private Versioner versioner;

    @Override
    public void storeItems(Collection<ClipboardImpl<P>> toStoreItems) {
    	this.storeItemsWithReturns(toStoreItems);
    }

    @Override
    public Collection<ClipboardImpl<P>> storeItemsWithReturns(Collection<ClipboardImpl<P>> toStoreItems) {
        if (toStoreItems == null || toStoreItems.isEmpty()) {
            return toStoreItems;
        }
        MongoSynchronizeExecutor mongoSynchronizeExecutor = new MongoSynchronizeExecutor(ClipboardImpl.class, injector);
        prepareClipboardId(toStoreItems);
        Collection<ContentImpl> contents = this.getContext(toStoreItems);

        MongoInsert<ClipboardImpl> mongoClipboardImplInsert =  new MongoInsert(ClipboardImpl.class, injector);
        mongoClipboardImplInsert.insert((Collection<ClipboardImpl>)(Object)toStoreItems).withBatch().execute();
        if (!contents.isEmpty()) {
        	MongoInsert<ContentImpl> contenImplInsert =  new MongoInsert(ContentImpl.class, injector);
        	contenImplInsert.insert(contents).withBatch().execute();
        }
        mongoSynchronizeExecutor.synchronizeInsert(toStoreItems).execute();
        return toStoreItems;
    }
    
    private Collection<ContentImpl> getContext(Collection<ClipboardImpl<P>> clipboards) {
		Collection<ContentImpl> contents = Lists.newArrayList();
		for (ClipboardImpl clipboard : clipboards) {
			contents.addAll(clipboard.getContents());
		}
		return contents;
    }

    private void prepareClipboardId(Collection<ClipboardImpl<P>> clipboards) {
    	Date createTime = new Date();
        for (ClipboardImpl<P> clipboard : clipboards) {
            versioner.onCreate(clipboard);
            clipboard.setPrimaryKey(UUID.randomUUID().toString());
            if (clipboard.getCreatedTime() == null) {
            	clipboard.setCreatedTime(createTime);
            }
        }
    }
    
    @Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

}
