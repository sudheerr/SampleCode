package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.URLPropertiesConfiguration;
import org.apache.commons.configuration.event.ConfigurationEvent;
import org.apache.commons.configuration.event.ConfigurationListener;

/**
 * Created by lw84456 on 3/22/2016.
 */
public class ResolvedValueURLConfigurationListener implements ConfigurationListener {
    private String resolvedValueURL = null;

    @Override
    public void configurationChanged(ConfigurationEvent configurationEvent) {
        if (!configurationEvent.isBeforeUpdate() /*&& configurationEvent.getType() == 3*/) {
            ((URLPropertiesConfiguration) configurationEvent.getSource()).getValueURLPropertiesConfiguration().setProperty(
                    configurationEvent.getPropertyName(), resolvedValueURL);
        }
    }

    public void setResolvedValueURL(String resolvedValueURL) {
        this.resolvedValueURL = resolvedValueURL;
    }
}