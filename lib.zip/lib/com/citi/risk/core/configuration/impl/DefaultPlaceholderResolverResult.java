package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.PlaceholderResolverResult;

public class DefaultPlaceholderResolverResult implements PlaceholderResolverResult {
	
	private final String placeholderName;
	private String resolvedValue;
	private String resolvedValueFrom;

	public DefaultPlaceholderResolverResult(String placeholderName) {
		this.placeholderName = placeholderName;
	}

	@Override
	public String getPlaceholderName() {
		return placeholderName;
	}

	@Override
	public void setResolvedValue(String resolvedValue) {
		this.resolvedValue = resolvedValue;
	}

	@Override
	public String getResolvedValue() {
		return resolvedValue;
	}

	@Override
	public void setResolvedValueFrom(String resolvedValueFrom) {
		this.resolvedValueFrom = resolvedValueFrom;
	}

	@Override
	public String getResolvedValueFrom() {
		return resolvedValueFrom;
	}

}
