package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.Environment;
import com.citi.risk.core.configuration.api.URLPropertiesConfiguration;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.ioc.impl.guice.CorePropertiesReader;
import com.google.common.base.Joiner;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

/**
 * for a none place holder property, here enable optional overrides with values defined in overrides.properties.
 * when an optional property defined in overrides property, it will only replace the existing property against current env.
 *
 */
public class OptionalPropertyResolver {
	private static final Logger LOGGER = LoggerFactory.getLogger(OptionalPropertyResolver.class);
	private static final Environment ENVIROMENT = CoreModule.getEnvironment();
	private static final String LIFECYCLE = ENVIROMENT.getLifeCycle().getName();
	private static final String CLUSTER = ENVIROMENT.getCluster().getName();
	private static final String INSTANCE = ENVIROMENT.getInstance();
	
	private static final String ENV_INFO = Joiner.on(CorePropertiesReader.SEPARATOR_HASH).join(LIFECYCLE, CLUSTER, INSTANCE);
	
	private Set<URLPropertiesConfiguration> propSets;
	private Map<String, Properties> propMap;
	private Set<String> allPlaceHolderNames;
	
	public OptionalPropertyResolver(Map<String, Properties> propMap, Set<URLPropertiesConfiguration> propSets, Set<String> allPlaceHolderNames) {
		this.propMap = propMap;
		this.propSets = propSets;
		this.allPlaceHolderNames = allPlaceHolderNames;
	}

	public void resolve() {
		if (CollectionUtils.isNotEmpty(propSets)) {
			for (PropertiesConfiguration propConfig : propSets) {
				Iterator<String> iterator = propConfig.getKeys();
				while (iterator.hasNext()) {
					String currentProptyNameWithEnv = iterator.next();
					String keyName = stripPropertEnvInfo(currentProptyNameWithEnv);
					
					resolveNonPlaceHolderValue(propConfig, currentProptyNameWithEnv, keyName);
				}
			}
		}
	}

	private void resolveNonPlaceHolderValue(PropertiesConfiguration propConfig, String currentProptyNameWithEnv,
			String keyName) {
		if (isNotPlaceHolder(keyName)) {
			// not a place holder
			resolveOverridesProp(propConfig, currentProptyNameWithEnv, keyName);
		}
	}

	private void resolveOverridesProp(PropertiesConfiguration propConfig, String currentProptyNameWithEnv,
			String keyName) {
		Set<Entry<String, Properties>> overridesPropSet = propMap.entrySet();
		for (Entry<String, Properties> overridesPropEntry : overridesPropSet) {
			Properties overridesProp = overridesPropEntry.getValue();
			if (overridesProp.containsKey(keyName)) {
				// currently defined in overrides properties
				
				String propNameWithEnv = getTargetPropEntryByEnv(propConfig, keyName);
				
				if (StringUtils.equals(propNameWithEnv, currentProptyNameWithEnv)) {
					// need to replace with overrides value
					String overrideValue = overridesProp.getProperty(keyName);
					LOGGER.debug("optional overrides " + propNameWithEnv + " = " + overrideValue + "from " + overridesPropEntry.getKey() + " for envInfo " + ENV_INFO);

					ResolvedValueURLConfigurationListener resolvedValueURLConfigurationListener = new ResolvedValueURLConfigurationListener();
					resolvedValueURLConfigurationListener.setResolvedValueURL(overridesPropEntry.getKey());
					propConfig.addConfigurationListener(resolvedValueURLConfigurationListener);

					propConfig.setProperty(currentProptyNameWithEnv
							, StringUtils.equals(overrideValue, CorePropertiesReader.NULL_STRING_TOKEN) ? null : overrideValue);

					propConfig.clearConfigurationListeners();
					break;
				}
			}
		}
	}
	
	private boolean isNotPlaceHolder(String keyName) {
		if (CollectionUtils.isNotEmpty(allPlaceHolderNames)) {
			return !allPlaceHolderNames.contains(keyName); 
		} else {
			return true;
		}
		
	}

	/**
	 * for current key, the join key with env.
	 * 
	 * @param propConfig
	 * @param keyName
	 * @return
	 */
	private String getTargetPropEntryByEnv(PropertiesConfiguration propConfig, String keyName) {
		String lifeCycle = LIFECYCLE;
		String cluster = CLUSTER;
		String instance = INSTANCE;
		
		String joinKey = Joiner.on(CorePropertiesReader.DOT).useForNull(CorePropertiesReader.STAR).join(lifeCycle, cluster, instance, keyName);
		boolean contains = propConfig.containsKey(joinKey);
		if (!contains) {
			instance = null;
			joinKey = Joiner.on(CorePropertiesReader.DOT).useForNull(CorePropertiesReader.STAR).join(lifeCycle, cluster, instance, keyName);
			contains = propConfig.containsKey(joinKey);
		}
		if (!contains) {
			cluster = null;
			joinKey = Joiner.on(CorePropertiesReader.DOT).useForNull(CorePropertiesReader.STAR).join(lifeCycle, cluster, instance, keyName);
			contains = propConfig.containsKey(joinKey);
		}
		if (!contains) {
			lifeCycle = null;
			joinKey = Joiner.on(CorePropertiesReader.DOT).useForNull(CorePropertiesReader.STAR).join(lifeCycle, cluster, instance, keyName);
		}
		
		return joinKey;
	}

	/**
	 * e.g. for DEV.PRIMARY.*.reference-iem.JDBC.schema will return reference-iem.JDBC.schema
	 * 
	 * @param key
	 * @return
	 */
	private String stripPropertEnvInfo(String key) {
		int firstDot = key.indexOf(CorePropertiesReader.DOT);
		int secondDot = key.indexOf(CorePropertiesReader.DOT, firstDot + 1);
		int thirdDot = key.indexOf(CorePropertiesReader.DOT, secondDot + 1);
		
		return key.substring(thirdDot + 1);
	}
	
	
}
