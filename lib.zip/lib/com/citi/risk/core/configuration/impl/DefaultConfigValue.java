package com.citi.risk.core.configuration.impl;

import org.apache.commons.lang3.ArrayUtils;

import com.citi.risk.core.configuration.api.ConfigValue;
import com.citi.risk.core.lang.businessobject.NullTerminator;

public class DefaultConfigValue implements ConfigValue {

	private static final long serialVersionUID = -3268919318809327790L;

	private String[] values;
	
	public DefaultConfigValue() {
		super();
	}
	
	public DefaultConfigValue(String[] values) {
		this();
		this.values = ArrayUtils.clone(values);
	}

	@Override
	public Boolean isMulti() {
		return ArrayUtils.getLength(values) > 1;
	}

	@Override
	public String value() {
		return ArrayUtils.toString(values, NullTerminator.STRING_NULL);
	}

	@Override
	public String[] values() {
		return ArrayUtils.clone(values);
	}

	@Override
	public String id() {
		return String.valueOf(hashCode());
	}

	public final void setValues(String[] values) {
		this.values = ArrayUtils.clone(values);
	}

}
