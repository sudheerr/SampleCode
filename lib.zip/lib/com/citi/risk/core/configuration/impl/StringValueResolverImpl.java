package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.PlaceholderResolver;
import com.citi.risk.core.configuration.api.PlaceholderResolverResult;
import com.citi.risk.core.configuration.api.StringValueResolver;
import com.citi.risk.core.ioc.impl.guice.CorePropertiesReader;

import java.net.URL;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class StringValueResolverImpl implements StringValueResolver {
	public static final String DEFAULT_PLACEHOLDER_PREFIX = "${";

	public static final String DEFAULT_PLACEHOLDER_SUFFIX = "}";

	public static final String DEFAULT_VALUE_SEPARATOR = ":";

	protected String placeholderPrefix = DEFAULT_PLACEHOLDER_PREFIX;

	protected String placeholderSuffix = DEFAULT_PLACEHOLDER_SUFFIX;

	protected String valueSeparator = DEFAULT_VALUE_SEPARATOR;

	protected boolean ignoreUnresolvablePlaceholders = true;
	
	private final PropertyPlaceholderHelper helper;

	private final PlaceholderResolver resolver;

	public StringValueResolverImpl(URL currentResourceURL, Map<String, Properties> propMap, Map<String, Set<String>> existingPlaceHolerMapByURL) {
		this.helper = new PropertyPlaceholderHelper(
				placeholderPrefix, placeholderSuffix, valueSeparator, ignoreUnresolvablePlaceholders);
		this.resolver = new PlaceholderResolverImpl(currentResourceURL, propMap, existingPlaceHolerMapByURL);
	}
	
	public StringValueResolverImpl(Map<String, Properties> propMap) {
		this.helper = new PropertyPlaceholderHelper(
				placeholderPrefix, placeholderSuffix, valueSeparator, ignoreUnresolvablePlaceholders);
		this.resolver = new PlaceholderResolverImpl(propMap);
	}

	@Override
	public PlaceholderResolverResult resolveStringValue(String key, String strVal) {
		DefaultPlaceholderResolverResult placeholderResolverResult = new DefaultPlaceholderResolverResult(strVal);
		String value = this.helper.replacePlaceholders(strVal, this.resolver);

		placeholderResolverResult.setResolvedValue(value);
		String keyWithoutEnvInfo = stripPropertEnvInfo(key);
		placeholderResolverResult.setResolvedValueFrom(resolver.getPlaceholder2ValueFromMap().get(keyWithoutEnvInfo));
		return placeholderResolverResult;
	}

	private String stripPropertEnvInfo(String key) {
		int firstDot = key.indexOf(CorePropertiesReader.DOT);
		int secondDot = key.indexOf(CorePropertiesReader.DOT, firstDot + 1);
		int thirdDot = key.indexOf(CorePropertiesReader.DOT, secondDot + 1);

		return key.substring(thirdDot + 1);
	}

}
