package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.ConfigElement;
import com.citi.risk.core.configuration.api.ConfigKey;
import com.citi.risk.core.configuration.api.ConfigValue;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultCreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.TimeMark;

public class DefaultConfigElement implements ConfigElement {

	private static final long serialVersionUID = -5183613295142252330L;

	private ConfigKey key;
	private ConfigValue value;
	private Boolean editable;
	private String propertiesURL;
	private String resolvedValueURL;

	public DefaultConfigElement()
	{
		super();
	}

	public DefaultConfigElement(ConfigKey key, ConfigValue value) {
		this();
		this.key = key;
		this.value = value;
	}

	public DefaultConfigElement(ConfigKey key, ConfigValue value, Boolean editable) {
		this();
		this.key = key;
		this.value = value;
		this.editable = editable;
	}

	@Override
	public ConfigKey key() {
		return key;
	}

	@Override
	public ConfigValue value() {
		return value;
	}

	@Override
	public String getPropertyName() {
		return this.key().property();
	}


	@Override
	public String getPropertyValue() {
		return this.value().value();
	}


	@Override
	public String getLifeCycle() {
		return this.key().getLifeCycleName();
	}

	@Override
	public String getInstance() {
		return this.key().getInstance();
	}


	@Override
	public String getCluster() {
		return this.key().getClusterName();
	}

	@Override
	public Boolean isEditable() {
		return editable;
	}

	@Override
	public String getPropertiesURL() {
		return propertiesURL;
	}

	@Override
	public void setPropertiesURL(String propertiesURL) {
		this.propertiesURL = propertiesURL;
	}

	@Override
	public String getResolvedValueURL() {
		return resolvedValueURL;
	}

	@Override
	public void setResolvedValueURL(String resolvedValueURL) {
		this.resolvedValueURL = resolvedValueURL;
	}

	@Override
	public String getId() {
		return this.key().id();
	}

	public final void setKey(ConfigKey key) {
		this.key = key;
	}

	public final void setValue(ConfigValue value) {
		this.value = value;
	}

	@Override
	public TimeMark getTimeMark() {
		return DefaultTimeMark.NULL;
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		//intentionally-blank override
	}

	@Override
	public CreatedBy getCreatedBy() {
		return DefaultCreatedBy.NULL;
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		//intentionally-blank override
	}

	@Override
	public String getCreatedByString() {
		return DefaultCreatedBy.NULL.getKeyString();
	}

	@Override
	public String getTimeMarkString() {
		return DefaultTimeMark.NULL.getTimeMarkKey();
	}

	@Override
	public void setTimeMarkString(String timeMarkKey) {
		//intentionally-blank override
	}

	@Override
	public void setCreatedByString(String createdByKey) {
		//intentionally-blank override
	}

}
