package com.citi.risk.core.configuration.impl;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Nullable;

import com.citi.risk.core.configuration.api.Cluster;
import com.citi.risk.core.configuration.api.Clusters;
import com.citi.risk.core.configuration.api.Environment;
import com.citi.risk.core.configuration.api.LifeCycle;
import com.citi.risk.core.configuration.api.LifeCycles;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.google.common.base.Enums;
import com.google.common.base.Function;
import com.google.common.base.Objects;
import com.google.common.base.Optional;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterators;
import com.google.common.collect.Sets;
import com.google.inject.Inject;
import com.google.inject.Singleton;

/**
 * Default implementation for environment with
 * <p/>
 * Lifecycle defaulted to Local.
 * Cluster defaulted to Local.
 * Empty default domains.
 * Instance can be any instance.
 */
@Singleton
public class DefaultEnvironment implements Environment {

	public static final String ENV_LIFECYCLE = System.getProperty(Environment.LIFE_CYCLE, LifeCycles.LOCAL.getName());
	public static final String ENV_CLUSTER = System.getProperty(Environment.CLUSTER, Clusters.LOCAL.getName());
	public static final String ENV_DOMAINS = System.getProperty(Environment.DOMAINS, "");
	public static final String ENV_DOMAIN_CLASSES = System.getProperty(Environment.DOMAIN_CLASSES, "");
	public static final String ENV_INSTANCE = System.getProperty(Environment.INSTANCE, "*");

	@Inject
	Logger logger;

	private final String envLifeCycle = ENV_LIFECYCLE;

	private final String envCluster = ENV_CLUSTER;

	private final String envDomains = ENV_DOMAINS;

	private final String envDomainClasses = ENV_DOMAIN_CLASSES;

	@Inject(optional = true)
	private Dictionary dictionary;

	@Inject
	private DictionaryParser dictionaryParser;

	private LifeCycle lifeCycle = null;

	private Cluster cluster = null;

	private Collection<DataDomain<?>> domains = null;

	private String instance;

	public DefaultEnvironment() {
		//intentionally-blank override
	}

	@Override
	public LifeCycle getLifeCycle() {
		if (null == lifeCycle) {
			lifeCycle = createLifeCycle(envLifeCycle);
		}
		return lifeCycle;
	}

	@Override
	public Cluster getCluster() {
		if (null == cluster) {
			cluster = createCluster(envCluster);
		}
		return cluster;
	}

	@Override
	public Collection<DataDomain<?>> getDomains() {
		if (null == domains) {
			domains = createDomains();
		}
		return domains;
	}

	@Override
	public String getInstance() {
		if (null == instance) {
			instance = createInstance();
		}
		return instance;
	}

	private String createInstance() {
		return Strings.isNullOrEmpty(ENV_INSTANCE) ? "*" : ENV_INSTANCE;
	}

	protected Dictionary getDictionary() {
		if (null == dictionary) {
			dictionary = createDictionary();
		}
		return dictionary;
	}

	private Dictionary createDictionary() {
		checkNotNull(envDomainClasses);
		checkNotNull(dictionaryParser);

		Set<String> domainClasses = Sets.newHashSet(Splitter.on(",").trimResults().omitEmptyStrings().split(envDomainClasses));
		List<Class<?>> classes = new ArrayList();
		for (String domainClass : domainClasses) {
			try {
				classes.add(Class.forName(domainClass));
			} catch (ClassNotFoundException e) {
				logger.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		return dictionaryParser.parse(classes);
	}

	protected LifeCycle createLifeCycle(final String name) {
		Optional<LifeCycles> lifeCycleOptional = Enums.getIfPresent(LifeCycles.class, envLifeCycle);
		return lifeCycleOptional.isPresent() ? lifeCycleOptional.get() : new LifeCycle() {

			@Override
			public String getName() {
				return name;
			}
		};
	}

	protected Cluster createCluster(final String name) {
		Optional<Clusters> clusterOptional = Enums.getIfPresent(Clusters.class, envCluster);
		return clusterOptional.isPresent() ? clusterOptional.get() : new Cluster() {

			@Override
			public String getName() {
				return name;
			}
		};
	}

	protected Collection<DataDomain<?>> createDomains() {
		checkNotNull(getDictionary());
		final Set<String> _domains;
		if (envDomains == null) {
			checkNotNull(envDomainClasses);
			final Set<String> domainClasses = Sets.newHashSet(Splitter.on(",").trimResults().omitEmptyStrings().split(envDomainClasses));
			_domains = Sets.newHashSet(Collections2.transform(domainClasses, new Function<String, String>() {

				@Nullable
				@Override
				public String apply(String domainClass) {
					return Iterators.getLast(Splitter.on(".").trimResults().omitEmptyStrings().split(domainClass).iterator());
				}
			}));
		} else {
			_domains = Sets.newHashSet(Splitter.on(",").trimResults().omitEmptyStrings().split(envDomains));
		}
		return getDictionary().getDomains(_domains);
	}

	@Override
	public String toString() {
		return Objects.toStringHelper(this).add("envLifeCycle", envLifeCycle).add("envCluster", envCluster).add("envDomains", envDomains).add("envDomainClasses", envDomainClasses).toString();
	}

	@Override
	public String getShortString() {
		return Objects.toStringHelper(this).add("envLifeCycle", envLifeCycle).add("envCluster", envCluster).add("envInstance", instance).toString();
	}
}
