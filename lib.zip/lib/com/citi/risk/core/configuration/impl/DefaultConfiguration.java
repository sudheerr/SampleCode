package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.*;
import com.citi.risk.core.data.store.api.DataKey;
import com.citi.risk.core.dictionary.api.Criteria;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.select.Select;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;

import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Default implementation for configuration using default environment
 */
@Singleton
public class DefaultConfiguration implements Configuration {

	private static final String SEPARATOR_COMMA = ",";
	private final Environment environment;
	private final org.apache.commons.configuration.Configuration configuration;

	@Inject
	public DefaultConfiguration(Environment environment, org.apache.commons.configuration.Configuration configuration) {
		checkNotNull(environment);
		checkNotNull(configuration);
		this.environment = environment;
		this.configuration = configuration;
	}

	@Override
	public Environment getEnvironment() {
		return environment;
	}

	@Override
	public Collection<String> getPropertyPath(String key) {
		// todo: figure out a way to extract path
		return Collections.emptyList();
	}

	@Override
	public boolean isEmpty() {
		return configuration.isEmpty();
	}

	@Override
	public boolean containsKey(String key) {
		return configuration.containsKey(buildKey(key));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getProperty(String key) {
		return (T) configuration.getProperty(buildKey(key));
	}

	@Override
	public Iterator<String> getKeys() {
		return getKeys(null);
	}

	@Override
	public Iterator<String> getKeys(final String prefix) {
		final Map<String, String> keys = new HashMap();
		final Iterator<String> configKeys = configuration.getKeys();

		while (configKeys.hasNext()) {
			final String fullConfigKey = configKeys.next();
			String configKey = fullConfigKey;
			keys.put(configKey, fullConfigKey);
		}
		return keys.keySet().iterator();
	}

	private String getShortKeys(final String fullConfigKey) {
		String configKey = fullConfigKey;
		if (isCRFDefinedProperty(configKey)) {
			String fullPrefix = Joiner.on(".").skipNulls().join(Joiner.on(".").useForNull("*").join(getLifeCycleName(configKey),getClusterName(configKey), getInstance(configKey)), null);
			configKey = configKey.substring(fullPrefix.length() + 1);
		}
		return configKey;
	}

	private boolean isCRFDefinedProperty(String configKey) {
		boolean isCRFDefinedProperty = false;

		for(LifeCycles lf : LifeCycles.values()) {
			if (configKey.startsWith(lf.getName()) || configKey.startsWith("*")) {
				isCRFDefinedProperty = true;
			}
		}

		return isCRFDefinedProperty;
	}

	public URLPropertiesConfiguration getURLConfiguration() {
		URLPropertiesConfiguration urlConfiguration = new URLPropertiesConfiguration();
		if (configuration instanceof CompositeConfiguration) {
			CompositeConfiguration compositeConfiguration = (CompositeConfiguration)configuration;

			for(int i = 0; i < compositeConfiguration.getNumberOfConfigurations(); i++) {
				if (compositeConfiguration.getConfiguration(i) instanceof URLPropertiesConfiguration) {
					return (URLPropertiesConfiguration)compositeConfiguration.getConfiguration(i);
				}
			}
		}

		return urlConfiguration;
	}


	@Override
	public void addProperty(String key, Object value) {
		configuration.addProperty(buildKey(key), value);
	}

	@Override
	public void setProperty(String key, Object value) {
		configuration.setProperty(buildKey(key), value);
	}

	@Override
	public void setPropertyWithFullKey(String key, Object value) {
		configuration.setProperty(key, value);
	}

	@Override
	public void clearProperty(String key) {
		configuration.clearProperty(buildKey(key));
	}

	@Override
	public void clear() {
		configuration.clear();
	}

	@Override
	public Properties getPrefixProperties(String prefix) {
		return getPrefixProperties(prefix, null);
	}

	@Override
	public Properties getPrefixProperties(String prefix, Properties defaultProperties) {

		Properties properties = null == defaultProperties ? new Properties() : new Properties(defaultProperties);
		String lifeCycle = null;
		String cluster = null;
		String instance = null;

		String propertiesPrefix = Joiner.on(".").skipNulls().join(Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance), prefix);
		buildPrefixProperties(properties, propertiesPrefix);

		lifeCycle = environment.getLifeCycle().getName();
		propertiesPrefix = Joiner.on(".").skipNulls().join(Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance), prefix);
		buildPrefixProperties(properties, propertiesPrefix);

		cluster = environment.getCluster().getName();
		propertiesPrefix = Joiner.on(".").skipNulls().join(Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance), prefix);
		buildPrefixProperties(properties, propertiesPrefix);

		instance = environment.getInstance();
		propertiesPrefix = Joiner.on(".").skipNulls().join(Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance), prefix);
		buildPrefixProperties(properties, propertiesPrefix);

		return properties;
	}

	private void buildPrefixProperties(Properties properties, String propertiesPrefix) {
		Iterator<String> keys = configuration.getKeys(propertiesPrefix);
		while (keys.hasNext()) {
			String key = keys.next();
			String[] values = configuration.getStringArray(key);
			String value = Joiner.on(SEPARATOR_COMMA).join(values);
			properties.put(key.substring(propertiesPrefix.length() + 1), value);
		}
	}

	private String buildKey(String keyName) {
		String lifeCycle = environment.getLifeCycle().getName();
		String cluster = environment.getCluster().getName();
		String instance = environment.getInstance();
		String joinKey = Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance, keyName);
		boolean contains = configuration.containsKey(joinKey);
		if (!contains) {
			instance = null;
			joinKey = Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance, keyName);
			contains = configuration.containsKey(joinKey);
		}
		if (!contains) {
			cluster = null;
			joinKey = Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance, keyName);
			contains = configuration.containsKey(joinKey);
		}
		if (!contains) {
			lifeCycle = null;
			joinKey = Joiner.on(".").useForNull("*").join(lifeCycle, cluster, instance, keyName);
		}
		return joinKey;
	}

	@Override
	public Properties getProperties(String key) {
		return configuration.getProperties(buildKey(key));
	}

	@Override
	public Properties getProperties(String key, Properties defaults) {
		Properties properties = configuration.getProperties(buildKey(key));
		if (null == properties)
			properties = defaults;
		return properties;
	}

	@Override
	public Boolean getBoolean(String key) {
		return configuration.getBoolean(buildKey(key));
	}

	@Override
	public Boolean getBoolean(String key, Boolean defaultValue) {
		return configuration.getBoolean(buildKey(key), defaultValue);
	}

	@Override
	public Byte getByte(String key) {
		return configuration.getByte(buildKey(key));
	}

	@Override
	public Byte getByte(String key, Byte defaultValue) {
		return configuration.getByte(buildKey(key), defaultValue);
	}

	@Override
	public Double getDouble(String key) {
		return configuration.getDouble(buildKey(key));
	}

	@Override
	public Double getDouble(String key, Double defaultValue) {
		return configuration.getDouble(buildKey(key), defaultValue);
	}

	@Override
	public Float getFloat(String key) {
		return configuration.getFloat(buildKey(key));
	}

	@Override
	public Float getFloat(String key, Float defaultValue) {
		return configuration.getFloat(buildKey(key), defaultValue);
	}

	@Override
	public Integer getInt(String key) {
		return configuration.getInt(buildKey(key));
	}

	@Override
	public Integer getInteger(String key, Integer defaultValue) {
		return configuration.getInteger(buildKey(key), defaultValue);
	}

	@Override
	public Long getLong(String key) {
		return configuration.getLong(buildKey(key));
	}

	@Override
	public Long getLong(String key, Long defaultValue) {
		return configuration.getLong(buildKey(key), defaultValue);
	}

	@Override
	public Short getShort(String key) {
		return configuration.getShort(buildKey(key));
	}

	@Override
	public Short getShort(String key, Short defaultValue) {
		return configuration.getShort(buildKey(key), defaultValue);
	}

	@Override
	public BigDecimal getBigDecimal(String key) {
		return configuration.getBigDecimal(buildKey(key));
	}

	@Override
	public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
		return configuration.getBigDecimal(buildKey(key), defaultValue);
	}

	@Override
	public BigInteger getBigInteger(String key) {
		return configuration.getBigInteger(buildKey(key));
	}

	@Override
	public BigInteger getBigInteger(String key, BigInteger defaultValue) {
		return configuration.getBigInteger(buildKey(key), defaultValue);
	}
	
	@Override
	public String getString(String key) {
		if ( !this.containsKey(key) ) 
			return null;
		String[] values = configuration.getStringArray(buildKey(key));
		return Joiner.on(SEPARATOR_COMMA).join(values);
	}

	@Override
	public String getString(String key, String defaultValue) {
		String[] values = configuration.getStringArray(buildKey(key));
		if ( values.length == 0 )
			return defaultValue;		
		return  Joiner.on(SEPARATOR_COMMA).join(values);
	}

	@Override
	public String[] getStringArray(String key) {
		return configuration.getStringArray(buildKey(key));
	}

	private String[] getStringArrayWithFullConfigKey(String key) {
		return configuration.getStringArray(key);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getList(String key) {
		return getList(buildKey(key), (List<T>) Lists.newArrayList());
	}

	@Override
	public <T> List<T> getList(String key, List<T> defaultValue) {
		List<T> values = defaultValue;
		List<Object> list = configuration.getList(buildKey(key));
		if (null != list) {
			values = Lists.transform(list, new Function<Object, T>() {
				@SuppressWarnings("unchecked")
				@Nullable
				@Override
				public T apply(@Nullable Object input) {
					return (T) input;
				}
			});
		}
		return values;
	}

	private String getLifeCycleName(String configKey) {
		if (isCRFDefinedProperty(configKey)) {
			return getConfigKeyParameter(configKey)[0];
		}
		return "";
	}

	private String getClusterName(String configKey) {
		if (isCRFDefinedProperty(configKey)) {
			return getConfigKeyParameter(configKey)[1];
		}
		return "";
	}

	private String getInstance(String configKey) {
		if (isCRFDefinedProperty(configKey)) {
			return getConfigKeyParameter(configKey)[2];
		}
		return "";
	}

	private String[] getConfigKeyParameter(String configKey) {
		String[] keyArray = null;

		if (isCRFDefinedProperty(configKey)) {
			keyArray = configKey.split("\\.");
			if(keyArray.length <3) {
				throw new RuntimeException("Invalid CRF defined configuration!");
			}
		}
		return keyArray;
	}

	@Override
	public <E extends IdentifiedBy<?>> Collection<E> search(DataKey dataKey, Select<E> select) {
		return select.select((Collection<E>) getAll(dataKey.getDomain()));
	}

	@Override
	public <E extends IdentifiedBy<?>> Collection<E> search(DataDomain domain, Select<E> select) {
		return select.select((Collection<E>) getAll(domain));
	}
	
	@Override
	public <E extends IdentifiedBy<?>> Collection<E> select(Criteria<E> criteria, Select<E> specialSelect) {
		DataDomain<E> domain = criteria.getDomain();
        Select<E> select = criteria.getSelect();
        Collection<E> results = search(domain, select);
		return specialSelect.select(results);
	}

	@Override
	public Collection<ConfigElement> getConfigElements() {
		Collection<ConfigElement> toReturn = Lists.<ConfigElement>newArrayList();
		final Iterator<String> keysIterator = getKeys();
		PropertiesConfiguration propertiesConfigurationForURL = getURLConfiguration().getUrlPropertiesConfiguration();
		PropertiesConfiguration configForResolvedValueURL = getURLConfiguration().getValueURLPropertiesConfiguration();
		while(keysIterator.hasNext())
		{
			final String key = keysIterator.next();
			final String[] values = getStringArrayWithFullConfigKey(key);
			final ConfigKey configKey = new DefaultConfigKey(getLifeCycleName(key), getClusterName(key), getInstance(key), getShortKeys(key), key);
			final ConfigValue configValue = new DefaultConfigValue(values);
			final Boolean editable = isCRFDefinedProperty(key);
			ConfigElement configElement = new DefaultConfigElement(configKey, configValue, editable);
			if (propertiesConfigurationForURL.getProperty(key) != null && configForResolvedValueURL.getProperty(key) != null) {
				configElement.setPropertiesURL(propertiesConfigurationForURL.getProperty(key).toString());
				configElement.setResolvedValueURL(configForResolvedValueURL.getProperty(key).toString());
			} else {
				configElement.setPropertiesURL("System Properties");
				configElement.setResolvedValueURL("Resolved by System Properties");
			}
			toReturn.add(configElement);
		}
		return toReturn;
	}


	@Override
	public Collection<ConfigElement> getAll(DataKey dataKey) {
		return getConfigElements();
	}

	@Override
	public Collection<ConfigElement> getAll(DataDomain domain) {
		return getConfigElements();
	}

}
