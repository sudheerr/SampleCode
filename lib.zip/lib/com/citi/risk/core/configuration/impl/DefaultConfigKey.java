package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.ConfigKey;
import com.citi.risk.core.configuration.api.Environment;

public class DefaultConfigKey implements ConfigKey {

	private static final long serialVersionUID = -8883995726413044061L;

	private Environment environment;
	private String lifeCycleName;
	private String clusterName;
	private String instance;
	private String property;
	private String id;

	public DefaultConfigKey() {
		super();
	}

	public DefaultConfigKey(Environment environment, String property) {
		this();
		this.environment = environment;
		this.property = property;
	}

	public DefaultConfigKey(String lifeCycleName, String clusterName, String instance, String property) {
		this();
		this.lifeCycleName = lifeCycleName;
		this.clusterName = clusterName;
		this.instance = instance;
		this.property = property;
	}

	public DefaultConfigKey(String lifeCycleName, String clusterName, String instance, String property, String id) {
		this();
		this.lifeCycleName = lifeCycleName;
		this.clusterName = clusterName;
		this.instance = instance;
		this.property = property;
		this.id = id;
	}

	@Override
	public Environment environment() {
		return environment;
	}

	@Override
	public String getLifeCycleName() {
		return lifeCycleName;
	}

	public void setLifeCycleName(String lifeCycleName) {
		this.lifeCycleName = lifeCycleName;
	}

	@Override
	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	@Override
	public String getInstance() {
		return instance;
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	@Override
	public String property() {
		return property;
	}

	@Override
	public String id() {
		return id;
	}

	public final void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public final void setProperty(String property) {
		this.property = property;
	}

}
