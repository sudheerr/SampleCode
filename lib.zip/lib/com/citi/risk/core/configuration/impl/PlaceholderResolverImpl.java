package com.citi.risk.core.configuration.impl;

import com.citi.risk.core.configuration.api.Environment;
import com.citi.risk.core.configuration.api.LifeCycles;
import com.citi.risk.core.configuration.api.PlaceholderResolver;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.ioc.impl.guice.CorePropertiesReader;
import com.google.common.base.Joiner;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class PlaceholderResolverImpl implements PlaceholderResolver {
	private static final Logger LOGGER = LoggerFactory.getLogger(PlaceholderResolverImpl.class);
	private static final Environment ENVIROMENT = CoreModule.getEnvironment();
	private static final String ENV_INFO = Joiner.on(CorePropertiesReader.SEPARATOR_HASH).join(
					ENVIROMENT.getLifeCycle().getName().toLowerCase()
					, ENVIROMENT.getCluster().getName().toLowerCase()
					, ENVIROMENT.getInstance().toLowerCase());
	
	private URL currentResourceURL;
	private Map<String, Properties> propMap;
	private Map<String, Set<String>> existingPlaceHolerMapByURL;
	private Map<String, String> placeholder2ValueFromMap = new HashMap<>();
	
	public PlaceholderResolverImpl(URL currentResourceURL, Map<String, Properties> propMap, Map<String, Set<String>> existingPlaceHolerMapByURL) {
		this.currentResourceURL = currentResourceURL;
		this.propMap = propMap;
		this.existingPlaceHolerMapByURL = existingPlaceHolerMapByURL;
	}
	
	public PlaceholderResolverImpl(Map<String, Properties> propMap) {
		this.propMap = propMap;
	}

	@Override
	public String resolvePlaceholder(String placeholderName) {
		// if not a real place holder, skip resolving
		if (isARealPlaceHolder(placeholderName)) {
			// valid if exist duplicated place holder in other resource.
			validPlaceHolderAgainstOtherResource(placeholderName);
			
			// start resolving
			Set<Entry<String, Properties>> entrySet = this.propMap.entrySet();
			
			for (Entry<String, Properties> entry : entrySet) {
				Properties properties = entry.getValue();
				if (properties.containsKey(placeholderName)) {
					String value = properties.getProperty(placeholderName);
					LOGGER.debug(placeholderName + " = " + value + " from " + entry.getKey() + " for envInfo " + ENV_INFO);
					placeholder2ValueFromMap.put(placeholderName, entry.getKey());
					return value;
				}
			}
		}
		
		return null;
	}

	@Override
	public Map<String, String> getPlaceholder2ValueFromMap() {
		return placeholder2ValueFromMap;
	}

	/**
	 * eCore allows place holder e.g.
	 * 
	 * DEV.PRIMARY.*.reference-iem.JDBC.schema=${*.*.*.cdmdb.SybaseIQIEMSchema}
	 * UAT.PRIMARY.*.reference-iem.JDBC.schema=${UAT.*.*.cdmdb.SybaseIQIEMSchema}
	 * 
	 * in this case, here to check if a place holder starts with env info or asterisk(*), if yes, it's not a real place holder.
	 * 
	 * @param placeholderName place holder string to check
	 */
	private boolean isARealPlaceHolder(String placeholderName) {
		boolean isHolder = true;
		LifeCycles[] values = LifeCycles.values();
		for (LifeCycles lifeCycles : values) {
			// if a place holder start with env info, then it's not a real place holder
			if (placeholderName.startsWith(lifeCycles.getName())) {
				isHolder = false;
				break;
			}
		}

		// check start with asterisk if not start envInfo
		isHolder = isHolder ? !placeholderName.startsWith(CorePropertiesReader.STAR) : isHolder;
		
		return isHolder;
	}
	
	private void validPlaceHolderAgainstOtherResource(String placeholderName) {
		if (MapUtils.isNotEmpty(existingPlaceHolerMapByURL)) {
			Set<Entry<String, Set<String>>> entrySet = existingPlaceHolerMapByURL.entrySet();
			for (Entry<String, Set<String>> entry : entrySet) {
				String checkingUrl = entry.getKey();
				if (!StringUtils.equals(checkingUrl, currentResourceURL.toString())) {
					// only checking other resource url
					placeHolderValidation(placeholderName, entry, checkingUrl);
				}
			}
			
			// if no duplicated exists, add current placeholder name
			Set<String> placeHolderSet = existingPlaceHolerMapByURL.get(currentResourceURL.toString());
			placeHolderSet.add(placeholderName);
		}
	}

	private void placeHolderValidation(String placeholderName, Entry<String, Set<String>> entry, String checkingUrl) {
		Set<String> placeHolderSet = entry.getValue();
		if (CollectionUtils.isNotEmpty(placeHolderSet) && placeHolderSet.contains(placeholderName)) {
			boolean allowDuplicateProperty = Boolean.parseBoolean(System.getProperty("ecore.config.duplicate", "false"));
			if (allowDuplicateProperty) {
				LOGGER.warn("duplicated place holder name [" + placeholderName + "] in [" + currentResourceURL + ", " + checkingUrl + "]");
			} else {
				throw new RuntimeException("duplicated place holder name [" + placeholderName + "] in [" + currentResourceURL + ", " + checkingUrl + "]");
			}
		}
	}
	
}
