package com.citi.risk.core.configuration.application.impl;

import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.citi.risk.core.clipboard.deleter.RdbmsClipboardDeleter;
import com.citi.risk.core.clipboard.impl.RdbmsClipboardImpl;
import com.citi.risk.core.clipboard.impl.RelationalClipboardService;
import com.citi.risk.core.clipboard.loader.RdbmsClipboardLoader;
import com.citi.risk.core.clipboard.storer.RdbmsClipboardStorer;
import com.citi.risk.core.clipboard.updater.RdbmsClipboardUpdater;
import com.citi.risk.core.configuration.api.BlackList;
import com.citi.risk.core.configuration.api.LifeCycle;
import com.citi.risk.core.configuration.api.LifeCycles;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.google.common.collect.Sets;

public class CoreBlackList implements BlackList {
	private static final String RDBMS_CLIPBOARD_ENABLED = System.getProperty("rdbms.clipboard.enabled", null);
	
	@Override
	public Set<Class> getBlackClass() {
		Set<Class> classes = Sets.<Class>newHashSet();
		if(needFilter()) {
			classes.add(RdbmsClipboardImpl.class);
			classes.add(RdbmsClipboardLoader.class);
			classes.add(RdbmsClipboardStorer.class);
			classes.add(RdbmsClipboardUpdater.class);
			classes.add(RdbmsClipboardDeleter.class);
			classes.add(RelationalClipboardService.class);
		}
		return classes;
	}
	
	private boolean needFilter() {
		Boolean filter;
		if (RDBMS_CLIPBOARD_ENABLED != null) {
			filter = StringUtils.equalsIgnoreCase(RDBMS_CLIPBOARD_ENABLED,"false");
		} else {
			filter = !CoreModule.getConfiguration().getBoolean("rdbms.clipboard.enabled", true);
		}
		return filter;
	}


	@Override
	public LifeCycle[] getAvailableLifeCycles() {
		return new LifeCycle[] {LifeCycles.UAT, LifeCycles.PROD};
	}

}
