package com.citi.risk.core.configuration.application.impl;

import com.citi.risk.core.application.api.ViewConfiguration;
import com.citi.risk.core.application.impl.DefaultView;
import com.citi.risk.core.configuration.api.ConfigElement;
import com.citi.risk.core.configuration.api.Environment;
import com.citi.risk.core.data.query.impl.ManageConfigruationQuery;
import com.citi.risk.core.dictionary.api.DataPath;
import com.google.inject.Inject;

@ViewConfiguration(name = "Configuration", domainClass = ConfigElement.class, tableBasedElementClasses = ConfigurationTableBasedElement.class, queryClass = ManageConfigruationQuery.class)
public class ConfigurationView extends DefaultView {

	@Inject
	Environment enviroment;

	@Override
	public void setDefaultCriteria() {
		DataPath lifeCyclePath = this.getViewContext().getDomain().getItem("Life Cycle").path();
		DataPath ClusterPath = this.getViewContext().getDomain().getItem("Cluster").path();
		DataPath instancePath = this.getViewContext().getDomain().getItem("Instance").path();


		this.setCriteria(lifeCyclePath.likeObjectString(enviroment.getLifeCycle().getName()).
				and(ClusterPath.likeObjectString(enviroment.getCluster().getName()).and(instancePath.likeObjectString(enviroment.getInstance()))));
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}