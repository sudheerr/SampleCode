package com.citi.risk.core.configuration.application.impl;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.risk.core.configuration.api.BlackList;
import com.citi.risk.core.ioc.impl.guice.CoreModule;
import com.citi.risk.core.lang.collection.set.Sets;

public final class BlackListConfiguration {
	private static final Logger LOGGER = LoggerFactory.getLogger(BlackListConfiguration.class);
	private final static BlackListConfiguration INSTANCE = new BlackListConfiguration();
	
	private BlackListConfiguration() {}
	
	public static BlackListConfiguration getInstance() {
		return INSTANCE;
	}
	
	public static synchronized void addBlackListConfig(Class<? extends BlackList> blackListClass) {
		if (!INSTANCE.blackListConfigClass.contains(blackListClass)) {
			INSTANCE.blackListConfigClass.add(blackListClass);
			try {
				BlackList blackList = blackListClass.newInstance();
				if(ArrayUtils.contains(blackList.getAvailableLifeCycles(), CoreModule.getEnvironment().getLifeCycle()) 
						&& CollectionUtils.isNotEmpty(blackList.getBlackClass()) ) {
					INSTANCE.blackListClasses.addAll(blackList.getBlackClass());
				}
			} catch (InstantiationException | IllegalAccessException e) {
				LOGGER.error("failed to newInstance for " + blackListClass.getName(), e);
			}
		}
	}

	private Set<Class> blackListClasses = Sets.newHashSet();
	private Set<Class> blackListConfigClass = Sets.newHashSet();
	
	public Set<Class> getBlackList() {
		return Collections.unmodifiableSet(this.blackListClasses);
	}
	
	public boolean contain(Class klass) {
		return klass == null ? false : blackListClasses.contains(klass);
	}
	
	public boolean contain(Type type) {
		if (Class.class.isInstance(type)) {
			return this.contain((Class)type);
		}
		return false;
	}
	
	public boolean hasBlackList() {
		return blackListClasses != null && !blackListClasses.isEmpty();
	}
	
}
