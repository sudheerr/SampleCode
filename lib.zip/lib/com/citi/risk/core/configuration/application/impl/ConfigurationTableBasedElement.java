package com.citi.risk.core.configuration.application.impl;

import java.util.ArrayList;
import java.util.List;

import com.citi.risk.core.application.api.Navigation;
import com.citi.risk.core.application.impl.DefaultTableBasedElement;
import com.citi.risk.core.application.impl.DownloadExcelNavigation;
import com.citi.risk.core.configuration.api.Configuration;
import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DictionaryParser;
import com.citi.risk.core.dictionary.api.DataPath;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * The Class ConfigruationkTableBasedElement.
 */
public class ConfigurationTableBasedElement extends DefaultTableBasedElement {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Inject
	private Configuration configuration;
	
	@Inject
	private DictionaryParser parser;
	
	@Inject
	@Named("DownloadExcelNavigation")
	private Navigation downloadExcelNavigationItem;

	@Override
	public void updateCell(String key, String updatePathString, Object toValue) {
		Dictionary dictionary = parser.parse(this.getViewContext().getDomain().getDomainClass());
		DataPath path = dictionary.newPath(updatePathString);

		if (!path.isTerminatedWithAnItem() || !path.getTerminatingItem().isEditable()) {
			return;
		}

		String toValueString = toValue.toString();
		int toValueLength = toValueString.length();

		if (toValueString.startsWith("{") && toValueString.endsWith("}")) {
			toValueString = toValueString.substring(1, toValueLength-1);
			String[] toValueArray = toValueString.split(",");
			configuration.setPropertyWithFullKey(key, toValueArray);
		} else {
			configuration.setPropertyWithFullKey(key, toValue);
		}

	}

	@Override
	public List<Navigation> getMenuList() {
		List<Navigation> list = new ArrayList();
		return list;
	}

	@Override
	public List<Navigation> getTableOperatorList() {
		List<Navigation> list = new ArrayList();
		list.add(downloadExcelNavigationItem);
		return list;
	}
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
