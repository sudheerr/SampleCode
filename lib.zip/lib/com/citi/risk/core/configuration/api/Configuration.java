package com.citi.risk.core.configuration.api;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.citi.risk.core.data.query.api.SearchProvider;
import com.citi.risk.core.dictionary.api.DDD;

/**
 * Resolves configuration parameters for the process. Uses Environment as a starting point.
 * Majority of the methods defined in this interface deals with accessing properties
 * of various data types.There is a generic getProperty() method, which returns the value of the
 * queried property in its raw data type.Other getter methods try to convert this raw data type
 * into a specific data type.
 * 
 * For most of the property getter methods an overloaded version exists that allows to specify a default value,
 * which will be returned if the queried property cannot be found in the configuration
 */
@DDD(name="Configuration")
public interface Configuration extends SearchProvider {

	/**
	 * Gets the @Environment associated with this configuration.
	 * @return Environment
	 */
	Environment getEnvironment();

	/**
	 *Gets the property
	 */
	Collection<String> getPropertyPath(String key);

	/**
	 * Check if the configuration is empty.
	 * @return boolean.
	 */
	boolean isEmpty();

	/**
	 * Check if the configuration contains the specified key.
	 * @param key
	 * @return
	 */
	boolean containsKey(String key);

	/**
	 * Add a property to the configuration.
	 * @param key
	 * @param value
	 */
	void addProperty(String key, Object value);

	/**
	 * Set a property,this will replace any previously set values.
	 * @param key
	 * @param value
	 */
	void setProperty(String key, Object value);

	void setPropertyWithFullKey(String key, Object value);
	/**
	 * Remove a property from the configuration.
	 * @param key
	 */
	void clearProperty(String key);

	/**
	 * Remove all properties from the configuration.
	 */
	void clear();

	/**
	 * Gets a property from the configuration.
	 * @param key
	 * @return T
	 */
	<T> T getProperty(String key);

	Iterator<String> getKeys(String prefix);

	/**
	 * Get the list of the keys contained in the configuration.
	 * @return String
	 */
	Iterator<String> getKeys();

	/**
	 * Gets all the properties with the specified prefix.
	 * @param prefix
	 * @return Properties
	 */
	Properties getPrefixProperties(String prefix);

	/**
	 * Gets all the properties associated with the prefix.
	 * @param prefix
	 * @param defaultProperties
	 * @return Properties
	 */
	Properties getPrefixProperties(String prefix, Properties defaultProperties);

	/**
	 * Get a List of properties associated with the given configuration key.
	 * @param key
	 * @return Properties
	 */
	Properties getProperties(String key);

	/**
	 * Get a list of properties associated with the given configuration key if present.
	 * If no properties exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Properties
	 */
	Properties getProperties(String key, Properties defaultValue);

	/**
	 * Get a Boolean associated with the given configuration key.
	 * @param key
	 * @return Boolean
	 */
	Boolean getBoolean(String key);

	/**
	 * Get a Boolean associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Boolean
	 */
	Boolean getBoolean(String key, Boolean defaultValue);

	/**
	 * Get a Byte associated with the given configuration key.
	 * @param key
	 * @return Byte
	 */
	Byte getByte(String key);

	/**
	 * Get a Byte associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Byte
	 */
	Byte getByte(String key, Byte defaultValue);

	/**
	 * Get a Double associated with the given configuration key.
	 * @param key
	 * @return Double
	 */
	Double getDouble(String key);

	/**
	 * Get a Double associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Double
	 */
	Double getDouble(String key, Double defaultValue);

	/**
	 * Get a Float associated with the given configuration key.
	 * @param key
	 * @return Float
	 */
	Float getFloat(String key);

	/**
	 * Get a Float associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @return Float
	 */
	Float getFloat(String key, Float defaultValue);

	/**
	 * Get a Int associated with the given configuration key.
	 * @param key
	 * @return Integer
	 */
	Integer getInt(String key);

	/**
	 * Get a Int associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @return Integer
	 */
	Integer getInteger(String key, Integer defaultValue);

	/**
	 * Get a Long associated with the given configuration key.
	 * @param key
	 * @param defaultValue
	 * @return Long
	 */
	Long getLong(String key);

	/**
	 * Get a Long associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Long
	 */
	Long getLong(String key, Long defaultValue);

	/**
	 * Get a Short associated with the given configuration key.
	 * @param key
	 * @return Short
	 */
	Short getShort(String key);

	/**
	 * Get a Short associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return Short
	 */
	Short getShort(String key, Short defaultValue);

	/**
	 * Get a BigDecimal associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @return BigDecimal
	 */
	BigDecimal getBigDecimal(String key);

	/**
	 * Get a BigDecimal associated with the given configuration key.
	 * @param key
	 * @param defaultValue
	 * @return BigDecimal
	 */
	BigDecimal getBigDecimal(String key, BigDecimal defaultValue);

	/**
	 * Get a BigInteger associated with the given configuration key.
	 * @param key
	 * @return BigInteger
	 */
	BigInteger getBigInteger(String key);

	/**
	 * Get a BigInteger associated with the given configuration key.
	 * @param key
	 * @param defaultValue
	 * @return BigInteger
	 */
	BigInteger getBigInteger(String key, BigInteger defaultValue);

	/**
	 * Get a String associated with the given configuration key.
	 * @param key
	 * @return String
	 */
	String getString(String key);

	/**
	 * Get a String associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return String
	 */
	String getString(String key, String defaultValue);

	/**
	 * Get a String[] associated with the given configuration key.
	 * @param key
	 * @return String[]
	 */
	String[] getStringArray(String key);

	/**
	 * Get a List associated with the given configuration key.
	 * @param key
	 * @return List<>
	 */
	<T> List<T> getList(String key);

	/**
	 * Get a List<> associated with the given configuration key.
	 * If no value exist for the given key defaultValue is returned.
	 * @param key
	 * @param defaultValue
	 * @return List<>
	 */
	<T> List<T> getList(String key, List<T> defaultValue);

	Collection<ConfigElement> getConfigElements();

}
