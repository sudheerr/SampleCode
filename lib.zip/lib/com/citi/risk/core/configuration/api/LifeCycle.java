package com.citi.risk.core.configuration.api;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;

/**
 * LifeCyle holder
 */
@DDD(name="LifeCycle")
public interface LifeCycle {

	/**
	 * Name of the LifeCycle
	 *
	 * @return Name of the LifeCycle
	 */
	@DDI(name = "Name", isKey = true, prominence = Prominence.Low)
	String getName();

}
