package com.citi.risk.core.configuration.api;

import java.util.Set;

public interface BlackList {

	Set<Class> getBlackClass();
	
	LifeCycle[] getAvailableLifeCycles();
	
}
