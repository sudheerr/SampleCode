package com.citi.risk.core.configuration.api;

import com.citi.risk.core.dictionary.api.Dictionary;
import com.citi.risk.core.dictionary.api.DataItem;
import com.citi.risk.core.dictionary.impl.DefaultDataPath;
import com.google.common.base.Function;
import com.google.inject.Inject;
import javax.annotation.Generated;

@Generated(
	value="com.citi.risk.core.dictionary.ui.handlers.PathCodeGen",
	date="2014-09-02T09:49:015+0800",
	comments="@see com.citi.risk.core.configuration.api.ConfigElement"
)
public final class ConfigElementPath {
	private ConfigElementPath() {}

	public static final class Id extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public Id(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Id"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getId();
		}
	}

	public static final class PropertyName extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public PropertyName(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Property Name"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getPropertyName();
		}
	}

	public static final class PropertyValue extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public PropertyValue(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Property Value"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getPropertyValue();
		}
	}

	public static final class LifeCycle extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public LifeCycle(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Life Cycle"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getLifeCycle();
		}
	}

	public static final class Instance extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public Instance(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Instance"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getInstance();
		}
	}

	public static final class Cluster extends DefaultDataPath<ConfigElement, String> implements Function<ConfigElement, String> {
		@Inject
		public Cluster(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Cluster"));
		}

		@Override
		public String apply(ConfigElement input) {
			return input.getCluster();
		}
	}

	public static final class Editable extends DefaultDataPath<ConfigElement, Boolean> implements Function<ConfigElement, Boolean> {
		@Inject
		public Editable(Dictionary dictionary) {
			super((DataItem)dictionary.getDomain(ConfigElement.class).getItem("Is Editable"));
		}

		@Override
		public Boolean apply(ConfigElement input) {
			return input.isEditable();
		}
	}

}