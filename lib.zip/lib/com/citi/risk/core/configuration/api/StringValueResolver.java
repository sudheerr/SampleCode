package com.citi.risk.core.configuration.api;

public interface StringValueResolver {
	PlaceholderResolverResult resolveStringValue(String key, String strVal);
}
