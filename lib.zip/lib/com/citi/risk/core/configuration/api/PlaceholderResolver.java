package com.citi.risk.core.configuration.api;

import java.util.Map;

public interface PlaceholderResolver {
	String resolvePlaceholder(String placeholderName);

	Map<String, String> getPlaceholder2ValueFromMap();
}
