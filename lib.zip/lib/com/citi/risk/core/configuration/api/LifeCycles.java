package com.citi.risk.core.configuration.api;

/**
 * Default LifeCycles available
 *
 * @see LifeCycle
 */
public enum LifeCycles implements LifeCycle {

	PROD,
	QA,
	UAT,
	COB,
	DEV,
    SIT,
	LOCAL;

	@Override
	public String getName() {
		return name();
	}


}
