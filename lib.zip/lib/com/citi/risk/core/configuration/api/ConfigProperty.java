package com.citi.risk.core.configuration.api;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;
import com.citi.risk.core.lang.businessobject.CreatedBy;
import com.citi.risk.core.lang.businessobject.DefaultTimeMark;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;
import com.citi.risk.core.lang.businessobject.NullTerminable;
import com.citi.risk.core.lang.businessobject.NullTerminator;
import com.citi.risk.core.lang.businessobject.TimeMark;

@DDD(name = "ConfigProperty")
public class ConfigProperty implements IdentifiedBy<String>, NullTerminable<ConfigProperty> {

	String propertyName;
	String propertyValue;
	String lifeCycle;
	String category;
	String instance;
	String cluster;
	boolean editable;

	public ConfigProperty(String propertyName, String propertyValue, String lifeCycle, String category, String instance, String cluster,
			boolean editable) {
		this.propertyName = propertyName;
		this.propertyValue = propertyValue;
		this.lifeCycle = lifeCycle;
		this.category = category;
		this.instance = instance;
		this.cluster = cluster;
		this.editable = editable;

	}

	@DDI(name = "Property Name", isEntityName = true, prominence = Prominence.High)
	@Override
	public String key() {
		return propertyName;
	}

	@DDI(name = "Property Value", prominence = Prominence.High)
	public String getPropertyValue() {
		return propertyValue;
	}

	@DDI(name = "Life Cycle", prominence = Prominence.Med)
	public String getLifeCycle() {
		return lifeCycle;
	}

	@DDI(name = "Category", prominence = Prominence.Med)
	public String getCategory() {
		return category;
	}

	@DDI(name = "Instance", prominence = Prominence.Med)
	public String getInstance() {
		return instance;
	}

	@DDI(name = "Cluster", prominence = Prominence.Med)
	public String getCluster() {
		return cluster;
	}

	@DDI(name = "Is Editable", prominence = Prominence.Low)
	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	public void setLifeCycle(String lifeCycle) {
		this.lifeCycle = lifeCycle;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
	}

	@Override
	public TimeMark getTimeMark() {
		return NullTerminator.create(TimeMark.class);
	}

	@Override
	public void setTimeMark(TimeMark timeMark) {
		//intentionally-blank override
	}

	@Override
	public CreatedBy getCreatedBy() {
		return NullTerminator.create(CreatedBy.class);
	}

	@Override
	public void setCreatedBy(CreatedBy createdBy) {
		//intentionally-blank override
	}

	@Override
	public ConfigProperty nullTerminal() {
		return NullTerminator.create(ConfigProperty.class);
	}

	@Override
	public String getCreatedByString() {
		return NullTerminator.create(CreatedBy.class).getKeyString();
	}

	@Override
	public String getTimeMarkString() {
		return NullTerminator.create(TimeMark.class).getTimeMarkKey();
	}

	@Override
	public void setTimeMarkString(String timeMarkKey) {
		//intentionally-blank override
	}


	@Override
	public void setCreatedByString(String createdByKey) {
		//intentionally-blank override
	}

}
