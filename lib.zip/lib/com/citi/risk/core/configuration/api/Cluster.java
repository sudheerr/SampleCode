package com.citi.risk.core.configuration.api;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;

/**
 * Interface to hold the Cluster instance
 */
@DDD(name="Cluster")
public interface Cluster {

	@DDI(name = "Name", isKey = true, prominence = Prominence.Low)
	String getName();

}
