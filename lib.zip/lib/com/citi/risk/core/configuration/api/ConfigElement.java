package com.citi.risk.core.configuration.api;

import java.io.Serializable;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;
import com.citi.risk.core.lang.businessobject.IdentifiedBy;

@DDD(name="Configuration Element")
public interface ConfigElement extends IdentifiedBy<ConfigKey>, Serializable {
	@Override
	public ConfigKey key();

	public ConfigValue value();

	@DDI(name = "Id", isKey = true, prominence = Prominence.Low)
	public String getId();

	@DDI(name = "Property Name", isEntityName = true, prominence = Prominence.High)
	String getPropertyName();

	@DDI(name = "Property Value", editable = true, prominence = Prominence.High)
	String getPropertyValue();

	@DDI(name = "Life Cycle", prominence = Prominence.Med)
	String getLifeCycle();

	@DDI(name = "Instance", prominence = Prominence.Med)
	String getInstance();

	@DDI(name = "Cluster", prominence = Prominence.Med)
	String getCluster();

	@DDI(name = "Is Editable", prominence = Prominence.Low)
	Boolean isEditable();

	@DDI(name = "Properties URL", prominence = Prominence.Low)
	String getPropertiesURL();
	void setPropertiesURL(String propertiesURL);

	@DDI(name = "Resolved Value URL", prominence = Prominence.Med)
	String getResolvedValueURL();
	void setResolvedValueURL(String resolvedValueURL);
}
