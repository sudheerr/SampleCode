package com.citi.risk.core.configuration.api;

import java.io.Serializable;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.DDR;
import com.citi.risk.core.dictionary.api.Prominence;

@DDD(name="Configuration.Key")
public interface ConfigKey extends Serializable {
	@DDR(name = "To Environment", prominence = Prominence.High, endingClass = Environment.class)
	public Environment environment();

	@DDI(name = "Property", prominence = Prominence.High)
	public String property();

	@DDI(name = "Id", isKey = true, prominence = Prominence.Low)
	public String id();

	@DDI(name = "lifeCycle", prominence = Prominence.Med)
	public String getLifeCycleName();

	@DDI(name = "clusterName", prominence = Prominence.Med)
	public String getClusterName();

	@DDI(name = "instance", prominence = Prominence.Med)
	public String getInstance();
}
