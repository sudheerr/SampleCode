package com.citi.risk.core.configuration.api;

import java.io.Serializable;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.Prominence;

@DDD(name="Configuration.Value")
public interface ConfigValue extends Serializable {
	@DDI(name = "isMulti", prominence = Prominence.High)
	public Boolean isMulti();
	
	@DDI(name = "Value", prominence = Prominence.High)
	public String value();
	
	@DDI(name = "Values", prominence = Prominence.High)
	public String[] values();

	@DDI(name = "Id", isKey = true, prominence = Prominence.Low)
	public String id();
}
