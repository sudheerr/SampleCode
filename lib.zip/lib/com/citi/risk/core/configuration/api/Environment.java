package com.citi.risk.core.configuration.api;

import java.util.Collection;

import com.citi.risk.core.dictionary.api.DDD;
import com.citi.risk.core.dictionary.api.DDI;
import com.citi.risk.core.dictionary.api.DDR;
import com.citi.risk.core.dictionary.api.DataDomain;
import com.citi.risk.core.dictionary.api.Prominence;

/**
 * Starting interface for environment. Environment is driven by -D parameters. You specify LifeCycle, Cluster and Domains to load.
 * The defaulting logic is applied if not present
 *
 * @see LifeCycle
 * @see Cluster
 * @see DataDomain
 * @see Clusters
 * @see LifeCycles
 */
@DDD(name="Configuration.Environment")
public interface Environment {

	/**
	 * LifeCycle -D parameter specified via -Denv.lifeCycle=LOCAL etc...
	 *
	 * @see LifeCycle
	 * @see LifeCycles
	 */
	public static final String LIFE_CYCLE = "env.lifeCycle";
	/**
	 * Cluster -D parameter specified via -Denv.cluster=LOCAL etc...
	 *
	 * @see Cluster
	 * @see Clusters
	 */
	public static final String CLUSTER = "env.cluster";
	/**
	 * Domain -D parameter specified via -Denv.domains=Trade,Execution etc... Optional, as it can be resolved by Domain Classes.
	 * Use it only if you want a subset for this particular environment
	 */
	public static final String DOMAINS = "env.domains";
	/**
	 * Domain classes -D parameter specified via -Denv.domainClasses=com.risk.bo.Trade,com.risk.bo.Execution etc...
	 */
	public static final String DOMAIN_CLASSES = "env.domainClasses";

	/**
	 * Instance -D parameters specified via -Denv.instance=TradeExecutionInstance etc...
	 */
	public static final String INSTANCE = "env.instance";

	public static final String PROPERTIES = "env.properties";

	/**
	 * Lifecycle for the environment
	 *
	 * @return Lifecycle for the environment
	 */
	@DDR(name = "To Lifecycle", prominence = Prominence.High, endingClass = LifeCycle.class)
	LifeCycle getLifeCycle();

	/**
	 * Cluster for the environment
	 *
	 * @return Cluster for the environment
	 */
	@DDR(name = "To Cluster", prominence = Prominence.High, endingClass = Cluster.class)
	Cluster getCluster();

	/**
	 * Instance name
	 *
	 * @return Instance name
	 */
	@DDI(name = "Instance", prominence = Prominence.High)
	String getInstance();

	/**
	 * Domains for the environment
	 *
	 * @return Domains for the environment
	 */
	Collection<DataDomain<?>> getDomains();

	@Override
	@DDI(name = "Id", isKey = true, prominence = Prominence.Low)
	String toString();
	
	String getShortString();
}
