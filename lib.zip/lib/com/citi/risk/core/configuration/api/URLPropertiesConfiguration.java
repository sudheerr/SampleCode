package com.citi.risk.core.configuration.api;

import org.apache.commons.configuration.PropertiesConfiguration;

/**
 * Created by lw84456 on 3/21/2016.
 */
public class URLPropertiesConfiguration extends PropertiesConfiguration {
    private PropertiesConfiguration urlPropertiesConfiguration = new PropertiesConfiguration();

    private PropertiesConfiguration valueURLPropertiesConfiguration = new PropertiesConfiguration();

    public PropertiesConfiguration getUrlPropertiesConfiguration() {
        return urlPropertiesConfiguration;
    }

    public PropertiesConfiguration getValueURLPropertiesConfiguration() {
        return valueURLPropertiesConfiguration;
    }
}
