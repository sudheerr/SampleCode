package com.citi.risk.core.configuration.api;

/**
 * Created by lw84456 on 3/22/2016.
 */
public interface PlaceholderResolverResult {
    String getPlaceholderName();

    String getResolvedValue();
    void setResolvedValue(String resolvedValue);

    String getResolvedValueFrom();
    void setResolvedValueFrom(String resolvedValueFrom);

}

