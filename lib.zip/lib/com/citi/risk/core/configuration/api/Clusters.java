package com.citi.risk.core.configuration.api;

/**
 * Enum to hold the available default cluster instances 
 * 
 * @see Cluster
 */
public enum Clusters implements Cluster {

	PRIMARY,
	SECONDARY,
	LOCAL;

	@Override
	public String getName() {
		return name();
	}

}
