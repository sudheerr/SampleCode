package com.citi.risk.core.concurrent.waitable;

import com.citi.risk.core.lang.select.ComparableSelects;

/**
 * @deprecated will Removed. use waitable2 package instead
 */
@Deprecated
public final class WaitableInt extends Waitable<Integer> implements Comparable<WaitableInt> {
	
	private WaitableInt(Integer value) {
		super(value);
		if (!(value instanceof Comparable))
			throw new RuntimeException(value + " need to be comparable");
	}

	public Integer increment(Integer value) {
		getLock().lock();
		try {
			set(get() + value);
			return get();
		} finally {
			getLock().unlock();
		}
	}

	public Integer decrement(Integer value) {
		getLock().lock();
		try {
			set(get() - value);
			return get();
		} finally {
			getLock().unlock();
		}
	}

	public void waitTillEquals(Integer compareValue) throws InterruptedException {
		waitTillTrue(new ComparableSelects.EqualsTo<Integer>(compareValue));
	}

	public void waitTillGreaterThan(Integer compareValue) throws InterruptedException {
		waitTillTrue(new ComparableSelects.GreaterThan<Integer>(compareValue));
	}

	public void waitTillLessThan(Integer compareValue) throws InterruptedException {
		waitTillTrue(new ComparableSelects.LessThan<Integer>(compareValue));
	}


	@Override
	public int compareTo(WaitableInt o) {
		return ((Comparable) this.get()).compareTo((Comparable) o.get());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + get();
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WaitableInt other = (WaitableInt) obj;
		if (get() == null) {
			if (other.get() != null)
				return false;
		} else if (!get().equals(other.get()))
			return false;
		return true;
	}
}
