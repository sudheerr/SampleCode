package com.citi.risk.core.concurrent.waitable;

import com.google.common.base.Predicate;
import com.google.common.collect.Maps;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @deprecated will Removed. use waitable2 package instead
 */
@Deprecated
public class WaitableMap<K, V> extends Waitable<Map<K, V>> implements Map<K, V> {
	private WaitableMap() {
		super(new HashMap<K, V>());
	}

	private WaitableMap(Map<K, V> map) {
		super(Maps.newHashMap(map));
	}

	@Override
	public void clear() {
		getLock().lock();
		try {
			Map<K, V> map = get();
			map.clear();
			set(map);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean containsKey(Object key) {
		getLock().lock();
		try {
			return get().containsKey(key);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean containsValue(Object value) {
		getLock().lock();
		try {
			return get().containsValue(value);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() {
		throw new UnsupportedOperationException();
	}

	@Override
	public V get(Object key) {
		getLock().lock();
		try {
			return get().get(key);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean isEmpty() {
		getLock().lock();
		try {
			return get().isEmpty();
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public Set<K> keySet() {
		throw new UnsupportedOperationException();
	}

	@Override
	public V put(K key, V value) {
		getLock().lock();
		try {
			Map<K, V> map = get();
			map.put(key, value);
			set(map);
			return value;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		getLock().lock();
		try {
			Map<K, V> map = get();
			map.putAll(m);
			set(map);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public V remove(Object key) {
		getLock().lock();
		try {
			Map<K, V> map = get();
			V value = map.remove(key);
			set(map);
			return value;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public int size() {
		getLock().lock();
		try {
			Map<K, V> map = get();
			return map.size();
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public Collection<V> values() {
		throw new UnsupportedOperationException();
	}

	public V getButWaitIfAbsent(final K key) throws InterruptedException {
		waitTillTrue(new Predicate<Map<K, V>>() {
			@Override
			public boolean apply(Map<K, V> arg0) {
				return arg0.containsKey(key);
			}
		});
		return get(key);
	}

	public void waitTillKeyIsPresent(final K key) throws InterruptedException {
		waitTillTrue(new Predicate<Map<K, V>>() {
			@Override
			public boolean apply(Map<K, V> arg0) {
				return arg0.containsKey(key);
			}
		});
	}

	public void waitTillValueIsPresent(final V value) throws InterruptedException {
		waitTillTrue(new Predicate<Map<K, V>>() {
			@Override
			public boolean apply(Map<K, V> arg0) {
				return arg0.containsValue(value);
			}
		});
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((get() == null) ? 0 : get().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WaitableMap<K, V> other = (WaitableMap<K, V>) obj;
		if (get() == null) {
			if (other.get() != null)
				return false;
		} else if (!get().equals(other.get()))
			return false;
		return true;
	}
}
