package com.citi.risk.core.concurrent.waitable;

import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Predicate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @deprecated user Waitable at waitable2 package
 */
@Deprecated
abstract class Waitable<E> {
	private volatile E value;
	private ReentrantLock lock = new ReentrantLock();
	private ConcurrentMap<Predicate<E>, Pair<ReentrantLock, Condition>> lockConditionPairsByPredicates = new ConcurrentHashMap();

	protected Waitable(E value) {
		this.value = value;
	}

	public E get() {
		lock.lock();
		try {
			return value;
		} finally {
			lock.unlock();
		}
	}

	int getNumberOfWaitingPredicates() {
		lock.lock();
		try {
			return lockConditionPairsByPredicates.size();
		} finally {
			lock.unlock();
		}

	}

	public void set(E value) {
		lock.lock();
		try {
			this.value = value;
			reevaluatePredictes();
		} finally {
			lock.unlock();
		}
	}

	protected Lock getLock() {
		return lock;
	}

	protected void waitTillTrue(Predicate<E> predicate) throws InterruptedException {
		lock.lock();
		Pair<ReentrantLock, Condition> lockConditionPair = null;
		try {
			if (predicate.apply(value))
				return;
			ReentrantLock newLock = new ReentrantLock();
			lockConditionPair = new Pair(newLock, newLock.newCondition());
			Pair<ReentrantLock, Condition> anotherLockConditionPair = lockConditionPairsByPredicates.putIfAbsent(predicate, lockConditionPair);
			if (anotherLockConditionPair != null)
				lockConditionPair = anotherLockConditionPair;


			lockConditionPair.getFirst().lock();
			try {
				lock.unlock();
				boolean condition = true;
				do {
					condition = lockConditionPair.getSecond().await(1, TimeUnit.SECONDS);
				} while(!condition);
				
			} finally {
				lockConditionPair.getFirst().unlock();
			}
		} finally {
			if (lock.isHeldByCurrentThread())
				lock.unlock();
		}
	}

	private void reevaluatePredictes() {
		List<Predicate<E>> metPredicates = new ArrayList();
		lock.lock();
		try {
			for (Entry<Predicate<E>, Pair<ReentrantLock, Condition>> predicateEntry : lockConditionPairsByPredicates.entrySet()) {
				if (!predicateEntry.getKey().apply(value))
					continue;

				metPredicates.add(predicateEntry.getKey());
				Pair<ReentrantLock, Condition> predicateConditionPair = predicateEntry.getValue();
				predicateConditionPair.getFirst().lock();
				try {
					predicateConditionPair.getSecond().signalAll();
				} finally {
					predicateConditionPair.getFirst().unlock();
				}
			}
			for (Predicate<E> predicate : metPredicates)
				lockConditionPairsByPredicates.remove(predicate);
		} finally {
			lock.unlock();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Waitable other = (Waitable) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}
}
