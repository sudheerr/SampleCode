package com.citi.risk.core.concurrent.waitable;

import com.citi.risk.core.lang.select.SetSelects;
import com.google.common.collect.Sets;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @deprecated will Removed. use waitable2 package instead
 */
@Deprecated
public final class WaitableSet<E> extends Waitable<Set<E>> implements Set<E> {
	public WaitableSet() {
		super(new HashSet<E>());
	}

	public WaitableSet(E... es) {
		super(Sets.newHashSet(es));
	}

	public WaitableSet(Set<E> set) {
		super(Sets.newHashSet(set));
	}

	@Override
	public int size() {
		getLock().lock();
		try {
			return get().size();
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean isEmpty() {
		getLock().lock();
		try {
			return get().isEmpty();
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean contains(Object paramObject) {
		getLock().lock();
		try {
			return get().contains(paramObject);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public Iterator<E> iterator() {
		throw new UnsupportedOperationException();
	}

	@Override
	public Object[] toArray() {
		getLock().lock();
		try {
			return get().toArray();
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public <T> T[] toArray(T[] paramArrayOfT) {
		getLock().lock();
		try {
			return get().toArray(paramArrayOfT);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean add(E paramE) {
		getLock().lock();
		try {
			if (!get().add(paramE))
				return false;
			set(get());
			return true;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean remove(Object paramObject) {
		getLock().lock();
		try {
			if (!get().remove(paramObject))
				return false;
			set(get());
			return true;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean containsAll(Collection<?> paramCollection) {
		getLock().lock();
		try {
			return get().containsAll(paramCollection);
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean addAll(Collection<? extends E> paramCollection) {
		getLock().lock();
		try {
			if (!get().addAll(paramCollection))
				return false;
			set(get());
			return true;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean retainAll(Collection<?> paramCollection) {
		getLock().lock();
		try {
			if (!get().retainAll(paramCollection))
				return false;
			set(get());
			return true;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public boolean removeAll(Collection<?> paramCollection) {
		getLock().lock();
		try {
			if (!get().removeAll(paramCollection))
				return false;
			set(get());
			return true;
		} finally {
			getLock().unlock();
		}
	}

	@Override
	public void clear() {
		getLock().lock();
		try {
			if (get().size() == 0)
				return;
			get().clear();
			set(get());
		} finally {
			getLock().unlock();
		}
	}

	public void waitTillIsSubSetOf(Set<E> object) throws InterruptedException {
		waitTillTrue(new SetSelects.IsSubSetOf<E, Set<E>>(object));
	}

	public void waitTillIsSuperSetOf(Set<E> object) throws InterruptedException {
		waitTillTrue(new SetSelects.IsSuperSetOf<E, Set<E>>(object));
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((get() == null) ? 0 : get().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WaitableSet<E> other = (WaitableSet<E>) obj;
		if (get() == null) {
			if (other.get() != null)
				return false;
		} else if (!get().equals(other.get()))
			return false;
		return true;
	}
}
