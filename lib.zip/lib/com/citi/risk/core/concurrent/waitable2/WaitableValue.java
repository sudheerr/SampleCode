package com.citi.risk.core.concurrent.waitable2;

import com.citi.risk.core.lang.collection.Pair;
import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

import java.util.Collection;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.collections.CollectionUtils;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/6/13
 * Time: 10:35 AM
 */
public class WaitableValue<V> implements Waitable<V> {

	protected final ListMultimap<Object, Pair<Condition, Predicate<V>>> lockConditions = ArrayListMultimap.create();
	protected final ReentrantLock lock = new ReentrantLock();

	private V value = null;

	public WaitableValue(V value) {
		this.value = value;
	}

	public V get() {
		try {
			lock.lock();
			return value;
		} finally {
			lock.unlock();
		}
	}

	@Override
	public int getNumberOfWaitingPredicates() {
		try {
			lock.lock();
			return lockConditions.size();
		} finally {
			lock.unlock();
		}
	}

	public V modify(Function<V, V> function) {
		try {
			lock.lock();
			return unsafeModify(function, lockConditions.values());
		} finally {
			lock.unlock();
		}
	}

	protected V modify(Object key, Function<V, V> function) {
		try {
			lock.lock();
			V fv;
			if (!lock.equals(key)) unsafeModify(function, lockConditions.get(lock));
			fv = unsafeModify(function, lockConditions.get(key));
			return fv;
		} finally {
			lock.unlock();
		}
	}

	protected V unsafeModify(Function<V, V> function, Collection<Pair<Condition, Predicate<V>>> lockConditions) {
		if (null != function) value = function.apply(value);
		for (Pair<Condition, Predicate<V>> pair : lockConditions) {
			if (pair.getSecond().apply(value)) pair.getFirst().signalAll();
		}
		return value;
	}

	protected <FV> FV apply(Function<V, FV> function) {
		try {
			lock.lock();
			return unsafeApply(function, lockConditions.values());
		} finally {
			lock.unlock();
		}
	}

	protected <FV> FV apply(Object key, Function<V, FV> function) {
		try {
			lock.lock();
			FV fv;
			if (!lock.equals(key)) unsafeApply(function, lockConditions.get(lock));
			fv = unsafeApply(function, lockConditions.get(key));
			return fv;
		} finally {
			lock.unlock();
		}
	}

	protected <FV> FV unsafeApply(Function<V, FV> function, Collection<Pair<Condition, Predicate<V>>> lockConditions) {
		FV fv = null;
		if (null != function) fv = function.apply(value);
		for (Pair<Condition, Predicate<V>> pair : lockConditions) {
			if (pair.getSecond().apply(value)) pair.getFirst().signalAll();
		}
		return fv;
	}

	@Override
	public V waitTill(Predicate<V> condition) throws InterruptedException {
		return waitTill(lock, condition);
	}

	protected V waitTill(Object key, Predicate<V> condition) throws InterruptedException {
		try {
			lock.lock();
			Condition waitCondition = lock.newCondition();
			Pair<Condition, Predicate<V>> conditionPair = new Pair(waitCondition, condition);
			lockConditions.put(key, conditionPair);
			while (!condition.apply(value)) {
				waitCondition.await();
			}
			lockConditions.remove(key, conditionPair);
			if (CollectionUtils.isEmpty(lockConditions.get(key))) {
				lockConditions.removeAll(key);
			}
		} finally {
			lock.unlock();
		}
		return value;
	}
}
