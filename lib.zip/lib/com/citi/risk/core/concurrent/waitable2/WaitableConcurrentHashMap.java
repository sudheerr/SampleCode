package com.citi.risk.core.concurrent.waitable2;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 1/29/13
 * Time: 12:39 PM
 */
public class WaitableConcurrentHashMap<K, V> extends AbstractWaitableConcurrentMap<K, V> implements WaitableMap<K, V> {

	public WaitableConcurrentHashMap() {
		this(new ConcurrentHashMap<K, V>());
	}

	public WaitableConcurrentHashMap(ConcurrentMap<K, V> value) {
		super(value);
	}
}
