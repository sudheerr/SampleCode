package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Function;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/6/13
 * Time: 10:24 AM
 */
public abstract class AbstractWaitableConcurrentMap<K, V> extends AbstractWaitableMap<K, V> implements WaitableConcurrentMap<K, V> {

	public AbstractWaitableConcurrentMap(ConcurrentMap<K, V> value) {
		super(value);
	}

	@Override
	public ConcurrentMap<K, V> get() {
		return (ConcurrentMap<K, V>) super.get();
	}

	@Override
	public V putIfAbsent(final K key, final V value) {
		return apply(key, new Function<Map<K, V>, V>() {
			@Nullable
			@Override
			public V apply(@Nullable Map<K, V> input) {
				return get().putIfAbsent(key, value);
			}
		});
	}

	@Override
	public boolean remove(final Object key, final Object value) {
		return apply(key, new Function<Map<K, V>, Boolean>() {
			@Nullable
			@Override
			public Boolean apply(@Nullable Map<K, V> input) {
				return get().remove(key, value);
			}
		});
	}

	@Override
	public boolean replace(final K key, final V oldValue, final V newValue) {
		return apply(key, new Function<Map<K, V>, Boolean>() {
			@Nullable
			@Override
			public Boolean apply(@Nullable Map<K, V> input) {
				return get().replace(key, oldValue, newValue);
			}
		});
	}

	@Override
	public V replace(final K key, final V value) {
		return apply(key, new Function<Map<K, V>, V>() {
			@Nullable
			@Override
			public V apply(@Nullable Map<K, V> input) {
				return get().replace(key, value);
			}
		});
	}
}
