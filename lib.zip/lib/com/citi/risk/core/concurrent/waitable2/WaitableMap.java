package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Predicate;

import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 1/29/13
 * Time: 12:39 PM
 */
public interface WaitableMap<K, V> extends Map<K, V>, Waitable<Map<K, V>> {

	int getNumberOfWaitingPredicates(K key);

	V getAndWait(Object key) throws InterruptedException;

	V getAndWait(Object key, Predicate<Object> condition) throws InterruptedException;


}
