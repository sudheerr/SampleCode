package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Predicate;

import java.util.Collection;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 1/31/13
 * Time: 11:37 AM
 */
public interface WaitableCollection<V> extends Collection<V>, Waitable<Collection<V>> {

	boolean containsAndWait(V value) throws InterruptedException;

	boolean containsAndWait(Predicate<Object> condition) throws InterruptedException;

}
