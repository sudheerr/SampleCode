package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Predicate;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/6/13
 * Time: 1:08 PM
 */
public interface Waitable<V> {

	int getNumberOfWaitingPredicates();

	V waitTill(Predicate<V> condition) throws InterruptedException;
}
