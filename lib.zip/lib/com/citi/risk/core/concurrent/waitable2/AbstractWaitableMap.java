package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/5/13
 * Time: 3:23 PM
 */
public abstract class AbstractWaitableMap<K, V> extends WaitableValue<Map<K, V>> implements WaitableMap<K, V> {

	public AbstractWaitableMap(Map<K, V> value) {
		super(value);
	}

	@Override
	public int getNumberOfWaitingPredicates(K key) {
		try {
			lock.lock();
			return lockConditions.get(key).size();
		} finally {
			lock.unlock();
		}
	}

	@Override
	public int size() {
		return get().size();
	}

	@Override
	public boolean isEmpty() {
		return get().isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		return get().containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		return get().containsValue(value);
	}

	@Override
	public V get(Object key) {
		return get().get(key);
	}

	@Override
	public V put(final K key, final V value) {
		return apply(key, new Function<Map<K, V>, V>() {
			@Nullable
			@Override
			public V apply(@Nullable Map<K, V> input) {
				return get().put(key, value);
			}
		});
	}

	@Override
	public V remove(final Object key) {
		return apply(key, new Function<Map<K, V>, V>() {
			@SuppressWarnings("SuspiciousMethodCalls")
			@Nullable
			@Override
			public V apply(Map<K, V> input) {
				return get().remove(key);
			}
		});
	}

	@Override
	public void putAll(final Map<? extends K, ? extends V> m) {
		apply(new Function<Map<K, V>, Void>() {
			@Nullable
			@Override
			public Void apply(@Nullable Map<K, V> input) {
				get().putAll(m);
				return null;
			}
		});
	}

	@Override
	public void clear() {
		apply(new Function<Map<K, V>, Void>() {
			@Nullable
			@Override
			public Void apply(@Nullable Map<K, V> input) {
				get().clear();
				return null;
			}
		});
	}

	@Override
	public Set<K> keySet() {
		return get().keySet();
	}

	@Override
	public Collection<V> values() {
		return get().values();
	}

	@Override
	public Set<Entry<K, V>> entrySet() {
		return get().entrySet();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V getAndWait(final Object key) throws InterruptedException {
		return getAndWait(key, Predicates.notNull());
	}

	@SuppressWarnings("SuspiciousMethodCalls")
	@Override
	public V getAndWait(final Object key, final Predicate<Object> condition) throws InterruptedException {
		waitTill(key, new Predicate<Map<K, V>>() {
			@Override
			public boolean apply(Map<K, V> map) {
				return condition.apply(map.get(key));
			}
		});
		return get().get(key);
	}
}
