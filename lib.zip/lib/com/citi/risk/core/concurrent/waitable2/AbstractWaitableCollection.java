package com.citi.risk.core.concurrent.waitable2;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Iterator;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/5/13
 * Time: 4:39 PM
 */
public abstract class AbstractWaitableCollection<V> extends WaitableValue<Collection<V>> implements WaitableCollection<V> {

	public AbstractWaitableCollection(Collection<V> collection) {
		super(collection);
	}

	@Override
	public int size() {
		return get().size();
	}

	@Override
	public boolean isEmpty() {
		return get().isEmpty();
	}

	@Override
	public boolean contains(final Object o) {
		return get().contains(o);
	}

	@Override
	public Iterator<V> iterator() {
		return get().iterator();
	}

	@Override
	public Object[] toArray() {
		return get().toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return get().toArray(a);
	}

	@Override
	public boolean add(final V v) {
		return apply(new Function<Collection<V>, Boolean>() {
			@Nullable
			@Override
			public Boolean apply(@Nullable Collection<V> input) {
				return get().add(v);
			}
		});
	}

	@Override
	public boolean remove(final Object o) {
		return apply(new Function<Collection<V>, Boolean>() {
			@Nullable
			@Override
			public Boolean apply(@Nullable Collection<V> input) {
				return get().remove(o);
			}
		});
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return get().containsAll(c);
	}

	@Override
	public boolean addAll(final Collection<? extends V> c) {
		return apply(new Function<Collection<V>, Boolean>() {
			@Nullable
			@Override
			public Boolean apply(@Nullable Collection<V> input) {
				return get().addAll(c);
			}
		});
	}

	@Override
	public boolean removeAll(final Collection<?> c) {
		return get().removeAll(c);
	}

	@Override
	public boolean retainAll(final Collection<?> c) {
		return get().retainAll(c);
	}

	@Override
	public void clear() {
		get().clear();
	}

	@Override
	public boolean containsAndWait(V value) throws InterruptedException {
		return containsAndWait(Predicates.equalTo((Object) value));
	}

	@Override
	public boolean containsAndWait(final Predicate<Object> condition) throws InterruptedException {
		waitTill(new Predicate<Collection<V>>() {
			@Override
			public boolean apply(@Nullable Collection<V> input) {
				return !Collections2.filter(get(), condition).isEmpty();
			}
		});
		return true;
	}
}
