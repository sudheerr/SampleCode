package com.citi.risk.core.concurrent.waitable2;

import com.google.common.collect.Sets;

import java.util.Collections;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 2/5/13
 * Time: 4:52 PM
 */
public class WaitableConcurrentHashSet<V> extends AbstractWaitableCollection<V> implements Set<V> {

	@SuppressWarnings("unchecked")
	public WaitableConcurrentHashSet() {
		this(Collections.synchronizedSet((Set<V>) Sets.newHashSet()));
	}

	public WaitableConcurrentHashSet(Set<V> from) {
		super(from);
	}
}
