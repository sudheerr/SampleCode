package com.citi.risk.core.concurrent.waitable2;

import java.util.concurrent.ConcurrentMap;

/**
 * Created with IntelliJ IDEA.
 * User: vs39078
 * Date: 1/29/13
 * Time: 12:39 PM
 */
public interface WaitableConcurrentMap<K, V> extends ConcurrentMap<K, V>, WaitableMap<K, V> {

}
